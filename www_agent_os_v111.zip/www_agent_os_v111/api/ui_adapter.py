"""UI 对齐 — Agent 控制台响应格式标准化。

将 Agent OS 的响应格式对齐到 Agent Console UI 规范：
- 响应包含 status / data / meta 三段结构
- 任务进度实时推流
- 文件操作反馈标准化
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class UIEventType(Enum):
    """UI 可消费的事件类型。"""
    TASK_STARTED = "task_started"
    TASK_PROGRESS = "task_progress"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"
    FILE_OPERATION = "file_operation"
    MESSAGE = "message"
    ERROR = "error"
    WARNING = "warning"


@dataclass
class UIEvent:
    """标准化 UI 事件。"""
    type: UIEventType
    data: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        import time
        return {
            "type": self.type.value,
            "data": self.data,
            "timestamp": self.timestamp or time.time(),
        }


class UIResponseFormatter:
    """将内部响应格式化为 Agent Console 标准格式。

    标准响应结构::

        {
            "status": "success" | "error" | "partial",
            "data": { ... },
            "meta": {
                "task_id": "...",
                "duration_ms": 1234,
                "tokens_used": 0
            }
        }
    """

    @staticmethod
    def success(data: Any, meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """成功响应。"""
        return {
            "status": "success",
            "data": data,
            "meta": meta or {},
        }

    @staticmethod
    def error(message: str, code: str = "INTERNAL_ERROR",
              details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """错误响应。"""
        return {
            "status": "error",
            "data": None,
            "meta": {
                "error": {
                    "code": code,
                    "message": message,
                    "details": details or {},
                }
            },
        }

    @staticmethod
    def partial(data: Any, progress: float, meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """部分完成（流式/中间状态）。"""
        m = meta or {}
        m["progress"] = round(progress, 3)
        return {
            "status": "partial",
            "data": data,
            "meta": m,
        }

    @staticmethod
    def stream_event(event: UIEvent) -> str:
        """生成 SSE (Server-Sent Events) 格式字符串。"""
        return f"event: {event.type.value}\ndata: {json.dumps(event.to_dict(), ensure_ascii=False)}\n\n"


class ProgressTracker:
    """任务进度追踪器（供 UI 实时更新）。"""

    def __init__(self, task_id: str, total_steps: int = 0) -> None:
        self.task_id = task_id
        self.total_steps = total_steps
        self.completed_steps = 0
        self.current_step = ""
        self._events: List[UIEvent] = []

    @property
    def progress(self) -> float:
        if self.total_steps == 0:
            return 0.0
        return self.completed_steps / self.total_steps

    def start(self, step_name: str = "") -> UIEvent:
        """标记任务开始。"""
        self.current_step = step_name
        event = UIEvent(
            type=UIEventType.TASK_STARTED,
            data={"task_id": self.task_id, "step": step_name, "total_steps": self.total_steps},
        )
        self._events.append(event)
        return event

    def advance(self, step_name: str = "", delta: int = 1) -> UIEvent:
        """推进步骤。"""
        self.completed_steps += delta
        self.current_step = step_name
        event = UIEvent(
            type=UIEventType.TASK_PROGRESS,
            data={
                "task_id": self.task_id,
                "progress": self.progress,
                "step": step_name,
                "completed": self.completed_steps,
                "total": self.total_steps,
            },
        )
        self._events.append(event)
        return event

    def complete(self, result: Any = None) -> UIEvent:
        """标记任务完成。"""
        self.completed_steps = self.total_steps
        event = UIEvent(
            type=UIEventType.TASK_COMPLETED,
            data={"task_id": self.task_id, "result": result, "progress": 1.0},
        )
        self._events.append(event)
        return event

    def fail(self, error: str) -> UIEvent:
        """标记任务失败。"""
        event = UIEvent(
            type=UIEventType.TASK_FAILED,
            data={"task_id": self.task_id, "error": error},
        )
        self._events.append(event)
        return event

    def get_events(self) -> List[UIEvent]:
        return list(self._events)
