"""
WWW Agent OS v11.0 — HOST 入口（薄门面）

runtime/host.py 是 Engine 的薄门面层，提供：
- CLI 交互入口
- 向后兼容的 HostResult 数据结构
- 简单的模块健康追踪（仅用于日志/展示）

所有核心逻辑在 core/engine.py 中。
不再有 Feature Flag、双轨分支、legacy 回退。
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("HostEntry")

# 确保项目根目录在 sys.path 中
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from core.engine import Engine, EngineResult


# ------------------------------------------------------------------
# 向后兼容的数据结构
# ------------------------------------------------------------------

@dataclass
class HostResult:
    """HOST 调度结果（向后兼容 UI 层）。"""

    reply: str = ""
    persona_id: str = "host"
    persona_name: str = ""
    reasoning: str = ""
    score: dict = field(default_factory=dict)
    sanitizer_findings: list[str] = field(default_factory=list)
    sub_results: list[dict] = field(default_factory=list)
    pending_confirmations: list[dict] = field(default_factory=list)
    elapsed_ms: float = 0.0
    error: Optional[str] = None
    stages: list[str] = field(default_factory=list)
    using_new_path: bool = True  # 始终 True — 不再有旧链路
    active_modules: list[str] = field(default_factory=lambda: ["Engine"])
    fallback_modules: list[str] = field(default_factory=list)

    @classmethod
    def from_engine_result(cls, er: EngineResult) -> "HostResult":
        """从 EngineResult 转换。"""
        return cls(
            reply=er.reply,
            persona_id=er.persona_id,
            persona_name=er.persona_name,
            reasoning=er.reasoning,
            score=er.score,
            sanitizer_findings=er.sanitizer_findings,
            sub_results=er.sub_results,
            pending_confirmations=er.pending_confirmations,
            elapsed_ms=er.elapsed_ms,
            error=er.error,
            stages=er.stages,
        )


# ------------------------------------------------------------------
# HOST 入口
# ------------------------------------------------------------------

class HostEntry:
    """HOST 入口 — Engine 的薄门面。

    提供与旧版 HostEntry 相同的公开接口，内部全部委托给 Engine。
    保留 HealthChecker 用于简单的模块状态追踪（可选）。

    使用方式:
        from runtime.host import HostEntry

        host = HostEntry()
        result = host.process("帮我装个 VS Code")
        print(result.reply)
    """

    def __init__(
        self,
        project_root: Optional[str] = None,
        di_container: Any = None,
        **kwargs,
    ) -> None:
        """
        Args:
            project_root: 项目根目录（None 时自动推断）。
            di_container: DIContainer 实例（None 时 Engine 自行管理）。
            **kwargs: 传递给 Engine 的额外参数（sanitizer, memory_store 等）。
        """
        self._project_root = project_root or str(Path(__file__).resolve().parent.parent)
        self._engine = Engine(
            project_root=self._project_root,
            di_container=di_container,
            **kwargs,
        )
        logger.info("HostEntry 已初始化 (薄门面模式)")

    # ------------------------------------------------------------------
    # 主处理
    # ------------------------------------------------------------------

    def process(
        self,
        user_message: str,
        user_preference: Optional[str] = None,
        progress_callback: Optional[Callable] = None,
    ) -> HostResult:
        """处理用户消息。

        Args:
            user_message: 用户输入文本。
            user_preference: 用户指定的偏好 persona_id（可选）。
            progress_callback: 进度回调。

        Returns:
            HostResult 包含回复和元信息。
        """
        er = self._engine.process(user_message, user_preference, progress_callback)
        return HostResult.from_engine_result(er)

    # ------------------------------------------------------------------
    # 状态查询（委托给 Engine）
    # ------------------------------------------------------------------

    def get_status_report(self) -> str:
        """获取系统状态报告。"""
        return self._engine.get_status_report()

    def get_health_report(self) -> Dict[str, Any]:
        """获取模块健康报告（简化版）。"""
        return {
            "engine": {"healthy": True, "error_count": 0},
            "note": "v11.0 统一架构 — 不再需要模块级健康检查",
        }

    def get_feature_flags_report(self) -> str:
        """Feature Flag 报告（v11.0 中已废弃）。"""
        return (
            "| Flag | Value |\n|------|-------|\n"
            "| USE_NEW_ARCH | ✓ (已废弃 — 统一架构) |\n"
            "| USE_NEW_HOST | ✓ (已废弃 — 统一架构) |\n"
            "| USE_INPUT_SANITIZER | ✓ (已废弃 — 始终启用) |\n"
            "| USE_PERSONA_MANAGER | ✓ (已废弃 — 始终启用) |\n"
            "| USE_MODEL_GATEWAY | ✓ (已废弃 — 始终启用) |\n"
            "| USE_MEMORY_STORE | ✓ (已废弃 — 始终启用) |\n"
        )

    def get_switch_log(self, limit: int = 50) -> list[dict]:
        """切换日志（v11.0 中不再有切换）。"""
        return [{"note": "v11.0 统一架构 — 不再有新旧链路切换"}]

    def reset_all_health(self) -> None:
        """重置健康状态（空操作）。"""
        logger.info("健康重置请求 — v11.0 统一架构无需重置")

    def has_pending_confirmations(self) -> bool:
        """检查是否有待处理确认请求。"""
        return self._engine.has_pending_confirmations()

    def get_pending_confirmations(self) -> list[dict]:
        """获取待处理确认请求。"""
        return self._engine.get_pending_confirmations()

    def check_all_models(self, progress_callback: Callable = None) -> None:
        """检查所有模型在线状态。"""
        self._engine.check_all_models(progress_callback)

    def shutdown(self) -> None:
        """关闭系统，保存所有状态。"""
        self._engine.shutdown()

    # ------------------------------------------------------------------
    # 直接访问 Engine（高级用法）
    # ------------------------------------------------------------------

    @property
    def engine(self) -> Engine:
        """获取底层 Engine 实例。"""
        return self._engine


# ------------------------------------------------------------------
# 交互式 CLI 入口
# ------------------------------------------------------------------

def _print_banner() -> None:
    print()
    print("=" * 56)
    print("  WWW Agent OS  -  Multi-Persona Collaboration System")
    print("  Version 11.0 (Unified Architecture)")
    print("=" * 56)
    print()


def _print_help() -> None:
    print()
    print("Commands:")
    print("  /help       - Show this help")
    print("  /status     - Show system status")
    print("  /health     - Show module health")
    print("  /models     - Check all models")
    print("  /confirm    - Show pending confirmations")
    print("  /exit, /quit - Exit")
    print("  <anything>  - Send message to Engine.process()")
    print()


def _interactive_loop(host: "HostEntry") -> None:
    _print_banner()
    print("Type /help for available commands, or just type a message.\n")

    while True:
        try:
            user_input = input("You > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_input:
            continue

        cmd = user_input.lower()

        if cmd in ("/exit", "/quit", "/q"):
            host.shutdown()
            print("Goodbye.")
            break

        if cmd == "/help":
            _print_help()
            continue

        if cmd == "/status":
            print(host.get_status_report())
            continue

        if cmd == "/health":
            print(json.dumps(host.get_health_report(), indent=2, ensure_ascii=False))
            continue

        if cmd == "/models":
            print("Checking models...")
            host.check_all_models(lambda pid, done, total: print(f"  [{done}/{total}] {pid}"))
            print("\n" + host.get_status_report())
            continue

        if cmd == "/confirm":
            confirmations = host.get_pending_confirmations()
            if not confirmations:
                print("(no pending confirmations)")
            else:
                for cfm in confirmations:
                    print(f"  {cfm['cfm_id']} ({cfm['persona_name']}): "
                          f"{cfm['fields'].get('description', 'N/A')}")
            continue

        if cmd.startswith("/"):
            print(f"Unknown command: {user_input}. Type /help for available commands.")
            continue

        # 普通消息
        print()
        result = host.process(user_input)
        if result.error:
            print(f"[ERROR] {result.error}")
        else:
            print(f"[{result.persona_name}] {result.reply}")
        print(f"(elapsed: {result.elapsed_ms:.0f}ms | persona: {result.persona_id} "
              f"| stages: {'→'.join(result.stages)})")
        print()


def main() -> None:
    """CLI 入口。"""
    import argparse

    parser = argparse.ArgumentParser(
        description="WWW Agent OS - Multi-Persona Collaboration System"
    )
    parser.add_argument(
        "--project-root", default=None,
        help="Project root directory (default: auto-detect)",
    )
    parser.add_argument("--version", "-V", action="store_true", help="Print version and exit")
    args = parser.parse_args()

    if args.version:
        print("WWW Agent OS 11.0 (Unified Architecture)")
        return

    project_root = args.project_root or str(Path(__file__).resolve().parent.parent)
    print(f"[INFO] Project root: {project_root}")

    try:
        host = HostEntry(project_root=project_root)
    except Exception as e:
        print(f"[FATAL] Failed to initialize: {e}")
        traceback.print_exc()
        sys.exit(1)

    _interactive_loop(host)


if __name__ == "__main__":
    main()
