"""
EventBus — 发布/订阅事件总线

支持：
- 同步事件发布
- 通配符订阅（如 'task.*' 匹配 'task.created'）
- 事件类型预定义常量
- 线程安全

版本: 1.0.0
"""

from __future__ import annotations

import fnmatch
import logging
import os
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Union

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# 事件类型定义
# ------------------------------------------------------------------

class EventType(str, Enum):
    """预定义事件类型（技术文档定义 50 种事件类型）。"""

    # ── Persona 生命周期事件（第2章 2.4） ──
    PERSONA_CREATED = "persona.created"
    PERSONA_INSTALLED = "persona.installed"
    PERSONA_LOADED = "persona.loaded"
    PERSONA_REGISTERED = "persona.registered"
    PERSONA_ACTIVATED = "persona.activated"
    PERSONA_DEACTIVATED = "persona.deactivated"
    PERSONA_SLEEP = "persona.sleep"
    PERSONA_WAKE = "persona.wake"
    PERSONA_ARCHIVED = "persona.archived"
    PERSONA_RESTORED = "persona.restored"
    PERSONA_UPGRADED = "persona.upgraded"
    PERSONA_SPLIT = "persona.split"
    PERSONA_MERGED = "persona.merged"
    PERSONA_DESTROYED = "persona.destroyed"
    PERSONA_TERMINATED = "persona.terminated"
    PERSONA_ERROR = "persona.error"
    PERSONA_HEALTH_CHECK = "persona.health_check"
    PERSONA_LIFECYCLE = "persona.lifecycle"

    # ── Task 管理事件 ──
    TASK_CREATED = "task.created"
    TASK_QUEUED = "task.queued"
    TASK_DISPATCHED = "task.dispatched"
    TASK_STARTED = "task.started"
    TASK_PROGRESS = "task.progress"
    TASK_COMPLETED = "task.completed"
    TASK_FAILED = "task.failed"
    TASK_RETRY = "task.retry"
    TASK_CANCELLED = "task.cancelled"
    TASK_TIMEOUT = "task.timeout"

    # ── Tool 路由事件 ──
    TOOL_REGISTERED = "tool.registered"
    TOOL_UNREGISTERED = "tool.unregistered"
    TOOL_INVOKED = "tool.invoked"
    TOOL_COMPLETED = "tool.completed"
    TOOL_ERROR = "tool.error"
    TOOL_TIMEOUT = "tool.timeout"

    # ── Model Gateway 事件 ──
    MODEL_REQUESTED = "model.requested"
    MODEL_RESPONDED = "model.responded"
    MODEL_STREAM_START = "model.stream_start"
    MODEL_STREAM_CHUNK = "model.stream_chunk"
    MODEL_STREAM_END = "model.stream_end"
    MODEL_ERROR = "model.error"
    MODEL_TIMEOUT = "model.timeout"

    # ── Memory Store 事件 ──
    MEMORY_ALLOCATED = "memory.allocated"
    MEMORY_STORED = "memory.stored"
    MEMORY_RETRIEVED = "memory.retrieved"
    MEMORY_UPDATED = "memory.updated"
    MEMORY_EXPIRED = "memory.expired"
    MEMORY_COMPACTED = "memory.compacted"
    MEMORY_CLEARED = "memory.cleared"

    # ── 系统级事件 ──
    SYSTEM_STARTUP = "system.startup"
    SYSTEM_SHUTDOWN = "system.shutdown"
    SYSTEM_HEARTBEAT = "system.heartbeat"
    ERROR_OCCURRED = "error.occurred"
    CONFIG_CHANGED = "config.changed"


# ------------------------------------------------------------------
# Event 数据类
# ------------------------------------------------------------------

@dataclass
class Event:
    """事件对象（Event Envelope）。

    技术文档要求的 12 字段完整事件信封：
    - event_id: UUIDv4 唯一标识
    - event_type (type): 事件类型标识
    - event_version: 事件 schema 版本号
    - timestamp: ISO 8601 时间戳
    - source: 源模块/组件名
    - actor: 触发者标识（用户/系统/管理员）
    - correlation_id: 关联 ID，串联同一业务流程
    - causation_id: 因果 ID，指向触发本事件的上一事件
    - payload (data): 事件负载数据
    - metadata: 扩展元数据（含 trace_id、retry_count 等）
    - signature: Ed25519 签名（预留）
    - ttl: 生存时间（秒），过期事件可被丢弃

    Attributes:
        type: 事件类型（EventType 或字符串）。
        source: 事件来源模块名，如 'task.manager'。
        data: 事件携带的任意负载数据。
        timestamp: 事件发生时间（UTC）。
        event_id: 事件唯一 ID（UUIDv4 短格式）。
        event_version: 事件 schema 版本号，默认 1。
        actor: 触发者标识。
        correlation_id: 关联 ID，串联同一业务流程。
        causation_id: 因果 ID，指向触发本事件的上游事件。
        metadata: 扩展元数据（trace_id、retry_count 等）。
        signature: Ed25519 签名（预留字段）。
        ttl: 生存时间（秒），0 表示不过期。
    """

    type: Union[EventType, str]
    source: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    event_id: str = ""
    event_version: int = 1
    actor: str = ""
    correlation_id: str = ""
    causation_id: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    signature: str = ""
    ttl: int = 0

    def __post_init__(self) -> None:
        if not self.event_id:
            self.event_id = uuid.uuid4().hex[:12]
        if self.correlation_id == "" and "_trace_id" not in self.metadata:
            self.metadata["_trace_id"] = uuid.uuid4().hex[:12]

    def is_expired(self) -> bool:
        """检查事件是否已过期。"""
        if self.ttl <= 0:
            return False
        elapsed = (datetime.now(timezone.utc) - self.timestamp).total_seconds()
        return elapsed > self.ttl

    def with_causation(self, event_id: str) -> "Event":
        """设置因果链，返回自身（链式调用）。"""
        self.causation_id = event_id
        return self


# 回调类型定义
EventHandler = Callable[[Event], None]


# ------------------------------------------------------------------
# EventBus
# ------------------------------------------------------------------

class EventBus:
    """发布/订阅事件总线。

    特性：
    - 通配符订阅：'task.*' 匹配 'task.created', 'task.completed' 等。
    - 线程安全：使用 reentrant lock 保护订阅表。
    - 异常隔离：单个处理器异常不影响其他处理器。

    Usage::

        bus = EventBus()

        @bus.on("task.*")
        def on_task(event: Event):
            print(f"Task event: {event.type}")

        bus.emit(Event(type=EventType.TASK_CREATED, data={"task_id": "123"}))
    """

    def __init__(self, name: str = "default") -> None:
        """初始化 EventBus。

        Args:
            name: 总线名称（用于日志标识）。
        """
        self.name = name
        self._subscribers: Dict[str, List[EventHandler]] = {}
        self._lock = threading.RLock()
        self._event_count: int = 0
        self._dlq: Optional[Any] = None  # DeadLetterQueue 实例（延迟导入避免循环）
        self._dead_letter_queue: list[dict] = []  # 后备内存 DLQ（DLQ 未配置时使用）
        self._event_log_path: str = ""  # 事件日志持久化路径
        logger.debug("EventBus '%s' 已创建", name)

    def enable_dlq(self, storage_dir: str = "", max_retries: int = 3) -> None:
        """启用 DeadLetterQueue 集成。

        启用后，处理器异常事件将推入 DeadLetterQueue（持久化 + 可重试），
        替代后备内存队列。

        Args:
            storage_dir: DLQ 存储目录。
            max_retries: 最大重试次数。
        """
        from events.dead_letter_queue import DeadLetterQueue
        self._dlq = DeadLetterQueue(
            storage_dir=storage_dir or "data/dlq",
            max_retries=max_retries,
        )
        logger.info("EventBus[%s] DLQ 已启用: dir=%s", self.name, self._dlq._storage_dir)

    def enable_persistence(self, log_dir: str) -> None:
        """M09修复：启用事件日志持久化（JSONL 格式）。"""
        os.makedirs(log_dir, exist_ok=True)
        self._event_log_path = os.path.join(log_dir, "events.jsonl")

    def _persist_event(self, event_type: str, data: dict) -> None:
        """M09修复：将事件追加到持久化日志。"""
        if not self._event_log_path:
            return
        try:
            import json as _json
            entry = {"ts": datetime.now(timezone.utc).isoformat(), "type": event_type, "data": data}
            with open(self._event_log_path, "a", encoding="utf-8") as f:
                f.write(_json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def _handle_dead_letter(self, event: Event, handler_name: str, error: str) -> None:
        """异常事件入死信队列。

        优先使用 DeadLetterQueue（持久化 + 可重试），
        未配置时退回内存队列。
        """
        if self._dlq is not None:
            # 使用完整 DeadLetterQueue 模块
            self._dlq.push(event, error=error, handler_name=handler_name)
            return

        # 后备：内存队列
        event_type = event.type if isinstance(event.type, str) else event.type.value
        self._dead_letter_queue.append({
            "ts": datetime.now(timezone.utc).isoformat(),
            "event_id": event.event_id,
            "event": event_type,
            "handler": handler_name,
            "error": error[:500],
        })
        if len(self._dead_letter_queue) > 100:
            self._dead_letter_queue = self._dead_letter_queue[-50:]

    def get_dead_letters(self, limit: int = 20) -> list[dict]:
        """获取最近死信事件。

        Returns:
            死信列表（字典格式）。
        """
        if self._dlq is not None:
            # 从 DeadLetterQueue 获取
            all_dl = self._dlq.list_all()[:limit]
            return [
                {
                    "ts": dl.failed_at.isoformat(),
                    "event_id": dl.event.event_id if dl.event else "",
                    "event": self._dlq._event_type(dl.event) if dl.event else "unknown",
                    "handler": dl.handler_name,
                    "error": dl.error[:500],
                    "status": dl.status.value,
                    "retry_count": dl.retry_count,
                }
                for dl in all_dl
            ]
        return self._dead_letter_queue[-limit:]

    def retry_dead_letters(self) -> dict[str, int]:
        """重试所有待处理死信（需要启用 DLQ）。

        Returns:
            {'replayed': N, 'failed': M, 'skipped': K}，未启用 DLQ 时返回空统计。
        """
        if self._dlq is not None:
            return self._dlq.retry_pending(self)
        return {"replayed": 0, "failed": 0, "skipped": 0}

    # ------------------------------------------------------------------
    # 订阅
    # ------------------------------------------------------------------

    def subscribe(self, event_pattern: str, handler: EventHandler) -> None:
        """订阅事件。

        Args:
            event_pattern: 事件类型或通配符模式，如 'task.*'。
            handler: 事件处理回调函数，接收 Event 对象。
        """
        with self._lock:
            if event_pattern not in self._subscribers:
                self._subscribers[event_pattern] = []
            if handler not in self._subscribers[event_pattern]:
                self._subscribers[event_pattern].append(handler)
                logger.debug("EventBus[%s] 订阅: %s → %s", self.name, event_pattern, handler.__name__)

    def unsubscribe(self, event_pattern: str, handler: EventHandler) -> bool:
        """取消订阅。

        Args:
            event_pattern: 事件模式。
            handler: 要移除的处理函数。

        Returns:
            是否成功取消订阅。
        """
        with self._lock:
            if event_pattern in self._subscribers:
                handlers = self._subscribers[event_pattern]
                if handler in handlers:
                    handlers.remove(handler)
                    if not handlers:
                        del self._subscribers[event_pattern]
                    return True
            return False

    def on(self, event_pattern: str) -> Callable[[EventHandler], EventHandler]:
        """装饰器方式订阅。

        Usage::

            @bus.on("task.*")
            def handle_task(event: Event):
                ...
        """
        def decorator(handler: EventHandler) -> EventHandler:
            self.subscribe(event_pattern, handler)
            return handler
        return decorator

    # ------------------------------------------------------------------
    # 发布
    # ------------------------------------------------------------------

    def emit(self, event: Event) -> int:
        """发布事件，同步调用所有匹配的处理器。

        Args:
            event: 事件对象。

        Returns:
            被调用的处理器数量。
        """
        event_type = event.type if isinstance(event.type, str) else event.type.value

        # 收集匹配的处理器（在锁内读取副本，释放锁后调用以避死锁）
        with self._lock:
            matched: List[EventHandler] = []
            for pattern, handlers in self._subscribers.items():
                if self._match_pattern(pattern, event_type):
                    matched.extend(handlers)
            # P1修复：_event_count 在锁内自增
            self._event_count += 1

        called = 0
        for handler in matched:
            try:
                handler(event)
                called += 1
            except Exception as exc:
                logger.error(
                    "EventBus[%s] 处理器 '%s' 处理事件 '%s' 时异常: %s",
                    self.name, handler.__name__, event_type, exc,
                )
                # 异常事件写入死信队列（传递完整 Event 对象）
                self._handle_dead_letter(event, handler.__name__, str(exc))

        # M09修复：持久化事件日志
        self._persist_event(event_type, event.data)

        return called

    def emit_async(self, event: Event) -> int:
        """异步发布事件（通过新线程）。

        Args:
            event: 事件对象。

        Returns:
            预期触发的处理器数量（基于当前订阅表，实际执行在线程内完成）。
        """
        event_type = event.type if isinstance(event.type, str) else event.type.value

        # 先计算匹配的处理器数量（在锁内）
        with self._lock:
            matched_count = 0
            for pattern in self._subscribers:
                if self._match_pattern(pattern, event_type):
                    matched_count += len(self._subscribers[pattern])

        def _run() -> None:
            self.emit(event)

        thread = threading.Thread(target=_run, daemon=True, name=f"eb-{event.type}")
        thread.start()
        return matched_count

    # ------------------------------------------------------------------
    # 通配符匹配
    # ------------------------------------------------------------------

    @staticmethod
    def _match_pattern(pattern: str, event_type: str) -> bool:
        """检查事件类型是否匹配订阅模式。

        支持 * 通配符：
        - 'task.*' 匹配 'task.created', 'task.completed' 等。
        - '*' 匹配所有事件。
        - 'task.created' 精确匹配。

        Args:
            pattern: 订阅模式。
            event_type: 实际事件类型。

        Returns:
            是否匹配。
        """
        if pattern == "*":
            return True
        if pattern == event_type:
            return True
        if "*" in pattern:
            return fnmatch.fnmatch(event_type, pattern)
        return False

    # ------------------------------------------------------------------
    # 统计与诊断
    # ------------------------------------------------------------------

    @property
    def subscriber_count(self) -> int:
        """活跃订阅模式数量。"""
        with self._lock:
            return len(self._subscribers)

    @property
    def event_count(self) -> int:
        """已发布事件总数。"""
        with self._lock:
            return self._event_count

    def list_subscribers(self) -> Dict[str, List[str]]:
        """列出所有订阅模式及其处理器名称。

        Returns:
            {pattern: [handler_name, ...]}。
        """
        with self._lock:
            return {
                pattern: [h.__name__ for h in handlers]
                for pattern, handlers in self._subscribers.items()
            }

    def clear(self) -> None:
        """清除所有订阅。"""
        with self._lock:
            self._subscribers.clear()
            self._event_count = 0
            logger.info("EventBus[%s] 已清除所有订阅", self.name)


# ------------------------------------------------------------------
# 全局默认 EventBus 实例（向后兼容，推荐使用 DIContainer）
# ------------------------------------------------------------------

_default_bus: Optional[EventBus] = None
_default_bus_lock = threading.Lock()


def get_default_bus() -> EventBus:
    """获取全局默认 EventBus 单例。

    .. deprecated::
        推荐通过 DIContainer.get('bus') 获取 EventBus 实例。
        此函数保留用于向后兼容和独立模块测试。
    """
    global _default_bus
    if _default_bus is None:
        with _default_bus_lock:
            if _default_bus is None:
                _default_bus = EventBus(name="global")
    return _default_bus


def set_default_bus(bus: EventBus) -> None:
    """设置全局默认 EventBus 实例（供 DIContainer 注入）。

    Args:
        bus: 要设为全局默认的 EventBus 实例。
    """
    global _default_bus
    with _default_bus_lock:
        _default_bus = bus
