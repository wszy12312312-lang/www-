"""
OllamaProvider — 本地 Ollama API Provider

封装 Ollama HTTP API，支持：
- /api/chat 同步 + 流式
- /api/generate 兼容模式
- 健康检查
- Bearer Token / Basic Auth 认证
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, Generator, List, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from models.provider.base import (
    ChatMessage,
    GenerationConfig,
    ModelResponse,
    ProviderInterface,
)

logger = logging.getLogger(__name__)

DEFAULT_OLLAMA_HOST = "http://localhost:11434"


class OllamaProvider(ProviderInterface):
    """Ollama API Provider。

    Usage::

        provider = OllamaProvider(host="http://localhost:11434")
        resp = provider.chat("qwen2.5:7b", [ChatMessage("user", "Hello")])
        print(resp.content)
    """

    provider_name = "ollama"
    provider_version = "1.0.0"

    def __init__(
        self,
        host: str = "",
        api_key: str = "",
        api_user: str = "",
        api_password: str = "",
        timeout: int = 120,
        max_retries: int = 2,
    ) -> None:
        self.host = host.rstrip("/") if host else DEFAULT_OLLAMA_HOST
        self.timeout = timeout
        self.max_retries = max_retries

        self._api_key = api_key
        self._api_user = api_user
        self._api_password = api_password

        self._session = requests.Session()
        self._session.trust_env = False

        # 认证头
        self._auth_headers: Dict[str, str] = {}
        if api_key:
            self._auth_headers["Authorization"] = f"Bearer {api_key}"
        elif api_user and api_password:
            import base64
            creds = base64.b64encode(f"{api_user}:{api_password}".encode()).decode()
            self._auth_headers["Authorization"] = f"Basic {creds}"

        # 重试策略
        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=1.0,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=4, pool_maxsize=8)
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)

    def _request(self, method: str, path: str, json_data: Optional[Dict] = None,
                 timeout: Optional[int] = None, stream: bool = False) -> requests.Response:
        url = f"{self.host}{path}"
        if timeout is None:
            timeout = self.timeout
        if stream:
            timeout = max(timeout, 300)
        return self._session.request(
            method=method, url=url, json=json_data,
            headers=self._auth_headers, timeout=timeout, stream=stream,
        )

    def chat(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        timeout: Optional[int] = None,
    ) -> ModelResponse:
        body: Dict[str, Any] = {"model": model, "messages": [], "stream": False}
        if system:
            body["messages"].append({"role": "system", "content": system})
        for msg in messages:
            body["messages"].append(msg.to_dict())
        if config:
            body["options"] = {
                "temperature": config.temperature,
                "top_p": config.top_p,
                "top_k": config.top_k,
                "repeat_penalty": config.repeat_penalty,
                "seed": config.seed if config.seed != 0 else None,
            }
            if config.max_tokens > 0:
                body["options"]["num_predict"] = config.max_tokens

        t0 = time.perf_counter()
        try:
            resp = self._request("POST", "/api/chat", json_data=body, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
            msg = data.get("message", {})
            t1 = time.perf_counter()
            return ModelResponse(
                content=msg.get("content", ""),
                reasoning=msg.get("reasoning_content", "") or msg.get("thinking", ""),
                model=data.get("model", model),
                done=data.get("done", True),
                total_duration_ms=(t1 - t0) * 1000,
                eval_count=data.get("eval_count", 0),
            )
        except requests.RequestException as e:
            elapsed = (time.perf_counter() - t0) * 1000
            return ModelResponse(error=f"[{model}] API 异常: {e}", model=model, total_duration_ms=elapsed)

    def chat_stream(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
    ) -> Generator[str, None, None]:
        body: Dict[str, Any] = {"model": model, "messages": [], "stream": True}
        if system:
            body["messages"].append({"role": "system", "content": system})
        for msg in messages:
            body["messages"].append(msg.to_dict())
        if config:
            body["options"] = {
                "temperature": config.temperature,
                "top_p": config.top_p,
                "top_k": config.top_k,
            }

        try:
            resp = self._request("POST", "/api/chat", json_data=body, stream=True)
            resp.raise_for_status()
            for line in resp.iter_lines(decode_unicode=True):
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                    content = chunk.get("message", {}).get("content", "")
                    if content:
                        yield content
                    if chunk.get("done", False):
                        break
                except json.JSONDecodeError:
                    continue
        except requests.RequestException as e:
            yield f"[{model}] 流式异常: {e}"

    def check_health(self) -> bool:
        try:
            resp = self._request("GET", "/api/tags", timeout=10)
            return resp.status_code == 200
        except Exception:
            return False

    def list_models(self) -> List[str]:
        try:
            resp = self._request("GET", "/api/tags")
            resp.raise_for_status()
            data = resp.json()
            return [m.get("name", "") for m in data.get("models", [])]
        except Exception:
            return []

    def model_exists(self, model_name: str) -> bool:
        models = self.list_models()
        installed = set(models)
        if model_name in installed:
            return True
        base = model_name.split(":")[0]
        return any(m == base or m.startswith(base + ":") for m in installed)

    def close(self) -> None:
        self._session.close()


class LocalLlamaProvider(OllamaProvider):
    """Local Llama Provider — OllamaProvider 的别名，用于本地 Llama 模型。

    与 OllamaProvider 共享同一后端，仅 provider_name 不同，
    便于在 MultiProviderRouter 中按名称区分。
    """

    provider_name = "local_llama"
    provider_version = "1.0.0"
