"""
models/provider — 多 Provider 路由器

提供：
- MultiProviderRouter: 按模型名自动路由到对应 Provider
- ProviderRegistry: Provider 注册、健康检查、负载均衡
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Generator, List, Optional

from models.provider.base import (
    ChatMessage,
    GenerationConfig,
    ModelResponse,
    ProviderInterface,
)
from models.provider.ollama import OllamaProvider, LocalLlamaProvider
from models.provider.openai import OpenAIProvider
from models.provider.anthropic import AnthropicProvider

logger = logging.getLogger(__name__)

__all__ = [
    "ProviderInterface",
    "ChatMessage",
    "GenerationConfig",
    "ModelResponse",
    "OllamaProvider",
    "LocalLlamaProvider",
    "OpenAIProvider",
    "AnthropicProvider",
    "MultiProviderRouter",
    "create_default_router",
]


class MultiProviderRouter:
    """多 Provider 路由器。

    特性：
    - 按模型名自动路由
    - 前缀匹配（如 'ollama:' 前缀 → OllamaProvider）
    - 健康检查 + 自动降级
    - 统一 chat/stream 接口

    Usage::

        router = MultiProviderRouter()
        router.register("ollama", OllamaProvider())
        router.register("openai", OpenAIProvider(api_key="sk-..."))
        resp = router.chat("ollama:qwen2.5:7b", messages=[...])
    """

    def __init__(self) -> None:
        self._providers: Dict[str, ProviderInterface] = {}
        self._route_map: Dict[str, str] = {}  # model_name → provider_key

    def register(self, key: str, provider: ProviderInterface) -> None:
        """注册一个 Provider。

        Args:
            key: Provider 标识（如 'ollama', 'openai'）。
            provider: Provider 实例。
        """
        self._providers[key] = provider
        # 自动注册已知模型的路由
        try:
            models = provider.list_models()
            for model in models:
                self._route_map[model] = key
                self._route_map[f"{key}:{model}"] = key
        except Exception:
            pass
        logger.info("Provider 已注册: %s → %s (v%s)", key, provider.provider_name, provider.provider_version)

    def unregister(self, key: str) -> None:
        """注销 Provider。"""
        self._providers.pop(key, None)
        self._route_map = {m: p for m, p in self._route_map.items() if p != key}

    def _resolve(self, model: str) -> tuple[ProviderInterface, str]:
        """解析模型名到 Provider + 真实模型名。

        Args:
            model: 带前缀或不带前缀的模型名。
                   'ollama:qwen2.5:7b' → OllamaProvider, 'qwen2.5:7b'
                   'qwen2.5:7b' → 从路由表中查找

        Returns:
            (Provider, resolved_model_name)
        """
        resolved_model = model

        # 前缀解析
        if ":" in model and not model.startswith("claude"):
            prefix = model.split(":")[0]
            if prefix in self._providers:
                resolved_model = model[len(prefix) + 1:]
                return self._providers[prefix], resolved_model

        # 路由表查找
        if model in self._route_map:
            provider_key = self._route_map[model]
            return self._providers[provider_key], model

        # 模糊匹配：尝试在每个 Provider 的模型列表中查找
        for key, provider in self._providers.items():
            try:
                models = provider.list_models()
                if model in models:
                    return provider, model
                # 检查基础名称匹配
                base = model.split(":")[0]
                for m in models:
                    if m == base or m.startswith(base + ":"):
                        return provider, model
            except Exception:
                continue

        # 回退到第一个可用的 Provider
        for key, provider in self._providers.items():
            if provider.check_health():
                logger.warning("模型 %s 未找到，回退到 %s", model, key)
                return provider, model

        raise ValueError(f"没有可用的 Provider 处理模型: {model}")

    def chat(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        timeout: Optional[int] = None,
    ) -> ModelResponse:
        """同步聊天请求（自动路由）。"""
        provider, resolved_model = self._resolve(model)
        return provider.chat(resolved_model, messages, system=system, config=config, timeout=timeout)

    def chat_stream(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
    ) -> Generator[str, None, None]:
        """流式聊天（自动路由）。"""
        provider, resolved_model = self._resolve(model)
        return provider.chat_stream(resolved_model, messages, system=system, config=config)

    def check_health(self, key: Optional[str] = None) -> Dict[str, bool]:
        """健康检查。

        Args:
            key: 指定 Provider key，None 则检查全部。

        Returns:
            {provider_key: healthy_bool}
        """
        if key:
            provider = self._providers.get(key)
            return {key: provider.check_health() if provider else False}

        return {k: p.check_health() for k, p in self._providers.items()}

    def list_all_models(self) -> Dict[str, List[str]]:
        """列出所有 Provider 的模型。

        Returns:
            {provider_key: [model_names]}
        """
        result = {}
        for key, provider in self._providers.items():
            try:
                result[key] = provider.list_models()
            except Exception:
                result[key] = []
        return result

    def close_all(self) -> None:
        """关闭所有 Provider 连接。"""
        for provider in self._providers.values():
            try:
                provider.close()
            except Exception:
                pass


def create_default_router() -> MultiProviderRouter:
    """创建默认路由器（Ollama + OpenAI + Anthropic）。"""
    router = MultiProviderRouter()

    # 默认注册 Ollama（本地）
    try:
        ollama = OllamaProvider()
        if ollama.check_health():
            router.register("ollama", ollama)
        else:
            logger.info("Ollama 未运行，跳过注册")
    except Exception:
        logger.info("Ollama 初始化失败，跳过")

    # 注册 Local Llama（复用 Ollama）
    try:
        local_llama = LocalLlamaProvider()
        if local_llama.check_health():
            router.register("local_llama", local_llama)
    except Exception:
        pass

    return router
