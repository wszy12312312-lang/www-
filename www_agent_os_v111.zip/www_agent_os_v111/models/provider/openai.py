"""
OpenAIProvider — OpenAI 兼容 API Provider

支持：
- OpenAI 官方 API
- 兼容 OpenAI 格式的第三方 API（如 vLLM、LiteLLM、Groq 等）
- chat/completions 端点
- 流式输出
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, Generator, List, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from models.provider.base import (
    ChatMessage,
    GenerationConfig,
    ModelResponse,
    ProviderInterface,
)

logger = logging.getLogger(__name__)

DEFAULT_OPENAI_HOST = "https://api.openai.com"


class OpenAIProvider(ProviderInterface):
    """OpenAI API Provider。

    Usage::

        provider = OpenAIProvider(api_key="sk-...")
        resp = provider.chat("gpt-4o", [ChatMessage("user", "Hello")])
    """

    provider_name = "openai"
    provider_version = "1.0.0"

    def __init__(
        self,
        api_key: str = "",
        base_url: str = "",
        timeout: int = 120,
        max_retries: int = 2,
    ) -> None:
        self.base_url = (base_url or DEFAULT_OPENAI_HOST).rstrip("/")
        self.api_key = api_key
        self.timeout = timeout

        self._session = requests.Session()
        self._session.trust_env = False

        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=1.0,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=4, pool_maxsize=8)
        self._session.mount("https://", adapter)
        self._session.mount("http://", adapter)

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _build_messages(self, messages: List[ChatMessage], system: Optional[str] = None) -> List[Dict]:
        result: List[Dict] = []
        if system:
            result.append({"role": "system", "content": system})
        for msg in messages:
            result.append(msg.to_dict())
        return result

    def chat(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        timeout: Optional[int] = None,
    ) -> ModelResponse:
        body: Dict[str, Any] = {
            "model": model,
            "messages": self._build_messages(messages, system),
            "stream": False,
        }
        if config:
            body["temperature"] = config.temperature
            body["top_p"] = config.top_p
            if config.max_tokens > 0:
                body["max_tokens"] = config.max_tokens
            if config.seed != 0:
                body["seed"] = config.seed

        t0 = time.perf_counter()
        try:
            resp = self._session.post(
                f"{self.base_url}/v1/chat/completions",
                json=body,
                headers=self._headers(),
                timeout=timeout or self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            choice = data.get("choices", [{}])[0]
            msg = choice.get("message", {})
            t1 = time.perf_counter()
            return ModelResponse(
                content=msg.get("content", ""),
                reasoning=msg.get("reasoning_content", ""),
                model=data.get("model", model),
                total_duration_ms=(t1 - t0) * 1000,
                eval_count=data.get("usage", {}).get("completion_tokens", 0),
            )
        except requests.RequestException as e:
            elapsed = (time.perf_counter() - t0) * 1000
            return ModelResponse(error=f"[{model}] API 异常: {e}", model=model, total_duration_ms=elapsed)

    def chat_stream(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
    ) -> Generator[str, None, None]:
        body: Dict[str, Any] = {
            "model": model,
            "messages": self._build_messages(messages, system),
            "stream": True,
        }
        if config:
            body["temperature"] = config.temperature
            body["top_p"] = config.top_p
            if config.max_tokens > 0:
                body["max_tokens"] = config.max_tokens

        try:
            resp = self._session.post(
                f"{self.base_url}/v1/chat/completions",
                json=body,
                headers=self._headers(),
                timeout=self.timeout * 2,
                stream=True,
            )
            resp.raise_for_status()
            for line in resp.iter_lines(decode_unicode=True):
                if not line or not line.startswith("data: "):
                    continue
                data_str = line[6:].strip()
                if data_str == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    delta = chunk.get("choices", [{}])[0].get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        yield content
                except json.JSONDecodeError:
                    continue
        except requests.RequestException as e:
            yield f"[{model}] 流式异常: {e}"

    def check_health(self) -> bool:
        try:
            resp = self._session.get(
                f"{self.base_url}/v1/models",
                headers=self._headers(),
                timeout=10,
            )
            return resp.status_code == 200
        except Exception:
            return False

    def list_models(self) -> List[str]:
        try:
            resp = self._session.get(
                f"{self.base_url}/v1/models",
                headers=self._headers(),
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()
            return [m.get("id", "") for m in data.get("data", [])]
        except Exception:
            return []

    def close(self) -> None:
        self._session.close()
