"""
Provider Interface — 统一的模型 Provider 抽象接口。

所有 Provider 必须实现此接口，确保：
- 统一的 chat / chat_stream 签名
- 统一的 ModelResponse 返回类型
- 统一的健康检查接口
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Generator, List, Optional


@dataclass
class ModelResponse:
    """统一模型响应。"""
    content: str = ""
    reasoning: str = ""
    model: str = ""
    done: bool = True
    total_duration_ms: float = 0.0
    eval_count: int = 0
    error: str = ""


@dataclass
class ChatMessage:
    """聊天消息。"""
    role: str
    content: str

    def to_dict(self) -> Dict[str, str]:
        return {"role": self.role, "content": self.content}


@dataclass
class GenerationConfig:
    """生成配置。"""
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    max_tokens: int = -1
    repeat_penalty: float = 1.1
    seed: int = 0


class ProviderInterface(ABC):
    """模型 Provider 抽象基类。

    所有 Provider 实现必须继承此类并实现所有抽象方法。
    """

    provider_name: str = "base"
    provider_version: str = "0.1.0"

    @abstractmethod
    def chat(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        timeout: Optional[int] = None,
    ) -> ModelResponse:
        """同步聊天请求。

        Args:
            model: 模型名称。
            messages: 消息列表。
            system: 系统提示。
            config: 生成配置。
            timeout: 超时秒数。

        Returns:
            ModelResponse 对象。
        """
        ...

    @abstractmethod
    def chat_stream(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
    ) -> Generator[str, None, None]:
        """流式聊天生成。

        Yields:
            增量文本片段。
        """
        ...

    @abstractmethod
    def check_health(self) -> bool:
        """健康检查。

        Returns:
            True 表示 Provider 可用。
        """
        ...

    @abstractmethod
    def list_models(self) -> List[str]:
        """列出可用模型。

        Returns:
            模型名称列表。
        """
        ...

    def supports_model(self, model: str) -> bool:
        """检查是否支持指定模型。"""
        try:
            return model in self.list_models()
        except Exception:
            return False
