"""
AnthropicProvider — Anthropic Claude API Provider

支持：
- Anthropic Messages API
- Claude 3.x / 3.5 系列模型
- 流式输出 (SSE)
- 思维链 (extended thinking) 支持
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, Generator, List, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from models.provider.base import (
    ChatMessage,
    GenerationConfig,
    ModelResponse,
    ProviderInterface,
)

logger = logging.getLogger(__name__)

DEFAULT_ANTHROPIC_HOST = "https://api.anthropic.com"
ANTHROPIC_VERSION = "2023-06-01"


class AnthropicProvider(ProviderInterface):
    """Anthropic Claude API Provider。

    Usage::

        provider = AnthropicProvider(api_key="sk-ant-...")
        resp = provider.chat("claude-sonnet-4-20250514", [ChatMessage("user", "Hello")])
    """

    provider_name = "anthropic"
    provider_version = "1.0.0"

    def __init__(
        self,
        api_key: str = "",
        base_url: str = "",
        timeout: int = 120,
        max_retries: int = 2,
    ) -> None:
        self.base_url = (base_url or DEFAULT_ANTHROPIC_HOST).rstrip("/")
        self.api_key = api_key
        self.timeout = timeout

        self._session = requests.Session()
        self._session.trust_env = False

        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=2.0,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=4, pool_maxsize=8)
        self._session.mount("https://", adapter)
        self._session.mount("http://", adapter)

    def _headers(self) -> Dict[str, str]:
        return {
            "x-api-key": self.api_key,
            "anthropic-version": ANTHROPIC_VERSION,
            "Content-Type": "application/json",
        }

    def _build_messages(self, messages: List[ChatMessage], system: Optional[str] = None) -> List[Dict]:
        result: List[Dict] = []
        for msg in messages:
            result.append(msg.to_dict())
        return result

    def chat(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        timeout: Optional[int] = None,
    ) -> ModelResponse:
        body: Dict[str, Any] = {
            "model": model,
            "messages": self._build_messages(messages, system),
            "max_tokens": config.max_tokens if config and config.max_tokens > 0 else 4096,
            "stream": False,
        }
        if system:
            body["system"] = system
        if config:
            body["temperature"] = config.temperature
            body["top_p"] = config.top_p
            if config.top_k != 40:
                body["top_k"] = config.top_k

        t0 = time.perf_counter()
        try:
            resp = self._session.post(
                f"{self.base_url}/v1/messages",
                json=body,
                headers=self._headers(),
                timeout=timeout or self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            content_blocks = data.get("content", [])
            text_parts = []
            reasoning_parts = []
            for block in content_blocks:
                if block.get("type") == "text":
                    text_parts.append(block.get("text", ""))
                elif block.get("type") == "thinking":
                    reasoning_parts.append(block.get("thinking", ""))

            t1 = time.perf_counter()
            return ModelResponse(
                content="\n".join(text_parts),
                reasoning="\n".join(reasoning_parts),
                model=data.get("model", model),
                total_duration_ms=(t1 - t0) * 1000,
                eval_count=data.get("usage", {}).get("output_tokens", 0),
            )
        except requests.RequestException as e:
            elapsed = (time.perf_counter() - t0) * 1000
            return ModelResponse(error=f"[{model}] API 异常: {e}", model=model, total_duration_ms=elapsed)

    def chat_stream(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
    ) -> Generator[str, None, None]:
        body: Dict[str, Any] = {
            "model": model,
            "messages": self._build_messages(messages, system),
            "max_tokens": config.max_tokens if config and config.max_tokens > 0 else 4096,
            "stream": True,
        }
        if system:
            body["system"] = system
        if config:
            body["temperature"] = config.temperature
            body["top_p"] = config.top_p

        try:
            resp = self._session.post(
                f"{self.base_url}/v1/messages",
                json=body,
                headers=self._headers(),
                timeout=self.timeout * 2,
                stream=True,
            )
            resp.raise_for_status()
            for line in resp.iter_lines(decode_unicode=True):
                if not line or not line.startswith("data: "):
                    continue
                data_str = line[6:].strip()
                try:
                    event = json.loads(data_str)
                    if event.get("type") == "content_block_delta":
                        delta = event.get("delta", {})
                        text = delta.get("text", "")
                        if text:
                            yield text
                    elif event.get("type") == "message_stop":
                        break
                except json.JSONDecodeError:
                    continue
        except requests.RequestException as e:
            yield f"[{model}] 流式异常: {e}"

    def check_health(self) -> bool:
        try:
            resp = self._session.get(
                f"{self.base_url}/v1/messages",
                headers=self._headers(),
                timeout=10,
            )
            return resp.status_code in (200, 405)  # 405 = endpoint exists but needs POST
        except Exception:
            return False

    def list_models(self) -> List[str]:
        # Anthropic 没有公开的 list models 端点
        # 返回已知的模型列表
        return [
            "claude-sonnet-4-20250514",
            "claude-opus-4-20250514",
            "claude-haiku-3.5-20241022",
            "claude-3.5-sonnet-20241022",
        ]

    def close(self) -> None:
        self._session.close()
