"""
ModelGateway — 模型网关（多 Provider 版本）

封装多 Provider 调用，提供：
- Ollama / OpenAI / Anthropic / LocalLlama 多后端支持
- 自动路由与健康检查
- API 认证支持（H02 修复）
- 模型列表查询
- 文本生成（同步 + 流式）
- 超时与重试机制
- 与 EventBus 集成

版本: 2.0.0 — Provider 抽象层集成
"""

from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Generator, List, Optional, Tuple

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from events.bus import Event, EventBus, EventType, get_default_bus
from models.provider.base import (
    ChatMessage as ProviderChatMessage,
    GenerationConfig as ProviderGenConfig,
    ModelResponse as ProviderModelResponse,
)
from models.provider import (
    MultiProviderRouter,
    OllamaProvider,
    OpenAIProvider,
    AnthropicProvider,
    LocalLlamaProvider,
)

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# 数据类（保持向后兼容，复用 Provider 基类）
# ------------------------------------------------------------------

@dataclass
class ModelInfo:
    """已安装模型信息。"""

    name: str
    modified_at: str = ""
    size: int = 0  # bytes
    digest: str = ""
    family: str = ""
    parameter_size: str = ""


@dataclass
class GenerationConfig:
    """文本生成配置。"""

    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    num_predict: int = -1  # -1 表示不限制
    repeat_penalty: float = 1.1
    seed: int = 0  # 0 表示随机
    num_ctx: int = 4096

    def to_dict(self) -> Dict[str, Any]:
        """转换为 Ollama options 字典，过滤默认值。"""
        result: Dict[str, Any] = {}
        if self.temperature != 0.7:
            result["temperature"] = self.temperature
        if self.top_p != 0.9:
            result["top_p"] = self.top_p
        if self.top_k != 40:
            result["top_k"] = self.top_k
        if self.num_predict > 0:
            result["num_predict"] = self.num_predict
        if self.repeat_penalty != 1.1:
            result["repeat_penalty"] = self.repeat_penalty
        if self.seed != 0:
            result["seed"] = self.seed
        if self.num_ctx != 4096:
            result["num_ctx"] = self.num_ctx
        return result

    def to_provider_config(self) -> ProviderGenConfig:
        """转为 Provider 通用配置。"""
        return ProviderGenConfig(
            temperature=self.temperature,
            top_p=self.top_p,
            top_k=self.top_k,
            max_tokens=self.num_predict,
            repeat_penalty=self.repeat_penalty,
            seed=self.seed,
        )


@dataclass
class ChatMessage:
    """聊天消息。"""

    role: str  # 'system', 'user', 'assistant'
    content: str

    def to_dict(self) -> Dict[str, str]:
        return {"role": self.role, "content": self.content}

    def to_provider_message(self) -> ProviderChatMessage:
        return ProviderChatMessage(role=self.role, content=self.content)

    @staticmethod
    def from_provider_message(pm: ProviderChatMessage) -> "ChatMessage":
        return ChatMessage(role=pm.role, content=pm.content)


@dataclass
class ModelResponse:
    """模型响应。"""

    content: str = ""
    reasoning: str = ""
    model: str = ""
    done: bool = True
    total_duration_ms: float = 0.0
    eval_count: int = 0
    error: str = ""

    @staticmethod
    def from_provider_response(pr: ProviderModelResponse) -> "ModelResponse":
        return ModelResponse(
            content=pr.content,
            reasoning=pr.reasoning,
            model=pr.model,
            done=pr.done,
            total_duration_ms=pr.total_duration_ms,
            eval_count=pr.eval_count,
            error=pr.error,
        )


# ------------------------------------------------------------------
# ModelGateway
# ------------------------------------------------------------------

class ModelGateway:
    """模型网关 — 多 Provider 模型调用（v2.0）。

    特性：
    - 多 Provider 支持：Ollama / OpenAI / Anthropic / LocalLlama
    - MultiProviderRouter 自动路由（按模型名前缀）
    - API 密钥认证（Bearer Token / Basic Auth）
    - 连接池 + 自动重试（HTTPAdapter）
    - 超时控制、流式输出
    - EventBus 集成

    Usage::

        gw = ModelGateway(host="http://localhost:11434")
        gw.register_openai(api_key="sk-...")
        gw.register_anthropic(api_key="sk-ant-...")

        # 自动路由
        response = gw.chat("qwen2.5:7b", [ChatMessage("user", "Hello")])
        response = gw.chat("openai:gpt-4o", [ChatMessage("user", "Hello")])
    """

    # 默认配置
    DEFAULT_HOST = "http://localhost:11434"
    DEFAULT_TIMEOUT = 120  # 秒
    DEFAULT_MAX_RETRIES = 2

    def __init__(
        self,
        host: str = "",
        api_key: str = "",
        api_user: str = "",
        api_password: str = "",
        timeout: int = 0,
        max_retries: int = 0,
        bus: Optional[EventBus] = None,
    ) -> None:
        """初始化 ModelGateway。

        Args:
            host: Ollama API 地址，默认 http://localhost:11434。
            api_key: API 密钥（Bearer Token 认证）。
            api_user: 基本认证用户名。
            api_password: 基本认证密码。
            timeout: 请求超时秒数，默认 120。
            max_retries: 最大重试次数，默认 2。
            bus: EventBus 实例。
        """
        self.host = host.rstrip("/") if host else self.DEFAULT_HOST
        self.timeout = timeout or self.DEFAULT_TIMEOUT
        self.max_retries = max_retries if max_retries > 0 else self.DEFAULT_MAX_RETRIES

        # API 认证（H02）
        self._api_key = api_key
        self._api_user = api_user
        self._api_password = api_password

        # EventBus
        self._bus = bus or get_default_bus()

        # 构建 HTTP Session（保留用于直接 Ollama 调用）
        self._session = requests.Session()
        self._session.trust_env = False

        # 认证头
        self._auth_headers: Dict[str, str] = {}
        if api_key:
            self._auth_headers["Authorization"] = f"Bearer {api_key}"
            logger.info("ModelGateway: 使用 Bearer Token 认证")
        elif api_user and api_password:
            import base64
            creds = base64.b64encode(f"{api_user}:{api_password}".encode()).decode()
            self._auth_headers["Authorization"] = f"Basic {creds}"
            logger.info("ModelGateway: 使用 Basic Auth 认证")

        # 重试策略
        retry_strategy = Retry(
            total=self.max_retries,
            backoff_factor=1.0,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"],
        )
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=4,
            pool_maxsize=8,
        )
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)

        # 状态
        self._online: Optional[bool] = None
        self._lock = threading.RLock()

        # === v2.0: Provider 路由器 ===
        self._router = MultiProviderRouter()
        # 默认注册 Ollama（主后端）
        self._ollama = OllamaProvider(
            host=self.host,
            api_key=api_key,
            api_user=api_user,
            api_password=api_password,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        self._router.register("ollama", self._ollama)

        logger.info("ModelGateway v2.0 已初始化: host=%s, router=%d provider(s)",
                     self.host, len(self._router._providers))

    # ------------------------------------------------------------------
    # v2.0: Provider 注册方法
    # ------------------------------------------------------------------

    def register_openai(
        self,
        api_key: str = "",
        base_url: str = "",
    ) -> None:
        """注册 OpenAI Provider。

        Args:
            api_key: OpenAI API 密钥。
            base_url: 自定义 API 地址（兼容 OpenAI 协议的第三方）。
        """
        provider = OpenAIProvider(api_key=api_key, base_url=base_url, timeout=self.timeout)
        self._router.register("openai", provider)
        logger.info("ModelGateway: OpenAI Provider 已注册 (base_url=%s)", base_url or "default")

    def register_anthropic(
        self,
        api_key: str = "",
        base_url: str = "",
    ) -> None:
        """注册 Anthropic Provider。"""
        provider = AnthropicProvider(api_key=api_key, base_url=base_url, timeout=self.timeout)
        self._router.register("anthropic", provider)
        logger.info("ModelGateway: Anthropic Provider 已注册")

    def register_provider(self, name: str, provider: Any) -> None:
        """注册自定义 Provider。"""
        self._router.register(name, provider)
        logger.info("ModelGateway: 自定义 Provider '%s' 已注册", name)

    @property
    def router(self) -> MultiProviderRouter:
        """获取内部路由器（用于高级场景）。"""
        return self._router

    @property
    def bus(self) -> EventBus:
        return self._bus

    @property
    def is_online(self) -> Optional[bool]:
        """Ollama 服务是否在线（None=未检测）。"""
        return self._online

    # ------------------------------------------------------------------
    # 底层 HTTP 请求
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        json_data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
        stream: bool = False,
    ) -> requests.Response:
        """发送 HTTP 请求到 Ollama API。

        Args:
            method: HTTP 方法 (GET/POST)。
            path: API 路径（如 '/api/tags'）。
            json_data: JSON 请求体。
            timeout: 超时（秒），默认使用实例 timeout。
            stream: 是否流式响应。

        Returns:
            requests.Response 对象。

        Raises:
            requests.RequestException: 请求失败。
        """
        url = f"{self.host}{path}"
        headers = {**self._auth_headers}

        if timeout is None:
            timeout = self.timeout

        if stream:
            timeout = max(timeout, 300)  # 流式最小 5 分钟

        logger.debug("Ollama %s %s", method, url)
        resp = self._session.request(
            method=method,
            url=url,
            json=json_data,
            headers=headers,
            timeout=timeout,
            stream=stream,
        )
        return resp

    # ------------------------------------------------------------------
    # API: 模型管理
    # ------------------------------------------------------------------

    def list_models(self) -> List[ModelInfo]:
        """查询已安装的模型列表。

        Returns:
            ModelInfo 列表。

        Raises:
            RuntimeError: 服务不可用。
        """
        try:
            resp = self._request("GET", "/api/tags")
            resp.raise_for_status()
            data = resp.json()
            models = []
            for m in data.get("models", []):
                details = m.get("details", {})
                models.append(ModelInfo(
                    name=m.get("name", ""),
                    modified_at=m.get("modified_at", ""),
                    size=m.get("size", 0),
                    digest=m.get("digest", ""),
                    family=details.get("family", ""),
                    parameter_size=details.get("parameter_size", ""),
                ))
            self._online = True
            return models
        except requests.RequestException as e:
            self._online = False
            raise RuntimeError(f"无法获取模型列表: {e}") from e

    def check_health(self) -> bool:
        """检查 Ollama 服务健康状态。

        Returns:
            True 表示服务在线。
        """
        try:
            resp = self._request("GET", "/api/tags", timeout=10)
            self._online = resp.status_code == 200
            return self._online
        except Exception:
            self._online = False
            return False

    def model_exists(self, model_name: str) -> bool:
        """检查指定模型是否已安装。

        Args:
            model_name: 模型名称（如 'qwen2.5:7b'）。

        Returns:
            True 表示已安装。
        """
        try:
            models = self.list_models()
            installed_names = {m.name for m in models}
            if model_name in installed_names:
                return True
            # 也检查不带标签的版本
            base = model_name.split(":")[0]
            for mn in installed_names:
                if mn == base or mn.startswith(base + ":"):
                    return True
            return False
        except Exception:
            return False

    # ------------------------------------------------------------------
    # API: 文本生成（同步）— v2.0 Provider 路由
    # ------------------------------------------------------------------

    def chat(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        include_reasoning: bool = False,
        timeout: Optional[int] = None,
    ) -> ModelResponse:
        """发送聊天请求，自动路由到对应 Provider。

        Args:
            model: 模型名称。支持前缀路由：
                   - 'qwen2.5:7b' → 直接 Ollama
                   - 'openai:gpt-4o' → OpenAI
                   - 'anthropic:claude-sonnet-4-20250514' → Anthropic
            messages: 消息列表。
            system: 系统提示。
            config: 生成配置。
            include_reasoning: 是否获取思维链。
            timeout: 超时（秒）。

        Returns:
            ModelResponse 对象。
        """
        self._bus.emit(Event(
            type=EventType.MODEL_REQUESTED,
            source="model.gateway",
            data={"model": model, "message_count": len(messages)},
        ))

        # 转为 Provider 格式
        p_messages = [m.to_provider_message() for m in messages]
        p_config = config.to_provider_config() if config else None

        t0 = time.perf_counter()

        try:
            # 通过路由器调用
            p_resp = self._router.chat(
                model=model,
                messages=p_messages,
                system=system,
                config=p_config,
                timeout=timeout,
            )

            result = ModelResponse.from_provider_response(p_resp)
            t1 = time.perf_counter()
            result.total_duration_ms = (t1 - t0) * 1000

            self._bus.emit(Event(
                type=EventType.MODEL_RESPONDED,
                source="model.gateway",
                data={
                    "model": model,
                    "content_length": len(result.content),
                    "duration_ms": round(result.total_duration_ms, 1),
                },
            ))
            return result

        except Exception as e:
            elapsed = (time.perf_counter() - t0) * 1000
            self._bus.emit(Event(
                type=EventType.MODEL_ERROR,
                source="model.gateway",
                data={"model": model, "error": str(e), "duration_ms": round(elapsed, 1)},
            ))
            return ModelResponse(
                error=f"[{model}] API 请求异常: {e}",
                model=model,
                total_duration_ms=elapsed,
            )

    # ------------------------------------------------------------------
    # API: 流式输出
    # ------------------------------------------------------------------

    def chat_stream(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        include_reasoning: bool = False,
    ) -> Generator[str, None, None]:
        """流式聊天生成（v2.0 Provider 路由）。

        Yields:
            增量文本片段。
        """
        self._bus.emit(Event(
            type=EventType.MODEL_REQUESTED,
            source="model.gateway",
            data={"model": model, "stream": True},
        ))

        p_messages = [m.to_provider_message() for m in messages]
        p_config = config.to_provider_config() if config else None

        try:
            for chunk in self._router.chat_stream(
                model=model,
                messages=p_messages,
                system=system,
                config=p_config,
            ):
                yield chunk

            self._bus.emit(Event(
                type=EventType.MODEL_RESPONDED,
                source="model.gateway",
                data={"model": model, "stream": True},
            ))

        except Exception as e:
            self._bus.emit(Event(
                type=EventType.MODEL_ERROR,
                source="model.gateway",
                data={"model": model, "error": str(e), "stream": True},
            ))
            yield f"[{model}] 流式请求异常: {e}"

    # ------------------------------------------------------------------
    # API: 文本生成（generate，兼容旧接口）
    # ------------------------------------------------------------------

    def generate(
        self,
        model: str,
        prompt: str,
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        raw: bool = False,
    ) -> str:
        """使用 /api/generate 生成文本（兼容旧版 API）。

        Args:
            model: 模型名称。
            prompt: 提示文本。
            system: 系统提示。
            config: 生成配置。
            raw: 是否禁用模板。

        Returns:
            生成的文本。
        """
        body: Dict[str, Any] = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "raw": raw,
        }
        if system:
            body["system"] = system
        if config:
            body["options"] = config.to_dict()

        try:
            resp = self._request("POST", "/api/generate", json_data=body)
            resp.raise_for_status()
            return resp.json().get("response", "")
        except requests.RequestException as e:
            # M05修复：generate() 异常时抛出 RuntimeError 而非返回错误字符串，
            # 调用者可通过 try/except 标准处理而非检查字符串前缀。
            raise RuntimeError(f"[{model}] generate 异常: {e}") from e

    # ------------------------------------------------------------------
    # 统计
    # ------------------------------------------------------------------

    def verify_auth(self) -> Tuple[bool, str]:
        """验证认证配置是否正确。

        Returns:
            (是否通过, 信息)。
        """
        if not self._auth_headers:
            return True, "未配置 API 认证（本地访问）"
        try:
            resp = self._request("GET", "/api/tags", timeout=10)
            if resp.status_code == 200:
                return True, "认证验证通过"
            elif resp.status_code == 401:
                return False, "认证失败: 401 Unauthorized"
            elif resp.status_code == 403:
                return False, "认证失败: 403 Forbidden"
            else:
                return False, f"认证验证返回: {resp.status_code}"
        except Exception as e:
            return False, f"认证验证异常: {e}"

    def close(self) -> None:
        """关闭 HTTP Session。"""
        self._session.close()
        logger.info("ModelGateway 已关闭")
