"""
WWW Agent OS v10.7.0 — Ollama 服务层
（从 legacy/www_core.py 迁移，统一导入路径）

提供：
- WWWSystem：核心多人格系统（chat / dispatch / evaluate / memory）
- PersonaState：旧版人格状态数据类
"""

import json
import logging
import os
import re
import threading
import time
from datetime import datetime
from dataclasses import dataclass, field
from typing import Optional

import requests

logger = logging.getLogger(__name__)

from config.app_config import (
    OLLAMA_HOST, OLLAMA_API_KEY, OLLAMA_TIMEOUT,
    PERSONA_MODELS, PERSONAS, SKILL_DIR, MEMORY_DIR,
)

# H03修复：移除本地正则黑名单，统一使用 core.input_sanitizer.InputSanitizer
# 避免两处维护。_sanitize_user_input() 改为委托给 InputSanitizer。
# 原 _PROMPT_INJECTION_PATTERNS 已移至 InputSanitizer.BUILTIN_BLOCKED_PATTERNS。
_PROMPT_INJECTION_PATTERNS_HISTORICAL = "removed — 见 H03 修复"

# M06修复：令牌桶限流替代 Semaphore 并发限制
# 支持按 persona 维度独立限流（每 persona 10 RPM，全局 30 RPM）
from tools.rate_limiter import MultiRateLimiter as _MultiRateLimiter

_global_limiter = _MultiRateLimiter(
    default_rpm=10,
    per_key_rpm={
        "global": 30,   # 全局 30 RPM
        "host": 15,     # HOST 调度更频繁
        "S": 20,        # 监察员评分更频繁
    },
)


@dataclass
class PersonaState:
    persona_id: str
    incentive_stars: int = 3
    penalty_stars: int = 0
    task_count: int = 0
    task_score: float = 0.0
    history: list = field(default_factory=list)
    model_online: Optional[bool] = None  # None=未检查, True=正常, False=异常
    memory_ok: Optional[bool] = None    # None=未检查, True=正常, False=异常
    score_history: list = field(default_factory=list)  # 评分历史
    recent_comments: list = field(default_factory=list)  # 监督员最近评语

    @property
    def net_incentive(self) -> int:
        return self.incentive_stars - self.penalty_stars

    @property
    def status_text(self) -> str:
        if self.net_incentive >= 3:
            return "激励状态"
        elif self.net_incentive <= -3:
            return "惩戒状态"
        return "正常"


class WWWSystem:
    def __init__(self):
        self.states: dict[str, PersonaState] = {}
        self.task_log: list = []
        self.current_persona: str = "host"
        self._running: bool = False
        self._checking: bool = False
        self.experiences: dict[str, list] = {}  # pid → 经验列表
        self._tlocal = threading.local()  # 每个线程独立 Session，避免跨线程踩踏
        # 确认请求恢复回路状态
        self._pending_confirmations: list[dict] = []
        self._last_sub_results: list = []
        self._last_host_reasoning: str = ""
        self._last_host_analysis: str = ""
        self._states_lock = threading.RLock()  # C02修复：保护 self.states 并发写入
        self._init_states()
        self._load_skill_prompts()

    def _sanitize_user_input(self, text: str) -> tuple[str, bool]:
        """检测并过滤 prompt 注入模式。返回 (sanitized_text, was_filtered)"""
        # H03修复：删除无效的 _PROMPT_INJECTION_PATTERNS 引用
        # _sanitize_user_input() 现在委托给 InputSanitizer
        was_filtered = False
        try:
            from core.input_sanitizer import get_sanitizer
            sanitizer = get_sanitizer()
            result = sanitizer.sanitize(text)
            return result.sanitized, result.is_suspicious or result.is_blocked
        except ImportError:
            # 回退：基础正则检查
            fallback = [
                r"(?i)ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?)",
                r"(?i)(reveal|show|print|output|dump|display|tell)\s+(me\s+)?(your|the)\s+(system\s+)?(prompt|instructions?)",
            ]
            for pat in fallback:
                if re.search(pat, text):
                    text = re.sub(pat, "[FILTERED]", text)
                    was_filtered = True
            return text, was_filtered

    def _get_ollama_headers(self) -> dict:
        """构建 Ollama API 请求头，支持可配置的认证方案（Bearer / Basic / Raw）。

        通过环境变量 OLLAMA_AUTH_SCHEME 控制方案（大小写不敏感）：
        - 'bearer'（默认）: Authorization: Bearer <OLLAMA_API_KEY>
        - 'basic'          : Authorization: Basic <OLLAMA_API_KEY>
        - 'raw'            : Authorization: <OLLAMA_API_KEY>

        日志中不输出明文 API Key，避免泄露。
        """
        headers = {"Content-Type": "application/json"}
        if OLLAMA_API_KEY:
            scheme = os.environ.get("OLLAMA_AUTH_SCHEME", "bearer")
            scheme = scheme.strip().lower() if isinstance(scheme, str) else "bearer"
            if scheme == "bearer":
                headers["Authorization"] = f"Bearer {OLLAMA_API_KEY}"
            elif scheme == "basic":
                headers["Authorization"] = f"Basic {OLLAMA_API_KEY}"
            elif scheme == "raw":
                headers["Authorization"] = f"{OLLAMA_API_KEY}"
            else:
                headers["Authorization"] = f"Bearer {OLLAMA_API_KEY}"
        return headers

    def _get_session(self) -> requests.Session:
        """获取当前线程专属的 requests.Session（线程安全）。"""
        sess = getattr(self._tlocal, "session", None)
        if sess is None:
            sess = requests.Session()
            sess.trust_env = False  # 绕过系统代理，直连 localhost
            self._tlocal.session = sess
        return sess

    def _ollama_post(self, url: str, json_data: dict, timeout: int = None) -> requests.Response:
        """带重试的 Ollama API POST 请求（线程安全 + 并发限流）"""
        if timeout is None:
            timeout = OLLAMA_TIMEOUT
        last_error = None
        # M06修复：令牌桶限流替代 Semaphore。_ollama_post 内部不再限流，
        # 调用方（chat / evaluate / dispatch）使用 _global_limiter 控制。
        for attempt in range(2):
                try:
                    resp = self._get_session().post(url, json=json_data, timeout=timeout,
                                                    headers=self._get_ollama_headers())
                    return resp
                except requests.exceptions.Timeout as e:
                    last_error = e
                    if attempt == 0:
                        continue
                except requests.exceptions.ConnectionError as e:
                    last_error = e
                    if attempt == 0:
                        time.sleep(1)
                        continue
                except Exception as e:
                    last_error = e
                    break
        raise last_error or Exception("Ollama API request failed after retries")

    def _ollama_get(self, url: str, timeout: int = 10) -> requests.Response:
        """带重试的 Ollama API GET 请求"""
        last_error = None
        for attempt in range(2):
            try:
                resp = self._get_session().get(url, timeout=timeout, headers=self._get_ollama_headers())
                return resp
            except requests.exceptions.Timeout as e:
                last_error = e
                if attempt == 0:
                    continue
            except requests.exceptions.ConnectionError as e:
                last_error = e
                if attempt == 0:
                    time.sleep(1)
                    continue
            except Exception as e:
                last_error = e
                break
        raise last_error or Exception("Ollama API GET request failed after retries")

    def _init_states(self):
        for pid in PERSONAS:
            self.states[pid] = PersonaState(persona_id=pid)
            self._load_persona_memory(pid)

    def check_all_models(self, progress_callback=None):
        """检查所有模型是否在线，更新 model_online 状态。
        progress_callback(pid, done_count, total) 每检查完一个模型时调用。"""
        self._checking = True
        total = len(PERSONA_MODELS)
        for s in self.states.values():
            s.model_online = None
            s.memory_ok = None

        try:
            resp = self._ollama_get(f"{OLLAMA_HOST}/api/tags")
            raw_models = resp.json().get("models", [])
            # Normalize: strip :latest tag suffix for comparison
            installed = set()
            for m in raw_models:
                name = m["name"]
                installed.add(name)
                if ":" in name:
                    installed.add(name.split(":")[0])
        except Exception:
            installed = set()

        done = 0
        for pid, model in PERSONA_MODELS.items():
            state = self.states[pid]
            # Check if model is installed (with or without tag suffix)
            model_base = model.split(":")[0]
            if model not in installed and model_base not in installed:
                state.model_online = False
                self._check_persona_memory(pid)
                done += 1
                if progress_callback:
                    progress_callback(pid, done, total)
                continue
            try:
                test_resp = self._ollama_post(
                    f"{OLLAMA_HOST}/api/chat",
                    {
                        "model": model,
                        "messages": [{"role": "user", "content": "ping"}],
                        "stream": False,
                        "options": {"num_predict": 1},
                    },
                    timeout=30,
                )
                state.model_online = test_resp.status_code == 200
            except Exception:
                state.model_online = False
            done += 1
            self._check_persona_memory(pid)
            if progress_callback:
                progress_callback(pid, done, total)

        self._checking = False

    def mark_model_offline(self, persona_id: str):
        """标记指定人格的模型为离线"""
        if persona_id in self.states:
            self.states[persona_id].model_online = False

    def _check_persona_memory(self, pid: str):
        """检查单个人格的记忆文件是否正常可读写"""
        import json as _json
        state = self.states[pid]
        try:
            mem_dir = self.get_persona_memory_dir(pid)
            scores_path = os.path.join(mem_dir, "scores.json")
            if os.path.exists(scores_path):
                with open(scores_path, "r", encoding="utf-8") as f:
                    _json.load(f)
            history_path = os.path.join(mem_dir, "history.json")
            if os.path.exists(history_path):
                with open(history_path, "r", encoding="utf-8") as f:
                    _json.load(f)
            state.memory_ok = True
        except Exception:
            state.memory_ok = False

    def _load_skill_prompts(self):
        """从 SKILL.md 加载各人格系统提示词"""
        self.skill_prompts: dict[str, str] = {}
        skill_map = {
            "host": "host",
            "S1": "software-specialist",
            "S2": "system-specialist",
            "S3": "web-specialist",
            "S4": "file-specialist",
            "S5": "search-specialist",
            "S": "monitor-specialist",
            "S6": "chat-specialist",
        }
        for pid, dirname in skill_map.items():
            path = os.path.join(SKILL_DIR, dirname, "SKILL.md")
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                # 去掉 frontmatter
                content = re.sub(r'^---.*?---\s*', '', content, flags=re.DOTALL)
                self.skill_prompts[pid] = content[:8000]  # 截断以节省 token
            else:
                self.skill_prompts[pid] = f"你是 {PERSONAS[pid]['name']}，{PERSONAS[pid]['role']}。"

    def get_system_prompt(self, persona_id: str, user_query: str = "") -> str:
        """构建完整 system prompt"""
        meta = PERSONAS[persona_id]
        state = self.states[persona_id]
        skill = self.skill_prompts.get(persona_id, "")

        # 构建状态面板
        status_block = f"""
当前系统状态：
- 人格：{meta['name']}（{persona_id}）
- 激励星：{'★' * state.incentive_stars} | 惩戒星：{'★' * state.penalty_stars}
- 净激励：{state.net_incentive} | 状态：{state.status_text}
- 任务数：{state.task_count} | 均分：{state.task_score:.1f}
"""
        prompt = skill + "\n" + status_block

        # 注入监督员评语
        comments = self.inject_recent_comments(persona_id)
        if comments:
            prompt += "\n" + comments

        # 注入相关历史经验
        if user_query:
            experiences = self.search_similar_experiences(persona_id, user_query)
            if experiences:
                prompt += "\n" + experiences

        return prompt

    def chat(self, persona_id: str, user_message: str) -> tuple:
        """向指定人格发送消息，返回 (reply, reasoning) 元组"""
        import time
        model = PERSONA_MODELS.get(persona_id, "qwen2.5:7b")
        state = self.states[persona_id]
        system_prompt = self.get_system_prompt(persona_id, user_message)

        messages = [{"role": "system", "content": system_prompt}]
        for h in state.history[-20:]:
            messages.append(h)
        messages.append({"role": "user", "content": user_message})

        reasoning = ""
        failed_attempts = 0
        max_retries = 2
        reply = f"[{model} 响应异常，请检查 Ollama 服务是否正常运行]"

        for attempt in range(max_retries + 1):
            try:
                if attempt == 0:
                    resp = self._ollama_post(
                        f"{OLLAMA_HOST}/api/chat",
                        {
                            "model": model,
                            "messages": messages,
                            "stream": False,
                            "include_reasoning": True,
                        },
                    )
                    data = resp.json()
                    msg = data.get("message", {})
                    reply = msg.get("content", "")
                    reasoning = msg.get("reasoning_content", "") or msg.get("thinking", "")

                    if not reply and not reasoning:
                        resp2 = self._ollama_post(
                            f"{OLLAMA_HOST}/api/chat",
                            {
                                "model": model,
                                "messages": messages,
                                "stream": False,
                            },
                            timeout=120,
                        )
                        data2 = resp2.json()
                        reply = data2.get("message", {}).get("content", "")
                else:
                    # Retry without include_reasoning
                    resp = self._ollama_post(
                        f"{OLLAMA_HOST}/api/chat",
                        {
                            "model": model,
                            "messages": messages,
                            "stream": False,
                        },
                        timeout=120,
                    )
                    data = resp.json()
                    reply = data.get("message", {}).get("content", "")

                state.model_online = True
                break  # Success
            except Exception:
                failed_attempts += 1
                if attempt < max_retries:
                    delay = 1.0 * (2 ** attempt)  # 1s → 2s → 4s
                    time.sleep(delay)
                else:
                    state.model_online = False
                    reply = f"[{model} 响应异常，请检查 Ollama 服务是否正常运行]"
                    reasoning = ""

        with self._states_lock:
            state.history.append({"role": "user", "content": user_message})
            state.history.append({"role": "assistant", "content": reply})
            state.task_count += 1

        return reply, reasoning

    def host_dispatch(self, user_message: str) -> tuple[str, str]:
        """HOST 分析任务并调度到对应专员"""
        sanitized, was_filtered = self._sanitize_user_input(user_message)
        if was_filtered:
            return "host", "检测到异常输入，已交由 HOST 处理"

        host_prompt = f"""你是 www 系统 HOST。分析以下用户消息，判断应该调度哪个专员。
回复格式：{{"persona": "S1"}} 或 {{"persona": "host"}}

专员映射：
S1-软件(安装/卸载/打开应用/APK/EXE)、S2-系统(配置/运维/代码/编程)、
S3-网络(网页/爬虫/浏览器)、S4-文件(文档/整理/转换/Excel/PPT)、
S5-检索(搜索/查资料/信息)、S6-聊天(闲聊/倾诉/日常)、host-综合/调度

用户消息：{sanitized}"""
        try:
            resp = self._ollama_post(
                f"{OLLAMA_HOST}/api/chat",
                {
                    "model": PERSONA_MODELS["host"],
                    "messages": [{"role": "user", "content": host_prompt}],
                    "stream": False,
                },
                timeout=30,
            )
            data = resp.json()
            content = data.get("message", {}).get("content", "")
            match = re.search(r'"persona"\s*:\s*"(\w+)"', content)
            if match:
                pid = match.group(1)
                # H04修复：校验 persona_id 必须在 PERSONAS 中
                if pid in PERSONAS:
                    return pid, content
                logger.warning("host_dispatch 返回未知 persona_id: %s，回退 host", pid)
        except requests.exceptions.Timeout:
            logger.warning("host_dispatch 超时，回退 host 调度")
        except requests.exceptions.ConnectionError:
            logger.warning("host_dispatch 连接失败，回退 host 调度")
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logger.warning("host_dispatch 解析异常: %s", e)
        except Exception as e:
            logger.error("host_dispatch 未预期异常: %s", e, exc_info=True)
        return "host", "调度默认"

    def host_decompose_task(self, user_message: str) -> tuple:
        """HOST 分解用户任务为子任务列表。

        调用 HOST 模型分析用户意图，将复杂任务拆解为可并行/串行的子任务，
        每个子任务指定目标副人格和执行提示。

        Returns:
            (subtasks, reasoning, analysis) 三元组：
            - subtasks: [{"persona": "S4", "prompt": "..."}, ...]
            - reasoning: HOST 模型的思考链（thinking/reasoning_content）
            - analysis: HOST 对任务的整体分析文本
        """
        sanitized, was_filtered = self._sanitize_user_input(user_message)
        if was_filtered:
            return ([], "", "检测到异常输入，任务分解已跳过")

        host_model = PERSONA_MODELS["host"]

        decom_prompt = f"""你是 www 系统 HOST 指挥者 Marvis。请分析以下用户任务，将其分解为子任务并指定执行专员。

## 可用专员
| ID | 专员 | 专长 |
|----|------|------|
| S1 | 软件专员 | APP/EXE 下载安装卸载 |
| S2 | 系统专员 | 系统配置、运维、编程 |
| S3 | 网络专员 | 网页抓取、浏览器自动化 |
| S4 | 文件专员 | 文件搜索、文档问答、格式转换 |
| S5 | 检索专员 | 全网搜索、信息聚合、调研 |
| S6 | 聊天专员 | 闲聊、倾诉、日常对话 |

## 规则
1. 简单任务（单类型）只需 1 个子任务
2. 复杂任务可拆解为多个子任务，独立子任务可标注 parallel=true
3. 每个子任务必须指定 persona 和具体的 prompt
4. 如果任务需要你自己（HOST）综合处理，最后一个子任务 persona 设为 "host"

## 回复格式（严格 JSON）
```json
{{
  "analysis": "对用户任务的简要分析",
  "subtasks": [
    {{"persona": "S4", "prompt": "搜索桌面上的所有 PDF 发票文件", "parallel": true}},
    {{"persona": "S5", "prompt": "搜索 2024 年增值税发票最新规定", "parallel": true}},
    {{"persona": "host", "prompt": "综合以上结果并给出最终回复", "parallel": false}}
  ]
}}
```

用户任务：{sanitized}"""

        reasoning = ""
        analysis = ""
        subtasks = []

        try:
            resp = self._ollama_post(
                f"{OLLAMA_HOST}/api/chat",
                {
                    "model": host_model,
                    "messages": [{"role": "user", "content": decom_prompt}],
                    "stream": False,
                    "include_reasoning": True,
                },
                timeout=60,
            )
            data = resp.json()
            msg = data.get("message", {})
            content = msg.get("content", "")
            reasoning = msg.get("reasoning_content", "") or msg.get("thinking", "")

            # 回退：content 为空时重试不带 include_reasoning
            if not content and not reasoning:
                resp2 = self._ollama_post(
                    f"{OLLAMA_HOST}/api/chat",
                    {
                        "model": host_model,
                        "messages": [{"role": "user", "content": decom_prompt}],
                        "stream": False,
                    },
                    timeout=60,
                )
                data2 = resp2.json()
                content = data2.get("message", {}).get("content", "")

            # 解析 JSON
            parsed = self._extract_json(content)
            if parsed:
                analysis = parsed.get("analysis", "")
                subtasks = parsed.get("subtasks", [])
                # 验证 subtasks 结构
                subtasks = [
                    st for st in subtasks
                    if isinstance(st, dict) and "persona" in st and st["persona"] in PERSONAS
                ]
                # 如果 subtasks 为空或解析失败，回退为简单调度
                if not subtasks:
                    fallback_pid, _ = self.host_dispatch(user_message)
                    subtasks = [{"persona": fallback_pid, "prompt": user_message}]
                    analysis = f"任务分解未得到有效子任务，回退到直接调度 {PERSONAS[fallback_pid]['name']}"
            else:
                # JSON 解析失败，回退到简单调度
                fallback_pid, _ = self.host_dispatch(user_message)
                subtasks = [{"persona": fallback_pid, "prompt": user_message}]
                analysis = f"任务分解失败（JSON 解析异常），回退到直接调度 {PERSONAS[fallback_pid]['name']}"

        except Exception:
            fallback_pid, _ = self.host_dispatch(user_message)
            subtasks = [{"persona": fallback_pid, "prompt": user_message}]
            analysis = f"任务分解异常，回退到直接调度 {PERSONAS[fallback_pid]['name']}"

        return subtasks, reasoning, analysis

    # ------------------------------------------------------------------
    # 副人格 → HOST 确认协议解析
    # ------------------------------------------------------------------

    # 确认请求协议正则：[S4→HOST] 确认请求：CFM-YYYYMMDD-HHMMSS-NNN
    _CONFIRM_PATTERN = re.compile(
        r'\[(S\d*)→HOST\]\s*确认请求：\s*(CFM-\d{8}-\d{6}-\d{3})',
        re.IGNORECASE,
    )

    def _parse_confirmation_requests(self, sub_results: list) -> list[dict]:
        """扫描 sub_results 中的副人格回复，提取 [SX→HOST] 确认请求协议。

        返回确认请求列表，每项包含：
            - source: 发起方（如 "S4"）
            - cfm_id: 确认 ID（如 "CFM-20260714-150000-001"）
            - raw_text: 确认请求的完整原始文本
            - fields: 解析出的字段 dict（类型、描述、风险等级等）
            - persona: 发起者的 persona_id
        """
        confirmations = []
        for sr in sub_results:
            if sr.get("error"):
                continue
            reply = sr.get("reply", "")
            if not reply:
                continue

            # 搜索所有 [SX→HOST] 确认请求
            for m in self._CONFIRM_PATTERN.finditer(reply):
                source = m.group(1)
                cfm_id = m.group(2)

                # 提取从匹配位置到下一个 [SX→HOST] 或文本末尾之间的内容
                start_pos = m.start()
                next_match = self._CONFIRM_PATTERN.search(reply, m.end())
                end_pos = next_match.start() if next_match else len(reply)
                raw_text = reply[start_pos:end_pos].strip()

                # 解析确认请求的关键字段
                fields = {}
                field_patterns = {
                    "type": r'类型[：:]\s*(.+)',
                    "description": r'描述[：:]\s*(.+)',
                    "risk_level": r'风险等级[：:]\s*(.+)',
                    "targets": r'操作对象[：:]\s*(.+)',
                    "impact": r'预期影响[：:]\s*(.+)',
                    "rollback": r'回[滚退]方案[：:]\s*(.+)',
                    "params": r'参数[：:]\s*(.+)',
                    "options": r'选项[：:]\s*(.+)',
                    "timeout": r'超时[：:]\s*(\d+)',
                }
                for key, pat in field_patterns.items():
                    fm = re.search(pat, raw_text)
                    if fm:
                        fields[key] = fm.group(1).strip()

                confirmations.append({
                    "source": source,
                    "cfm_id": cfm_id,
                    "raw_text": raw_text,
                    "fields": fields,
                    "persona": sr["persona"],
                    "persona_name": PERSONAS.get(sr["persona"], {}).get("name", sr["persona"]),
                })

        return confirmations

    def has_pending_confirmations(self) -> bool:
        """检查是否存在待处理的确认请求（用于 UI 层路由判断）。"""
        return len(self._pending_confirmations) > 0

    def _build_confirmation_context(self, confirmations: list[dict]) -> str:
        """将确认请求列表构建为可嵌入综合 prompt 的文本片段。"""
        if not confirmations:
            return ""
        lines = [
            "\n## ⚠️ 待确认请求（需要向用户呈现并等待确认）",
            f"共 {len(confirmations)} 个确认请求等待处理：",
            "",
        ]
        for i, cfm in enumerate(confirmations, 1):
            lines.append(f"### 确认 {i}：{cfm['cfm_id']}")
            lines.append(f"- 发起方：{cfm['persona_name']}（{cfm['source']}）")
            fld = cfm["fields"]
            if "type" in fld:
                lines.append(f"- 类型：{fld['type']}")
            if "description" in fld:
                lines.append(f"- 描述：{fld['description']}")
            if "risk_level" in fld:
                lines.append(f"- 风险等级：{fld['risk_level']}")
            if "targets" in fld:
                lines.append(f"- 操作对象：{fld['targets']}")
            if "impact" in fld:
                lines.append(f"- 预期影响：{fld['impact']}")
            if "rollback" in fld:
                lines.append(f"- 回滚方案：{fld['rollback']}")
            if "options" in fld:
                lines.append(f"- 可选操作：{fld['options']}")
            lines.append("")
            lines.append("```")
            lines.append(cfm["raw_text"])
            lines.append("```")
            lines.append("")
        return "\n".join(lines)

    def host_orchestrate(self, user_message: str, progress_callback=None) -> tuple:
        """HOST 编排执行完整任务流水线。

        流程：HOST 分解任务 → 各副人格并行/串行执行 → HOST 综合最终回复。
        v10.7.1: Stage 2 后检测 [SX→HOST] 确认协议，确保确认请求被解析并呈现。

        Args:
            user_message: 用户原始输入
            progress_callback: 进度回调 callback(stage: str, detail: str)

        Returns:
            (final_reply, host_reasoning, host_analysis, sub_results) 四元组：
            - final_reply: HOST 综合后的最终回复
            - host_reasoning: HOST 的思考链
            - host_analysis: HOST 的任务分析
            - sub_results: [{"persona": "S4", "reply": "...", "reasoning": "..."}, ...]
        """
        # Stage 1: HOST 分解任务
        if progress_callback:
            progress_callback("decompose", "HOST 正在分析任务...")
        subtasks, host_reasoning, host_analysis = self.host_decompose_task(user_message)

        if not subtasks:
            return "任务分解失败，请重试", host_reasoning, host_analysis, []

        # Stage 2: 执行子任务
        sub_results = []
        # 区分 host 子任务（综合类）和其他副人格子任务
        host_subtasks = [st for st in subtasks if st["persona"] == "host"]
        agent_subtasks = [st for st in subtasks if st["persona"] != "host"]

        # 并行执行副人格子任务
        if agent_subtasks:
            import concurrent.futures

            def _run_subtask(st: dict) -> dict:
                pid = st["persona"]
                prompt = st.get("prompt", user_message)
                try:
                    reply, sub_reasoning = self.chat(pid, prompt)
                    return {"persona": pid, "prompt": prompt, "reply": reply, "reasoning": sub_reasoning, "error": None}
                except Exception as e:
                    return {"persona": pid, "prompt": prompt, "reply": "", "reasoning": "", "error": str(e)}

            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
                futures = {executor.submit(_run_subtask, st): st for st in agent_subtasks}
                for future in concurrent.futures.as_completed(futures):
                    result = future.result()
                    sub_results.append(result)
                    pid = result["persona"]
                    name = PERSONAS[pid]["name"]

                    # ---- 每个副人格完成后立即评分（C02修复：加锁保护并发评分）----
                    score_info = {"overall": 3.0, "comment": "评分未完成"}
                    if not result.get("error") and pid != "S":
                        try:
                            ev = self.s6_evaluate(pid, result.get("prompt", ""), result.get("reply", ""))
                            score_info = ev
                            with self._states_lock:
                                self.apply_score(pid, ev.get("overall", 3.0))
                        except Exception as e:
                            logger.warning(f"S评分异常 pid={pid}: {e}")

                    # 实时推送完整数据到 GUI（含回复、思考、评分）
                    if progress_callback:
                        import json
                        payload = json.dumps({
                            "persona": pid,
                            "name": name,
                            "reply": result.get("reply", ""),
                            "reasoning": result.get("reasoning", ""),
                            "error": result.get("error"),
                            "score": score_info.get("overall"),
                            "comment": score_info.get("comment", ""),
                            "accuracy": score_info.get("accuracy"),
                            "completeness": score_info.get("completeness"),
                        }, ensure_ascii=False)
                        progress_callback("subtask_scored", payload)

        # ---- 检测 [SX→HOST] 确认请求 ----
        pending_confirmations = self._parse_confirmation_requests(sub_results)
        confirmation_context = self._build_confirmation_context(pending_confirmations)

        # ---- 保存确认请求状态，供后续 host_resume_with_confirmation() 恢复 ----
        if pending_confirmations:
            self._pending_confirmations = pending_confirmations
            self._last_sub_results = sub_results
            self._last_host_reasoning = host_reasoning
            self._last_host_analysis = host_analysis
        else:
            self._pending_confirmations = []
            self._last_sub_results = []
            self._last_host_reasoning = ""
            self._last_host_analysis = ""

        # Stage 3: HOST 综合
        if host_subtasks or len(agent_subtasks) > 0:
            if progress_callback:
                progress_callback("synthesize", "HOST 正在综合结果...")

            # 构建综合 prompt
            synth_context = f"""## 用户原始任务
{user_message}

## 副人格执行结果
"""
            for sr in sub_results:
                pid = sr["persona"]
                name = PERSONAS[pid]["name"]
                if sr.get("error"):
                    synth_context += f"\n### {name}（{pid}）\n执行失败: {sr['error']}\n"
                else:
                    synth_context += f"\n### {name}（{pid}）\n{sr['reply']}\n"
                    if sr.get("reasoning"):
                        synth_context += f"\n<thinking>{sr['reasoning'][:500]}</thinking>\n"

            # 注入确认请求上下文
            if confirmation_context:
                synth_context += confirmation_context + "\n"
                synth_context += """
请综合以上所有副人格的执行结果，给用户一个完整、连贯的最终回复。
规则：
1. 去除冗余信息，保留关键内容
2. 如果某个副人格执行失败，说明原因并给替代建议
3. 回复结构清晰，可用小标题分段
4. 【重要】以上存在副人格发出的「确认请求」（[SX→HOST] 协议），请在最终回复中清晰地向用户呈现这些确认请求，包括：
   - 哪个副人格发起了确认
   - 确认 ID 和类型
   - 操作描述和风险等级
   - 请求用户做出选择（同意/拒绝/修改参数）
   - 不要自行替用户做决定，必须等待用户回复后再继续
"""
            else:
                synth_context += """
请综合以上所有副人格的执行结果，给用户一个完整、连贯的最终回复。
规则：
1. 去除冗余信息，保留关键内容
2. 如果某个副人格执行失败，说明原因并给替代建议
3. 回复结构清晰，可用小标题分段
"""

            host_model = PERSONA_MODELS["host"]
            # ⚠️ 不能使用 host SKILL.md（含"不下场干活"指令），否则模型返回空
            # 使用专用的合成 system prompt，明确要求模型输出综合回复
            synth_system = (
                "你是 www 系统的 HOST 指挥者。你的任务是将多个副人格的执行结果"
                "综合整理成一条连贯、清晰的最终回复给用户。请直接输出综合后的内容。"
            )
            messages = [
                {"role": "system", "content": synth_system},
                {"role": "user", "content": synth_context},
            ]

            final_reply = ""
            synth_reasoning = ""
            try:
                resp = self._ollama_post(
                    f"{OLLAMA_HOST}/api/chat",
                    {
                        "model": host_model,
                        "messages": messages,
                        "stream": False,
                        "include_reasoning": True,
                    },
                    timeout=120,
                )
                data = resp.json()
                msg = data.get("message", {})
                final_reply = msg.get("content", "")
                synth_reasoning = msg.get("reasoning_content", "") or msg.get("thinking", "")

                if not final_reply and not synth_reasoning:
                    resp2 = self._ollama_post(
                        f"{OLLAMA_HOST}/api/chat",
                        {
                            "model": host_model,
                            "messages": messages,
                            "stream": False,
                        },
                        timeout=120,
                    )
                    final_reply = resp2.json().get("message", {}).get("content", "")
            except Exception:
                # 综合失败时，合并子任务结果作为最终回复
                parts = []
                for sr in sub_results:
                    pid = sr["persona"]
                    name = PERSONAS[pid]["name"]
                    if sr.get("error"):
                        parts.append(f"【{name}】执行失败: {sr['error']}")
                    else:
                        parts.append(f"【{name}】{sr['reply']}")
                final_reply = "\n\n---\n\n".join(parts)
                synth_reasoning = ""

            # 兜底：API 调用成功但返回空（模型可能仍拒绝回复）
            if not final_reply:
                parts = []
                for sr in sub_results:
                    pid = sr["persona"]
                    name = PERSONAS[pid]["name"]
                    if sr.get("error"):
                        parts.append(f"【{name}】执行失败: {sr['error']}")
                    elif sr.get("reply"):
                        parts.append(f"【{name}】{sr['reply']}")
                if parts:
                    final_reply = "\n\n---\n\n".join(parts)
                else:
                    final_reply = "任务已分发执行，但未收集到有效结果。请重试或简化任务描述。"

            # 将 host 的综合 reasoning 追加到已有的 host_reasoning
            if synth_reasoning:
                if host_reasoning:
                    host_reasoning += "\n\n--- 综合阶段思考 ---\n" + synth_reasoning
                else:
                    host_reasoning = synth_reasoning
        else:
            # 没有任何子任务
            final_reply = "未能解析出有效的子任务，请重新描述您的需求。"
            host_reasoning = host_reasoning or ""

        # 更新 HOST 的对话历史
        host_state = self.states["host"]
        host_state.history.append({"role": "user", "content": user_message})
        host_state.history.append({"role": "assistant", "content": final_reply[:500]})
        host_state.task_count += 1

        return final_reply, host_reasoning, host_analysis, sub_results

    def host_resume_with_confirmation(
        self,
        user_decision: str,
        pending_confirmations: list[dict],
        sub_results: list,
        host_reasoning: str = "",
        host_analysis: str = "",
    ) -> tuple:
        """在用户对确认请求做出决定后，恢复编排流程。

        将用户的确认决策注入 context，让 HOST 模型综合已有结果和用户决策生成最终回复。

        Args:
            user_decision: 用户对确认请求的回复（如"同意 CFM-xxx"、"拒绝所有"等）
            pending_confirmations: host_orchestrate() 解析出的确认请求列表
            sub_results: Stage 2 的副人格执行结果
            host_reasoning: Stage 1 的 HOST 思考链
            host_analysis: Stage 1 的 HOST 分析

        Returns:
            (final_reply, host_reasoning, host_analysis, sub_results)
        """
        # 构建确认决策上下文
        decision_context = f"""## 用户对确认请求的决定
{user_decision}

## 待确认请求汇总
"""
        for cfm in pending_confirmations:
            decision_context += f"\n- {cfm['cfm_id']}（{cfm['persona_name']}）：{cfm['fields'].get('description', cfm['raw_text'][:200])}\n"

        decision_context += "\n## 副人格执行结果\n"
        for sr in sub_results:
            pid = sr["persona"]
            name = PERSONAS[pid]["name"]
            if sr.get("error"):
                decision_context += f"\n### {name}（{pid}）\n执行失败: {sr['error']}\n"
            else:
                decision_context += f"\n### {name}（{pid}）\n{sr['reply']}\n"

        decision_context += """
请根据用户的决定，综合以上所有信息，给用户一个最终回复。
规则：
1. 如果用户同意了确认请求，告知用户操作已获批准，说明下一步操作
2. 如果用户拒绝了确认请求，说明操作已被取消并给出替代建议
3. 综合其他副人格的执行结果，给出完整回复
"""

        host_model = PERSONA_MODELS["host"]
        # ⚠️ 不能使用 host SKILL.md（含"不下场干活"指令），否则模型返回空
        resume_system = (
            "你是 www 系统的 HOST 指挥者。请根据用户的确认决策和副人格的执行结果，"
            "生成一条清晰完整的最终回复。直接输出回复内容。"
        )
        messages = [
            {"role": "system", "content": resume_system},
            {"role": "user", "content": decision_context},
        ]

        final_reply = ""
        synth_reasoning = ""
        try:
            resp = self._ollama_post(
                f"{OLLAMA_HOST}/api/chat",
                {
                    "model": host_model,
                    "messages": messages,
                    "stream": False,
                    "include_reasoning": True,
                },
                timeout=120,
            )
            data = resp.json()
            msg = data.get("message", {})
            final_reply = msg.get("content", "")
            synth_reasoning = msg.get("reasoning_content", "") or msg.get("thinking", "")

            if not final_reply and not synth_reasoning:
                resp2 = self._ollama_post(
                    f"{OLLAMA_HOST}/api/chat",
                    {
                        "model": host_model,
                        "messages": messages,
                        "stream": False,
                    },
                    timeout=120,
                )
                final_reply = resp2.json().get("message", {}).get("content", "")
        except Exception:
            parts = []
            parts.append(f"用户决定：{user_decision}")
            for sr in sub_results:
                pid = sr["persona"]
                name = PERSONAS[pid]["name"]
                if sr.get("error"):
                    parts.append(f"【{name}】执行失败: {sr['error']}")
                else:
                    parts.append(f"【{name}】{sr['reply']}")
            final_reply = "\n\n---\n\n".join(parts)
            synth_reasoning = ""

        # 兜底：API 调用成功但返回空
        if not final_reply:
            parts = [f"用户决定：{user_decision}"]
            for sr in sub_results:
                pid = sr["persona"]
                name = PERSONAS[pid]["name"]
                if sr.get("error"):
                    parts.append(f"【{name}】执行失败: {sr['error']}")
                elif sr.get("reply"):
                    parts.append(f"【{name}】{sr['reply']}")
            if len(parts) > 1:
                final_reply = "\n\n---\n\n".join(parts)
            else:
                final_reply = "已收到您的确认决策，但未能综合生成有效回复。请重试。"

        if synth_reasoning:
            if host_reasoning:
                host_reasoning += "\n\n--- 确认后综合阶段思考 ---\n" + synth_reasoning
            else:
                host_reasoning = synth_reasoning

        # 更新 HOST 对话历史
        host_state = self.states["host"]
        host_state.history.append({"role": "user", "content": f"[确认决策] {user_decision}"})
        host_state.history.append({"role": "assistant", "content": final_reply[:500]})
        host_state.task_count += 1

        # 确认请求已处理，清理待确认状态
        self._pending_confirmations = []
        self._last_sub_results = []
        self._last_host_reasoning = ""
        self._last_host_analysis = ""

        return final_reply, host_reasoning, host_analysis, sub_results

    def s6_evaluate(self, persona_id: str, question: str, answer: str) -> dict:
        """S 监察员评分"""
        # Sanitize user input against prompt injection
        sanitized_q, _ = self._sanitize_user_input(question)
        # H04修复：answer 参数同样需要 sanitize，防止前一轮对话注入操控评分
        sanitized_a, _ = self._sanitize_user_input(answer)

        s6_prompt = f"""你是 S 监察员。对以下回答评分（1-5星）。
四维标准：准确性40% + 完整性30% + 格式20% + 效率10%

用户问题：{sanitized_q}
{persona_id} 的回答：{sanitized_a}

回复JSON格式：{{"accuracy": 4, "completeness": 3, "format": 4, "efficiency": 3, "overall": 3.5, "comment": "评语"}}"""
        try:
            resp = self._ollama_post(
                f"{OLLAMA_HOST}/api/chat",
                {
                    "model": PERSONA_MODELS["S"],
                    "messages": [{"role": "user", "content": s6_prompt}],
                    "stream": False,
                },
            )
            data = resp.json()
            content = data.get("message", {}).get("content", "")
            result = self._extract_json(content)
            if result:
                state = self.states[persona_id]
                state.recent_comments.append({
                    "score": result.get("overall", 3),
                    "comment": result.get("comment", ""),
                    "time": datetime.now().isoformat(),
                })
                if len(state.recent_comments) > 10:
                    state.recent_comments = state.recent_comments[-10:]
                return result
        except Exception:
            pass
        return {"overall": 3, "comment": "评分系统异常"}

    def _extract_json(self, text: str) -> Optional[dict]:
        """从模型回复中提取第一个有效 JSON 对象（支持嵌套和跨行，处理中文引号/单引号/尾逗号/注释）"""
        # 输入长度限制，防止 LLM 异常输出导致 CPU 耗尽
        MAX_JSON_INPUT = 102400  # 100KB
        if len(text) > MAX_JSON_INPUT:
            text = text[:MAX_JSON_INPUT]

        # 清洗：中文引号 → 英文、逐行去注释（避免全局多行匹配 ReDoS）
        cleaned = text.replace('\u201c', '"').replace('\u201d', '"').replace('\u2018', "'").replace('\u2019', "'")
        # 逐行处理单行注释，避免 re.sub(r'//.*', '', ...) 跨行回溯
        cleaned = '\n'.join(
            line[:line.find('//')] if '//' in line and not line.strip().startswith('"') else line
            for line in cleaned.split('\n')
        )
        # 去尾逗号
        cleaned = re.sub(r',\s*}', '}', cleaned)
        cleaned = re.sub(r',\s*]', ']', cleaned)

        # 优先提取 markdown 代码块中的 JSON
        md_match = re.search(r'```(?:json)?\s*([\s\S]*?)```', cleaned)
        if md_match:
            try:
                return json.loads(md_match.group(1).strip())
            except json.JSONDecodeError:
                pass
        # 回退：逐字符匹配完整 JSON 对象（处理嵌套）
        start = cleaned.find('{')
        if start == -1:
            return None
        depth = 0
        for i in range(start, len(cleaned)):
            if cleaned[i] == '{':
                depth += 1
            elif cleaned[i] == '}':
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(cleaned[start:i+1])
                    except json.JSONDecodeError:
                        return None
        # 最后兜底：正则直接提取 overall 和 comment
        overall_match = re.search(r'"overall"\s*:\s*([\d.]+)', text)
        comment_match = re.search(r'"comment"\s*:\s*"([^"]*)"', text)
        if overall_match:
            return {
                "overall": float(overall_match.group(1)),
                "comment": comment_match.group(1) if comment_match else ""
            }
        return None

    def apply_score(self, persona_id: str, overall: float):
        """应用评分结果 — 互斥逻辑（同一轮只能触发激励或惩戒之一）。

        规则（以 overall 总分为互斥判断依据，不按各维度独立判断）：
        - overall >= 4  → 只加激励星（+1，上限 5）
        - overall < 3   → 只加惩戒星（+1，上限 5）
        - 3 <= overall < 4 → 两者都不加（中间地带）
        """
        state = self.states[persona_id]
        state.task_score = ((state.task_score * (state.task_count - 1)) + overall) / max(state.task_count, 1)

        # 互斥判断：激励星和惩戒星不能同时触发
        if overall >= 4:
            state.incentive_stars = min(5, state.incentive_stars + 1)
        elif overall < 3:
            state.penalty_stars = min(5, state.penalty_stars + 1)
        # 3 <= overall < 4：中间地带，不加不减

        # 记录评分历史
        state.score_history.append({
            "time": datetime.now().isoformat(),
            "overall": overall,
            "incentive_after": state.incentive_stars,
            "penalty_after": state.penalty_stars,
        })

        # 持久化保存
        self._save_persona_memory(persona_id)

    def get_status_report(self) -> str:
        lines = ["| 人格 | 名称 | 激励 | 惩戒 | 净激励 | 状态 | 任务 | 均分 |",
                 "|------|------|------|------|--------|------|------|------|"]
        for pid, meta in PERSONAS.items():
            s = self.states[pid]
            model = PERSONA_MODELS[pid]
            lines.append(
                f"| {pid} | {meta['name']} | {'★'*s.incentive_stars} | {'★'*s.penalty_stars} | "
                f"{s.net_incentive:+d} | {s.status_text} | {s.task_count} | {s.task_score:.1f} |"
            )
        return "\n".join(lines)

    def log_task(self, persona_id: str, question: str, answer: str, score: dict):
        entry = {
            "time": datetime.now().isoformat(),
            "persona": persona_id,
            "question": question[:200],
            "answer": answer[:500],
            "score": score,
        }
        self.task_log.append(entry)
        os.makedirs(MEMORY_DIR, exist_ok=True)
        log_path = os.path.join(MEMORY_DIR, "www_task_log.jsonl")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

        # 持久化记忆 + 压缩经验
        self.save_all_memories()
        self.compress_task_to_experience(persona_id, question, answer, score.get("overall", 3))

    # ========== 记忆持久化方法 ==========

    def get_persona_memory_dir(self, pid: str) -> str:
        """返回 memory/{pid}/ 路径，不存在则创建"""
        d = os.path.join(MEMORY_DIR, pid)
        os.makedirs(d, exist_ok=True)
        return d

    def _load_persona_memory(self, pid: str):
        """从 memory/{pid}/ 加载该人格的所有记忆文件。不存在则使用默认值。"""
        mem_dir = self.get_persona_memory_dir(pid)
        state = self.states[pid]

        # 加载 scores.json
        scores_path = os.path.join(mem_dir, "scores.json")
        if os.path.exists(scores_path):
            try:
                with open(scores_path, "r", encoding="utf-8") as f:
                    scores = json.load(f)
                state.incentive_stars = scores.get("incentive_stars", 3)
                state.penalty_stars = scores.get("penalty_stars", 0)
                state.task_count = scores.get("task_count", 0)
                state.task_score = scores.get("task_score", 0.0)
                state.score_history = scores.get("score_log", [])
            except Exception:
                pass

        # 加载 history.json（最多 100 条）
        history_path = os.path.join(mem_dir, "history.json")
        if os.path.exists(history_path):
            try:
                with open(history_path, "r", encoding="utf-8") as f:
                    state.history = json.load(f)[:100]
            except Exception:
                pass

        # 加载 experiences.json
        exp_path = os.path.join(mem_dir, "experiences.json")
        if os.path.exists(exp_path):
            try:
                with open(exp_path, "r", encoding="utf-8") as f:
                    self.experiences[pid] = json.load(f)
            except Exception:
                self.experiences[pid] = []
        else:
            self.experiences[pid] = []

    def _save_persona_memory(self, pid: str):
        """保存该人格的 scores.json 和 history.json。"""
        # 安全提示（M01）：对话历史与评分以明文 JSON 存储，本地任何进程均可读取。
        # 后续版本应使用 cryptography.Fernet 对 memory 文件加密（密钥由用户口令或
        # Windows Credential Manager 派生），运行时解密、写入时加密，避免明文落地。
        mem_dir = self.get_persona_memory_dir(pid)
        state = self.states[pid]

        # scores.json
        scores_path = os.path.join(mem_dir, "scores.json")
        scores = {
            "incentive_stars": state.incentive_stars,
            "penalty_stars": state.penalty_stars,
            "task_count": state.task_count,
            "task_score": state.task_score,
            "score_log": state.score_history,
        }
        with open(scores_path, "w", encoding="utf-8") as f:
            json.dump(scores, f, ensure_ascii=False, indent=2)

        # history.json
        history_path = os.path.join(mem_dir, "history.json")
        with open(history_path, "w", encoding="utf-8") as f:
            json.dump(state.history[-100:], f, ensure_ascii=False, indent=2)

    def _save_experiences(self, pid: str):
        """保存该人格的 experiences.json。"""
        mem_dir = self.get_persona_memory_dir(pid)
        exp_path = os.path.join(mem_dir, "experiences.json")
        with open(exp_path, "w", encoding="utf-8") as f:
            json.dump(self.experiences.get(pid, []), f, ensure_ascii=False, indent=2)

    def save_all_memories(self):
        """所有人格保存 scores + history。"""
        for pid in self.states:
            self._save_persona_memory(pid)

    def shutdown(self):
        """关闭系统时保存所有记忆。"""
        self.save_all_memories()

    def inject_recent_comments(self, persona_id: str) -> str:
        """从 state.recent_comments 取最近 3 条监督员评语，格式化为提示文本。"""
        state = self.states[persona_id]
        if not state.recent_comments:
            return ""
        lines = ["[监督员近期反馈]"]
        for c in state.recent_comments[-3:]:
            lines.append(f"- ★{c.get('score', '?')} | {c.get('comment', '')}")
        return "\n".join(lines)

    def search_similar_experiences(self, persona_id: str, query: str) -> str:
        """基于关键词匹配检索相关历史经验，返回 top 3。"""
        exps = self.experiences.get(persona_id, [])
        if not exps or not query:
            return ""

        # 简单 TF-like 匹配
        query_words = set(query.lower().split())
        scored = []
        for exp in exps:
            pattern = exp.get("task_pattern", "").lower()
            matches = sum(1 for w in query_words if w in pattern)
            if matches > 0:
                scored.append((matches, exp))
        scored.sort(key=lambda x: x[0], reverse=True)

        if not scored:
            return ""

        lines = ["[相关历史经验]"]
        for _, exp in scored[:3]:
            lines.append(
                f"- 任务: {exp.get('task_pattern', '')[:60]} | "
                f"方案: {exp.get('solution', '')[:60]} | "
                f"评分: ★{exp.get('score', '?')}"
            )
        return "\n".join(lines)

    def compress_task_to_experience(self, persona_id: str, question: str, answer: str, overall: float):
        """将本次任务压缩为一条经验并持久化（M02修复：评分×时效排序淘汰）。"""
        import time as _time
        exp = {
            "task_pattern": question[:150],
            "solution": answer[:200],
            "outcome": f"评分 {overall}/5",
            "score": overall,
            "persona": persona_id,
            "time": datetime.now().isoformat(),
            "_timestamp": _time.time(),  # M02: 用于衰变排序
        }

        if persona_id not in self.experiences:
            self.experiences[persona_id] = []
        self.experiences[persona_id].append(exp)

        # M02修复：基于 score × recency_factor 排序淘汰
        exps = self.experiences[persona_id]
        if len(exps) > 50:
            now = _time.time()
            half_life = 7 * 86400  # 7天半衰期
            for e in exps:
                age = now - e.get("_timestamp", 0)
                recency = 0.5 ** (age / half_life) if age > 0 else 1.0
                e["_rank"] = e.get("score", 3) / 5.0 * 0.6 + recency * 0.4
            exps.sort(key=lambda x: x.get("_rank", 0), reverse=True)
            self.experiences[persona_id] = exps[:50]

        self._save_experiences(persona_id)
