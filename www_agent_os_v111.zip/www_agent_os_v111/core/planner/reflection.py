"""
Reflection — 任务执行反思与自我修正

职责：
- 子任务执行后结果反思
- 错误分析与修正建议
- 计划调整（动态重规划）
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from core.planner.planner import Plan, SubTask, TaskStatus

logger = logging.getLogger(__name__)


class ReflectionType(Enum):
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILURE = "failure"
    UNCERTAIN = "uncertain"


@dataclass
class ReflectionResult:
    """反思结果。"""
    type: ReflectionType
    task_id: str
    summary: str
    issues: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    confidence: float = 0.5
    should_retry: bool = False
    adjusted_params: Dict[str, Any] = field(default_factory=dict)


class ReflectionLoop:
    """反思循环 — 任务执行后的自我评估与修正。

    Usage::

        loop = ReflectionLoop(llm_callback=my_llm_fn)
        result = loop.reflect(subtask, output)
        if result.should_retry:
            # 调整参数后重试
            pass
    """

    def __init__(self, llm_callback: Optional[Callable] = None) -> None:
        self._llm = llm_callback
        self._reflection_log: List[ReflectionResult] = []

    def reflect(self, task: SubTask, output: Any,
                expected: Optional[Any] = None) -> ReflectionResult:
        """对子任务执行结果进行反思。

        Args:
            task: 已执行的子任务。
            output: 执行结果。
            expected: 期望结果（可选）。

        Returns:
            ReflectionResult 反思结论。
        """
        # 基础规则判断
        if task.status == TaskStatus.COMPLETED:
            if expected is not None and output != expected:
                return ReflectionResult(
                    type=ReflectionType.PARTIAL,
                    task_id=task.id,
                    summary="任务完成但结果与预期不符",
                    issues=[f"期望: {expected}, 实际: {output}"],
                    suggestions=["检查输入参数", "尝试不同的工具配置"],
                    confidence=0.4,
                    should_retry=True,
                )
            return ReflectionResult(
                type=ReflectionType.SUCCESS,
                task_id=task.id,
                summary="任务成功完成",
                confidence=0.9,
            )

        elif task.status == TaskStatus.FAILED:
            # 分析失败原因
            issues = self._analyze_failure(task)
            return ReflectionResult(
                type=ReflectionType.FAILURE,
                task_id=task.id,
                summary=f"任务失败: {task.error}",
                issues=issues,
                suggestions=self._generate_fix_suggestions(task, issues),
                confidence=0.1,
                should_retry=task.retries < task.max_retries,
            )

        return ReflectionResult(
            type=ReflectionType.UNCERTAIN,
            task_id=task.id,
            summary="任务状态不确定",
            confidence=0.3,
        )

    def _analyze_failure(self, task: SubTask) -> List[str]:
        """分析失败原因。"""
        issues = []
        error_msg = task.error.lower()

        if "timeout" in error_msg:
            issues.append("执行超时 — 可能需要增加超时时间或拆分任务")
        if "permission" in error_msg or "denied" in error_msg:
            issues.append("权限不足 — 检查角色权限配置")
        if "not found" in error_msg:
            issues.append("目标资源不存在 — 检查路径/标识符")
        if "connection" in error_msg:
            issues.append("连接失败 — 检查网络/服务状态")
        if "memory" in error_msg:
            issues.append("内存不足 — 减少并发任务或增加内存限制")

        if not issues:
            issues.append(f"未知错误: {task.error}")

        return issues

    def _generate_fix_suggestions(self, task: SubTask, issues: List[str]) -> List[str]:
        """生成修复建议。"""
        suggestions = []
        for issue in issues:
            if "超时" in issue:
                suggestions.append("增加 timeouts 参数或拆分大任务为小步骤")
            if "权限" in issue:
                suggestions.append("确认当前角色权限，或请求 HOST 授权")
            if "不存在" in issue:
                suggestions.append("检查路径拼写，确认目标文件/目录存在")
            if "连接" in issue:
                suggestions.append("确认服务已启动，稍后重试")
            if "内存" in issue:
                suggestions.append("减少批处理大小")
        return suggestions

    def adjust_plan(self, plan: Plan, reflection: ReflectionResult) -> Plan:
        """根据反思结果动态调整计划。

        Args:
            plan: 原始计划。
            reflection: 反思结果。

        Returns:
            调整后的计划。
        """
        if reflection.type == ReflectionType.SUCCESS:
            return plan

        task = next((t for t in plan.subtasks if t.id == reflection.task_id), None)
        if not task:
            return plan

        if reflection.should_retry and task.retries < task.max_retries:
            task.status = TaskStatus.PENDING
            if reflection.adjusted_params:
                task.params.update(reflection.adjusted_params)
            logger.info("计划调整: %s 将重试 (第 %d 次)", task.id, task.retries + 1)

        return plan

    def get_log(self, limit: int = 20) -> List[ReflectionResult]:
        """获取最近的反思日志。"""
        return self._reflection_log[-limit:]
