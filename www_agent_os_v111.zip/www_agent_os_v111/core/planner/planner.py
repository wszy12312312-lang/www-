"""
Planner — 任务拆解系统

职责：
- 复杂任务拆解为子任务 DAG
- 依赖关系排序与并行度分析
- 子任务执行的进度追踪
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class SubTask:
    """子任务定义。"""
    id: str
    name: str
    description: str = ""
    depends_on: List[str] = field(default_factory=list)
    tool: str = ""  # 对应工具名称
    params: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    result: Any = None
    error: str = ""
    retries: int = 0
    max_retries: int = 2


@dataclass
class Plan:
    """任务执行计划。"""
    id: str
    goal: str
    subtasks: List[SubTask] = field(default_factory=list)
    created_at: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_ready_tasks(self) -> List[SubTask]:
        """获取所有就绪的子任务（依赖全部满足）。"""
        ready = []
        completed_ids = {t.id for t in self.subtasks if t.status == TaskStatus.COMPLETED}

        for task in self.subtasks:
            if task.status != TaskStatus.PENDING:
                continue
            if all(dep in completed_ids for dep in task.depends_on):
                ready.append(task)
        return ready

    def is_complete(self) -> bool:
        """计划是否全部完成。"""
        return all(t.status in (TaskStatus.COMPLETED, TaskStatus.SKIPPED) for t in self.subtasks)

    def has_failed(self) -> bool:
        """计划是否有失败且不可重试的任务。"""
        for t in self.subtasks:
            if t.status == TaskStatus.FAILED and t.retries >= t.max_retries:
                return True
        return False

    def progress(self) -> Dict[str, Any]:
        """进度报告。"""
        total = len(self.subtasks)
        completed = sum(1 for t in self.subtasks if t.status == TaskStatus.COMPLETED)
        failed = sum(1 for t in self.subtasks if t.status == TaskStatus.FAILED)
        running = sum(1 for t in self.subtasks if t.status == TaskStatus.RUNNING)
        return {
            "total": total,
            "completed": completed,
            "failed": failed,
            "running": running,
            "pending": total - completed - failed - running,
            "percent": round(completed / total * 100, 1) if total > 0 else 0,
        }


class TaskDecomposer:
    """任务拆解器。

    将用户的高层目标拆解为可执行的子任务序列。
    """

    def __init__(self, llm_callback: Optional[Callable] = None) -> None:
        self._llm = llm_callback

    def decompose(self, goal: str, available_tools: Optional[List[str]] = None,
                  context: Optional[Dict[str, Any]] = None) -> Plan:
        """将目标拆解为子任务计划。

        Args:
            goal: 用户的高层目标描述。
            available_tools: 可用工具列表。
            context: 上下文信息。

        Returns:
            Plan 对象。
        """
        plan_id = f"plan_{hash(goal) & 0xFFFF:04x}"

        if self._llm:
            return self._llm_decompose(plan_id, goal, available_tools, context)

        # 无 LLM 时的规则拆解
        return self._rule_decompose(plan_id, goal, available_tools or [])

    def _rule_decompose(self, plan_id: str, goal: str, tools: List[str]) -> Plan:
        """基于规则的简单拆解（无 LLM 回退）。"""
        import datetime

        subtasks = []

        keywords_to_tools = {
            "文件": "file_operations",
            "搜索": "search",
            "读写": "file_read_write",
            "分析": "analysis",
            "报告": "report_generation",
            "整理": "file_organize",
            "发票": "invoice_processing",
            "图片": "image_processing",
            "记忆": "memory_access",
        }

        for keyword, tool in keywords_to_tools.items():
            if keyword in goal:
                subtasks.append(SubTask(
                    id=f"{plan_id}_t{len(subtasks):02d}",
                    name=f"{keyword}处理",
                    description=f"执行与 {keyword} 相关的操作",
                    tool=tool,
                    depends_on=[s.id for s in subtasks] if subtasks else [],
                ))

        if not subtasks:
            subtasks.append(SubTask(
                id=f"{plan_id}_t00",
                name="主任务执行",
                description=goal,
            ))

        return Plan(
            id=plan_id,
            goal=goal,
            subtasks=subtasks,
            created_at=datetime.datetime.now().isoformat(),
        )

    def _llm_decompose(self, plan_id: str, goal: str, tools: Optional[List[str]],
                       context: Optional[Dict[str, Any]]) -> Plan:
        """使用 LLM 进行智能拆解。"""
        # 预留 LLM 调用接口
        # 实际使用时由调度层注入 LLM callback
        return self._rule_decompose(plan_id, goal, tools or [])


class Planner:
    """任务规划器 — 管理执行计划和进度追踪。"""

    def __init__(self) -> None:
        self._decomposer = TaskDecomposer()
        self._current_plan: Optional[Plan] = None
        self._history: List[Plan] = []

    def plan(self, goal: str, available_tools: Optional[List[str]] = None,
             context: Optional[Dict[str, Any]] = None) -> Plan:
        """创建执行计划。"""
        plan = self._decomposer.decompose(goal, available_tools, context)
        self._current_plan = plan
        return plan

    def execute(self, executor: Callable[[SubTask], Any]) -> Plan:
        """执行当前计划。

        Args:
            executor: 子任务执行器，接收 SubTask，返回结果。
        """
        if not self._current_plan:
            raise RuntimeError("没有当前计划")

        plan = self._current_plan

        while not plan.is_complete():
            ready = plan.get_ready_tasks()
            if not ready:
                if plan.has_failed():
                    logger.error("计划执行失败: 存在不可恢复的错误")
                    break
                # 所有就绪任务完成但还有任务 pending — 检查死锁
                pending = [t for t in plan.subtasks if t.status == TaskStatus.PENDING]
                logger.warning("可能存在依赖死锁: %s", [t.id for t in pending])
                break

            for task in ready:
                task.status = TaskStatus.RUNNING
                try:
                    task.result = executor(task)
                    task.status = TaskStatus.COMPLETED
                    logger.info("子任务完成: %s", task.id)
                except Exception as e:
                    task.error = str(e)
                    task.retries += 1
                    if task.retries >= task.max_retries:
                        task.status = TaskStatus.FAILED
                    else:
                        task.status = TaskStatus.PENDING
                        logger.warning("子任务重试: %s (%d/%d)", task.id, task.retries, task.max_retries)

        self._history.append(plan)
        return plan

    @property
    def current_plan(self) -> Optional[Plan]:
        return self._current_plan

    def get_progress(self) -> Dict[str, Any]:
        if not self._current_plan:
            return {}
        return self._current_plan.progress()
