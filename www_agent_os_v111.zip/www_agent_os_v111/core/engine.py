"""
WWW Agent OS v11.0 — 统一引擎

替代旧版 HostEntry + WWWSystem 双轨架构，提供单一处理管线：

    User Input
      │
      ▼
    InputSanitizer → 安全过滤
      │
      ▼
    Dispatcher → 意图分析 + Persona 调度
      │
      ▼
    Executor → Chat / Orchestrate / Resume
      │               ├─ 单人格：ChatService.chat()
      │               └─ 多人格：Orchestrator.orchestrate()
      ▼
    Scorer → ScoringEngine 评分 + 奖惩
      │
      ▼
    Memory → MemoryStore 持久化 + 经验压缩
      │
      ▼
    Response

所有模块通过 DIContainer 注入，无全局单例，无 Feature Flag 分支。
"""

from __future__ import annotations

import json
import logging
import os
import re
import sys
import time
import threading
import concurrent.futures
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("Engine")

# 确保项目根目录在 sys.path 中
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from config.app_config import (
    OLLAMA_HOST, OLLAMA_API_KEY, OLLAMA_TIMEOUT,
    PERSONA_MODELS, PERSONAS, SKILL_DIR, MEMORY_DIR,
)
from core.input_sanitizer import InputSanitizer, SanitizerResult
from core.evaluation.scoring_engine import ScoringEngine
from memory.store import MemoryStore
from events.bus import EventBus
from task.manager import TaskManager
from tools.rate_limiter import MultiRateLimiter


# ------------------------------------------------------------------
# 数据结构
# ------------------------------------------------------------------

@dataclass
class EngineResult:
    """引擎处理结果。"""

    reply: str = ""
    persona_id: str = "host"
    persona_name: str = ""
    reasoning: str = ""
    score: dict = field(default_factory=dict)
    sanitizer_findings: list[str] = field(default_factory=list)
    sub_results: list[dict] = field(default_factory=list)
    pending_confirmations: list[dict] = field(default_factory=list)
    elapsed_ms: float = 0.0
    error: Optional[str] = None
    stages: list[str] = field(default_factory=list)
    """各阶段执行记录，用于调试和 UI 展示。"""


# ------------------------------------------------------------------
# 旧版 PersonaState 迁移（从 ollama_service.py 提取）
# ------------------------------------------------------------------

@dataclass
class PersonaState:
    """人格运行时状态 — 激励/惩戒/任务/评分。"""

    persona_id: str
    incentive_stars: int = 3
    penalty_stars: int = 0
    task_count: int = 0
    task_score: float = 0.0
    history: list = field(default_factory=list)
    model_online: Optional[bool] = None
    memory_ok: Optional[bool] = None
    score_history: list = field(default_factory=list)
    recent_comments: list = field(default_factory=list)

    @property
    def net_incentive(self) -> int:
        return self.incentive_stars - self.penalty_stars

    @property
    def status_text(self) -> str:
        if self.net_incentive >= 3:
            return "激励状态"
        elif self.net_incentive <= -3:
            return "惩戒状态"
        return "正常"


# ------------------------------------------------------------------
# 提示词管理器
# ------------------------------------------------------------------

class PromptManager:
    """统一管理各人格的系统提示词。"""

    # SKILL.md 目录映射
    SKILL_MAP = {
        "host": "host",
        "S1": "software-specialist",
        "S2": "system-specialist",
        "S3": "web-specialist",
        "S4": "file-specialist",
        "S5": "search-specialist",
        "S": "monitor-specialist",
        "S6": "chat-specialist",
    }

    def __init__(self, skill_dir: str = "") -> None:
        self._skill_dir = skill_dir or SKILL_DIR
        self._prompts: dict[str, str] = {}
        self._load()

    def _load(self) -> None:
        """从 SKILL.md 加载各人格系统提示词。"""
        for pid, dirname in self.SKILL_MAP.items():
            path = os.path.join(self._skill_dir, dirname, "SKILL.md")
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        content = f.read()
                    # 去掉 frontmatter
                    content = re.sub(r'^---.*?---\s*', '', content, flags=re.DOTALL)
                    self._prompts[pid] = content[:8000]
                except Exception as e:
                    logger.warning("加载 SKILL.md 失败 %s: %s", pid, e)
                    self._prompts[pid] = self._fallback_prompt(pid)
            else:
                self._prompts[pid] = self._fallback_prompt(pid)

    def _fallback_prompt(self, pid: str) -> str:
        meta = PERSONAS.get(pid, {"name": pid, "role": ""})
        return f"你是 {meta['name']}，{meta.get('role', '')}。"

    def get(self, persona_id: str) -> str:
        return self._prompts.get(persona_id, "")

    def build_system_prompt(
        self,
        persona_id: str,
        state: PersonaState,
        user_query: str = "",
        comments_text: str = "",
        experiences_text: str = "",
    ) -> str:
        """构建完整 system prompt。"""
        meta = PERSONAS.get(persona_id, {"name": persona_id})
        skill = self.get(persona_id)

        status_block = (
            f"\n当前系统状态：\n"
            f"- 人格：{meta['name']}（{persona_id}）\n"
            f"- 激励星：{'★' * state.incentive_stars} | 惩戒星：{'★' * state.penalty_stars}\n"
            f"- 净激励：{state.net_incentive:+d} | 状态：{state.status_text}\n"
            f"- 任务数：{state.task_count} | 均分：{state.task_score:.1f}\n"
        )

        prompt = skill + "\n" + status_block
        if comments_text:
            prompt += "\n" + comments_text
        if experiences_text:
            prompt += "\n" + experiences_text
        return prompt


# ------------------------------------------------------------------
# Ollama 客户端（线程安全 + 限流）
# ------------------------------------------------------------------

class OllamaClient:
    """Ollama API 客户端 — 线程安全 Session + 令牌桶限流 + 重试。"""

    def __init__(self) -> None:
        self._tlocal = threading.local()
        self._limiter = MultiRateLimiter(
            default_rpm=10,
            per_key_rpm={
                "global": 30,
                "host": 15,
                "S": 20,
            },
        )

    def _get_headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if OLLAMA_API_KEY:
            scheme = os.environ.get("OLLAMA_AUTH_SCHEME", "bearer").strip().lower()
            if scheme == "basic":
                headers["Authorization"] = f"Basic {OLLAMA_API_KEY}"
            elif scheme == "raw":
                headers["Authorization"] = f"{OLLAMA_API_KEY}"
            else:
                headers["Authorization"] = f"Bearer {OLLAMA_API_KEY}"
        return headers

    def _get_session(self):
        import requests
        sess = getattr(self._tlocal, "session", None)
        if sess is None:
            sess = requests.Session()
            sess.trust_env = False
            self._tlocal.session = sess
        return sess

    def post(self, url: str, data: dict, timeout: int = None) -> dict:
        """POST 请求，返回 JSON dict。带 2 次重试。"""
        import requests
        timeout = timeout or OLLAMA_TIMEOUT
        last_error = None
        for attempt in range(2):
            try:
                resp = self._get_session().post(
                    url, json=data, timeout=timeout, headers=self._get_headers()
                )
                return resp.json()
            except requests.exceptions.Timeout as e:
                last_error = e
                if attempt == 0:
                    continue
            except requests.exceptions.ConnectionError as e:
                last_error = e
                if attempt == 0:
                    time.sleep(1)
                    continue
            except Exception as e:
                last_error = e
                break
        raise last_error or RuntimeError("Ollama API request failed")

    def get(self, url: str, timeout: int = 10) -> dict:
        """GET 请求，返回 JSON dict。"""
        import requests
        last_error = None
        for attempt in range(2):
            try:
                resp = self._get_session().get(
                    url, timeout=timeout, headers=self._get_headers()
                )
                return resp.json()
            except requests.exceptions.Timeout as e:
                last_error = e
                if attempt == 0:
                    continue
            except requests.exceptions.ConnectionError as e:
                last_error = e
                if attempt == 0:
                    time.sleep(1)
                    continue
            except Exception as e:
                last_error = e
                break
        raise last_error or RuntimeError("Ollama API GET failed")

    def chat(
        self,
        model: str,
        messages: list[dict],
        include_reasoning: bool = False,
        timeout: int = None,
    ) -> Tuple[str, str]:
        """调用 /api/chat，返回 (content, reasoning)。"""
        data: dict = {
            "model": model,
            "messages": messages,
            "stream": False,
        }
        if include_reasoning:
            data["include_reasoning"] = True

        result = self.post(f"{OLLAMA_HOST}/api/chat", data, timeout=timeout)
        msg = result.get("message", {})
        content = msg.get("content", "")
        reasoning = msg.get("reasoning_content", "") or msg.get("thinking", "")

        # 回退：content 为空时重试不带 include_reasoning
        if not content and not reasoning and include_reasoning:
            data.pop("include_reasoning")
            result = self.post(f"{OLLAMA_HOST}/api/chat", data, timeout=timeout or 120)
            content = result.get("message", {}).get("content", "")

        return content, reasoning

    def check_model(self, model: str) -> bool:
        """检查模型是否在线。"""
        try:
            result = self.post(
                f"{OLLAMA_HOST}/api/chat",
                {
                    "model": model,
                    "messages": [{"role": "user", "content": "ping"}],
                    "stream": False,
                    "options": {"num_predict": 1},
                },
                timeout=30,
            )
            return True
        except Exception:
            return False

    def list_models(self) -> set:
        """获取已安装模型列表。"""
        try:
            result = self.get(f"{OLLAMA_HOST}/api/tags")
            raw = result.get("models", [])
            installed = set()
            for m in raw:
                name = m["name"]
                installed.add(name)
                if ":" in name:
                    installed.add(name.split(":")[0])
            return installed
        except Exception:
            return set()


# ------------------------------------------------------------------
# JSON 提取工具
# ------------------------------------------------------------------

def extract_json(text: str) -> Optional[dict]:
    """从模型回复中提取第一个有效 JSON 对象。

    支持：markdown 代码块、嵌套 JSON、中文引号、尾逗号、注释。
    """
    MAX_INPUT = 102400
    if len(text) > MAX_INPUT:
        text = text[:MAX_INPUT]

    # 中文引号 → 英文
    cleaned = (
        text.replace("\u201c", '"').replace("\u201d", '"')
        .replace("\u2018", "'").replace("\u2019", "'")
    )
    # 逐行去单行注释
    cleaned = "\n".join(
        line[:line.find("//")] if "//" in line and not line.strip().startswith('"') else line
        for line in cleaned.split("\n")
    )
    # 去尾逗号
    cleaned = re.sub(r",\s*}", "}", cleaned)
    cleaned = re.sub(r",\s*]", "]", cleaned)

    # 优先提取 markdown 代码块
    md_match = re.search(r"```(?:json)?\s*([\s\S]*?)```", cleaned)
    if md_match:
        try:
            return json.loads(md_match.group(1).strip())
        except json.JSONDecodeError:
            pass

    # 逐字符匹配完整 JSON
    start = cleaned.find("{")
    if start == -1:
        return None
    depth = 0
    for i in range(start, len(cleaned)):
        if cleaned[i] == "{":
            depth += 1
        elif cleaned[i] == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(cleaned[start : i + 1])
                except json.JSONDecodeError:
                    return None

    # 兜底：正则提取 overall 和 comment
    overall_match = re.search(r'"overall"\s*:\s*([\d.]+)', text)
    comment_match = re.search(r'"comment"\s*:\s*"([^"]*)"', text)
    if overall_match:
        return {
            "overall": float(overall_match.group(1)),
            "comment": comment_match.group(1) if comment_match else "",
        }
    return None


# ------------------------------------------------------------------
# 确认协议解析器
# ------------------------------------------------------------------

class ConfirmationParser:
    """[SX→HOST] 确认请求协议解析。"""

    _CONFIRM_PATTERN = re.compile(
        r"\[(S\d*)→HOST\]\s*确认请求：\s*(CFM-\d{8}-\d{6}-\d{3})",
        re.IGNORECASE,
    )

    _FIELD_PATTERNS = {
        "type": r"类型[：:]\s*(.+)",
        "description": r"描述[：:]\s*(.+)",
        "risk_level": r"风险等级[：:]\s*(.+)",
        "targets": r"操作对象[：:]\s*(.+)",
        "impact": r"预期影响[：:]\s*(.+)",
        "rollback": r"回[滚退]方案[：:]\s*(.+)",
        "params": r"参数[：:]\s*(.+)",
        "options": r"选项[：:]\s*(.+)",
        "timeout": r"超时[：:]\s*(\d+)",
    }

    @classmethod
    def parse(cls, sub_results: list[dict]) -> list[dict]:
        """扫描副人格回复，提取确认请求。"""
        confirmations = []
        for sr in sub_results:
            if sr.get("error"):
                continue
            reply = sr.get("reply", "")
            if not reply:
                continue
            for m in cls._CONFIRM_PATTERN.finditer(reply):
                source = m.group(1)
                cfm_id = m.group(2)
                start_pos = m.start()
                next_match = cls._CONFIRM_PATTERN.search(reply, m.end())
                end_pos = next_match.start() if next_match else len(reply)
                raw_text = reply[start_pos:end_pos].strip()

                fields = {}
                for key, pat in cls._FIELD_PATTERNS.items():
                    fm = re.search(pat, raw_text)
                    if fm:
                        fields[key] = fm.group(1).strip()

                confirmations.append({
                    "source": source,
                    "cfm_id": cfm_id,
                    "raw_text": raw_text,
                    "fields": fields,
                    "persona": sr["persona"],
                    "persona_name": PERSONAS.get(sr["persona"], {}).get("name", sr["persona"]),
                })
        return confirmations

    @classmethod
    def build_context(cls, confirmations: list[dict]) -> str:
        """构建确认请求上下文文本。"""
        if not confirmations:
            return ""
        lines = [
            "\n## ⚠️ 待确认请求（需要向用户呈现并等待确认）",
            f"共 {len(confirmations)} 个确认请求等待处理：",
            "",
        ]
        for i, cfm in enumerate(confirmations, 1):
            lines.append(f"### 确认 {i}：{cfm['cfm_id']}")
            lines.append(f"- 发起方：{cfm['persona_name']}（{cfm['source']}）")
            fld = cfm["fields"]
            for key, label in [
                ("type", "类型"), ("description", "描述"), ("risk_level", "风险等级"),
                ("targets", "操作对象"), ("impact", "预期影响"), ("rollback", "回滚方案"),
                ("options", "可选操作"),
            ]:
                if key in fld:
                    lines.append(f"- {label}：{fld[key]}")
            lines.append("")
            lines.append("```")
            lines.append(cfm["raw_text"])
            lines.append("```")
            lines.append("")
        return "\n".join(lines)


# ------------------------------------------------------------------
# 统一引擎
# ------------------------------------------------------------------

class Engine:
    """WWW Agent OS 统一引擎。

    取代 HostEntry + WWWSystem 双轨架构。
    所有功能模块通过构造函数注入，无 Feature Flag，无回退分支。

    处理管线：
        InputSanitizer → Dispatcher → Executor → Scorer → Memory → Response
    """

    def __init__(
        self,
        project_root: str = "",
        sanitizer: Optional[InputSanitizer] = None,
        scoring_engine: Optional[ScoringEngine] = None,
        memory_store: Optional[MemoryStore] = None,
        event_bus: Optional[EventBus] = None,
        task_manager: Optional[TaskManager] = None,
        di_container: Any = None,
    ) -> None:
        self._project_root = project_root or _project_root
        self._di = di_container

        # 注入或惰性创建
        self._sanitizer = sanitizer or self._create_sanitizer()
        self._scoring_engine = scoring_engine or self._create_scoring_engine()
        self._memory_store = memory_store or self._create_memory_store()
        self._event_bus = event_bus or self._create_event_bus()
        self._task_manager = task_manager

        # 内部组件
        self._ollama = OllamaClient()
        self._prompt_mgr = PromptManager()
        self._confirm_parser = ConfirmationParser()
        self._tool_router = self._create_tool_router()

        # 注册工具集
        self._register_tools()

        # 人格状态
        self._states: dict[str, PersonaState] = {}
        self._experiences: dict[str, list] = {}
        self._states_lock = threading.RLock()

        # 确认协议状态
        self._pending_confirmations: list[dict] = []
        self._last_sub_results: list[dict] = []
        self._last_host_reasoning: str = ""
        self._last_host_analysis: str = ""

        # UI 兼容标志
        self._checking = False
        self._running = False

        # 初始化
        self._init_states()
        self._load_all_memories()
        self._init_monitor_persona()
        self._setup_event_subscriptions()

        logger.info("Engine 已初始化 (project_root=%s)", self._project_root)

    # ------------------------------------------------------------------
    # UI 兼容属性
    # ------------------------------------------------------------------

    @property
    def states(self) -> dict:
        """公开访问人格状态字典（UI 兼容）。"""
        return self._states

    # ------------------------------------------------------------------
    # 惰性创建
    # ------------------------------------------------------------------

    def _create_sanitizer(self) -> InputSanitizer:
        if self._di:
            try:
                return self._di.sanitizer
            except (KeyError, AttributeError):
                pass
        return InputSanitizer(project_root=self._project_root)

    def _create_scoring_engine(self) -> ScoringEngine:
        if self._di:
            try:
                return self._di.scoring_engine
            except (KeyError, AttributeError):
                pass
        from core.evaluation.scoring_engine import ScoringEngine
        return ScoringEngine(sanitizer=self._sanitizer)

    def _create_memory_store(self) -> MemoryStore:
        if self._di:
            try:
                return self._di.memory_store
            except (KeyError, AttributeError):
                pass
        storage_dir = os.path.join(self._project_root, "data", "memory")
        return MemoryStore(storage_dir=storage_dir, bus=self._create_event_bus())

    def _create_event_bus(self) -> EventBus:
        if self._di:
            try:
                return self._di.bus
            except (KeyError, AttributeError):
                pass
        from events.bus import EventBus
        bus = EventBus(name="engine")
        log_dir = os.path.join(self._project_root, "logs", "events")
        bus.enable_persistence(log_dir)
        return bus

    def _create_tool_router(self):
        """创建 ToolRouter 实例。"""
        from tools.router import ToolRouter
        return ToolRouter(bus=self._event_bus)

    def _register_tools(self) -> None:
        """注册所有工具集到 ToolRouter。"""
        try:
            import tools.definitions.web as web_tools
            import tools.definitions.system as sys_tools
            import tools.definitions.file as file_tools
            import tools.definitions.code as code_tools
            n = 0
            n += web_tools.register_all(self._tool_router)
            n += sys_tools.register_all(self._tool_router)
            n += file_tools.register_all(self._tool_router)
            n += code_tools.register_all(self._tool_router)
            logger.info("ToolRouter: 共注册 %d 个工具", n)
        except Exception as e:
            logger.warning("ToolRouter 工具注册失败: %s", e)

    # ------------------------------------------------------------------
    # 状态管理
    # ------------------------------------------------------------------

    def _init_states(self) -> None:
        for pid in PERSONAS:
            self._states[pid] = PersonaState(persona_id=pid)

    def _load_all_memories(self) -> None:
        for pid in PERSONAS:
            self._load_persona_memory(pid)

    def _init_monitor_persona(self) -> None:
        """初始化 S 监察人格 — 创建 MonitorPersona 实例并激活定时器。

        v11.0 修复：MonitorPersona 此前从未被加载到运行时。
        现在在 Engine 启动时自动创建并激活，注册每日/每周评估定时器。
        """
        try:
            from persona.monitor_persona import MonitorPersona
            self._monitor_persona = MonitorPersona(engine=self)
            self._monitor_persona.on_activate()
            logger.info("S 监察人格已激活 (persona_id=%s)", self._monitor_persona.persona_id)
        except Exception as e:
            logger.warning("S 监察人格初始化失败: %s", e)
            self._monitor_persona = None

    def _setup_event_subscriptions(self) -> None:
        """注册 EventBus 订阅 — 打通事件驱动的模块交互。

        订阅以下事件：
        - task.completed: 记录任务完成统计
        - task.failed: 记录失败告警
        - tool.invoked: 工具调用计数
        """
        try:
            bus = self._event_bus

            @bus.on("task.completed")
            def _on_task_completed(event):
                data = event.data
                logger.info(
                    "[EventBus] 任务完成: persona=%s duration=%s",
                    data.get("persona_id", "?"),
                    f"{data.get('duration_ms', 0):.0f}ms",
                )

            @bus.on("task.failed")
            def _on_task_failed(event):
                data = event.data
                logger.warning(
                    "[EventBus] 任务失败: persona=%s error=%s",
                    data.get("persona_id", "?"),
                    data.get("error", "?")[:100],
                )

            @bus.on("tool.invoked")
            def _on_tool_invoked(event):
                data = event.data
                logger.debug(
                    "[EventBus] 工具调用: %s success=%s",
                    data.get("tool_name", "?"), data.get("success", True),
                )

            logger.info("EventBus: 已注册 %d 个订阅", 3)
        except Exception as e:
            logger.warning("EventBus 订阅注册失败: %s", e)

    def _get_persona_memory_dir(self, pid: str) -> str:
        d = os.path.join(MEMORY_DIR, pid)
        os.makedirs(d, exist_ok=True)
        return d

    def _load_persona_memory(self, pid: str) -> None:
        """从磁盘加载人格记忆。"""
        mem_dir = self._get_persona_memory_dir(pid)
        state = self._states[pid]

        # scores.json
        scores_path = os.path.join(mem_dir, "scores.json")
        if os.path.exists(scores_path):
            try:
                with open(scores_path, "r", encoding="utf-8") as f:
                    scores = json.load(f)
                state.incentive_stars = scores.get("incentive_stars", 3)
                state.penalty_stars = scores.get("penalty_stars", 0)
                state.task_count = scores.get("task_count", 0)
                state.task_score = scores.get("task_score", 0.0)
                state.score_history = scores.get("score_log", [])
            except Exception:
                pass

        # history.json
        history_path = os.path.join(mem_dir, "history.json")
        if os.path.exists(history_path):
            try:
                with open(history_path, "r", encoding="utf-8") as f:
                    state.history = json.load(f)[:100]
            except Exception:
                pass

        # experiences.json
        exp_path = os.path.join(mem_dir, "experiences.json")
        if os.path.exists(exp_path):
            try:
                with open(exp_path, "r", encoding="utf-8") as f:
                    self._experiences[pid] = json.load(f)
            except Exception:
                self._experiences[pid] = []
        else:
            self._experiences[pid] = []

    def _save_persona_memory(self, pid: str) -> None:
        """保存人格记忆到磁盘。"""
        mem_dir = self._get_persona_memory_dir(pid)
        state = self._states[pid]

        scores = {
            "incentive_stars": state.incentive_stars,
            "penalty_stars": state.penalty_stars,
            "task_count": state.task_count,
            "task_score": state.task_score,
            "score_log": state.score_history,
        }
        scores_path = os.path.join(mem_dir, "scores.json")
        with open(scores_path, "w", encoding="utf-8") as f:
            json.dump(scores, f, ensure_ascii=False, indent=2)

        history_path = os.path.join(mem_dir, "history.json")
        with open(history_path, "w", encoding="utf-8") as f:
            json.dump(state.history[-100:], f, ensure_ascii=False, indent=2)

    def _save_experiences(self, pid: str) -> None:
        mem_dir = self._get_persona_memory_dir(pid)
        exp_path = os.path.join(mem_dir, "experiences.json")
        with open(exp_path, "w", encoding="utf-8") as f:
            json.dump(self._experiences.get(pid, []), f, ensure_ascii=False, indent=2)

    def save_all_memories(self) -> None:
        """保存所有人格记忆。"""
        for pid in self._states:
            self._save_persona_memory(pid)

    def shutdown(self) -> None:
        """关闭引擎，保存所有状态。"""
        self.save_all_memories()
        if hasattr(self, "_monitor_persona") and self._monitor_persona is not None:
            try:
                self._monitor_persona.on_deactivate()
            except Exception:
                pass
        logger.info("Engine 已关闭，所有记忆已保存")

    # ------------------------------------------------------------------
    # 模型检查
    # ------------------------------------------------------------------

    def check_all_models(self, progress_callback: Callable = None) -> None:
        """检查所有模型在线状态（串行执行，避免VRAM争抢导致超时故障）。

        原 v11.1 使用 ThreadPoolExecutor(max_workers=2) 并发检查，
        在 VRAM 有限的机器上（如 16GB），大型模型（14B+12B）同时加载
        会导致 VRAM 溢出 → Ollama 静默卸载旧模型 → 检查超时/告警。

        v11.2 改为严格串行：先小模型后大模型，每次加载完成后释放上下文。
        """
        self._checking = True
        installed = self._ollama.list_models()

        # v11.2: 按模型大小从小到大排序，串行检查，避免 VRAM 争抢
        sorted_pids = sorted(
            PERSONA_MODELS.keys(),
            key=lambda pid: PERSONA_MODELS[pid].lower(),  # 按模型名排序（小的在前）
        )
        # 手动把大模型放最后
        large_models = ["qwen3:14b", "gemma3:12b", "deepseek-r1:7b"]
        ordered_pids = [p for p in sorted_pids if PERSONA_MODELS[p] not in large_models]
        ordered_pids += [p for p in sorted_pids if PERSONA_MODELS[p] in large_models]

        total = len(PERSONA_MODELS)

        for idx, pid in enumerate(ordered_pids):
            model = PERSONA_MODELS[pid]
            state = self._states[pid]
            model_base = model.split(":")[0]

            if model not in installed and model_base not in installed:
                state.model_online = False
                state.memory_ok = self._check_memory_file(pid)
            else:
                state.model_online = self._ollama.check_model(model)
                state.memory_ok = self._check_memory_file(pid)

            if progress_callback:
                progress_callback(pid, idx + 1, total)

        self._checking = False

    def _check_memory_file(self, pid: str) -> bool:
        try:
            mem_dir = self._get_persona_memory_dir(pid)
            for fname in ("scores.json", "history.json"):
                path = os.path.join(mem_dir, fname)
                if os.path.exists(path):
                    with open(path, "r", encoding="utf-8") as f:
                        json.load(f)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------
    # 输入安全
    # ------------------------------------------------------------------

    def _sanitize(self, text: str) -> SanitizerResult:
        """输入安全过滤。"""
        try:
            return self._sanitizer.sanitize(text)
        except Exception as e:
            logger.warning("InputSanitizer 异常，跳过过滤: %s", e)
            return SanitizerResult(sanitized=text)

    # ------------------------------------------------------------------
    # 调度
    # ------------------------------------------------------------------

    def _dispatch(self, user_message: str) -> Tuple[str, str]:
        """HOST 分析任务并调度到对应专员。

        Returns:
            (persona_id, dispatch_reasoning)
        """
        host_prompt = (
            f'你是 www 系统 HOST。分析以下用户消息，判断应该调度哪个专员。\n'
            f'回复格式：{{"persona": "S1"}} 或 {{"persona": "host"}}\n\n'
            f'专员映射（v11.2 真实能力）：\n'
            f'S1-软件(安装方案/卸载方案/软件搜索)、S2-系统(配置方案/代码/脚本)、\n'
            f'S3-网络(网页内容/浏览器打开URL/微信QQ链接处理/HTTP请求)、\n'
            f'S4-文件(搜索/阅读/MD转换)、S5-检索(搜索策略/调研/信息聚合)、\n'
            f'S6-聊天(闲聊/倾诉/日常)、S-监察(评估/评分/质量审查)、host-综合/调度\n\n'
            f'特别规则：\n'
            f'- "打开XX网站" "访问XX网页" "帮我打开" → S3\n'
            f'- 微信链接/小程序/QQ链接 → S3\n'
            f'- 搜索/查资料/调研 → S5\n'
            f'- 综合任务(多步骤) → host\n\n'
            f'用户消息：{user_message}'
        )
        try:
            content, _ = self._ollama.chat(
                PERSONA_MODELS["host"],
                [{"role": "user", "content": host_prompt}],
                timeout=30,
            )
            match = re.search(r'"persona"\s*:\s*"(\w+)"', content)
            if match:
                pid = match.group(1)
                if pid in PERSONAS:
                    return pid, content
                logger.warning("dispatch 返回未知 persona_id: %s，回退 host", pid)
        except Exception as e:
            logger.warning("dispatch 异常: %s", e)
        return "host", "调度默认"

    # ------------------------------------------------------------------
    # 聊天
    # ------------------------------------------------------------------

    def chat(self, persona_id: str, user_message: str) -> Tuple[str, str]:
        """向指定人格发送消息，返回 (reply, reasoning)。"""
        model = PERSONA_MODELS.get(persona_id, "qwen2.5:7b")
        state = self._states[persona_id]

        # 构建提示词
        comments = self._inject_recent_comments(persona_id)
        experiences = self._search_similar_experiences(persona_id, user_message)
        system_prompt = self._prompt_mgr.build_system_prompt(
            persona_id, state, user_message, comments, experiences
        )

        messages = [{"role": "system", "content": system_prompt}]
        messages.extend(state.history[-20:])
        messages.append({"role": "user", "content": user_message})

        reply = f"[{model} 响应异常，请检查 Ollama 服务是否正常运行]"
        reasoning = ""

        for attempt in range(3):
            try:
                reply, reasoning = self._ollama.chat(
                    model, messages,
                    include_reasoning=(attempt == 0),
                    timeout=120 if attempt > 0 else None,
                )
                state.model_online = True
                break
            except Exception:
                if attempt < 2:
                    time.sleep(1.0 * (2 ** attempt))
                else:
                    state.model_online = False

        with self._states_lock:
            state.history.append({"role": "user", "content": user_message})
            state.history.append({"role": "assistant", "content": reply})
            state.task_count += 1

        return reply, reasoning

    # ------------------------------------------------------------------
    # 任务编排
    # ------------------------------------------------------------------

    def _decompose_task(self, user_message: str) -> Tuple[list, str, str]:
        """HOST 分解任务为子任务列表。

        Returns:
            (subtasks, reasoning, analysis)
        """
        host_model = PERSONA_MODELS["host"]
        decom_prompt = (
            f'你是 www 系统 HOST 指挥者 Marvis。请分析以下用户任务，将其分解为子任务并指定执行专员。\n\n'
            f'## 可用专员\n'
            f'| ID | 专员 | 专长（v11.2） |\n|----|------|------|\n'
            f'| S1 | 软件专员 | 安装/卸载方案、软件搜索推荐 |\n'
            f'| S2 | 系统专员 | 配置方案、代码生成、脚本开发 |\n'
            f'| S3 | 网络专员 | 网页获取、浏览器打开URL、HTTP请求、微信QQ链接处理 |\n'
            f'| S4 | 文件专员 | 文件搜索、文档阅读、MD/文本转换 |\n'
            f'| S5 | 检索专员 | 搜索策略、信息聚合、调研报告 |\n'
            f'| S6 | 聊天专员 | 闲聊、倾诉、日常对话 |\n'
            f'| S | 监察员 | 评估/评分/质量审查/激励管理 |\n\n'
            f'## 规则\n'
            f'1. 简单任务（单类型）只需 1 个子任务\n'
            f'2. 复杂任务可拆解为多个子任务，独立子任务可标注 parallel=true\n'
            f'3. 每个子任务必须指定 persona 和具体的 prompt\n'
            f'4. 如果任务需要你自己（HOST）综合处理，最后一个子任务 persona 设为 "host"\n'
            f'5. 浏览器打开/微信链接/网页获取 → S3；搜索调研 → S5\n\n'
            f'## 回复格式（严格 JSON）\n'
            f'```json\n{{\n  "analysis": "对用户任务的简要分析",\n'
            f'  "subtasks": [\n'
            f'    {{"persona": "S4", "prompt": "...", "parallel": true}},\n'
            f'    {{"persona": "host", "prompt": "综合以上结果并给出最终回复", "parallel": false}}\n  ]\n}}\n```\n\n'
            f'用户任务：{user_message}'
        )

        try:
            content, reasoning = self._ollama.chat(
                host_model,
                [{"role": "user", "content": decom_prompt}],
                include_reasoning=True,
                timeout=60,
            )

            parsed = extract_json(content)
            if parsed:
                analysis = parsed.get("analysis", "")
                subtasks = parsed.get("subtasks", [])
                subtasks = [
                    st for st in subtasks
                    if isinstance(st, dict) and "persona" in st and st["persona"] in PERSONAS
                ]
                if not subtasks:
                    fallback_pid, _ = self._dispatch(user_message)
                    subtasks = [{"persona": fallback_pid, "prompt": user_message}]
                    analysis = f"任务分解未得到有效子任务，回退到直接调度 {PERSONAS[fallback_pid]['name']}"
                return subtasks, reasoning, analysis
            else:
                fallback_pid, _ = self._dispatch(user_message)
                return (
                    [{"persona": fallback_pid, "prompt": user_message}],
                    reasoning,
                    f"任务分解失败（JSON 解析异常），回退到直接调度 {PERSONAS[fallback_pid]['name']}",
                )
        except Exception:
            fallback_pid, _ = self._dispatch(user_message)
            return (
                [{"persona": fallback_pid, "prompt": user_message}],
                "",
                f"任务分解异常，回退到直接调度 {PERSONAS[fallback_pid]['name']}",
            )

    def orchestrate(
        self,
        user_message: str,
        progress_callback: Optional[Callable] = None,
    ) -> Tuple[str, str, str, list[dict]]:
        """HOST 编排执行完整任务流水线。

        流程：HOST 分解任务 → 各副人格并行/串行执行 → HOST 综合

        Returns:
            (final_reply, host_reasoning, host_analysis, sub_results)
        """
        # Stage 1: 分解任务
        if progress_callback:
            progress_callback("decompose", "HOST 正在分析任务...")
        subtasks, host_reasoning, host_analysis = self._decompose_task(user_message)

        if not subtasks:
            return "任务分解失败，请重试", host_reasoning, host_analysis, []

        # Stage 2: 执行子任务
        sub_results: list[dict] = []
        host_subtasks = [st for st in subtasks if st["persona"] == "host"]
        agent_subtasks = [st for st in subtasks if st["persona"] != "host"]

        if agent_subtasks:
            def _run_subtask(st: dict) -> dict:
                pid = st["persona"]
                prompt = st.get("prompt", user_message)
                try:
                    reply, sub_reasoning = self.chat(pid, prompt)
                    return {"persona": pid, "prompt": prompt, "reply": reply,
                            "reasoning": sub_reasoning, "error": None}
                except Exception as e:
                    return {"persona": pid, "prompt": prompt, "reply": "",
                            "reasoning": "", "error": str(e)}

            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
                futures = {executor.submit(_run_subtask, st): st for st in agent_subtasks}
                for future in concurrent.futures.as_completed(futures):
                    result = future.result()
                    sub_results.append(result)
                    pid = result["persona"]
                    name = PERSONAS[pid]["name"]

                    # 每个副人格完成后立即评分
                    score_info = {"overall": 3.0, "comment": "评分未完成"}
                    if not result.get("error") and pid != "S":
                        try:
                            score_info = self._evaluate(pid, result.get("prompt", ""),
                                                        result.get("reply", ""))
                            self._apply_score(pid, score_info.get("overall", 3.0))
                        except Exception as e:
                            logger.warning("S评分异常 pid=%s: %s", pid, e)

                    if progress_callback:
                        payload = json.dumps({
                            "persona": pid, "name": name,
                            "reply": result.get("reply", ""),
                            "reasoning": result.get("reasoning", ""),
                            "error": result.get("error"),
                            "score": score_info.get("overall"),
                            "comment": score_info.get("comment", ""),
                        }, ensure_ascii=False)
                        progress_callback("subtask_scored", payload)

        # 检测确认请求
        pending_confirmations = self._confirm_parser.parse(sub_results)
        confirmation_context = self._confirm_parser.build_context(pending_confirmations)

        if pending_confirmations:
            self._pending_confirmations = pending_confirmations
            self._last_sub_results = sub_results
            self._last_host_reasoning = host_reasoning
            self._last_host_analysis = host_analysis
        else:
            self._pending_confirmations = []
            self._last_sub_results = []
            self._last_host_reasoning = ""
            self._last_host_analysis = ""

        # Stage 3: HOST 综合
        if host_subtasks or len(agent_subtasks) > 0:
            if progress_callback:
                progress_callback("synthesize", "HOST 正在综合结果...")

            synth_context = f"## 用户原始任务\n{user_message}\n\n## 副人格执行结果\n"
            for sr in sub_results:
                pid = sr["persona"]
                name = PERSONAS[pid]["name"]
                if sr.get("error"):
                    synth_context += f"\n### {name}（{pid}）\n执行失败: {sr['error']}\n"
                else:
                    synth_context += f"\n### {name}（{pid}）\n{sr['reply']}\n"
                    if sr.get("reasoning"):
                        synth_context += f"\n<thinking>{sr['reasoning'][:500]}</thinking>\n"

            if confirmation_context:
                synth_context += confirmation_context + "\n"
                synth_context += (
                    "\n请综合以上所有副人格的执行结果，给用户一个完整、连贯的最终回复。\n"
                    "规则：\n1. 去除冗余信息，保留关键内容\n"
                    "2. 如果某个副人格执行失败，说明原因并给替代建议\n"
                    "3. 回复结构清晰，可用小标题分段\n"
                    "4. 【重要】以上存在副人格发出的「确认请求」（[SX→HOST] 协议），"
                    "请在最终回复中清晰地向用户呈现这些确认请求，包括：\n"
                    "   - 哪个副人格发起了确认\n   - 确认 ID 和类型\n"
                    "   - 操作描述和风险等级\n   - 请求用户做出选择（同意/拒绝/修改参数）\n"
                    "   - 不要自行替用户做决定，必须等待用户回复后再继续\n"
                )
            else:
                synth_context += (
                    "\n请综合以上所有副人格的执行结果，给用户一个完整、连贯的最终回复。\n"
                    "规则：\n1. 去除冗余信息，保留关键内容\n"
                    "2. 如果某个副人格执行失败，说明原因并给替代建议\n"
                    "3. 回复结构清晰，可用小标题分段\n"
                )

            synth_system = (
                "你是 www 系统的 HOST 指挥者。你的任务是将多个副人格的执行结果"
                "综合整理成一条连贯、清晰的最终回复给用户。请直接输出综合后的内容。"
            )

            try:
                final_reply, synth_reasoning = self._ollama.chat(
                    PERSONA_MODELS["host"],
                    [
                        {"role": "system", "content": synth_system},
                        {"role": "user", "content": synth_context},
                    ],
                    include_reasoning=True,
                    timeout=120,
                )
                if synth_reasoning:
                    if host_reasoning:
                        host_reasoning += "\n\n--- 综合阶段思考 ---\n" + synth_reasoning
                    else:
                        host_reasoning = synth_reasoning
            except Exception:
                final_reply = self._merge_sub_results(sub_results)

            # 兜底
            if not final_reply:
                final_reply = self._merge_sub_results(sub_results)
        else:
            final_reply = "未能解析出有效的子任务，请重新描述您的需求。"

        # 更新 HOST 历史
        host_state = self._states["host"]
        host_state.history.append({"role": "user", "content": user_message})
        host_state.history.append({"role": "assistant", "content": final_reply[:500]})
        host_state.task_count += 1

        return final_reply, host_reasoning, host_analysis, sub_results

    def _merge_sub_results(self, sub_results: list[dict]) -> str:
        """合并子任务结果作为兜底回复。"""
        parts = []
        for sr in sub_results:
            pid = sr["persona"]
            name = PERSONAS[pid]["name"]
            if sr.get("error"):
                parts.append(f"【{name}】执行失败: {sr['error']}")
            elif sr.get("reply"):
                parts.append(f"【{name}】{sr['reply']}")
        if parts:
            return "\n\n---\n\n".join(parts)
        return "任务已分发执行，但未收集到有效结果。请重试或简化任务描述。"

    # ------------------------------------------------------------------
    # 确认恢复
    # ------------------------------------------------------------------

    def resume_with_confirmation(
        self,
        user_decision: str,
        pending_confirmations: list[dict] = None,
        sub_results: list[dict] = None,
        host_reasoning: str = "",
        host_analysis: str = "",
    ) -> Tuple[str, str, str, list[dict]]:
        """用户确认后恢复编排流程。"""
        confirmations = pending_confirmations or self._pending_confirmations
        results = sub_results or self._last_sub_results
        reasoning = host_reasoning or self._last_host_reasoning
        analysis = host_analysis or self._last_host_analysis

        decision_context = f"## 用户对确认请求的决定\n{user_decision}\n\n## 待确认请求汇总\n"
        for cfm in confirmations:
            decision_context += (
                f"\n- {cfm['cfm_id']}（{cfm['persona_name']}）："
                f"{cfm['fields'].get('description', cfm['raw_text'][:200])}\n"
            )
        decision_context += "\n## 副人格执行结果\n"
        for sr in results:
            pid = sr["persona"]
            name = PERSONAS[pid]["name"]
            if sr.get("error"):
                decision_context += f"\n### {name}（{pid}）\n执行失败: {sr['error']}\n"
            else:
                decision_context += f"\n### {name}（{pid}）\n{sr['reply']}\n"
        decision_context += (
            "\n请根据用户的决定，综合以上所有信息，给用户一个最终回复。\n"
            "规则：\n1. 如果用户同意了确认请求，告知用户操作已获批准，说明下一步操作\n"
            "2. 如果用户拒绝了确认请求，说明操作已被取消并给出替代建议\n"
            "3. 综合其他副人格的执行结果，给出完整回复\n"
        )

        resume_system = (
            "你是 www 系统的 HOST 指挥者。请根据用户的确认决策和副人格的执行结果，"
            "生成一条清晰完整的最终回复。直接输出回复内容。"
        )

        try:
            final_reply, synth_reasoning = self._ollama.chat(
                PERSONA_MODELS["host"],
                [
                    {"role": "system", "content": resume_system},
                    {"role": "user", "content": decision_context},
                ],
                include_reasoning=True,
                timeout=120,
            )
            if synth_reasoning:
                if reasoning:
                    reasoning += "\n\n--- 确认后综合阶段思考 ---\n" + synth_reasoning
                else:
                    reasoning = synth_reasoning
        except Exception:
            final_reply = self._merge_sub_results(results)

        if not final_reply:
            parts = [f"用户决定：{user_decision}"]
            parts.append(self._merge_sub_results(results))
            final_reply = "\n\n---\n\n".join(parts) if len(parts) > 1 else parts[0]

        # 更新 HOST 历史
        host_state = self._states["host"]
        host_state.history.append({"role": "user", "content": f"[确认决策] {user_decision}"})
        host_state.history.append({"role": "assistant", "content": final_reply[:500]})
        host_state.task_count += 1

        # 清理确认状态
        self._pending_confirmations = []
        self._last_sub_results = []
        self._last_host_reasoning = ""
        self._last_host_analysis = ""

        return final_reply, reasoning, analysis, results

    def has_pending_confirmations(self) -> bool:
        """检查是否有待处理的确认请求。"""
        return len(self._pending_confirmations) > 0

    # ------------------------------------------------------------------
    # 评分
    # ------------------------------------------------------------------

    def _evaluate(self, persona_id: str, question: str, answer: str) -> dict:
        """S 监察员评分。"""
        sanitized_q, _ = self._sanitize(question), None
        sanitized_a, _ = self._sanitize(answer), None

        s6_prompt = (
            f'你是 S 监察员。对以下回答评分（1-5星）。\n'
            f'四维标准：准确性40% + 完整性30% + 格式20% + 效率10%\n\n'
            f'用户问题：{question}\n'
            f'{persona_id} 的回答：{answer}\n\n'
            f'回复JSON格式：{{"accuracy": 4, "completeness": 3, "format": 4, '
            f'"efficiency": 3, "overall": 3.5, "comment": "评语"}}'
        )
        try:
            content, _ = self._ollama.chat(
                PERSONA_MODELS["S"],
                [{"role": "user", "content": s6_prompt}],
            )
            result = extract_json(content)
            if result:
                state = self._states[persona_id]
                state.recent_comments.append({
                    "score": result.get("overall", 3),
                    "comment": result.get("comment", ""),
                    "time": datetime.now().isoformat(),
                })
                if len(state.recent_comments) > 10:
                    state.recent_comments = state.recent_comments[-10:]
                return result
        except Exception as e:
            logger.warning(
                "评分系统异常 (model=%s, persona=%s): %s",
                PERSONA_MODELS["S"], persona_id, e,
            )
        logger.warning(
            "S 监察员评分降级: model=%s 可能未安装或离线，"
            "请执行 ollama pull %s",
            PERSONA_MODELS["S"], PERSONA_MODELS["S"],
        )
        return {"overall": 3, "comment": "评分系统异常"}

    def _apply_score(self, persona_id: str, overall: float) -> None:
        """应用评分 — 互斥逻辑。"""
        with self._states_lock:
            state = self._states[persona_id]
            state.task_score = (
                (state.task_score * (state.task_count - 1)) + overall
            ) / max(state.task_count, 1)

            if overall >= 4:
                state.incentive_stars = min(5, state.incentive_stars + 1)
            elif overall < 3:
                state.penalty_stars = min(5, state.penalty_stars + 1)

            state.score_history.append({
                "time": datetime.now().isoformat(),
                "overall": overall,
                "incentive_after": state.incentive_stars,
                "penalty_after": state.penalty_stars,
            })

        self._save_persona_memory(persona_id)

    # ------------------------------------------------------------------
    # 公开评分接口（UI 兼容）
    # ------------------------------------------------------------------

    def evaluate(self, persona_id: str, question: str, answer: str) -> dict:
        """公开评分接口 — 包装 _evaluate。"""
        return self._evaluate(persona_id, question, answer)

    # 向后兼容别名
    s6_evaluate = evaluate

    def apply_score(self, persona_id: str, overall: float) -> None:
        """公开评分应用接口 — 包装 _apply_score。"""
        self._apply_score(persona_id, overall)

    def log_task(self, persona_id: str, task: str, reply: str, score: dict) -> None:
        """记录任务日志到人格历史。"""
        with self._states_lock:
            state = self._states[persona_id]
            state.history.append({
                "role": "system",
                "content": f"[task_log] {task[:100]} → {reply[:200]} (score: {score.get('overall', '?')})",
            })
            # 经验压缩
            exps = self._experiences.setdefault(persona_id, [])
            exps.append({
                "task_pattern": task[:200],
                "score": score.get("overall", 3),
                "comment": score.get("comment", ""),
                "time": datetime.now().isoformat(),
            })
            if len(exps) > 100:
                self._experiences[persona_id] = exps[-100:]
        self._save_persona_memory(persona_id)

    # ------------------------------------------------------------------
    # 经验管理
    # ------------------------------------------------------------------

    def _inject_recent_comments(self, persona_id: str) -> str:
        state = self._states[persona_id]
        if not state.recent_comments:
            return ""
        lines = ["[监督员近期反馈]"]
        for c in state.recent_comments[-3:]:
            lines.append(f"- ★{c.get('score', '?')} | {c.get('comment', '')}")
        return "\n".join(lines)

    def _search_similar_experiences(self, persona_id: str, query: str) -> str:
        """基于关键词匹配检索相关历史经验。"""
        exps = self._experiences.get(persona_id, [])
        if not exps or not query:
            return ""
        query_words = set(query.lower().split())
        scored = []
        for exp in exps:
            pattern = exp.get("task_pattern", "").lower()
            matches = sum(1 for w in query_words if w in pattern)
            if matches > 0:
                scored.append((matches, exp))
        scored.sort(key=lambda x: x[0], reverse=True)
        if not scored:
            return ""
        lines = ["[相关历史经验]"]
        for _, exp in scored[:3]:
            lines.append(
                f"- 任务: {exp.get('task_pattern', '')[:60]} | "
                f"方案: {exp.get('solution', '')[:60]} | "
                f"评分: ★{exp.get('score', '?')}"
            )
        return "\n".join(lines)

    def _compress_task_to_experience(
        self, persona_id: str, question: str, answer: str, overall: float
    ) -> None:
        """将任务压缩为经验并持久化。"""
        exp = {
            "task_pattern": question[:150],
            "solution": answer[:200],
            "outcome": f"评分 {overall}/5",
            "score": overall,
            "persona": persona_id,
            "time": datetime.now().isoformat(),
            "_timestamp": time.time(),
        }
        if persona_id not in self._experiences:
            self._experiences[persona_id] = []
        self._experiences[persona_id].append(exp)

        exps = self._experiences[persona_id]
        if len(exps) > 50:
            now = time.time()
            half_life = 7 * 86400
            for e in exps:
                age = now - e.get("_timestamp", 0)
                recency = 0.5 ** (age / half_life) if age > 0 else 1.0
                e["_rank"] = e.get("score", 3) / 5.0 * 0.6 + recency * 0.4
            exps.sort(key=lambda x: x.get("_rank", 0), reverse=True)
            self._experiences[persona_id] = exps[:50]

        self._save_experiences(persona_id)

    # ------------------------------------------------------------------
    # 任务日志
    # ------------------------------------------------------------------

    def _log_task(
        self, persona_id: str, question: str, answer: str, score: dict
    ) -> None:
        """记录任务日志到 JSONL。"""
        entry = {
            "time": datetime.now().isoformat(),
            "persona": persona_id,
            "question": question[:200],
            "answer": answer[:500],
            "score": score,
        }
        os.makedirs(MEMORY_DIR, exist_ok=True)
        log_path = os.path.join(MEMORY_DIR, "www_task_log.jsonl")
        try:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.warning("任务日志写入失败: %s", e)

        self.save_all_memories()
        self._compress_task_to_experience(
            persona_id, question, answer, score.get("overall", 3)
        )

    # ------------------------------------------------------------------
    # 主入口
    # ------------------------------------------------------------------

    def process(
        self,
        user_message: str,
        user_preference: Optional[str] = None,
        progress_callback: Optional[Callable] = None,
    ) -> EngineResult:
        """处理用户消息 — 统一入口。

        Args:
            user_message: 用户输入文本。
            user_preference: 用户指定的偏好 persona_id（可选）。
            progress_callback: 进度回调 callback(stage: str, detail: str)。

        Returns:
            EngineResult 包含回复和元信息。
        """
        t0 = time.perf_counter()
        result = EngineResult()
        stages: list[str] = []

        # Step 0: 创建任务追踪
        dispatch_id = "host"
        task = None
        if self._task_manager is not None:
            try:
                task = self._task_manager.create(
                    persona_id=dispatch_id,
                    user_input=user_message,
                )
                self._task_manager.start(task.id)
                stages.append("task_started")
            except Exception as e:
                logger.warning("TaskManager 创建任务失败: %s", e)

        # Step 1: 安全过滤
        sr = self._sanitize(user_message)
        result.sanitizer_findings = sr.findings
        stages.append("sanitizer")
        if sr.is_blocked:
            result.reply = sr.blocked_message
            result.elapsed_ms = (time.perf_counter() - t0) * 1000
            result.stages = stages
            return result
        sanitized = sr.sanitized

        # Step 2: 检查确认请求恢复
        if self.has_pending_confirmations():
            stages.append("resume_confirmation")
            try:
                final_reply, reasoning, _, sub_results = self.resume_with_confirmation(
                    user_decision=sanitized,
                )
                result.reply = final_reply
                result.reasoning = reasoning
                result.persona_id = "host"
                result.persona_name = PERSONAS["host"]["name"]
                result.sub_results = sub_results
                result.pending_confirmations = []

                # 评分
                score = self._evaluate("host", sanitized, final_reply)
                self._apply_score("host", score.get("overall", 3))
                self._log_task("host", sanitized, final_reply, score)
                result.score = score
                stages.append("scored")

                # 记忆持久化
                self._save_to_memory("host", sanitized, final_reply)
                stages.append("memory")

            except Exception as e:
                result.error = f"{type(e).__name__}: {e}"
                result.reply = f"[系统错误] {e}"
                logger.error("确认恢复失败:\n%s", e, exc_info=True)

            result.elapsed_ms = (time.perf_counter() - t0) * 1000
            result.stages = stages
            return result

        # Step 3: 调度
        stages.append("dispatch")
        if user_preference and user_preference in PERSONAS:
            persona_id = user_preference
        else:
            persona_id, _ = self._dispatch(sanitized)

        result.persona_id = persona_id
        result.persona_name = PERSONAS.get(persona_id, {}).get("name", persona_id)

        # Step 4: 执行
        try:
            if persona_id == "host":
                # HOST → 编排路径
                stages.append("orchestrate")
                final_reply, reasoning, analysis, sub_results = self.orchestrate(
                    sanitized, progress_callback
                )
                result.reply = final_reply
                result.reasoning = reasoning
                result.sub_results = sub_results

                # 检测确认请求
                confirmations = self._confirm_parser.parse(sub_results)
                result.pending_confirmations = confirmations
            else:
                # 副人格 → 直接聊天
                stages.append("chat")
                reply, reasoning = self.chat(persona_id, sanitized)
                result.reply = reply
                result.reasoning = reasoning

                # 评分
                stages.append("scored")
                score = self._evaluate(persona_id, sanitized, reply)
                self._apply_score(persona_id, score.get("overall", 3))
                self._log_task(persona_id, sanitized, reply, score)
                result.score = score

            # HOST 编排路径的评分在 orchestrate 内部已完成
            if persona_id == "host" and not result.score:
                stages.append("scored")
                score = self._evaluate("host", sanitized, final_reply)
                self._apply_score("host", score.get("overall", 3))
                self._log_task("host", sanitized, final_reply, score)
                result.score = score

            # Step 5: 记忆持久化
            stages.append("memory")
            self._save_to_memory(persona_id, sanitized, result.reply)

        except Exception as e:
            result.error = f"{type(e).__name__}: {e}"
            if not result.reply:
                result.reply = f"[系统错误] {e}"
            logger.error("执行失败:\n%s", e, exc_info=True)
            if self._task_manager is not None and task is not None:
                try:
                    self._task_manager.fail(task.id, error=str(e))
                    stages.append("task_failed")
                except Exception:
                    pass

        # TaskManager 记录完成
        if self._task_manager is not None and task is not None and result.error is None:
            try:
                self._task_manager.complete(task.id, result=result.reply[:500])
                stages.append("task_completed")
            except Exception:
                pass

        result.elapsed_ms = (time.perf_counter() - t0) * 1000
        result.stages = stages
        return result

    def _save_to_memory(self, persona_id: str, user_message: str, reply: str) -> None:
        """保存对话到 MemoryStore。"""
        try:
            self._memory_store.save_message(persona_id, user_message, role="user", persist=True)
            self._memory_store.save_message(persona_id, reply, role="assistant", persist=True)
        except Exception as e:
            logger.warning("MemoryStore 保存失败: %s", e)

    # ------------------------------------------------------------------
    # 状态报告
    # ------------------------------------------------------------------

    def get_status_report(self) -> str:
        """获取系统状态报告。"""
        lines = [
            "| 人格 | 名称 | 激励 | 惩戒 | 净激励 | 状态 | 任务 | 均分 | 模型 |",
            "|------|------|------|------|--------|------|------|------|------|",
        ]
        for pid, meta in PERSONAS.items():
            s = self._states[pid]
            model = PERSONA_MODELS[pid]
            model_status = "✓" if s.model_online else ("✗" if s.model_online is False else "?")
            lines.append(
                f"| {pid} | {meta['name']} | {'★'*s.incentive_stars} | "
                f"{'★'*s.penalty_stars} | {s.net_incentive:+d} | {s.status_text} | "
                f"{s.task_count} | {s.task_score:.1f} | {model} {model_status} |"
            )
        return "\n".join(lines)

    def get_pending_confirmations(self) -> list[dict]:
        """获取待处理确认请求。"""
        return self._pending_confirmations

    def get_persona_state(self, persona_id: str) -> Optional[PersonaState]:
        """获取人格运行时状态。"""
        return self._states.get(persona_id)
