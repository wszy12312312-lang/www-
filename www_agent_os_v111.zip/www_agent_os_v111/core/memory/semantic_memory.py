"""
SemanticMemory — 语义记忆层（向量化存储）

职责：
- 内容哈希去重
- 向量嵌入存储与检索
- 为 RAG 和语义搜索提供底层支持
- 可插拔 embedding 后端（当前内置 sentence-transformers 支持）

实现：SQLite 持久化 + 可选向量索引。
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Dict, List, Optional, Tuple

from database.sqlite.connection import get_db

logger = logging.getLogger(__name__)


class SemanticMemory:
    """语义记忆：向量化内容存储与检索。

    特性：
    - 内容哈希去重
    - 嵌入向量持久化
    - 基础余弦相似度检索
    - 可选外部向量索引集成
    """

    def __init__(self, persona_id: str = "host") -> None:
        self.persona_id = persona_id
        self._db = get_db()
        self._embedding_model: Any = None
        self._embedding_dim = 0

    @staticmethod
    def _content_hash(content: str) -> str:
        """SHA256 内容哈希。"""
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def store(
        self,
        content: str,
        embedding: Optional[List[float]] = None,
        embedding_model: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Tuple[int, bool]:
        """存储语义记忆（自动去重）。

        Args:
            content: 文本内容。
            embedding: 向量嵌入，None 则延后计算。
            embedding_model: 嵌入模型名称。
            metadata: 附加元数据。

        Returns:
            (id, is_new) — is_new 表示是否为新插入。
        """
        content_hash = self._content_hash(content)

        # 检查是否已存在
        with self._db.cursor() as cur:
            existing = cur.execute(
                "SELECT id FROM semantic_memory WHERE content_hash = ?", (content_hash,)
            ).fetchone()
            if existing:
                return (existing["id"], False)

        # 序列化向量
        emb_blob: Optional[bytes] = None
        if embedding:
            import struct
            emb_blob = struct.pack(f"{len(embedding)}f", *embedding)

        with self._db.cursor() as cur:
            cur.execute(
                "INSERT INTO semantic_memory (persona_id, content_hash, content, "
                "embedding, embedding_model, metadata_json, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, julianday('now'))",
                (
                    self.persona_id,
                    content_hash,
                    content,
                    emb_blob,
                    embedding_model,
                    json.dumps(metadata or {}, ensure_ascii=False),
                ),
            )
            return (cur.lastrowid or 0, True)

    def search_cosine(
        self,
        query_embedding: List[float],
        limit: int = 10,
        min_similarity: float = 0.0,
    ) -> List[Dict[str, Any]]:
        """余弦相似度搜索（内存计算，适合小规模）。

        Args:
            query_embedding: 查询向量。
            limit: 最大返回数。
            min_similarity: 最低相似度阈值。

        Returns:
            按相似度降序排列的结果列表。
        """
        import struct
        import math

        with self._db.cursor() as cur:
            rows = cur.execute(
                "SELECT id, content, embedding, metadata_json FROM semantic_memory "
                "WHERE persona_id = ? AND embedding IS NOT NULL",
                (self.persona_id,),
            ).fetchall()

        results = []
        q_vec = query_embedding
        q_norm = math.sqrt(sum(v * v for v in q_vec))

        if q_norm == 0:
            return []

        for row in rows:
            emb_bytes = row["embedding"]
            if not emb_bytes:
                continue
            num_floats = len(emb_bytes) // 4
            emb = list(struct.unpack(f"{num_floats}f", emb_bytes))

            # 余弦相似度
            dot = sum(a * b for a, b in zip(q_vec, emb))
            e_norm = math.sqrt(sum(v * v for v in emb))
            if e_norm == 0:
                continue
            sim = dot / (q_norm * e_norm)

            if sim >= min_similarity:
                try:
                    metadata = json.loads(row["metadata_json"])
                except (json.JSONDecodeError, TypeError):
                    metadata = {}
                results.append({
                    "id": row["id"],
                    "content": row["content"],
                    "similarity": sim,
                    "metadata": metadata,
                })

        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:limit]

    def search_by_text(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """文本模糊搜索（基于 content LIKE）。"""
        with self._db.cursor() as cur:
            rows = cur.execute(
                "SELECT id, content, metadata_json FROM semantic_memory "
                "WHERE persona_id = ? AND content LIKE ? LIMIT ?",
                (self.persona_id, f"%{query}%", limit),
            ).fetchall()
        results = []
        for row in rows:
            try:
                metadata = json.loads(row["metadata_json"])
            except (json.JSONDecodeError, TypeError):
                metadata = {}
            results.append({
                "id": row["id"],
                "content": row["content"],
                "metadata": metadata,
            })
        return results

    def get_embedding(self, text: str, model_name: str = "all-MiniLM-L6-v2") -> Optional[List[float]]:
        """使用 sentence-transformers 计算文本嵌入。

        Args:
            text: 输入文本。
            model_name: 模型名称。

        Returns:
            嵌入向量，或 None（如果库不可用）。
        """
        try:
            from sentence_transformers import SentenceTransformer
            if self._embedding_model is None:
                self._embedding_model = SentenceTransformer(model_name)
            embedding = self._embedding_model.encode(text, normalize_embeddings=True)
            return embedding.tolist()
        except ImportError:
            logger.warning("sentence-transformers 未安装，无法计算向量嵌入")
            return None
        except Exception:
            logger.exception("向量嵌入计算失败")
            return None

    def store_with_embedding(
        self,
        content: str,
        model_name: str = "all-MiniLM-L6-v2",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Tuple[int, bool]:
        """存储内容并自动计算嵌入向量。"""
        embedding = self.get_embedding(content, model_name)
        return self.store(content=content, embedding=embedding, embedding_model=model_name, metadata=metadata)

    def count(self) -> int:
        """返回语义记忆条目数。"""
        with self._db.cursor() as cur:
            row = cur.execute(
                "SELECT COUNT(*) as cnt FROM semantic_memory WHERE persona_id = ?",
                (self.persona_id,),
            ).fetchone()
        return row["cnt"] if row else 0

    def delete(self, memory_id: int) -> bool:
        """删除指定语义记忆。"""
        with self._db.cursor() as cur:
            cur.execute(
                "DELETE FROM semantic_memory WHERE id = ? AND persona_id = ?",
                (memory_id, self.persona_id),
            )
            return cur.rowcount > 0
