"""
core/memory — 三层记忆架构的统一入口。

提供：
- MemoryManager: 统一管理 ShortMemory / LongMemory / SemanticMemory
- 从旧 JSON 格式迁移到 SQLite 的工具
"""

from core.memory.short_memory import ShortMemory, MemoryEntry
from core.memory.long_memory import LongMemory, LongMemoryEntry
from core.memory.semantic_memory import SemanticMemory

__all__ = [
    "ShortMemory",
    "LongMemory",
    "SemanticMemory",
    "MemoryEntry",
    "LongMemoryEntry",
    "MemoryManager",
]


class MemoryManager:
    """三层记忆架构的统一管理器。"""

    def __init__(self, session_id: str = "default", persona_id: str = "host") -> None:
        self.session_id = session_id
        self.persona_id = persona_id
        self.short = ShortMemory(session_id=session_id, persona_id=persona_id)
        self.long = LongMemory(persona_id=persona_id)
        self.semantic = SemanticMemory(persona_id=persona_id)

    def get_context_messages(self, system_prompt: str = "", recent_limit: int = 20) -> list:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.extend(self.short.get_recent(limit=recent_limit))
        return messages

    def summarize_to_long(self, key_facts: list, category: str = "session_summary", importance: float = 0.6) -> int:
        recent = self.short.get_recent(limit=50)
        if not recent:
            return 0
        summary_parts = [f"[{msg['role']}]: {msg['content'][:200]}" for msg in recent]
        summary = " | ".join(summary_parts[-10:])
        return self.long.store(summary=summary, key_facts=key_facts, category=category, importance=importance)

    def cleanup(self) -> None:
        self.short.clear()
