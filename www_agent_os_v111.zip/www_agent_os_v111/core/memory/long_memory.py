"""
LongMemory — 长时记忆层（经验压缩）

职责：
- 跨会话持久化重要经验与知识
- 基于重要性的记忆衰减
- 按 persona_id / category 分类检索
- 支持 JSON 格式的 key_facts 结构化事实存储

实现：SQLite 持久化存储，支持摘要、关键事实、向量引用。
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from database.sqlite.connection import get_db

logger = logging.getLogger(__name__)


@dataclass
class LongMemoryEntry:
    """长时记忆条目。"""

    persona_id: str = "host"
    category: str = "general"
    summary: str = ""
    key_facts: List[str] = field(default_factory=list)
    importance: float = 0.5
    embedding_id: str = ""


class LongMemory:
    """长时记忆：持久化的重要经验与知识。

    特性：
    - 按 persona + category 分类
    - 重要性加权检索
    - 支持最近使用 (LRU) 和访问计数
    - JSON 格式 key_facts 结构化存储
    """

    def __init__(self, persona_id: str = "host") -> None:
        self.persona_id = persona_id
        self._db = get_db()

    def store(
        self,
        summary: str,
        key_facts: Optional[List[str]] = None,
        category: str = "general",
        importance: float = 0.5,
        embedding_id: str = "",
    ) -> int:
        """存储一条长时记忆。

        Returns:
            新记录的 id。
        """
        with self._db.cursor() as cur:
            cur.execute(
                "INSERT INTO long_memory (persona_id, category, summary, key_facts, "
                "embedding_id, importance, created_at, last_accessed) "
                "VALUES (?, ?, ?, ?, ?, ?, julianday('now'), julianday('now'))",
                (
                    self.persona_id,
                    category,
                    summary,
                    json.dumps(key_facts or [], ensure_ascii=False),
                    embedding_id,
                    max(0.0, min(1.0, importance)),
                ),
            )
            return cur.lastrowid or 0

    def retrieve(
        self,
        category: Optional[str] = None,
        limit: int = 20,
        min_importance: float = 0.0,
    ) -> List[Dict[str, Any]]:
        """检索长时记忆。

        Args:
            category: 按分类过滤，None 则全部。
            limit: 最大返回数。
            min_importance: 最低重要性阈值。

        Returns:
            [{"id": ..., "summary": ..., "key_facts": [...], ...}, ...]
        """
        query = "SELECT * FROM long_memory WHERE persona_id = ? AND importance >= ?"
        params: List[Any] = [self.persona_id, min_importance]

        if category:
            query += " AND category = ?"
            params.append(category)

        query += " ORDER BY last_accessed DESC, importance DESC LIMIT ?"
        params.append(limit)

        with self._db.cursor() as cur:
            rows = cur.execute(query, params).fetchall()

        results = []
        for r in rows:
            entry = dict(r)
            try:
                entry["key_facts"] = json.loads(entry.get("key_facts", "[]"))
            except (json.JSONDecodeError, TypeError):
                entry["key_facts"] = []
            results.append(entry)

        # 更新访问时间
        if results:
            ids = [r["id"] for r in results]
            with self._db.cursor() as cur:
                cur.execute(
                    f"UPDATE long_memory SET last_accessed = julianday('now'), "
                    f"access_count = access_count + 1 WHERE id IN ({','.join('?' * len(ids))})",
                    ids,
                )

        return results

    def search(
        self,
        query: str,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """全文搜索长时记忆（基于 summary 模糊匹配）。"""
        with self._db.cursor() as cur:
            rows = cur.execute(
                "SELECT * FROM long_memory WHERE persona_id = ? AND summary LIKE ? "
                "ORDER BY importance DESC, last_accessed DESC LIMIT ?",
                (self.persona_id, f"%{query}%", limit),
            ).fetchall()
        results = []
        for r in rows:
            entry = dict(r)
            try:
                entry["key_facts"] = json.loads(entry.get("key_facts", "[]"))
            except (json.JSONDecodeError, TypeError):
                entry["key_facts"] = []
            results.append(entry)

        if results:
            ids = [r["id"] for r in results]
            with self._db.cursor() as cur:
                cur.execute(
                    f"UPDATE long_memory SET last_accessed = julianday('now'), "
                    f"access_count = access_count + 1 WHERE id IN ({','.join('?' * len(ids))})",
                    ids,
                )
        return results

    def update_importance(self, memory_id: int, importance: float) -> None:
        """更新记忆重要性。"""
        with self._db.cursor() as cur:
            cur.execute(
                "UPDATE long_memory SET importance = ? WHERE id = ? AND persona_id = ?",
                (max(0.0, min(1.0, importance)), memory_id, self.persona_id),
            )

    def delete(self, memory_id: int) -> bool:
        """删除指定记忆。"""
        with self._db.cursor() as cur:
            cur.execute(
                "DELETE FROM long_memory WHERE id = ? AND persona_id = ?",
                (memory_id, self.persona_id),
            )
            return cur.rowcount > 0

    def decay(self, threshold: float = 0.05) -> int:
        """衰减低于阈值的记忆，返回删除数。"""
        with self._db.cursor() as cur:
            cur.execute(
                "DELETE FROM long_memory WHERE persona_id = ? AND importance < ?",
                (self.persona_id, threshold),
            )
            return cur.rowcount

    def count(self, category: Optional[str] = None) -> int:
        """统计记忆数量。"""
        query = "SELECT COUNT(*) as cnt FROM long_memory WHERE persona_id = ?"
        params: List[Any] = [self.persona_id]
        if category:
            query += " AND category = ?"
            params.append(category)
        with self._db.cursor() as cur:
            row = cur.execute(query, params).fetchone()
        return row["cnt"] if row else 0

    def list_categories(self) -> List[str]:
        """列出当前 persona 的所有分类。"""
        with self._db.cursor() as cur:
            rows = cur.execute(
                "SELECT DISTINCT category FROM long_memory WHERE persona_id = ? ORDER BY category",
                (self.persona_id,),
            ).fetchall()
        return [r["category"] for r in rows]

    def compact(self, category: str = "general", max_entries: int = 100) -> int:
        """压缩记忆：用 LLM 将多条同类记忆合并为摘要。

        注意：此方法需要外部提供 LLM，这里仅做框架预留。
        实际调用时传入 summarizer 回调。
        """
        entries = self.retrieve(category=category, limit=max_entries * 2)
        if len(entries) <= max_entries:
            return 0
        return len(entries) - max_entries  # 返回需要压缩的条目数
