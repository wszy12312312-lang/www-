"""
core/memory/memory_migration — 旧 JSON → SQLite 完整迁移工具

将 data/memory/<persona>/ 下的旧 JSON 文件（history.json / scores.json /
experiences.json）迁移到 SQLite memory.db 对应表中。

支持：
- 按 persona 子目录自动发现
- history.json → short_memory（对话轮次）
- experiences.json → long_memory（经验/知识）
- scores.json → scores（评分记录）
- dry-run 模式（仅报告不写入）
- 批量 INSERT（事务内提交）
- 迁移进度报告与统计

Usage:
    python -m core.memory.memory_migration --data-dir data/memory/ [--dry-run] [--db-path ...]
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from database.sqlite.connection import get_db, init_db

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 数据结构
# ---------------------------------------------------------------------------


@dataclass
class MigrateStats:
    """单次迁移统计。"""
    persona_id: str = ""
    short_memory: int = 0
    long_memory: int = 0
    scores: int = 0
    skipped: int = 0
    errors: int = 0
    warnings: List[str] = field(default_factory=list)


@dataclass
class GlobalStats:
    """全局迁移统计。"""
    total_short: int = 0
    total_long: int = 0
    total_scores: int = 0
    total_skipped: int = 0
    total_errors: int = 0
    personas: int = 0
    elapsed_ms: float = 0.0
    per_persona: List[MigrateStats] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            "=" * 56,
            "  迁移完成报告",
            "=" * 56,
            f"  总 Persona 数:     {self.personas}",
            f"  短时记忆 (history → short_memory):    {self.total_short}",
            f"  长时记忆 (experiences → long_memory): {self.total_long}",
            f"  评分记录 (scores → scores):           {self.total_scores}",
            f"  总跳过:                              {self.total_skipped}",
            f"  总错误:                              {self.total_errors}",
            f"  耗时:                                {self.elapsed_ms:.0f} ms",
            "=" * 56,
        ]
        for s in self.per_persona:
            lines.append(
                f"  [{s.persona_id}] short={s.short_memory} long={s.long_memory} "
                f"scores={s.scores} skipped={s.skipped} errors={s.errors}"
            )
            for w in s.warnings:
                lines.append(f"    ⚠ {w}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------


def _discover_persona_dirs(data_dir: str) -> List[str]:
    """发现 data/memory/ 下所有 persona 子目录。"""
    root = Path(data_dir)
    if not root.is_dir():
        logger.warning("数据目录不存在: %s", data_dir)
        return []

    subdirs = []
    for entry in root.iterdir():
        if entry.is_dir():
            # 检查是否包含至少一个目标 JSON 文件
            has_json = any(
                (entry / f).is_file()
                for f in ("history.json", "scores.json", "experiences.json")
            )
            if has_json:
                subdirs.append(entry.name)
    return sorted(subdirs)


def _read_json(filepath: str) -> Optional[Any]:
    """安全读取 JSON 文件。"""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return None
    except json.JSONDecodeError as e:
        logger.warning("JSON 解析失败 %s: %s", filepath, e)
        return None
    except Exception as e:
        logger.warning("读取失败 %s: %s", filepath, e)
        return None


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# 各表迁移逻辑
# ---------------------------------------------------------------------------


def migrate_history(
    persona_id: str,
    data_dir: str,
    dry_run: bool = False,
) -> Tuple[int, int, List[str]]:
    """迁移 history.json → short_memory 表。

    history.json 格式：
        [
            {"role": "user", "content": "..."},
            {"role": "assistant", "content": "..."},
            ...
        ]

    Returns:
        (inserted, skipped, warnings)
    """
    filepath = os.path.join(data_dir, persona_id, "history.json")
    data = _read_json(filepath)
    if data is None:
        return (0, 0, [f"history.json 不存在或无法读取"])

    if not isinstance(data, list):
        return (0, 0, ["history.json 不是数组格式"])

    db = get_db()
    inserted = 0
    skipped = 0
    warnings: List[str] = []

    session_id = f"migrated_{persona_id}_{int(time.time())}"

    if not dry_run:
        try:
            with db.cursor() as cur:
                for entry in data:
                    role = entry.get("role", "user")
                    content = entry.get("content", "")
                    if not content or not isinstance(content, str):
                        skipped += 1
                        continue
                    cur.execute(
                        "INSERT INTO short_memory "
                        "(session_id, role, content, persona_id, created_at, ttl_seconds) "
                        "VALUES (?, ?, ?, ?, julianday('now'), 3600)",
                        (session_id, role, content, persona_id),
                    )
                    inserted += 1
        except Exception as e:
            logger.exception("history 迁移写入失败")
            warnings.append(f"history.json 写入异常: {e}")
            return (inserted, skipped, warnings)
    else:
        for entry in data:
            content = entry.get("content", "")
            if not content or not isinstance(content, str):
                skipped += 1
            else:
                inserted += 1

    return (inserted, skipped, warnings)


def migrate_experiences(
    persona_id: str,
    data_dir: str,
    dry_run: bool = False,
) -> Tuple[int, int, List[str]]:
    """迁移 experiences.json → long_memory 表。

    experiences.json 格式：
        [
            {
                "task_pattern": "...",
                "solution": "...",
                "outcome": "...",
                "score": 3.6,
                "persona": "host",
                "time": "2026-07-14T04:25:27"
            },
            ...
        ]

    Returns:
        (inserted, skipped, warnings)
    """
    filepath = os.path.join(data_dir, persona_id, "experiences.json")
    data = _read_json(filepath)
    if data is None:
        # 不是错误 — 很多 persona 没有 experiences.json
        return (0, 0, [])

    if not isinstance(data, list):
        return (0, 0, ["experiences.json 不是数组格式"])

    db = get_db()
    inserted = 0
    skipped = 0
    warnings: List[str] = []

    if not dry_run:
        try:
            with db.cursor() as cur:
                for entry in data:
                    task_pattern = entry.get("task_pattern", "")
                    solution = entry.get("solution", "")
                    outcome = entry.get("outcome", "")
                    score = _safe_float(entry.get("score"), 0.5)
                    entry_persona = entry.get("persona", persona_id)

                    # 构造 summary: 合并 task_pattern + solution + outcome
                    summary_parts = []
                    if task_pattern:
                        summary_parts.append(f"[任务] {task_pattern}")
                    if solution:
                        summary_parts.append(f"[方案] {solution[:300]}")
                    if outcome:
                        summary_parts.append(f"[结果] {outcome}")
                    summary = " | ".join(summary_parts) if summary_parts else "（空经验）"

                    # key_facts: 提取 task_pattern 和 outcome 作为事实片段
                    key_facts = []
                    if task_pattern:
                        key_facts.append(f"任务模式: {task_pattern}")
                    if outcome:
                        key_facts.append(f"结果: {outcome}")
                    key_facts.append(f"评分: {score}")

                    # importance 基于 score 映射
                    importance = max(0.1, min(1.0, score / 5.0))

                    cur.execute(
                        "INSERT INTO long_memory "
                        "(persona_id, category, summary, key_facts, embedding_id, "
                        "importance, created_at, last_accessed) "
                        "VALUES (?, ?, ?, ?, ?, ?, julianday('now'), julianday('now'))",
                        (
                            entry_persona,
                            "experience",
                            summary,
                            json.dumps(key_facts, ensure_ascii=False),
                            "",
                            importance,
                        ),
                    )
                    inserted += 1
        except Exception as e:
            logger.exception("experiences 迁移写入失败")
            warnings.append(f"experiences.json 写入异常: {e}")
            return (inserted, skipped, warnings)
    else:
        inserted = len(data)

    return (inserted, skipped, warnings)


def migrate_scores(
    persona_id: str,
    data_dir: str,
    dry_run: bool = False,
) -> Tuple[int, int, List[str]]:
    """迁移 scores.json → scores 表。

    scores.json 格式：
        {
            "incentive_stars": 5,
            "penalty_stars": 0,
            "task_count": 20,
            "task_score": 3.325,
            "score_log": [
                {
                    "time": "2026-07-14T04:25:27.476909",
                    "overall": 3.6,
                    "incentive_after": 3,
                    "penalty_after": 0
                },
                ...
            ]
        }

    Returns:
        (inserted, skipped, warnings)
    """
    filepath = os.path.join(data_dir, persona_id, "scores.json")
    data = _read_json(filepath)
    if data is None:
        return (0, 0, [f"scores.json 不存在或无法读取"])

    if not isinstance(data, dict):
        return (0, 0, ["scores.json 不是对象格式"])

    db = get_db()
    inserted = 0
    skipped = 0
    warnings: List[str] = []

    score_log = data.get("score_log", [])
    if not isinstance(score_log, list):
        warnings.append("score_log 不是数组，跳过")
        return (0, 0, warnings)

    if not dry_run:
        try:
            with db.cursor() as cur:
                for log_entry in score_log:
                    overall = _safe_float(log_entry.get("overall"), 0.0)
                    incentive = _safe_float(log_entry.get("incentive_after"), 0.0)
                    penalty = _safe_float(log_entry.get("penalty_after"), 0.0)
                    ts = log_entry.get("time", "")

                    # overall score 条目
                    cur.execute(
                        "INSERT INTO scores "
                        "(persona_id, session_id, criterion, score, reason, created_at) "
                        "VALUES (?, ?, ?, ?, ?, julianday('now'))",
                        (persona_id, f"migrated_{persona_id}", "overall", overall, f"源时间: {ts}"),
                    )
                    inserted += 1

                    # incentive 条目
                    if incentive:
                        cur.execute(
                            "INSERT INTO scores "
                            "(persona_id, session_id, criterion, score, reason, created_at) "
                            "VALUES (?, ?, ?, ?, ?, julianday('now'))",
                            (persona_id, f"migrated_{persona_id}", "incentive", incentive, f"源时间: {ts}"),
                        )
                        inserted += 1

                    # penalty 条目
                    if penalty and penalty > 0:
                        cur.execute(
                            "INSERT INTO scores "
                            "(persona_id, session_id, criterion, score, reason, created_at) "
                            "VALUES (?, ?, ?, ?, ?, julianday('now'))",
                            (persona_id, f"migrated_{persona_id}", "penalty", -penalty, f"源时间: {ts}"),
                        )
                        inserted += 1
        except Exception as e:
            logger.exception("scores 迁移写入失败")
            warnings.append(f"scores.json 写入异常: {e}")
            return (inserted, skipped, warnings)
    else:
        for log_entry in score_log:
            inserted += 1  # overall
            if log_entry.get("incentive_after"):
                inserted += 1
            if log_entry.get("penalty_after", 0) > 0:
                inserted += 1

    return (inserted, skipped, warnings)


# ---------------------------------------------------------------------------
# 主迁移流程
# ---------------------------------------------------------------------------


def migrate_persona(
    persona_id: str,
    data_dir: str,
    dry_run: bool = False,
) -> MigrateStats:
    """迁移单个 persona 的所有 JSON 文件。"""
    stats = MigrateStats(persona_id=persona_id)
    persona_path = os.path.join(data_dir, persona_id)

    logger.info(
        "迁移 persona [%s] (dry_run=%s) → %s",
        persona_id, dry_run, persona_path,
    )

    # 1. history.json → short_memory
    n, skipped, warns = migrate_history(persona_id, data_dir, dry_run)
    stats.short_memory = n
    stats.skipped += skipped
    stats.warnings.extend(warns)

    # 2. experiences.json → long_memory
    n, skipped, warns = migrate_experiences(persona_id, data_dir, dry_run)
    stats.long_memory = n
    stats.skipped += skipped
    stats.warnings.extend(warns)

    # 3. scores.json → scores
    n, skipped, warns = migrate_scores(persona_id, data_dir, dry_run)
    stats.scores = n
    stats.skipped += skipped
    stats.warnings.extend(warns)

    return stats


def migrate_all(
    data_dir: str = "data/memory/",
    dry_run: bool = False,
    persona_filter: Optional[List[str]] = None,
) -> GlobalStats:
    """执行完整迁移。

    Args:
        data_dir: data/memory/ 目录路径。
        dry_run: True 时仅统计，不写入数据库。
        persona_filter: 可选，仅迁移指定 persona 列表。

    Returns:
        GlobalStats 迁移统计。
    """
    t0 = time.perf_counter()

    # 初始化数据库连接
    if not dry_run:
        init_db()

    persona_dirs = _discover_persona_dirs(data_dir)
    if persona_filter:
        persona_dirs = [p for p in persona_dirs if p in persona_filter]

    if not persona_dirs:
        logger.warning("没有找到可迁移的 persona 目录（data_dir=%s）", data_dir)
        return GlobalStats()

    gs = GlobalStats(personas=len(persona_dirs))

    for persona_id in persona_dirs:
        stats = migrate_persona(persona_id, data_dir, dry_run)
        gs.total_short += stats.short_memory
        gs.total_long += stats.long_memory
        gs.total_scores += stats.scores
        gs.total_skipped += stats.skipped
        gs.total_errors += stats.errors
        gs.per_persona.append(stats)

    gs.elapsed_ms = (time.perf_counter() - t0) * 1000

    if dry_run:
        logger.info("=== DRY-RUN 报告 ===\n%s", gs.summary())
    else:
        logger.info("迁移完成。\n%s", gs.summary())

    return gs


# ---------------------------------------------------------------------------
# CLI 入口
# ---------------------------------------------------------------------------


def main() -> None:
    """命令行入口。

    Usage:
        python -m core.memory.memory_migration --data-dir data/memory/
        python -m core.memory.memory_migration --data-dir data/memory/ --dry-run
        python -m core.memory.memory_migration --data-dir data/memory/ --persona host,S1
    """
    import argparse

    parser = argparse.ArgumentParser(
        description="旧 JSON → SQLite 记忆迁移工具",
    )
    parser.add_argument(
        "--data-dir",
        default="data/memory/",
        help="data/memory/ 目录路径（默认: data/memory/）",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="仅统计不写入",
    )
    parser.add_argument(
        "--persona",
        default="",
        help="逗号分隔的 persona 列表，留空则全部迁移",
    )
    parser.add_argument(
        "--db-path",
        default="",
        help="SQLite 数据库路径（默认: data/sqlite/memory.db）",
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-7s  %(message)s",
        datefmt="%H:%M:%S",
    )

    persona_filter = None
    if args.persona:
        persona_filter = [p.strip() for p in args.persona.split(",") if p.strip()]

    gs = migrate_all(
        data_dir=args.data_dir,
        dry_run=args.dry_run,
        persona_filter=persona_filter,
    )

    print(gs.summary())


if __name__ == "__main__":
    main()
