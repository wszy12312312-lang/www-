"""
ShortMemory — 短时记忆层（会话级别）

职责：
- 当前会话的对话轮次暂存
- TTL 过期自动清理
- 上下文窗口管理（截断旧消息）

实现：SQLite 存储，支持按 session_id / persona_id 查询。
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from database.sqlite.connection import get_db

logger = logging.getLogger(__name__)

DEFAULT_TTL = 3600  # 1 小时
DEFAULT_MAX_TURNS = 50


@dataclass
class MemoryEntry:
    """短时记忆条目。"""

    role: str  # 'user' / 'assistant' / 'system'
    content: str
    persona_id: str = "host"
    metadata: Dict[str, Any] = field(default_factory=dict)


class ShortMemory:
    """短时记忆：会话级别的对话轮次存储。

    特性：
    - 按 session_id 隔离
    - 自动 TTL 清理
    - 上下文窗口截断
    - 可序列化为 LLM messages 格式
    """

    def __init__(
        self,
        session_id: str,
        persona_id: str = "host",
        max_turns: int = DEFAULT_MAX_TURNS,
        ttl_seconds: int = DEFAULT_TTL,
    ) -> None:
        self.session_id = session_id
        self.persona_id = persona_id
        self.max_turns = max_turns
        self.ttl_seconds = ttl_seconds
        self._db = get_db()
        self._cleanup_expired()

    def _cleanup_expired(self) -> None:
        """清理过期条目。"""
        cutoff = time.time() - self.ttl_seconds
        try:
            with self._db.cursor() as cur:
                cur.execute(
                    "DELETE FROM short_memory WHERE session_id = ? AND created_at < ?",
                    (self.session_id, cutoff),
                )
        except Exception:
            logger.debug("短时记忆过期清理失败", exc_info=True)

    def add(self, role: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """添加一条记忆。"""
        with self._db.cursor() as cur:
            cur.execute(
                "INSERT INTO short_memory (session_id, role, content, persona_id, created_at, ttl_seconds) "
                "VALUES (?, ?, ?, ?, julianday('now'), ?)",
                (self.session_id, role, content, self.persona_id, self.ttl_seconds),
            )

    def add_batch(self, entries: List[MemoryEntry]) -> None:
        """批量添加。"""
        with self._db.cursor() as cur:
            cur.executemany(
                "INSERT INTO short_memory (session_id, role, content, persona_id, created_at, ttl_seconds) "
                "VALUES (?, ?, ?, ?, julianday('now'), ?)",
                [
                    (self.session_id, e.role, e.content, e.persona_id, self.ttl_seconds)
                    for e in entries
                ],
            )

    def get_recent(self, limit: Optional[int] = None) -> List[Dict[str, str]]:
        """获取最近的对话轮次（llm messages 格式）。

        Args:
            limit: 最大轮次数，不传则用 max_turns。

        Returns:
            [{"role": "user", "content": "..."}, ...]
        """
        if limit is None:
            limit = self.max_turns
        self._cleanup_expired()
        with self._db.cursor() as cur:
            rows = cur.execute(
                "SELECT role, content FROM short_memory "
                "WHERE session_id = ? "
                "ORDER BY id DESC LIMIT ?",
                (self.session_id, limit),
            ).fetchall()
        messages = [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]
        return messages

    def get_all(self) -> List[Dict[str, str]]:
        """获取全部记忆。"""
        self._cleanup_expired()
        with self._db.cursor() as cur:
            rows = cur.execute(
                "SELECT role, content FROM short_memory WHERE session_id = ? ORDER BY id ASC",
                (self.session_id,),
            ).fetchall()
        return [{"role": r["role"], "content": r["content"]} for r in rows]

    def to_messages(self, system_prompt: str = "") -> List[Dict[str, str]]:
        """转为完整 messages 列表（含 system prompt，适用于 LLM API）。"""
        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.extend(self.get_recent())
        return messages

    def clear(self) -> None:
        """清除当前会话所有短时记忆。"""
        with self._db.cursor() as cur:
            cur.execute("DELETE FROM short_memory WHERE session_id = ?", (self.session_id,))

    def count(self) -> int:
        """返回当前会话的记忆条目数。"""
        with self._db.cursor() as cur:
            row = cur.execute(
                "SELECT COUNT(*) as cnt FROM short_memory WHERE session_id = ?",
                (self.session_id,),
            ).fetchone()
        return row["cnt"] if row else 0
