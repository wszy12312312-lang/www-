"""
EventScheduler — 轻量定时器调度模块

提供简单的每日/每周定时任务注册与执行。
基于 threading.Timer 实现，不依赖外部任务队列服务。

用法:
    from core.scheduler import EventScheduler

    scheduler = EventScheduler()
    scheduler.schedule_daily("daily-review", 12, 0, callback, args)
    scheduler.schedule_weekly("weekly-deep", 5, 12, 0, callback, args)  # 周五=4=周六
    scheduler.cancel("daily-review")
    scheduler.shutdown()
"""

from __future__ import annotations

import datetime
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger("EventScheduler")


@dataclass
class ScheduledJob:
    """定时任务描述。"""

    job_id: str
    kind: str                       # "daily" | "weekly"
    hour: int
    minute: int
    weekday: int = -1               # weekly: 0=Mon ... 6=Sun
    callback: Optional[Callable] = None
    args: tuple = ()
    enabled: bool = True
    next_run: float = 0.0           # Unix timestamp
    _timer: Optional[threading.Timer] = field(default=None, repr=False)
    _shutdown: bool = field(default=False, repr=False)


class EventScheduler:
    """轻量定时器调度器。

    每个 job 通过 threading.Timer 实现，到期后自动 reschedule 自身。
    线程安全，支持新增/取消/关闭。

    精度: ±1 秒级，适合每日/每周评估场景。
    """

    def __init__(self, name: str = "default") -> None:
        self.name = name
        self._jobs: Dict[str, ScheduledJob] = {}
        self._lock = threading.RLock()
        self._shutdown_flag = threading.Event()
        logger.info("EventScheduler[%s] 已创建", name)

    # ------------------------------------------------------------------
    # 公开 API
    # ------------------------------------------------------------------

    def schedule_daily(
        self,
        job_id: str,
        hour: int,
        minute: int,
        callback: Callable,
        args: tuple = (),
    ) -> ScheduledJob:
        """注册每日定时任务。

        Args:
            job_id: 唯一标识符。
            hour: 小时（0-23）。
            minute: 分钟（0-59）。
            callback: 到期时调用的函数。
            args: 传递给 callback 的参数。

        Returns:
            ScheduledJob 实例。

        Raises:
            ValueError: job_id 已存在。
        """
        with self._lock:
            if job_id in self._jobs:
                raise ValueError(f"Job '{job_id}' 已存在")
            job = ScheduledJob(
                job_id=job_id,
                kind="daily",
                hour=hour,
                minute=minute,
                callback=callback,
                args=args,
            )
            self._jobs[job_id] = job
            self._reschedule(job)
            logger.info("EventScheduler[%s] 注册每日任务: %s @ %02d:%02d",
                        self.name, job_id, hour, minute)
            return job

    def schedule_weekly(
        self,
        job_id: str,
        weekday: int,
        hour: int,
        minute: int,
        callback: Callable,
        args: tuple = (),
    ) -> ScheduledJob:
        """注册每周定时任务。

        Args:
            job_id: 唯一标识符。
            weekday: 星期几（0=Mon ... 6=Sun）。
            hour: 小时（0-23）。
            minute: 分钟（0-59）。
            callback: 到期时调用的函数。
            args: 传递给 callback 的参数。

        Returns:
            ScheduledJob 实例。
        """
        with self._lock:
            if job_id in self._jobs:
                raise ValueError(f"Job '{job_id}' 已存在")
            job = ScheduledJob(
                job_id=job_id,
                kind="weekly",
                hour=hour,
                minute=minute,
                weekday=weekday,
                callback=callback,
                args=args,
            )
            self._jobs[job_id] = job
            self._reschedule(job)
            logger.info("EventScheduler[%s] 注册每周任务: %s @ 周%d %02d:%02d",
                        self.name, job_id, weekday, hour, minute)
            return job

    def cancel(self, job_id: str) -> bool:
        """取消定时任务。

        Args:
            job_id: 任务标识。

        Returns:
            True 表示成功取消，False 表示不存在。
        """
        with self._lock:
            job = self._jobs.pop(job_id, None)
            if job is None:
                return False
            if job._timer is not None:
                job._timer.cancel()
            job._shutdown = True
            logger.info("EventScheduler[%s] 取消任务: %s", self.name, job_id)
            return True

    def list_jobs(self) -> list[dict]:
        """列出所有已注册任务。"""
        with self._lock:
            return [
                {
                    "job_id": j.job_id,
                    "kind": j.kind,
                    "hour": j.hour,
                    "minute": j.minute,
                    "weekday": j.weekday if j.kind == "weekly" else None,
                    "enabled": j.enabled,
                    "next_run": datetime.datetime.fromtimestamp(j.next_run).isoformat() if j.next_run else None,
                }
                for j in self._jobs.values()
            ]

    def shutdown(self) -> None:
        """关闭调度器，取消所有定时任务。"""
        self._shutdown_flag.set()
        with self._lock:
            for job in list(self._jobs.values()):
                if job._timer is not None:
                    job._timer.cancel()
            self._jobs.clear()
        logger.info("EventScheduler[%s] 已关闭", self.name)

    # ------------------------------------------------------------------
    # 内部
    # ------------------------------------------------------------------

    def _reschedule(self, job: ScheduledJob) -> None:
        """计算下次触发时间并启动 Timer。"""
        if self._shutdown_flag.is_set():
            return

        next_time = self._next_run(job)
        job.next_run = next_time

        delay = next_time - time.time()
        if delay < 0:
            delay = 0  # 立即触发

        def _run() -> None:
            if self._shutdown_flag.is_set() or job._shutdown:
                return
            try:
                if job.callback is not None:
                    job.callback(*job.args)
            except Exception as e:
                logger.error("EventScheduler[%s] job '%s' 执行异常: %s",
                            self.name, job.job_id, e)
            # 重新调度下一次
            if not self._shutdown_flag.is_set() and not job._shutdown:
                self._reschedule(job)

        job._timer = threading.Timer(delay, _run)
        job._timer.daemon = True
        job._timer.start()

    @staticmethod
    def _next_run(job: ScheduledJob) -> float:
        """计算下次运行时间的 Unix 时间戳。"""
        now = datetime.datetime.now()
        target = now.replace(
            hour=job.hour, minute=job.minute, second=0, microsecond=0
        )

        if job.kind == "daily":
            if target <= now:
                target += datetime.timedelta(days=1)
        elif job.kind == "weekly":
            days_ahead = job.weekday - now.weekday()
            if days_ahead < 0:
                days_ahead += 7
            target = target.replace(
                day=now.day + (days_ahead if days_ahead > 0 else 7)
            )
            if days_ahead == 0 and target <= now:
                target += datetime.timedelta(days=7)

        return target.timestamp()
