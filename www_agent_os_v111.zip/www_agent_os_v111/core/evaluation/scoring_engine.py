"""
ScoringEngine — 独立评分引擎

将评分逻辑从旧 WWWSystem 中解耦，支持两种评估模式：
1. LLM 评估（S 监察员模式）：通过 LLM 对回答进行四维打分
2. 算法评估（Evaluator 模式）：基于输出特征的算法评分

两种模式可配置切换，评分结果统一通过 ScoringResult 返回，
由 PersonaManager.update_score() 应用激励/惩戒。

版本: 1.0.0
"""

from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional

from core.evaluation.evaluator import Evaluator, EvaluationResult

logger = logging.getLogger(__name__)


@dataclass
class ScoringResult:
    """评分结果（统一格式）。

    四维评分：准确性(40%) + 完整性(30%) + 格式(20%) + 效率(10%)
    overall 范围：0.0 ~ 5.0（与旧系统兼容）
    """

    accuracy: float = 3.0       # 0~5
    completeness: float = 3.0   # 0~5
    format: float = 3.0         # 0~5
    efficiency: float = 3.0     # 0~5
    overall: float = 3.0        # 加权总分 0~5
    comment: str = ""
    method: str = "algorithm"   # "llm" 或 "algorithm"
    timestamp: float = field(default_factory=time.time)

    @property
    def normalized_overall(self) -> float:
        """归一化到 0.0~1.0。"""
        return min(self.overall / 5.0, 1.0)

    def to_dict(self) -> dict:
        return {
            "accuracy": self.accuracy,
            "completeness": self.completeness,
            "format": self.format,
            "efficiency": self.efficiency,
            "overall": self.overall,
            "comment": self.comment,
            "method": self.method,
        }


class ScoringEngine:
    """独立评分引擎。

    替代 WWWSystem.s6_evaluate() + apply_score()，
    支持配置化切换 LLM 评分和算法评分。

    Usage::

        engine = ScoringEngine(llm_callback=ollama_chat_fn)
        result = engine.evaluate("S1", "用户问题", "人格回答")
        print(result.overall)  # 0~5
    """

    # 四维权重（与旧系统一致）
    WEIGHT_ACCURACY = 0.40
    WEIGHT_COMPLETENESS = 0.30
    WEIGHT_FORMAT = 0.20
    WEIGHT_EFFICIENCY = 0.10

    # 激励/惩戒阈值
    THRESHOLD_INCENTIVE = 4.0    # >= 4 加激励星
    THRESHOLD_PENALTY = 3.0      # < 3 加惩戒星

    def __init__(
        self,
        llm_callback: Optional[Callable[[str, str], str]] = None,
        use_llm: bool = True,
        sanitizer: Optional[Callable[[str], str]] = None,
    ) -> None:
        """初始化评分引擎。

        Args:
            llm_callback: LLM 调用函数 (model_name, prompt) → response_text。
                          为 None 时自动退回算法评分。
            use_llm: 是否优先使用 LLM 评分。
            sanitizer: 输入净化函数，对 question 和 answer 进行预处理。
        """
        self._llm = llm_callback
        self._use_llm = use_llm and llm_callback is not None
        self._sanitizer = sanitizer or (lambda x: x)
        self._algorithmic = Evaluator()
        self._history: list[ScoringResult] = []

    # ------------------------------------------------------------------
    # 评估
    # ------------------------------------------------------------------

    def evaluate(
        self,
        persona_id: str,
        question: str,
        answer: str,
        model_name: str = "",
    ) -> ScoringResult:
        """执行评分。

        Args:
            persona_id: 被评人格 ID。
            question: 用户原始问题。
            answer: 人格的回答。
            model_name: LLM 评分使用的模型名（仅 LLM 模式有效）。

        Returns:
            ScoringResult 评分结果。
        """
        # 输入净化
        safe_q = self._sanitizer(question)
        safe_a = self._sanitizer(answer)

        if self._use_llm and self._llm is not None:
            result = self._llm_evaluate(persona_id, safe_q, safe_a, model_name)
        else:
            result = self._algorithm_evaluate(persona_id, safe_q, safe_a)

        self._history.append(result)
        return result

    def _llm_evaluate(
        self,
        persona_id: str,
        question: str,
        answer: str,
        model_name: str,
    ) -> ScoringResult:
        """LLM 评分（S 监察员模式）。"""
        prompt = self._build_eval_prompt(persona_id, question, answer)

        try:
            response = self._llm(model_name, prompt) if model_name else self._llm("default", prompt)
            parsed = self._extract_json(response)

            if parsed and "overall" in parsed:
                return ScoringResult(
                    accuracy=float(parsed.get("accuracy", 3)),
                    completeness=float(parsed.get("completeness", 3)),
                    format=float(parsed.get("format", 3)),
                    efficiency=float(parsed.get("efficiency", 3)),
                    overall=float(parsed.get("overall", 3)),
                    comment=parsed.get("comment", ""),
                    method="llm",
                )
        except Exception as e:
            logger.warning("LLM 评分异常，退回算法评分: %s", e)

        return self._algorithm_evaluate(persona_id, question, answer)

    def _algorithm_evaluate(
        self,
        persona_id: str,
        question: str,
        answer: str,
    ) -> ScoringResult:
        """算法评分（Evaluator 模式）。"""
        eval_result = self._algorithmic.evaluate(
            task_id=persona_id,
            task_description=question,
            output=answer,
        )

        # 将 0.0~1.0 映射到 0~5
        return ScoringResult(
            accuracy=round(eval_result.accuracy * 5, 1),
            completeness=round(eval_result.completeness * 5, 1),
            format=round(eval_result.completeness * 5, 1),  # 复用 completeness
            efficiency=round(eval_result.efficiency * 5, 1),
            overall=round(eval_result.overall_score * 5, 1),
            comment=eval_result.notes,
            method="algorithm",
        )

    @staticmethod
    def _build_eval_prompt(persona_id: str, question: str, answer: str) -> str:
        """构建 LLM 评分 prompt。"""
        return (
            f"你是 S 监察员。对以下回答评分（1-5星）。\n"
            f"四维标准：准确性40% + 完整性30% + 格式20% + 效率10%\n\n"
            f"用户问题：{question}\n"
            f"{persona_id} 的回答：{answer}\n\n"
            f'回复JSON格式：'
            f'{{"accuracy": 4, "completeness": 3, "format": 4, "efficiency": 3, '
            f'"overall": 3.5, "comment": "评语"}}'
        )

    @staticmethod
    def _extract_json(text: str) -> Optional[dict]:
        """从模型回复中提取 JSON（从旧系统迁移，增加长度限制）。"""
        MAX_INPUT = 102400  # 100KB
        if len(text) > MAX_INPUT:
            text = text[:MAX_INPUT]

        # 清洗中文引号
        cleaned = (
            text.replace("\u201c", '"').replace("\u201d", '"')
                .replace("\u2018", "'").replace("\u2019", "'")
        )
        # 去尾逗号
        cleaned = re.sub(r",\s*}", "}", cleaned)
        cleaned = re.sub(r",\s*]", "]", cleaned)

        # 优先提取 markdown 代码块
        md_match = re.search(r"```(?:json)?\s*([\s\S]*?)```", cleaned)
        if md_match:
            try:
                return json.loads(md_match.group(1).strip())
            except json.JSONDecodeError:
                pass

        # 逐字符匹配完整 JSON
        start = cleaned.find("{")
        if start == -1:
            return None
        depth = 0
        for i in range(start, len(cleaned)):
            if cleaned[i] == "{":
                depth += 1
            elif cleaned[i] == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(cleaned[start:i + 1])
                    except json.JSONDecodeError:
                        return None

        # 兜底：正则提取 overall
        overall_match = re.search(r'"overall"\s*:\s*([\d.]+)', text)
        comment_match = re.search(r'"comment"\s*:\s*"([^"]*)"', text)
        if overall_match:
            return {
                "overall": float(overall_match.group(1)),
                "comment": comment_match.group(1) if comment_match else "",
            }
        return None

    # ------------------------------------------------------------------
    # 激励/惩戒计算
    # ------------------------------------------------------------------

    def compute_incentive(self, overall: float) -> tuple[int, int]:
        """根据 overall 分数计算激励/惩戒变化。

        互斥逻辑：
        - overall >= 4 → 激励 +1
        - overall < 3  → 惩戒 +1
        - 3 <= overall < 4 → 不变

        Returns:
            (incentive_delta, penalty_delta)
        """
        if overall >= self.THRESHOLD_INCENTIVE:
            return (1, 0)
        if overall < self.THRESHOLD_PENALTY:
            return (0, 1)
        return (0, 0)

    # ------------------------------------------------------------------
    # 统计
    # ------------------------------------------------------------------

    def get_history(self, limit: int = 50) -> list[ScoringResult]:
        """获取评分历史。"""
        return self._history[-limit:]

    def get_average(self, last_n: int = 10) -> dict[str, float]:
        """获取最近 N 次评分均值。"""
        recent = self._history[-last_n:]
        if not recent:
            return {}
        n = len(recent)
        return {
            "overall": round(sum(r.overall for r in recent) / n, 2),
            "accuracy": round(sum(r.accuracy for r in recent) / n, 2),
            "completeness": round(sum(r.completeness for r in recent) / n, 2),
            "format": round(sum(r.format for r in recent) / n, 2),
            "efficiency": round(sum(r.efficiency for r in recent) / n, 2),
        }
