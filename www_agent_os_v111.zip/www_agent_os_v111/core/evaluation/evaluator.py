"""
Evaluator — 反馈学习循环

职责：
- 任务执行质量评估
- 多维度打分（准确性、效率、完整性）
- 奖励信号计算
- 记忆重要性更新
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class EvaluationResult:
    """评估结果。"""
    task_id: str
    overall_score: float  # 0.0 ~ 1.0
    accuracy: float = 0.0
    efficiency: float = 0.0
    completeness: float = 0.0
    user_satisfaction: float = 0.0
    notes: str = ""
    timestamp: float = field(default_factory=time.time)


@dataclass
class RewardSignal:
    """奖励信号。"""
    value: float
    source: str  # 'auto', 'user_feedback', 'comparison'
    confidence: float = 0.5
    metadata: Dict[str, Any] = field(default_factory=dict)


class Evaluator:
    """任务评估器 — 多维度质量评估 + 奖励信号。"""

    def __init__(self, llm_callback: Optional[Callable] = None) -> None:
        self._llm = llm_callback
        self._history: List[EvaluationResult] = []

    def evaluate(
        self,
        task_id: str,
        task_description: str,
        output: Any,
        expected: Optional[Any] = None,
        metrics: Optional[Dict[str, Any]] = None,
    ) -> EvaluationResult:
        """执行多维度评估。

        Args:
            task_id: 任务标识。
            task_description: 任务描述。
            output: 实际输出。
            expected: 期望输出。
            metrics: 性能指标（如耗时、内存等）。

        Returns:
            EvaluationResult。
        """
        accuracy = self._score_accuracy(output, expected)
        efficiency = self._score_efficiency(metrics or {})
        completeness = self._score_completeness(output, task_description)

        overall = (accuracy * 0.4 + efficiency * 0.2 + completeness * 0.3 + 0.1)

        result = EvaluationResult(
            task_id=task_id,
            overall_score=round(overall, 3),
            accuracy=round(accuracy, 3),
            efficiency=round(efficiency, 3),
            completeness=round(completeness, 3),
            notes=self._generate_notes(accuracy, efficiency, completeness),
        )
        self._history.append(result)
        return result

    def _score_accuracy(self, output: Any, expected: Optional[Any]) -> float:
        """准确性评分。"""
        if expected is None:
            return 0.7  # 无参考时中等偏上
        if output == expected:
            return 1.0
        if isinstance(output, str) and isinstance(expected, str):
            # 简单字符串相似度
            if expected.lower() in output.lower() or output.lower() in expected.lower():
                return 0.8
            common = set(output.split()) & set(expected.split())
            total = set(expected.split())
            return len(common) / max(len(total), 1) if total else 0.5
        if isinstance(output, (int, float)) and isinstance(expected, (int, float)):
            diff = abs(output - expected)
            return max(0.0, 1.0 - diff / max(abs(expected), 1))
        return 0.5

    def _score_efficiency(self, metrics: Dict[str, Any]) -> float:
        """效率评分。"""
        if not metrics:
            return 0.7

        elapsed = metrics.get("elapsed_ms", 0)
        expected_ms = metrics.get("expected_ms", 5000)
        memory_mb = metrics.get("memory_mb", 0)
        max_memory_mb = metrics.get("max_memory_mb", 512)

        time_score = max(0.0, 1.0 - elapsed / max(expected_ms, 1)) if expected_ms > 0 else 0.8
        mem_score = max(0.0, 1.0 - memory_mb / max(max_memory_mb, 1)) if max_memory_mb > 0 else 0.8

        return round((time_score * 0.6 + mem_score * 0.4), 3)

    def _score_completeness(self, output: Any, task_description: str) -> float:
        """完整性评分。"""
        if output is None:
            return 0.0
        if isinstance(output, str) and len(output) == 0:
            return 0.0
        if isinstance(output, (list, dict)) and len(output) == 0:
            return 0.3
        if isinstance(output, str) and len(output) > 100:
            return 0.8
        return 0.6

    def _generate_notes(self, accuracy: float, efficiency: float, completeness: float) -> str:
        """生成评估备注。"""
        notes = []
        if accuracy < 0.5:
            notes.append("准确性偏低")
        if efficiency < 0.4:
            notes.append("效率需要优化")
        if completeness < 0.5:
            notes.append("输出不完整")
        if not notes:
            notes.append("整体表现良好")
        return "; ".join(notes)

    def compute_reward(self, evaluation: EvaluationResult,
                       user_feedback: Optional[float] = None) -> RewardSignal:
        """根据评估计算奖励信号。

        Args:
            evaluation: 评估结果。
            user_feedback: 用户显式反馈（0~1）。

        Returns:
            RewardSignal。
        """
        if user_feedback is not None:
            return RewardSignal(
                value=user_feedback,
                source="user_feedback",
                confidence=0.9,
            )

        reward = evaluation.overall_score
        return RewardSignal(
            value=reward,
            source="auto",
            confidence=0.6,
        )

    def get_average_scores(self, last_n: int = 10) -> Dict[str, float]:
        """获取最近 N 次评估的平均分。"""
        recent = self._history[-last_n:]
        if not recent:
            return {}
        n = len(recent)
        return {
            "overall": round(sum(r.overall_score for r in recent) / n, 3),
            "accuracy": round(sum(r.accuracy for r in recent) / n, 3),
            "efficiency": round(sum(r.efficiency for r in recent) / n, 3),
            "completeness": round(sum(r.completeness for r in recent) / n, 3),
        }

    def get_history(self, limit: int = 50) -> List[EvaluationResult]:
        return self._history[-limit:]


class RewardAggregator:
    """奖励聚合器 — 累积奖励并更新长期记忆重要性。"""

    def __init__(self, decay_factor: float = 0.95) -> None:
        self.decay_factor = decay_factor
        self._cumulative: float = 0.0
        self._steps: int = 0

    def add(self, reward: RewardSignal) -> float:
        """添加奖励信号并返回加权累积值。"""
        self._cumulative = self._cumulative * self.decay_factor + reward.value
        self._steps += 1
        return self._cumulative

    @property
    def average(self) -> float:
        if self._steps == 0:
            return 0.0
        return self._cumulative / self._steps

    def reset(self) -> None:
        self._cumulative = 0.0
        self._steps = 0
