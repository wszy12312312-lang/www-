"""
core/evaluation/reward — 奖励信号系统

提供完整的奖励信号建模与聚合能力，与 evaluator.py 的评估结果对接。

核心组件：
- RewardSignal:  带时间戳、来源、分值、权重的奖励信号
- RewardAggregator: 支持指数衰减累积、时间衰减因子的奖励聚合器
- per_persona_aggregate: 按 Persona 维度汇总奖励

设计理念：
- 每次评估结果可转化为一个或多个 RewardSignal
- RewardAggregator 维护滑动窗口累积值，越早的奖励权重越低
- 支持按 persona 维度独立跟踪，适配多 Agent 场景
"""

from __future__ import annotations

import logging
import math
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from core.evaluation.evaluator import EvaluationResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

DEFAULT_DECAY_FACTOR = 0.95        # 每步衰减因子
DEFAULT_TIME_DECAY_HALFLIFE = 3600.0  # 时间衰减半衰期（秒），默认 1 小时


# ---------------------------------------------------------------------------
# RewardSignal — 奖励信号
# ---------------------------------------------------------------------------


@dataclass
class RewardSignal:
    """单个奖励信号。

    每个信号记录一次评估/反馈的来源、分值、权重与时间戳，
    可用于下游强化学习或重要性更新。

    Attributes:
        value:      奖励值，-1.0 ~ 1.0（负值表示惩罚）。
        source:     来源标识：'auto' | 'user_feedback' | 'comparison' | 'oracle' 等。
        weight:     该信号的权重（0.0~1.0），用于加权聚合。
        timestamp:  Unix 时间戳，用于时间衰减计算。
        confidence: 信号置信度（0.0~1.0），越高表示越可靠。
        persona_id: 关联的 Persona ID。
        dimension:  评分维度标签，如 'accuracy' / 'efficiency' / 'completeness'。
        metadata:   附加元数据（任务 ID、备注等）。
    """

    value: float
    source: str = "auto"
    weight: float = 1.0
    timestamp: float = field(default_factory=time.time)
    confidence: float = 0.5
    persona_id: str = "host"
    dimension: str = "overall"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # 钳制合理范围
        self.value = max(-1.0, min(1.0, self.value))
        self.weight = max(0.0, min(1.0, self.weight))
        self.confidence = max(0.0, min(1.0, self.confidence))

    @property
    def weighted_value(self) -> float:
        """权重 × 置信度 加权后的奖励值。"""
        return self.value * self.weight * self.confidence

    @property
    def age_seconds(self) -> float:
        """信号距今的秒数。"""
        return max(0.0, time.time() - self.timestamp)

    @classmethod
    def from_evaluation(
        cls,
        result: EvaluationResult,
        persona_id: str = "host",
        weight: float = 1.0,
    ) -> List[RewardSignal]:
        """从 EvaluationResult 生成一组奖励信号（按维度拆分）。

        每个评估维度（overall / accuracy / efficiency / completeness）
        独立生成一个 RewardSignal，方便按维度粒度聚合分析。

        Args:
            result:     evaluator.py 产出的评估结果。
            persona_id: 所属 persona。
            weight:     基础权重。

        Returns:
            按维度拆分的 RewardSignal 列表。
        """
        ts = result.timestamp if result.timestamp > 0 else time.time()
        signals: List[RewardSignal] = []

        dimensions = [
            ("overall", result.overall_score),
            ("accuracy", result.accuracy),
            ("efficiency", result.efficiency),
            ("completeness", result.completeness),
        ]

        for dim_name, score in dimensions:
            if score == 0.0 and dim_name != "overall":
                continue  # 跳过未评分的维度

            # 归一化到 -1~1：假设原始分数 0~1
            normalized = (score - 0.5) * 2.0  # 0.5 → 0, 1.0 → 1.0, 0.0 → -1.0

            signals.append(cls(
                value=round(normalized, 4),
                source="auto",
                weight=weight,
                timestamp=ts,
                confidence=0.6,
                persona_id=persona_id,
                dimension=dim_name,
                metadata={
                    "task_id": result.task_id,
                    "notes": result.notes,
                    "user_satisfaction": result.user_satisfaction,
                },
            ))

        return signals

    @classmethod
    def from_user_feedback(
        cls,
        score: float,
        persona_id: str = "host",
        confidence: float = 0.9,
    ) -> RewardSignal:
        """从用户显式反馈创建奖励信号。

        Args:
            score:      用户评分（0~1）。
            persona_id: 关联 persona。
            confidence: 用户反馈置信度（默认 0.9）。

        Returns:
            RewardSignal。
        """
        normalized = (score - 0.5) * 2.0  # 映射到 -1~1
        return cls(
            value=round(normalized, 4),
            source="user_feedback",
            weight=1.0,
            confidence=confidence,
            persona_id=persona_id,
            dimension="overall",
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "value": self.value,
            "source": self.source,
            "weight": self.weight,
            "timestamp": self.timestamp,
            "confidence": self.confidence,
            "persona_id": self.persona_id,
            "dimension": self.dimension,
            "metadata": self.metadata,
            "weighted_value": self.weighted_value,
        }


# ---------------------------------------------------------------------------
# RewardAggregator — 奖励聚合器
# ---------------------------------------------------------------------------


@dataclass
class AggregationSnapshot:
    """聚合快照。"""
    cumulative: float       # 当前累积奖励
    weighted_cumulative: float  # 加权累积（含置信度）
    step_count: int         # 累积步数
    raw_average: float      # 简单平均
    decayed_average: float  # 衰减加权平均
    time_decayed_value: float  # 经时间衰减后的当前值
    last_update: float      # 最后更新时间戳


class RewardAggregator:
    """奖励聚合器 — 指数衰减累积 + 时间衰减因子。

    特性：
    - **步级衰减**：每次 add() 时，旧累积值乘以 decay_factor。
    - **时间衰减**：读取时根据距今时间对累积值施加额外衰减。
    - **按维度跟踪**：可独立跟踪 overall / accuracy / efficiency 等维度。
    - **按 Persona 汇总**：支持多 Agent 场景下的独立累积。

    Usage:
        agg = RewardAggregator(decay_factor=0.95)
        agg.add(RewardSignal(value=0.8, source='auto'))
        agg.add(RewardSignal(value=-0.3, source='user_feedback'))
        print(agg.snapshot())
    """

    def __init__(
        self,
        decay_factor: float = DEFAULT_DECAY_FACTOR,
        time_decay_halflife: float = DEFAULT_TIME_DECAY_HALFLIFE,
    ) -> None:
        """
        Args:
            decay_factor:        步级衰减因子（0~1），越接近 1 衰减越慢。
            time_decay_halflife: 时间衰减半衰期（秒）。
        """
        self.decay_factor = max(0.0, min(1.0, decay_factor))
        self.time_decay_halflife = time_decay_halflife

        # 全局累积
        self._cumulative: float = 0.0
        self._weighted_cumulative: float = 0.0
        self._steps: int = 0
        self._raw_sum: float = 0.0
        self._last_update: float = time.time()

        # 按维度跟踪: dimension → (cumulative, weighted_cumulative, steps, raw_sum)
        self._dimensions: Dict[str, Tuple[float, float, int, float]] = {}

        # 信号历史（滑动窗口，最多保留 N 条）
        self._history: List[RewardSignal] = []
        self._max_history: int = 1000

    # ------------------------------------------------------------------
    # 核心方法
    # ------------------------------------------------------------------

    def add(self, reward: RewardSignal) -> float:
        """添加一个奖励信号并返回更新后的累积值。

        先执行步级衰减，再加上新信号。

        Args:
            reward: 奖励信号。

        Returns:
            更新后的 _cumulative 值。
        """
        # 步级衰减
        self._cumulative = self._cumulative * self.decay_factor
        self._weighted_cumulative = self._weighted_cumulative * self.decay_factor

        # 加上新信号
        self._cumulative += reward.value
        self._weighted_cumulative += reward.weighted_value
        self._raw_sum += reward.value
        self._steps += 1
        self._last_update = time.time()

        # 按维度更新
        dim = reward.dimension
        if dim not in self._dimensions:
            self._dimensions[dim] = (0.0, 0.0, 0, 0.0)

        dim_cum, dim_wcum, dim_steps, dim_raw = self._dimensions[dim]
        dim_cum = dim_cum * self.decay_factor + reward.value
        dim_wcum = dim_wcum * self.decay_factor + reward.weighted_value
        dim_steps += 1
        dim_raw += reward.value
        self._dimensions[dim] = (dim_cum, dim_wcum, dim_steps, dim_raw)

        # 记录历史
        self._history.append(reward)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

        return self._cumulative

    def add_batch(self, rewards: List[RewardSignal]) -> float:
        """批量添加奖励信号。"""
        for r in rewards:
            self.add(r)
        return self._cumulative

    def snapshot(self) -> AggregationSnapshot:
        """获取当前聚合快照（含时间衰减）。"""
        elapsed = max(0.0, time.time() - self._last_update)
        time_decay = self._compute_time_decay(elapsed)

        time_decayed = self._cumulative * time_decay
        decayed_avg = self._weighted_cumulative / max(self._steps, 1)
        raw_avg = self._raw_sum / max(self._steps, 1)

        return AggregationSnapshot(
            cumulative=self._cumulative,
            weighted_cumulative=self._weighted_cumulative,
            step_count=self._steps,
            raw_average=raw_avg,
            decayed_average=decayed_avg,
            time_decayed_value=time_decayed,
            last_update=self._last_update,
        )

    def dimension_snapshot(self, dimension: str) -> Optional[AggregationSnapshot]:
        """获取指定维度的聚合快照。"""
        if dimension not in self._dimensions:
            return None
        dim_cum, dim_wcum, dim_steps, dim_raw = self._dimensions[dimension]

        elapsed = max(0.0, time.time() - self._last_update)
        time_decay = self._compute_time_decay(elapsed)

        return AggregationSnapshot(
            cumulative=dim_cum,
            weighted_cumulative=dim_wcum,
            step_count=dim_steps,
            raw_average=dim_raw / max(dim_steps, 1),
            decayed_average=dim_wcum / max(dim_steps, 1),
            time_decayed_value=dim_cum * time_decay,
            last_update=self._last_update,
        )

    # ------------------------------------------------------------------
    # 属性
    # ------------------------------------------------------------------

    @property
    def cumulative(self) -> float:
        """当前累积奖励（含时间衰减）。"""
        elapsed = max(0.0, time.time() - self._last_update)
        return self._cumulative * self._compute_time_decay(elapsed)

    @property
    def average(self) -> float:
        """简单平均奖励。"""
        if self._steps == 0:
            return 0.0
        return self._raw_sum / self._steps

    @property
    def decayed_average(self) -> float:
        """衰减加权平均。"""
        if self._steps == 0:
            return 0.0
        return self._weighted_cumulative / self._steps

    @property
    def steps(self) -> int:
        return self._steps

    @property
    def dimensions(self) -> List[str]:
        return list(self._dimensions.keys())

    # ------------------------------------------------------------------
    # 内部方法
    # ------------------------------------------------------------------

    def _compute_time_decay(self, elapsed_seconds: float) -> float:
        """计算时间衰减因子。

        使用指数衰减: decay = 2^(-elapsed / halflife)
        半衰期越大，衰减越慢。
        """
        if self.time_decay_halflife <= 0 or elapsed_seconds <= 0:
            return 1.0
        decay = math.exp(-math.log(2) * elapsed_seconds / self.time_decay_halflife)
        return decay

    # ------------------------------------------------------------------
    # 管理方法
    # ------------------------------------------------------------------

    def reset(self) -> None:
        """重置所有累积状态。"""
        self._cumulative = 0.0
        self._weighted_cumulative = 0.0
        self._steps = 0
        self._raw_sum = 0.0
        self._last_update = time.time()
        self._dimensions.clear()
        self._history.clear()

    def get_history(self, limit: int = 50) -> List[RewardSignal]:
        """获取最近 N 条信号历史。"""
        return self._history[-limit:]

    def get_positive_ratio(self, window: int = 50) -> float:
        """最近 window 条信号中正奖励比例。"""
        recent = self._history[-window:]
        if not recent:
            return 0.0
        positive = sum(1 for r in recent if r.value > 0)
        return positive / len(recent)


# ---------------------------------------------------------------------------
# 按 Persona 维度汇总
# ---------------------------------------------------------------------------


class PersonaRewardTracker:
    """按 Persona 维度独立跟踪奖励。

    适用场景：
    - 多 Agent 系统中，每个 persona 独立维护自己的累积奖励。
    - 支持全局汇总视图，便于横向对比各 persona 表现。

    Usage:
        tracker = PersonaRewardTracker()
        tracker.add("host", RewardSignal(value=0.8, source='auto'))
        tracker.add("S1", RewardSignal(value=-0.2, source='user_feedback'))
        print(tracker.summary())
    """

    def __init__(
        self,
        decay_factor: float = DEFAULT_DECAY_FACTOR,
        time_decay_halflife: float = DEFAULT_TIME_DECAY_HALFLIFE,
    ) -> None:
        self.decay_factor = decay_factor
        self.time_decay_halflife = time_decay_halflife
        self._aggregators: Dict[str, RewardAggregator] = {}

    def _get_or_create(self, persona_id: str) -> RewardAggregator:
        if persona_id not in self._aggregators:
            self._aggregators[persona_id] = RewardAggregator(
                decay_factor=self.decay_factor,
                time_decay_halflife=self.time_decay_halflife,
            )
        return self._aggregators[persona_id]

    def add(self, persona_id: str, reward: RewardSignal) -> float:
        """向指定 persona 添加奖励信号，返回该 persona 更新后的累积值。"""
        agg = self._get_or_create(persona_id)
        return agg.add(reward)

    def add_evaluation(
        self,
        persona_id: str,
        result: EvaluationResult,
        weight: float = 1.0,
    ) -> None:
        """从评估结果批量添加到指定 persona。"""
        signals = RewardSignal.from_evaluation(result, persona_id=persona_id, weight=weight)
        agg = self._get_or_create(persona_id)
        agg.add_batch(signals)

    def snapshot(self, persona_id: str) -> Optional[AggregationSnapshot]:
        """获取指定 persona 的聚合快照。"""
        agg = self._aggregators.get(persona_id)
        if agg is None:
            return None
        return agg.snapshot()

    def summary(self) -> Dict[str, Dict[str, Any]]:
        """获取所有 persona 的汇总。

        Returns:
            {persona_id: {"cumulative": ..., "average": ..., "steps": ..., "positive_ratio": ...}, ...}
        """
        result = {}
        for persona_id, agg in self._aggregators.items():
            snap = agg.snapshot()
            result[persona_id] = {
                "cumulative": snap.cumulative,
                "time_decayed": snap.time_decayed_value,
                "decayed_average": snap.decayed_average,
                "raw_average": snap.raw_average,
                "steps": snap.step_count,
                "positive_ratio": agg.get_positive_ratio(),
                "dimensions": {
                    dim: agg.dimension_snapshot(dim).cumulative if agg.dimension_snapshot(dim) else 0.0
                    for dim in agg.dimensions
                },
            }
        return result

    def global_average(self) -> float:
        """所有 persona 的全局加权平均奖励。"""
        if not self._aggregators:
            return 0.0
        total = sum(agg.decayed_average for agg in self._aggregators.values())
        return total / len(self._aggregators)

    def best_persona(self) -> Optional[str]:
        """返回累积奖励最高的 persona ID。"""
        if not self._aggregators:
            return None
        return max(self._aggregators, key=lambda pid: self._aggregators[pid].cumulative)

    def worst_persona(self) -> Optional[str]:
        """返回累积奖励最低的 persona ID。"""
        if not self._aggregators:
            return None
        return min(self._aggregators, key=lambda pid: self._aggregators[pid].cumulative)

    def reset(self, persona_id: Optional[str] = None) -> None:
        """重置指定或全部 persona 的累积状态。"""
        if persona_id:
            agg = self._aggregators.pop(persona_id, None)
            if agg:
                agg.reset()
        else:
            for agg in self._aggregators.values():
                agg.reset()
            self._aggregators.clear()

    @property
    def persona_ids(self) -> List[str]:
        return list(self._aggregators.keys())


# ---------------------------------------------------------------------------
# 工厂函数
# ---------------------------------------------------------------------------


def create_aggregator(
    decay_factor: float = DEFAULT_DECAY_FACTOR,
    time_decay_halflife: float = DEFAULT_TIME_DECAY_HALFLIFE,
) -> RewardAggregator:
    """创建 RewardAggregator 的便捷工厂。"""
    return RewardAggregator(
        decay_factor=decay_factor,
        time_decay_halflife=time_decay_halflife,
    )


def create_persona_tracker(
    decay_factor: float = DEFAULT_DECAY_FACTOR,
    time_decay_halflife: float = DEFAULT_TIME_DECAY_HALFLIFE,
) -> PersonaRewardTracker:
    """创建 PersonaRewardTracker 的便捷工厂。"""
    return PersonaRewardTracker(
        decay_factor=decay_factor,
        time_decay_halflife=time_decay_halflife,
    )
