"""
YAML 工具模块 — 统一 YAML 加载入口

提供：
- load_yaml_file(path): 从文件加载 YAML
- load_yaml_string(text): 从字符串加载 YAML
- SimpleYamlParser: 零依赖 YAML 解析器（PyYAML 不可用时自动退回）

所有模块应通过此模块加载 YAML，避免重复实现解析器。

版本: 1.0.0
"""

from __future__ import annotations

import os
from typing import Any, Dict, List

# 检测 PyYAML 是否可用
try:
    import yaml as _yaml

    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False


def load_yaml_file(filepath: str) -> Dict[str, Any]:
    """从文件加载 YAML。

    优先使用 PyYAML，不可用时退回 SimpleYamlParser。

    Args:
        filepath: YAML 文件路径。

    Returns:
        解析后的字典。
    """
    if _YAML_AVAILABLE:
        with open(filepath, "r", encoding="utf-8") as f:
            return _yaml.safe_load(f) or {}

    parser = SimpleYamlParser()
    return parser.parse_file(filepath)


def load_yaml_string(text: str) -> Dict[str, Any]:
    """从字符串加载 YAML。

    优先使用 PyYAML，不可用时退回 SimpleYamlParser。

    Args:
        text: YAML 字符串。

    Returns:
        解析后的字典。
    """
    if _YAML_AVAILABLE:
        return _yaml.safe_load(text) or {}

    parser = SimpleYamlParser()
    return parser.parse(text)


def is_yaml_available() -> bool:
    """检查 PyYAML 是否可用。"""
    return _YAML_AVAILABLE


# ------------------------------------------------------------------
# SimpleYamlParser — 零依赖 YAML 解析器
# ------------------------------------------------------------------

class SimpleYamlParser:
    """简单 YAML 解析器，仅处理 key: value 和嵌套 dict，不依赖 PyYAML。

    支持特性：
    - key: value 基本键值对
    - 嵌套 dict（2 空格缩进）
    - 类型推断：bool / int / str
    - 注释（# 开头）
    - 引号字符串

    不支持：列表、多行字符串、锚点、别名等高级 YAML 特性。
    """

    def parse_file(self, filepath: str) -> Dict[str, Any]:
        """从文件解析 YAML。"""
        with open(filepath, "r", encoding="utf-8") as f:
            return self.parse(f.read())

    def parse(self, text: str) -> Dict[str, Any]:
        """从字符串解析 YAML。"""
        lines = text.split("\n")
        result: Dict[str, Any] = {}
        stack: List[Dict[str, Any]] = [result]
        indent_stack: List[int] = [-1]
        current_list: List[Any] | None = None
        list_key: str = ""

        for raw_line in lines:
            line = raw_line.rstrip()
            if not line or line.lstrip().startswith("#"):
                continue

            stripped = line.lstrip()
            indent = len(line) - len(stripped)

            # 计算实际缩进（2 空格 = 1 级）
            level = indent // 2

            # 回退栈
            while level <= indent_stack[-1] and len(stack) > 1:
                stack.pop()
                indent_stack.pop()

            # 列表项检测
            if stripped.startswith("- "):
                if current_list is not None:
                    item = stripped[2:].strip().strip('"').strip("'")
                    current_list.append(self._coerce_value(item))
                continue

            if ":" in stripped:
                # 结束上一个列表
                if current_list is not None:
                    stack[-1][list_key] = current_list
                    current_list = None

                comment = stripped.find(" #")
                if comment >= 0:
                    stripped = stripped[:comment].strip()
                key, _, value = stripped.partition(":")
                key = key.strip()
                value = value.strip().strip('"').strip("'")

                if value == "":
                    # 可能是嵌套对象或列表
                    current_list = []
                    list_key = key
                else:
                    stack[-1][key] = self._coerce_value(value)

        # 处理文件末尾的列表
        if current_list is not None and len(stack) > 0:
            stack[-1][list_key] = current_list

        return result

    @staticmethod
    def _coerce_value(value: str) -> Any:
        """类型推断。"""
        if value.lower() == "true":
            return True
        if value.lower() == "false":
            return False
        if value.lstrip("-").isdigit():
            return int(value)
        return value
