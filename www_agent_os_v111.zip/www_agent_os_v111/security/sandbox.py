"""
Sandbox — 代码执行沙箱

职责：
- 限制 Python 代码的可用模块和函数
- 强制最大执行时间和内存
- 阻止危险的内置函数调用
- 提供安全的受限执行环境

用于辅助 ToolRouter 在 persona 角色下执行受限代码。
"""

from __future__ import annotations

import logging
import re
import multiprocessing as _mp
import os as _os
import io as _io
import signal
import sys
import threading
import time
from contextlib import contextmanager
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

# 默认的危险关键字
DEFAULT_BLOCKED_KEYWORDS: Set[str] = {
    "__import__", "eval", "exec", "compile", "open",
    "globals", "locals", "getattr", "setattr", "delattr",
    "breakpoint", "input",
}

# 默认允许的安全模块
DEFAULT_ALLOWED_MODULES: Set[str] = {
    "json", "re", "datetime", "math", "csv",
    "pathlib", "collections", "itertools", "functools",
    "random", "string", "typing", "dataclasses",
    "hashlib", "base64", "uuid", "copy", "textwrap",
    "operator", "statistics", "decimal",
}

# 默认阻止的模块
DEFAULT_BLOCKED_MODULES: Set[str] = {
    "os", "subprocess", "shutil", "socket",
    "requests", "urllib", "http", "ctypes",
    "importlib", "sys", "signal", "threading",
    "multiprocessing", "asyncio",
}


class SandboxError(Exception):
    """沙箱安全异常。"""
    pass


class SandboxTimeoutError(SandboxError):
    """执行超时。"""
    pass


class SandboxSecurityViolation(SandboxError):
    """安全违规。"""
    pass


class CodeSandbox:
    """代码执行沙箱。

    特性：
    - 模块白名单/黑名单
    - 关键字扫描阻止危险调用
    - 超时限制
    - 内存限制（平台相关）
    - 命名空间隔离

    Usage::

        sandbox = CodeSandbox(timeout=5, max_memory_mb=128)
        result = sandbox.execute("print(1 + 1)")
    """

    def __init__(
        self,
        timeout: int = 30,
        max_memory_mb: int = 512,
        allowed_modules: Optional[Set[str]] = None,
        blocked_modules: Optional[Set[str]] = None,
        blocked_keywords: Optional[Set[str]] = None,
    ) -> None:
        self.timeout = timeout
        self.max_memory_mb = max_memory_mb
        self.allowed_modules = allowed_modules or DEFAULT_ALLOWED_MODULES.copy()
        self.blocked_modules = blocked_modules or DEFAULT_BLOCKED_MODULES.copy()
        self.blocked_keywords = blocked_keywords or DEFAULT_BLOCKED_KEYWORDS.copy()

    def scan_code(self, code: str) -> List[str]:
        """扫描代码中的安全问题。

        Returns:
            发现的问题列表（空列表表示安全）。
        """
        issues: List[str] = []

        # 检查危险关键字
        for keyword in self.blocked_keywords:
            # 使用单词边界匹配
            pattern = re.escape(keyword)
            if re.search(rf"\b{pattern}\b", code):
                issues.append(f"危险关键字: {keyword}")

        # 检查禁止的 import
        import_pattern = re.findall(
            r'(?:from\s+(\S+)\s+import|import\s+(\S+))',
            code,
        )
        for match in import_pattern:
            module = match[0] or match[1]
            base_module = module.split(".")[0]
            if base_module in self.blocked_modules:
                issues.append(f"禁止导入模块: {base_module}")
            elif base_module not in self.allowed_modules:
                issues.append(f"不在白名单的模块: {base_module}")

        # 检查 os.system / subprocess 等
        for banned in ["os.system", "os.popen", "subprocess.run", "subprocess.Popen",
                        "subprocess.call", "shutil.rmtree", "eval(", "exec("]:
            if banned in code:
                issues.append(f"禁止调用: {banned}")

        return issues

    def execute(self, code: str, globals_dict: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """在沙箱中安全执行代码。

        Args:
            code: Python 代码字符串。
            globals_dict: 额外的全局变量。

        Returns:
            {"result": ..., "stdout": ..., "issues": [...]}

        Raises:
            SandboxSecurityViolation: 安全违规。
            SandboxTimeoutError: 执行超时。
        """
        # 1. 代码扫描
        issues = self.scan_code(code)
        if issues:
            raise SandboxSecurityViolation(f"代码安全检查失败: {'; '.join(issues)}")

        # 2. 构建安全命名空间（H02修复：仅保留纯计算函数，移除可用于反射/逃逸的内置函数）
        safe_globals: Dict[str, Any] = {
            "__builtins__": {
                "abs": abs, "all": all, "any": any, "bin": bin, "bool": bool,
                "chr": chr, "divmod": divmod,
                "float": float, "format": format,
                "hash": hash, "hex": hex, "int": int,
                "len": len,
                "max": max, "min": min,
                "oct": oct, "ord": ord, "pow": pow, "print": print,
                "range": range, "round": round,
                "sorted": sorted, "str": str, "sum": sum,
                "True": True, "False": False, "None": None,
                "zip": zip,
            },
        }

        # 允许调用者注入额外全局变量，但必须检查键白名单（M04修复）
        _GLOBALS_ALLOWLIST = {"json", "re", "datetime", "math", "csv", "pathlib",
                              "collections", "itertools", "functools", "random",
                              "string", "typing", "dataclasses", "hashlib",
                              "base64", "uuid", "copy", "textwrap", "operator",
                              "statistics", "decimal", "io"}
        if globals_dict:
            for key in globals_dict:
                if key.startswith("__") or key not in _GLOBALS_ALLOWLIST:
                    raise SandboxSecurityViolation(
                        f"不允许覆盖安全命名空间键: '{key}'"
                    )
            safe_globals.update(globals_dict)

        # 3. 捕获 stdout
        import io
        stdout_capture = io.StringIO()

        local_vars: Dict[str, Any] = {}

        # 4. M07修复：子进程隔离超时。Windows 上 threading.Timer + PyThreadState_SetAsyncExc
        # 在 Python 3.12+ 不可靠，且无法中断 C 扩展调用。改用 multiprocessing.Process。
        return self._execute_in_subprocess(code, safe_globals, stdout_capture)

    # ── M07修复：子进程隔离执行 ──

    def _execute_in_subprocess(
        self, code: str, safe_globals: Dict[str, Any], stdout_capture
    ) -> Dict[str, Any]:
        """M07修复：使用 multiprocessing.Process 在子进程中执行代码。

        子进程隔离提供：
        - 真正的超时控制（Process.join(timeout)）
        - 内存隔离（子进程 OOM 不影响主进程）
        - 可中断 C 扩展调用（SIGKILL/TerminateProcess）
        """
        manager = _mp.Manager()
        result_queue = manager.Queue()

        def _worker(code_str, globs, queue):
            import traceback as _tb
            import time as _t
            import io as _io
            import sys as _sys
            out = _io.StringIO()
            _sys.stdout = out
            try:
                _t0 = _t.perf_counter()
                exec(code_str, globs, {})
                elapsed = _t.perf_counter() - _t0
                queue.put({
                    "success": True,
                    "stdout": out.getvalue(),
                    "elapsed_ms": round(elapsed * 1000, 1),
                })
            except Exception as e:
                queue.put({
                    "success": False,
                    "stdout": out.getvalue(),
                    "error": str(e),
                    "error_type": type(e).__name__,
                })
            finally:
                _sys.stdout = _sys.__stdout__

        p = _mp.Process(target=_worker, args=(code, dict(safe_globals), result_queue), daemon=True)
        p.start()

        # 独占 join（M07: 不能用 for p in ... join，这里只有一个子进程）
        p.join(timeout=self.timeout)

        if p.is_alive():
            p.terminate()
            p.join(timeout=5)
            if p.is_alive():
                p.kill()
                p.join(timeout=5)
            raise SandboxTimeoutError(f"代码执行超时 ({self.timeout}s)，子进程已终止")

        if not result_queue.empty():
            worker_result = result_queue.get(timeout=2)
            if worker_result["success"]:
                return {
                    "result": None,
                    "stdout": worker_result["stdout"],
                    "elapsed_ms": worker_result["elapsed_ms"],
                    "issues": [],
                }
            else:
                return {
                    "result": None,
                    "stdout": worker_result["stdout"],
                    "error": worker_result["error"],
                    "error_type": worker_result["error_type"],
                    "issues": [],
                }

        raise SandboxError("子进程未返回结果")

    def execute_safe(self, code: str) -> Dict[str, Any]:
        """安全执行，捕获所有异常。

        Returns:
            总是返回 dict，包含 success 字段。
        """
        try:
            result = self.execute(code)
            result["success"] = True
            return result
        except SandboxSecurityViolation as e:
            return {"success": False, "error": str(e), "type": "security_violation"}
        except SandboxTimeoutError as e:
            return {"success": False, "error": str(e), "type": "timeout"}
        except Exception as e:
            return {"success": False, "error": str(e), "type": "unexpected"}


def create_default_sandbox() -> CodeSandbox:
    """创建使用默认策略的沙箱。"""
    return CodeSandbox(
        timeout=30,
        max_memory_mb=512,
    )
