"""
Permission Layer — ToolRouter 调用前的权限检查层。

职责：
- 加载 policy.yaml 策略配置
- 验证角色 → 工具 → 动作的三级权限
- 路径白名单/黑名单检查
- 速率限制检查
- 审计日志记录

架构：
    ToolRequest → PermissionLayer.check() → {allow, deny, ask}
"""

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class Permission(Enum):
    """权限判定结果。"""
    ALLOW = "allow"
    DENY = "deny"
    ASK = "ask"


@dataclass
class ToolRequest:
    """工具调用请求。"""
    tool_name: str
    action: str  # e.g. 'read', 'write', 'delete', 'execute'
    role: str  # e.g. 'admin', 'host', 'persona', 'guest'
    persona_id: str = ""
    params: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class PermissionLayer:
    """权限检查层。

    Usage::

        pl = PermissionLayer()
        pl.load_policy("security/policy.yaml")
        req = ToolRequest("file_write", "write", "persona")
        result = pl.check(req)
        if result == Permission.DENY:
            raise PermissionError("persona 不允许写入文件")
    """

    def __init__(self) -> None:
        self._policy: Dict[str, Any] = {}
        self._rate_limiters: Dict[str, List[float]] = {}
        self._audit_log: List[Dict[str, Any]] = []

    def load_policy(self, yaml_path: str = "") -> None:
        """加载策略文件。"""
        from core.yaml_utils import load_yaml_file

        if not yaml_path:
            yaml_path = os.path.join(os.path.dirname(__file__), "policy.yaml")

        try:
            self._policy = load_yaml_file(yaml_path)
            logger.info("安全策略已加载: %s (v%s)", yaml_path, self._policy.get("version", "unknown"))
        except FileNotFoundError:
            logger.warning("策略文件未找到 %s，使用默认空策略", yaml_path)
            self._policy = {}
        except Exception:
            logger.exception("策略文件加载失败")
            self._policy = {}

    def load_policy_from_string(self, yaml_content: str) -> None:
        """从字符串加载策略（用于内置策略）。"""
        from core.yaml_utils import load_yaml_string
        self._policy = load_yaml_string(yaml_content)
        logger.info("安全策略已从内置配置加载")

    def check(self, request: ToolRequest) -> Permission:
        """执行权限检查。

        Returns:
            Permission.ALLOW / DENY / ASK
        """
        # 1. 速率限制检查
        if self._check_rate_limit(request):
            self._audit(request, "deny", "rate_limit_exceeded")
            return Permission.DENY

        # 2. 工具级权限检查
        result = self._check_tool_policy(request)
        if result == Permission.DENY:
            self._audit(request, "deny", "tool_policy")
            return Permission.DENY

        # 3. 角色权限检查
        role_result = self._check_role_permission(request)
        if role_result == Permission.DENY:
            self._audit(request, "deny", "role_permission")
            return Permission.DENY
        if role_result == Permission.ASK:
            self._audit(request, "ask", "role_permission")
            return Permission.ASK

        # 4. 路径安全检查（如果 params 中有路径）
        if "path" in request.params or "file_path" in request.params:
            path = request.params.get("path") or request.params.get("file_path", "")
            if not self._check_path_safety(path):
                self._audit(request, "deny", "path_blacklist")
                return Permission.DENY

        self._audit(request, "allow", "all_checks_passed")
        return Permission.ALLOW

    def _check_tool_policy(self, request: ToolRequest) -> Permission:
        """检查工具级权限。"""
        tool_policies = self._policy.get("tool_policies", {})
        tool_policy = tool_policies.get(request.action, {})
        role_permission = tool_policy.get(request.role, "deny")

        if role_permission == "allow":
            return Permission.ALLOW
        elif role_permission == "ask":
            return Permission.ASK
        elif role_permission == "own_only" and request.action == "access_memory":
            # 仅允许访问自己的 memory
            return Permission.ALLOW
        return Permission.DENY

    def _check_role_permission(self, request: ToolRequest) -> Permission:
        """检查角色级权限。"""
        role_perms = self._policy.get("role_permissions", {})
        role_def = role_perms.get(request.role, {})

        allowed = role_def.get("allowed_actions", [])
        denied = role_def.get("denied_actions", [])

        if "*" in allowed:
            return Permission.ALLOW
        if request.action in denied:
            return Permission.DENY
        if request.action in allowed:
            return Permission.ALLOW
        # 未明确定义的动作，默认拒绝
        return Permission.DENY

    def _check_path_safety(self, path: str) -> bool:
        """检查路径是否安全。"""
        if not path:
            return True

        path_policies = self._policy.get("path_policies", {})
        blacklist = path_policies.get("blacklist_paths", [])

        normalized = os.path.normpath(path)
        # H03修复：Windows 下 normpath() 不改变大小写，需额外 normcase() 防止大小写绕过
        normalized_lower = os.path.normcase(normalized)

        for bp in blacklist:
            bp_norm = os.path.normcase(bp)
            if normalized_lower.startswith(bp_norm) or normalized_lower == bp_norm:
                logger.warning("路径被黑名单拦截: %s (规则: %s)", path, bp)
                return False

        return True

    def _check_rate_limit(self, request: ToolRequest) -> bool:
        """检查速率限制。返回 True 表示超限。"""
        rate_limits = self._policy.get("rate_limits", {})
        limit_config = rate_limits.get(request.tool_name, rate_limits.get("default", {}))

        max_rpm = limit_config.get("max_requests_per_minute", 60)

        key = f"{request.role}:{request.tool_name}"
        now = time.time()
        window = 60.0  # 1分钟窗口

        if key not in self._rate_limiters:
            self._rate_limiters[key] = []

        # 清理过期记录
        self._rate_limiters[key] = [t for t in self._rate_limiters[key] if now - t < window]

        if len(self._rate_limiters[key]) >= max_rpm:
            return True

        self._rate_limiters[key].append(now)
        return False

    def _audit(self, request: ToolRequest, result: str, reason: str) -> None:
        """记录审计日志。"""
        entry = {
            "timestamp": request.timestamp,
            "role": request.role,
            "persona_id": request.persona_id,
            "tool": request.tool_name,
            "action": request.action,
            "result": result,
            "reason": reason,
        }
        self._audit_log.append(entry)
        if result in ("deny", "ask"):
            logger.info("AUDIT | %s | %s → %s | %s", request.role, request.tool_name, result, reason)

    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取最近的审计日志。"""
        return self._audit_log[-limit:]

    def clear_audit_log(self) -> None:
        """清除审计日志。"""
        self._audit_log.clear()


# 全局单例（向后兼容，推荐使用 DIContainer）
_default_permission: Optional[PermissionLayer] = None
_default_permission_lock = threading.Lock()


def get_permission_layer() -> PermissionLayer:
    """获取全局权限层实例。

    .. deprecated::
        推荐通过 DIContainer.get('permission_layer') 获取。
    """
    global _default_permission
    if _default_permission is None:
        with _default_permission_lock:
            if _default_permission is None:
                _default_permission = PermissionLayer()
    return _default_permission


def set_default_permission(pl: PermissionLayer) -> None:
    """设置全局默认 PermissionLayer 实例（供 DIContainer 注入）。"""
    global _default_permission
    with _default_permission_lock:
        _default_permission = pl
