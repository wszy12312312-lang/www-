# WWW Agent OS 架构设计文档

版本: 11.0 | 日期: 2026-07-16 | 状态: 统一 Engine 架构

> **v11.0 重大变更**: 消除 Feature Flag 双轨制，`WWWSystem` + `HostEntry` 合并为统一 `Engine` 类。

---

## 1. 架构总览

```
┌─────────────────────────────────────────────────────────┐
│                    User Interface                        │
│         ui/main.py (GUI)  /  ui/legacy_gui.py            │
└──────────────────────────┬──────────────────────────────┘
                           │ user_message
┌──────────────────────────▼──────────────────────────────┐
│                   runtime/host.py                         │
│              HostEntry (薄门面 → Engine)                  │
└──────────────────────────┬──────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────┐
│                   core/engine.py                          │
│                    Engine (统一引擎)                       │
│                                                           │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐  │
│  │ InputSanitizer│  │PersonaManager │  │  OllamaClient  │  │
│  │ (注入防护)    │  │ (五维评分调度) │  │ (线程安全HTTP)  │  │
│  └─────────────┘  └──────────────┘  └────────────────┘  │
│                                                           │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐  │
│  │  EventBus    │  │ TaskManager   │  │  MemoryStore   │  │
│  │ (pub/sub)    │  │ (状态流转)     │  │ (短期+长期+向量) │  │
│  └─────────────┘  └──────────────┘  └────────────────┘  │
│                                                           │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐  │
│  │ ToolRouter   │  │PromptManager  │  │ ConfirmationP.  │  │
│  │ (工具路由)    │  │ (SKILL.md)    │  │ (SX→HOST协议)   │  │
│  └─────────────┘  └──────────────┘  └────────────────┘  │
└─────────────────────────────────────────────────────────┘
                           │
                    ┌──────▼──────┐
                    │   Ollama    │
                    │ (本地 LLM)  │
                    └─────────────┘
```

## 2. 数据流图

```
用户输入
  │
  ▼
[1. InputSanitizer.sanitize()] ──── 过滤注入关键词、正则匹配、字符转义
  │                                  (始终启用，不可关闭)
  ▼
[2. Engine.orchestrate()] ────────── HOST 分析任务 → 分配人格
  │
  ├─ [2a. PersonaManager.dispatch()] ── 五维评分匹配最佳 Persona
  ├─ [2b. PromptManager.build()] ────── 加载 SKILL.md → 构建 system prompt
  │
  ▼
[3. OllamaClient.chat()] ─────────── HTTP → Ollama API (per-thread session)
  │                                  (含认证头 + 速率限制 + 重试)
  ▼
[4. ConfirmationParser.parse()] ──── 解析 [SX→HOST] 确认协议
  │                                  (有确认 → 暂停等待用户)
  ▼
[5. Engine._evaluate()] ──────────── S6 五维评分 (能力/效率/创新/准确/完整)
  │
  ▼
[6. Engine._apply_score()] ───────── 更新激励星/惩罚星 → 调整调度权重
  │
  ▼
[7. MemoryStore.save()] ──────────── 短期 deque LRU + 长期 JSON 持久化
  │
  ▼
[8. EventBus.publish()] ──────────── 通知所有订阅者 (persona_completed 等)
  │
  ▼
响应返回给用户
```

## 3. 模块职责说明

### 3.1 核心引擎层

| 模块 | 文件 | 职责 | 依赖 |
|------|------|------|------|
| **Engine** | `core/engine.py` | 统一引擎：调度+评分+记忆+模型+确认协议 | 所有模块 |
| InputSanitizer | `core/input_sanitizer.py` | Prompt 注入过滤：关键词黑名单、正则匹配、字符转义、审计日志 | YAML 规则文件 |
| OllamaClient | `core/engine.py` (内部类) | 线程安全 HTTP 客户端：per-thread session、速率限制、Bearer/Basic/Raw 认证 | requests |
| PromptManager | `core/engine.py` (内部类) | 加载 SKILL.md → 构建 system prompt + 状态块 | data/skills/ |
| ConfirmationParser | `core/engine.py` (内部类) | 解析 `[SX→HOST]` 确认协议 | — |

### 3.2 Persona 人格体系

| 模块 | 文件 | 职责 | 依赖 |
|------|------|------|------|
| Persona 基类 | `persona/base.py` | `PersonaState` 枚举 (5 状态)、生命周期钩子、序列化 | — |
| PersonaRegistry | `persona/registry.py` | 动态注入/注销、按 ID/名称/能力标签查询、JSON 持久化 | Persona base |
| PersonaManager | `persona/manager.py` | 五维评分匹配、双路匹配(关键词+能力标签)、Registry 集成 | Registry, base |
| 8 个 Persona 子类 | `persona/*_persona.py` | 各人格的 core_prompt + 能力标签 | base |

### 3.3 核心模块闭环

| 模块 | 文件 | 职责 | 依赖 |
|------|------|------|------|
| EventBus | `events/bus.py` | 单例发布-订阅，24 种事件类型、通配符匹配、线程安全 | — |
| EventStore | `events/store.py` | JSONL 持久化事件流 | EventBus |
| DeadLetterQueue | `events/dead_letter.py` | 独立 DLQ，处理失败事件 | EventBus |
| TaskManager | `task/manager.py` | Task CRUD、PENDING→RUNNING→COMPLETED/FAILED 状态流转 | EventBus |
| ToolRouter | `tools/router.py` | 注册/路由/参数验证、LLM function schema 导出 | EventBus |
| ModelGateway | `models/gateway.py` | Ollama API 封装、认证、指数退避重试、流式输出 | EventBus |
| MemoryStore | `memory/store.py` | 短期记忆 (deque LRU)、长期记录 (JSON 持久化)、搜索、TTL | EventBus |

### 3.4 运行时层

| 模块 | 文件 | 职责 | 依赖 |
|------|------|------|------|
| HostEntry | `runtime/host.py` | 薄门面层：CLI 入口、HostResult 兼容、委托给 Engine | Engine |
| DIContainer | `config/di_container.py` | 依赖注入容器：14 个懒加载工厂方法 | 所有模块 |

### 3.5 UI 层

| 模块 | 文件 | 职责 | 依赖 |
|------|------|------|------|
| WWWApp (新) | `ui/main.py` | CustomTkinter 桌面 GUI | Engine |
| WWWApp (旧) | `ui/legacy_gui.py` | 旧版桌面 GUI | Engine |
| StaticServer | `ui/server.py` | Web UI 静态文件服务器 | — |
| UIAdapter | `api/ui_adapter.py` | UI 响应格式适配 | — |

### 3.6 工具脚本

| 脚本 | 职责 | 状态 |
|------|------|------|
| `scripts/migrate_memory.py` | 旧 memory → MemoryStore 格式迁移 | ✅ 可用 |
| `scripts/migrate_prompts.py` | SKILL.md → Persona prompt 提取 | ✅ 可用 |
| `scripts/rollback.py` | 按阶段回滚 Feature Flag | ⚠️ 已弃用 |

## 4. 接口规范

### 4.1 Engine.orchestrate()

```python
def orchestrate(self, question: str, user_preference: str = None) -> EngineResult:
    """HOST 调度入口：分析 → 分配人格 → 执行 → 评分 → 记忆"""
```

- 输入: `question` (str), `user_preference` (Optional[str])
- 输出: `EngineResult(reply, persona_id, persona_name, reasoning, score, ...)`

### 4.2 Engine.resume_with_confirmation()

```python
def resume_with_confirmation(self, answer: str) -> EngineResult:
    """处理 [SX→HOST] 确认协议的回复"""
```

### 4.3 Engine API 速查

| 方法 | 说明 |
|------|------|
| `orchestrate(question)` | 任务调度 |
| `resume_with_confirmation(answer)` | 确认流程 |
| `check_all_models()` | 检查所有 Ollama 模型在线状态 |
| `evaluate(persona_id, q, a)` | S6 五维评分 |
| `apply_score(persona_id, overall)` | 应用评分到人格状态 |
| `log_task(persona_id, task, reply, score)` | 记录任务到历史 |
| `save_all_memories()` | 持久化所有人格记忆 |
| `has_pending_confirmations()` | 是否有待处理确认 |
| `get_pending_confirmations()` | 获取待处理确认列表 |
| `shutdown()` | 安全关闭 |
| `states` (property) | 人格状态字典 (UI 兼容) |

### 4.4 HostEntry 兼容接口

HostEntry 是 Engine 的薄门面，提供与旧版相同的公开接口：

| HostEntry 方法 | → Engine 委托 |
|----------------|---------------|
| `process(msg)` | `engine.process(msg)` → `HostResult` |
| `get_status_report()` | `engine.get_status_report()` |
| `get_health_report()` | 返回 `{"engine": {"healthy": True}}` |
| `get_feature_flags_report()` | 返回废弃通知 |
| `has_pending_confirmations()` | `engine.has_pending_confirmations()` |

### 4.5 EventBus 事件类型

| 事件 | 触发时机 | 携带数据 |
|------|---------|---------|
| `persona_activated` | Persona 被激活 (IDLE→BUSY) | persona_id, persona_name |
| `persona_deactivated` | Persona 停用 (BUSY→IDLE) | persona_id |
| `task_created` | 任务创建 | task_id, persona_id |
| `task_started` | 任务开始执行 (PENDING→RUNNING) | task_id |
| `task_completed` | 任务完成 (RUNNING→COMPLETED) | task_id, result |
| `task_failed` | 任务失败 (RUNNING→FAILED) | task_id, error |
| `model_request` | 模型调用 | persona_id, model |
| `model_response` | 模型返回 | persona_id, model, tokens |
| `memory_saved` | 记忆写入 | persona_id, entry_type |
| `error_occurred` | 任何错误发生 | module, error |

## 5. v11.0 架构变更说明

### 5.1 已消除的机制

| 旧机制 | v11.0 状态 | 替代方案 |
|--------|-----------|---------|
| Feature Flag (9 个) | ❌ 全部消除 | 统一架构，模块始终启用 |
| HealthChecker 自动回退 | ❌ 消除 | Engine 内置错误处理 |
| 新旧链路切换 | ❌ 消除 | 单一 Engine 调度链路 |
| `feature_flags.yaml` | ⚠️ 保留但弃用 | 仅供旧工具兼容 |
| `WWWSystem` | 📦 归档为 `.bak.py` | Engine 替代 |
| `scripts/rollback.py` | ⚠️ 已弃用 | 不再需要回滚 |

### 5.2 API 映射表

| 旧 API (WWWSystem/HostEntry) | 新 API (Engine) |
|------------------------------|-----------------|
| `WWWSystem()` | `Engine()` |
| `system.host_orchestrate(q)` | `engine.orchestrate(q)` |
| `system.host_resume_with_confirmation(a)` | `engine.resume_with_confirmation(a)` |
| `system.s6_evaluate(pid, q, a)` | `engine.evaluate(pid, q, a)` |
| `system.apply_score(pid, score)` | `engine.apply_score(pid, score)` |
| `system.log_task(pid, t, r, s)` | `engine.log_task(pid, t, r, s)` |
| `system.save_all_memories()` | `engine.save_all_memories()` |
| `system.check_all_models()` | `engine.check_all_models()` |
| `system.shutdown()` | `engine.shutdown()` |
| `system.states` | `engine.states` |
| `system._checking` | `engine._checking` |
| `system._running` | `engine._running` |
| `system._pending_confirmations` | `engine._pending_confirmations` |

### 5.3 DIContainer 变更

```python
# 旧
di.get("legacy_system")  # → WWWSystem

# 新
di.get("engine")  # → Engine

# 向后兼容别名
di.get("legacy_system")  # → Engine (通过 _create_legacy_system = _create_engine)
```

## 6. 依赖关系图

```
Engine
  ├── InputSanitizer (core/input_sanitizer.py)
  ├── PersonaManager (persona/manager.py)
  │     └── PersonaRegistry (persona/registry.py)
  │           └── Persona base (persona/base.py)
  ├── OllamaClient (内部类)
  │     └── config/app_config.py (认证配置)
  ├── PromptManager (内部类)
  │     └── data/skills/*.md (SKILL.md 文件)
  ├── ConfirmationParser (内部类)
  ├── EventBus (events/bus.py)
  │     ├── EventStore (events/store.py)
  │     └── DeadLetterQueue (events/dead_letter.py)
  ├── TaskManager (task/manager.py)
  ├── ToolRouter (tools/router.py)
  ├── ModelGateway (models/gateway.py)
  └── MemoryStore (memory/store.py)

HostEntry → Engine (薄门面)
DIContainer → 所有模块 (懒加载工厂)
```

## 7. 项目状态

| 阶段 | 内容 | 状态 |
|:--:|------|:--:|
| v1-v5 | 渐进式迁移 (Feature Flag) | ✅ 已完成 |
| v6-v10 | 架构债务清理 (统一 Persona, 集成 DLQ, 去全局单例) | ✅ 已完成 |
| **v11** | **统一 Engine 架构 (消除 Feature Flag)** | **✅ 当前版本** |

> 迁移指南: [migration_v11.md](migration_v11.md)
