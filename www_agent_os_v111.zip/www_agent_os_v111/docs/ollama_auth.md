# Ollama 认证配置

本项目支持通过环境变量配置 Ollama API 认证。

## 环境变量

- **OLLAMA_API_KEY**: API 密钥或令牌值（默认: 空，不启用认证）
- **OLLAMA_AUTH_SCHEME**: 认证方案（大小写不敏感）。支持的值：
  - `bearer`（默认）: 发送 `Authorization: Bearer <OLLAMA_API_KEY>`
  - `basic`          : 发送 `Authorization: Basic <OLLAMA_API_KEY>`
  - `raw`            : 发送 `Authorization: <OLLAMA_API_KEY>`

## 使用方式

```bash
# Bearer 认证（默认）
export OLLAMA_API_KEY="your-secret-token"
export OLLAMA_AUTH_SCHEME="bearer"

# Basic 认证
export OLLAMA_API_KEY="your-basic-token"
export OLLAMA_AUTH_SCHEME="basic"

# 原始令牌（自定义认证头）
export OLLAMA_API_KEY="your-raw-token"
export OLLAMA_AUTH_SCHEME="raw"
```

## 注意事项

- 模块在导入时从 `config.app_config` 读取配置，而 `config.app_config` 从环境变量读取。测试和运行时应在导入依赖这些值的模块之前设置环境变量，或修改环境变量后重新加载 `config.app_config` 和 `services` 模块。
- **不要在源码中提交密钥**。通过 CI secrets 或系统环境变量提供 `OLLAMA_API_KEY`。
- 未设置 `OLLAMA_API_KEY` 时不发送 `Authorization` 头，适用于本地无认证的 Ollama 实例。
