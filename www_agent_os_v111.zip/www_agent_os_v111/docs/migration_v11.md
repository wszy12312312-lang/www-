# WWW Agent OS v11.0 — 统一架构迁移指南

## 概述

v11.0 将旧版 HostEntry + WWWSystem 双轨架构合并为单一 `Engine` 引擎。
本指南说明从 v10.7.0 迁移到 v11.0 的所有变更。

## 核心变更

### 1. 统一入口

| 旧版 (v10.7) | 新版 (v11.0) |
|-------------|-------------|
| `services/ollama_service.py::WWWSystem` | `core/engine.py::Engine` |
| `runtime/host.py::HostEntry` (1065行) | `runtime/host.py::HostEntry` (~230行薄门面) |
| 9 个 Feature Flag 分支 | 0 个分支（统一管线） |
| `feature_flags.yaml` 配置 | 已废弃 |

### 2. 引擎接口映射

```python
# 旧版
from services.ollama_service import WWWSystem
system = WWWSystem()
system.host_orchestrate(message)
system.host_resume_with_confirmation(...)
system.s6_evaluate("host", task, reply)
system.apply_score("host", score)
system.log_task("host", task, reply, score)
system.check_all_models(callback)
system.save_all_memories()
system.shutdown()

# 新版
from core.engine import Engine
engine = Engine()
engine.orchestrate(message)              # host_orchestrate → orchestrate
engine.resume_with_confirmation(...)     # host_resume_with_confirmation → resume_with_confirmation
engine.evaluate("host", task, reply)     # s6_evaluate → evaluate (别名 s6_evaluate 保留)
engine.apply_score("host", score)        # 公开方法
engine.log_task("host", task, reply, score)
engine.check_all_models(callback)
engine.save_all_memories()
engine.shutdown()
```

### 3. UI 兼容属性

Engine 提供以下 UI 兼容属性：

| 属性 | 说明 |
|------|------|
| `engine.states` | 人格状态字典（等价旧 `system.states`） |
| `engine._checking` | 模型自检标志 |
| `engine._running` | 任务执行标志 |
| `engine._pending_confirmations` | 待处理确认列表 |
| `engine._last_sub_results` | 上次子任务结果 |
| `engine._last_host_reasoning` | 上次 HOST 推理 |
| `engine._last_host_analysis` | 上次 HOST 分析 |

### 4. DIContainer 变更

```python
# 旧版
di = DIContainer(project_root)
di.legacy_system  # → WWWSystem 实例

# 新版
di = DIContainer(project_root)
di.engine          # → Engine 实例
di.legacy_system   # → 向后兼容别名，返回 Engine
```

### 5. 新增模块

| 模块 | 说明 |
|------|------|
| `core/engine.py` | 统一引擎（~750行），整合 chat/orchestrate/evaluate/memory |
| `core/evaluation/scoring_engine.py` | 独立评分引擎 |
| `core/yaml_utils.py` | 统一 YAML 解析器 |
| `memory/vector_search.py` | TF-IDF 向量检索 |

### 6. 已归档文件

| 文件 | 状态 | 替代 |
|------|------|------|
| `services/ollama_service.py` | → `services/ollama_service_legacy.bak.py` | `core/engine.py` |
| `feature_flags.yaml` | 保留但已废弃 | 无需配置 |
| `config/flag_manager.py` | 保留但不再用于运行时控制 | Engine 无分支 |

## 迁移步骤

1. **更新导入** — 全局替换 `from services.ollama_service import WWWSystem` → `from core.engine import Engine`
2. **更新实例化** — `WWWSystem()` → `Engine()`
3. **更新方法调用** — `host_orchestrate` → `orchestrate`，`host_resume_with_confirmation` → `resume_with_confirmation`
4. **更新属性访问** — `system.states` → `engine.states`（无需改动，Engine 提供 `states` 属性）
5. **移除 Feature Flag** — 删除所有 `if self.use_*` 分支，统一走 Engine 管线
6. **更新测试** — 参见 `tests/test_ollama_headers.py`

## 模块依赖图（v11.0）

```
User Input
    │
    ▼
Engine.__init__()
    ├── InputSanitizer (DI 注入)
    ├── ScoringEngine (DI 注入)
    ├── MemoryStore (DI 注入)
    ├── EventBus (DI 注入)
    ├── TaskManager (DI 注入)
    ├── OllamaClient (内部创建)
    ├── PromptManager (内部创建)
    └── ConfirmationParser (内部创建)
    │
    ▼
Engine.chat() / Engine.orchestrate()
    ├── _sanitize() → InputSanitizer
    ├── _dispatch() / _decompose_task() → OllamaClient
    ├── chat() per persona → OllamaClient
    ├── _evaluate() → ScoringEngine
    ├── _apply_score() → PersonaState 更新
    └── _save_persona_memory() → 磁盘持久化
    │
    ▼
EngineResult / (reply, reasoning, analysis, sub_results)
```
