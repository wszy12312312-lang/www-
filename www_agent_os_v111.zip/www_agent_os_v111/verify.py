import sys, os, warnings
warnings.filterwarnings('ignore')

base = r'C:\Users\wszy1\.openclaw-autoclaw\workspace\.cluster\check'
sys.path.insert(0, base)

import logging
logging.basicConfig(level=logging.WARNING)

checks = []

# 1. 8 personas
try:
    from persona.host_persona import HostPersona
    from persona.web_persona import WebPersona
    from persona.software_persona import SoftwarePersona
    from persona.system_persona import SystemPersona
    from persona.file_persona import FilePersona
    from persona.search_persona import SearchPersona
    from persona.chat_persona import ChatPersona
    from persona.monitor_persona import MonitorPersona
    checks.append(('8 personas', True, f'host={HostPersona().version} mon={MonitorPersona().persona_id}'))
except Exception as e:
    checks.append(('8 personas', False, str(e)[:80]))

# 2. 16 tools
try:
    import tools.definitions.web as w
    import tools.definitions.system as s
    import tools.definitions.file as f
    import tools.definitions.code as c
    from tools.router import ToolRouter
    from events.bus import EventBus
    r = ToolRouter(bus=EventBus(name='test'))
    w.register_all(r); s.register_all(r); f.register_all(r); c.register_all(r)
    cats = {cat: len(r.list_by_category(cat)) for cat in ['web','system','file','code']}
    checks.append(('16 tools', r.count == 16, str(cats)))
except Exception as e:
    checks.append(('16 tools', False, str(e)[:80]))

# 3. Engine init
try:
    from core.engine import Engine
    e = Engine()
    trc = e._tool_router.count if hasattr(e, '_tool_router') else 0
    has_tm = e._task_manager is not None
    has_mp = hasattr(e, '_monitor_persona') and e._monitor_persona is not None
    subs = e._event_bus.subscriber_count
    e.shutdown()
    checks.append(('Engine', True, f'tools={trc} tm={has_tm} mon={has_mp} subs={subs}'))
except Exception as e:
    checks.append(('Engine', False, str(e)[:80]))

# 4. Scheduler
try:
    from core.scheduler import EventScheduler
    sch = EventScheduler('test')
    sch.schedule_daily('d', 12, 0, lambda: None)
    sch.schedule_weekly('w', 5, 12, 0, lambda: None)
    sch.shutdown()
    checks.append(('Scheduler', len(sch.list_jobs()) == 2, ''))
except Exception as e:
    checks.append(('Scheduler', False, str(e)[:80]))

# 5. engine.py patches
ec = open(os.path.join(base, 'core', 'engine.py'), encoding='utf-8').read()
checks.append(('engine patches', '_register_tools' in ec and '_setup_event_subscriptions' in ec and '_init_monitor_persona' in ec, ''))

# 6. ensure_env.py
checks.append(('ensure_env.py', os.path.exists(os.path.join(base, 'scripts', 'ensure_env.py')), ''))

# 7. v11.1 prompt
hc = open(os.path.join(base, 'persona', 'host_persona.py'), encoding='utf-8').read()
checks.append(('host v11.1', '能力诚实' in hc or '真实能力映射' in hc, ''))

# 8. tools are NOT empty
wc = open(os.path.join(base, 'tools', 'definitions', 'web', '__init__.py'), encoding='utf-8').read()
checks.append(('tools/web not empty', len(wc) > 100, f'{len(wc)} chars'))

fc = open(os.path.join(base, 'tools', 'definitions', 'file', '__init__.py'), encoding='utf-8').read()
checks.append(('tools/file not empty', len(fc) > 100, f'{len(fc)} chars'))

# 9. duplicate structure check
has_bad_core = os.path.exists(os.path.join(base, 'core', 'core'))
has_bad_prsn = os.path.exists(os.path.join(base, 'core', 'persona'))
checks.append(('no duplicate dirs', not has_bad_core and not has_bad_prsn,
              f'core/core={has_bad_core} core/persona={has_bad_prsn}'))

print()
for name, ok, detail in checks:
    print(f"  [{'OK' if ok else 'FAIL'}] {name} {detail}")
print()
all_ok = all(c[1] for c in checks)
print(f"RESULT: {sum(1 for c in checks if c[1])}/{len(checks)} passed" + (" - ALL OK" if all_ok else ""))
