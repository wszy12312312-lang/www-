# WWW Agent OS v11.0

多人格 AI Agent 操作系统 — 统一引擎架构，模块化设计，内置五维评分调度。
> **版本**: v11.0 — 统一 Engine 架构（消除 Feature Flag 双轨制）
> **迁移指南**: [migration_v11.md](docs/migration_v11.md)
> **架构文档**: [architecture.md](docs/architecture.md)
> **代码审计**: [audit_report_round1.md](docs/audit_report_round1.md) · [audit_closure_report.md](docs/audit_closure_report.md)

---

## v11.0 架构亮点

- **统一引擎**: `core/engine.py` — 单一 `Engine` 类替代旧 `WWWSystem` + `HostEntry` 双轨架构
- **零 Feature Flag**: 9 个 Feature Flag 全部消除，不再有新旧链路切换
- **模块化设计**: 每个子系统独立模块，通过 DIContainer 注入
- **五维评分调度**: HOST 根据各人格能力评分动态分配任务
- **线程安全**: OllamaClient 使用 per-thread session，支持并发请求
- **事件驱动**: EventBus (pub/sub + wildcard) + EventStore (JSONL) + DeadLetterQueue
- **双轨记忆**: 短期 deque LRU + 长期 JSON 持久化 + 向量搜索

---

## 目录结构

```
www_agent_os/
├── core/                          # 核心引擎
│   ├── engine.py                    #   统一 Engine (调度+评分+记忆+模型)
│   ├── input_sanitizer.py           #   Prompt 注入防护
│   └── __init__.py
├── persona/                       # Persona 人格体系
│   ├── base.py                      #   Persona 基类 + 状态机
│   ├── manager.py                   #   PersonaManager (五维评分调度)
│   ├── registry.py                  #   PersonaRegistry (动态注册)
│   ├── host_persona.py              #   主人格 Marvis
│   ├── software_persona.py          #   软件专员 (S1)
│   ├── system_persona.py            #   系统专员 (S2)
│   ├── web_persona.py               #   网络专员 (S3)
│   ├── file_persona.py              #   文件专员 (S4)
│   ├── search_persona.py            #   检索专员 (S5)
│   ├── chat_persona.py              #   聊天专员
│   ├── monitor_persona.py           #   独立监察 (S6)
│   └── __init__.py
├── events/                        # 事件总线
│   ├── bus.py                       #   EventBus (24 种事件类型 + wildcard)
│   ├── store.py                     #   EventStore (JSONL 持久化)
│   ├── dead_letter.py               #   DeadLetterQueue (独立 DLQ)
│   └── __init__.py
├── task/                          # 任务管理
│   ├── manager.py                   #   TaskManager (5 状态流转)
│   └── __init__.py
├── tools/                         # 工具路由
│   ├── router.py                    #   ToolRouter (注册/路由/参数验证)
│   └── __init__.py
├── models/                        # 模型网关
│   ├── gateway.py                   #   ModelGateway (Ollama + 认证)
│   └── __init__.py
├── memory/                        # 记忆存储
│   ├── store.py                     #   MemoryStore (短期+长期+向量搜索)
│   └── __init__.py
├── config/                        # 配置
│   ├── di_container.py              #   DIContainer (依赖注入容器)
│   ├── flag_manager.py              #   FeatureFlagManager (兼容遗留)
│   ├── app_config.py                #   应用配置
│   ├── sanitizer_rules.yaml         #   输入过滤规则
│   ├── policy.yaml                  #   策略配置
│   └── __init__.py
├── runtime/                       # 运行时入口
│   ├── host.py                      #   薄门面层 (→ Engine)
│   └── __init__.py
├── services/                      # 服务层
│   └── ollama_service_legacy.bak.py #   [已归档] 旧 WWWSystem 实现
├── ui/                            # UI 组件
│   ├── main.py                      #   桌面 GUI (CustomTkinter)
│   ├── legacy_gui.py                #   旧版桌面 GUI
│   ├── server.py                    #   Web UI 静态服务器
│   └── ui_adapter.py               #   UI 响应适配器
├── api/                           # API 层
│   └── routes/
├── scripts/                       # 工具脚本
│   ├── migrate_memory.py            #   记忆迁移
│   ├── migrate_prompts.py           #   Prompt 迁移
│   └── rollback.py                  #   [已弃用] Feature Flag 回滚
├── tests/                         # 测试
│   ├── test_ollama_headers.py       #   OllamaClient 认证测试
│   ├── test_e2e.py                  #   端到端测试
│   ├── test_integration.py          #   集成测试
│   ├── test_stage2.py               #   Stage 2: InputSanitizer
│   ├── test_stage3.py               #   Stage 3: Persona 体系
│   ├── test_stage4.py               #   Stage 4: 核心模块闭环
│   ├── test_stage5.py               #   Stage 5: 收尾测试
│   └── unit/                        #   单元测试
├── docs/                          # 文档
│   ├── architecture.md              #   架构设计文档
│   ├── migration_v11.md             #   v11.0 迁移指南
│   ├── migration_plan.md            #   [历史] 五阶段迁移方案
│   ├── audit_report_round1.md       #   第一轮代码审计
│   ├── audit_closure_report.md      #   审计清零报告
│   └── ollama_auth.md               #   Ollama 认证配置
├── data/                          # 运行时数据
│   ├── skills/                      #   技能描述文件 (8 个 Agent)
│   ├── memory/                      #   记忆存储
│   └── persona_prompts/             #   提取的 prompt 文件
├── requirements/                  # 依赖管理
│   ├── base.txt
│   └── dev.txt
├── feature_flags.yaml             # [已弃用] 全部 Flag 已固化
├── README.md                      # 本文档
├── pyproject.toml                 # 项目配置 (ruff + black)
├── Dockerfile                     # 容器化
├── docker-compose.yml             # 编排配置
└── .gitignore
```

---

## 安装指南

项目根目录提供了**一键下载安装脚本**，只需运行一个批处理文件即可完成全部环境配置。

### 下载脚本：`下载-WWW_Agent_OS.bat`

双击运行后显示四档配置菜单，按需选择：

| 配置 | 适用硬件 | 模型组合 | 磁盘占用 |
|------|---------|---------|---------|
| **低配** | 8GB RAM，无独显 | Qwen2.5-1.5B + StarCoder2-3B + BGE-small | ~5GB |
| **中配** | 16GB RAM，6GB+ VRAM | Qwen2.5-7B + DeepSeek-Coder-V2-Lite + BGE-M3 | ~15GB |
| **高配** | 32GB+ RAM，16GB+ VRAM | Qwen2.5-32B + DeepSeek-R1-32B + DeepSeek-Coder-V2 + BGE-M3 | ~50GB |
| **自定义** | 自行指定 | 交互式选择模型来源、名称、参数量、量化方式 | 视选择而定 |

脚本自动完成以下工作：
- 检测并配置 Python 环境
- 安装项目 Python 依赖
- 检测 / 自动安装 Ollama
- 下载对应配置的大模型
- 生成 `model_config.json` 配置文件
- 运行 `python runtime/host.py --version` 验证安装

> **提示**：Ollama 模型文件默认存储在 `C:\Users\<用户名>\.ollama\`。

---

## 快速开始

### 一键启动（推荐）

| 启动方式 | 文件 | 说明 |
|---------|------|------|
| **桌面快捷方式** | `WWW Agent OS` (桌面) | 双击桌面图标一键启动 |
| **命令行窗口** | `start_www_agent.bat` | 带控制台窗口，可查看启动日志 |
| **后台静默** | `start_www_agent.vbs` | 无窗口后台运行 |

**bat 脚本**：自动检测 Python 路径 → 启动 `runtime/host.py`
**vbs 脚本**：使用 `pythonw.exe` 无窗口启动，适合开机自启

### 编程方式启动

```python
from core.engine import Engine

# 创建引擎实例
engine = Engine()

# 检查所有模型状态
engine.check_all_models()

# 执行任务调度
result = engine.orchestrate("帮我分析这段代码的性能问题")

# 处理确认流程
if engine.has_pending_confirmations():
    engine.resume_with_confirmation("yes")

# S6 独立评估
score = engine.evaluate("s1", "分析代码性能", "回复内容...")
engine.apply_score("s1", score["overall"])

# 保存记忆
engine.save_all_memories()

# 关闭
engine.shutdown()
```

### 运行测试

```bash
# 全部测试
python -m pytest tests/ -v

# 指定测试文件
python -m pytest tests/test_ollama_headers.py -v
python -m pytest tests/test_stage3.py -v
python -m pytest tests/test_stage4.py -v

# 端到端测试
python -m pytest tests/test_e2e.py -v
```

### 数据迁移

```bash
# 记忆迁移（试运行）
python scripts/migrate_memory.py

# 记忆迁移（实际执行）
python scripts/migrate_memory.py --execute

# Prompt 迁移
python scripts/migrate_prompts.py
```

---

## 核心架构

### 统一引擎 (Engine)

`core/engine.py` 是系统的核心，整合了旧 `WWWSystem` 和 `HostEntry` 的全部功能：

| 功能 | 方法 | 说明 |
|------|------|------|
| 任务调度 | `orchestrate(question)` | HOST 分析 → 分配人格 → 执行 → 评分 |
| 确认流程 | `resume_with_confirmation(answer)` | 处理 `[SX→HOST]` 确认协议 |
| 模型检查 | `check_all_models()` | 检测所有 Ollama 模型在线状态 |
| 评分系统 | `evaluate(persona, q, a)` | S6 五维评分（能力/效率/创新/准确/完整） |
| 评分应用 | `apply_score(persona, score)` | 更新人格激励星 / 惩罚星 |
| 任务记录 | `log_task(persona, task, reply, score)` | 记录到人格历史和经验库 |
| 记忆保存 | `save_all_memories()` | 持久化所有人格记忆 |
| 安全关闭 | `shutdown()` | 保存状态 → 清理资源 |

### 依赖注入 (DIContainer)

`config/di_container.py` 提供 14 个懒加载工厂方法：

```python
di = DIContainer(project_root=Path("."))
engine = di.get("engine")          # 统一引擎
bus = di.get("bus")                # 事件总线
memory = di.get("memory_store")    # 记忆存储
sanitizer = di.get("sanitizer")    # 输入过滤
task_mgr = di.get("task_manager")  # 任务管理
```

### 人格体系

8 个人格由 `PersonaManager` 统一管理，HOST 根据五维能力评分动态分配任务：

| ID | 名称 | 职责 |
|----|------|------|
| host | Marvis | 主调度，分析任务并分配 |
| s1 | 软件专员 | 代码编写、调试、重构 |
| s2 | 系统专员 | 系统设计、架构分析 |
| s3 | 网络专员 | 网络请求、API 调用 |
| s4 | 文件专员 | 文件读写、目录管理 |
| s5 | 检索专员 | 信息搜索、数据收集 |
| s6 | 独立监察 | 五维评分、质量审查 |

### 事件总线

```python
from events.bus import EventBus

bus = EventBus()
bus.subscribe("persona.*", handler)    # 通配符订阅
bus.publish("persona.s1.start", data)  # 发布事件
```

支持 24 种事件类型，EventStore 持久化到 JSONL，DeadLetterQueue 处理失败事件。

---

## 开发指南

### 项目约定

- Python 3.10+
- ruff + black, line-length=120
- pytest 测试框架
- 中文注释 + 英文 docstring
- 标准库优先，第三方依赖最小化
- 所有公开 API 有类型注解和 docstring

### 添加新人格

1. 在 `persona/` 下创建 `xxx_persona.py`，继承 `Persona` 基类
2. 在 `data/skills/` 下创建对应的 `SKILL.md` 技能描述
3. 在 `PersonaManager` 中注册新人格
4. 在 `Engine._init_personas()` 中添加初始化逻辑
5. 编写测试

### 从旧版本迁移

详见 [migration_v11.md](docs/migration_v11.md)，包含完整的 API 映射表和迁移步骤。

---

## 安全说明

- 用户输入经过 `InputSanitizer` 过滤后才进入调度链
- OllamaClient 支持 API 认证（Bearer / Basic Auth / Raw Key）
- 错误详情仅记录在内部日志，不暴露给终端用户
- 所有破坏性操作（删除、覆盖）走确认流程
- 记忆数据独立存储于 `data/memory/`，新旧系统隔离

---

## 许可证

内部项目。
