"""
Memory Store — 记忆存储与检索

提供：
- MemoryEntry：单条记忆记录
- MemoryStore：短期记忆（会话内）+ 长期记忆（持久化到文件/数据库）
- 与 EventBus 集成
- 替代旧明文存储方式

版本: 1.0.0
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Iterator, List, Optional, Tuple

from events.bus import Event, EventBus, EventType, get_default_bus
from memory.vector_search import HybridSearcher

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# MemoryEntry
# ------------------------------------------------------------------

@dataclass
class MemoryEntry:
    """记忆条目。

    Attributes:
        id: 记忆唯一 ID（SHA256 前 12 位）。
        persona_id: 所属 Persona ID。
        content: 记忆内容（文本）。
        role: 角色（user / assistant / system / tool）。
        created_at: 创建时间（UTC）。
        metadata: 附加元数据（如 token 数、来源任务 ID）。
        ttl: 长期记忆存活时间（秒），0 表示永久。
        access_count: 访问次数（LRU 淘汰依据）。
        last_accessed: 最后访问时间。
    """

    id: str = ""
    persona_id: str = ""
    content: str = ""
    role: str = "system"
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)
    ttl: float = 0.0  # 0 = permanent
    access_count: int = 0
    last_accessed: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __post_init__(self) -> None:
        if not self.id:
            raw = f"{self.persona_id}:{self.content}:{self.created_at.isoformat()}:{self.role}"
            self.id = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]

    @property
    def is_expired(self) -> bool:
        """检查是否过期。"""
        if self.ttl <= 0:
            return False
        elapsed = (datetime.now(timezone.utc) - self.created_at).total_seconds()
        return elapsed > self.ttl

    @property
    def age_seconds(self) -> float:
        """存活时间（秒）。"""
        return (datetime.now(timezone.utc) - self.created_at).total_seconds()

    def touch(self) -> None:
        """更新访问时间与计数。"""
        self.last_accessed = datetime.now(timezone.utc)
        self.access_count += 1

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典。"""
        return {
            "id": self.id,
            "persona_id": self.persona_id,
            "content": self.content,
            "role": self.role,
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata,
            "ttl": self.ttl,
            "access_count": self.access_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryEntry":
        """从字典反序列化。"""
        return cls(
            id=data.get("id", ""),
            persona_id=data.get("persona_id", ""),
            content=data.get("content", ""),
            role=data.get("role", "system"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(timezone.utc),
            metadata=data.get("metadata", {}),
            ttl=data.get("ttl", 0.0),
            access_count=data.get("access_count", 0),
        )


# ------------------------------------------------------------------
# MemoryStore
# ------------------------------------------------------------------

class MemoryStore:
    """记忆存储引擎。

    双轨记忆：
    - 短期记忆：会话内，基于 deque（容量可配），LRU 淘汰。
    - 长期记忆：持久化到 JSON 文件，按 persona 分文件存储。

    Usage::

        store = MemoryStore(storage_dir="./data/memory")

        # 存储
        store.save(MemoryEntry(persona_id="s4", content="用户喜欢蓝色主题", role="user"))

        # 检索
        memories = store.retrieve(persona_id="s4", limit=10)

        # 搜索
        results = store.search("蓝色主题")
    """

    # 默认短期记忆容量
    DEFAULT_SHORT_TERM_CAPACITY = 100

    # 默认长期记忆文件
    DEFAULT_STORAGE_DIR = "data/memory"

    def __init__(
        self,
        storage_dir: str = "",
        short_term_capacity: int = 0,
        bus: Optional[EventBus] = None,
    ) -> None:
        """初始化 MemoryStore。

        Args:
            storage_dir: 长期记忆存储目录。
            short_term_capacity: 短期记忆容量上限，默认 100。
            bus: EventBus 实例。
        """
        self._storage_dir = storage_dir or self.DEFAULT_STORAGE_DIR
        self._short_term_capacity = short_term_capacity or self.DEFAULT_SHORT_TERM_CAPACITY
        self._bus = bus or get_default_bus()

        # 短期记忆：persona_id → deque of MemoryEntry
        self._short_term: Dict[str, deque[MemoryEntry]] = {}
        self._lock = threading.RLock()

        # 向量搜索引擎（TF-IDF + 子串回退）
        self._searcher = HybridSearcher(threshold=0.01)

        # 确保存储目录存在
        os.makedirs(self._storage_dir, exist_ok=True)

        logger.info(
            "MemoryStore 已初始化: storage=%s, short_term_capacity=%d",
            self._storage_dir, self._short_term_capacity,
        )

    @property
    def bus(self) -> EventBus:
        return self._bus

    @property
    def storage_dir(self) -> str:
        return self._storage_dir

    # ------------------------------------------------------------------
    # 存储
    # ------------------------------------------------------------------

    def save(
        self,
        entry: MemoryEntry,
        persist: bool = False,
    ) -> str:
        """保存记忆。

        Args:
            entry: 记忆条目。
            persist: 是否同时持久化到长期记忆文件。

        Returns:
            记忆 ID。
        """
        with self._lock:
            # 短期记忆
            if entry.persona_id not in self._short_term:
                self._short_term[entry.persona_id] = deque(maxlen=self._short_term_capacity)
            self._short_term[entry.persona_id].append(entry)

            # 长期记忆
            if persist:
                self._persist(entry)

        self._bus.emit(Event(
            type=EventType.MEMORY_STORED,
            source="memory.store",
            data={
                "memory_id": entry.id,
                "persona_id": entry.persona_id,
                "role": entry.role,
                "persist": persist,
            },
        ))

        logger.debug("记忆已保存: %s (persona=%s, persist=%s)", entry.id, entry.persona_id, persist)
        return entry.id

    def save_message(
        self,
        persona_id: str,
        content: str,
        role: str = "user",
        persist: bool = True,
    ) -> str:
        """快速保存聊天消息。

        Args:
            persona_id: 所属 Persona。
            content: 消息内容。
            role: 角色。
            persist: 是否持久化。

        Returns:
            记忆 ID。
        """
        entry = MemoryEntry(
            persona_id=persona_id,
            content=content,
            role=role,
            metadata={"type": "message"},
            ttl=86400 * 7,  # 7 天 TTL
        )
        return self.save(entry, persist=persist)

    def save_conversation(
        self,
        persona_id: str,
        messages: List[Tuple[str, str]],
        persist: bool = True,
    ) -> List[str]:
        """批量保存对话。

        Args:
            persona_id: Persona ID。
            messages: [(role, content), ...] 列表。
            persist: 是否持久化。

        Returns:
            记忆 ID 列表。
        """
        ids: List[str] = []
        for role, content in messages:
            ids.append(self.save_message(persona_id, content, role, persist=persist))
        return ids

    # ------------------------------------------------------------------
    # 检索
    # ------------------------------------------------------------------

    def retrieve(
        self,
        persona_id: str = "",
        limit: int = 20,
        role: str = "",
        include_expired: bool = False,
    ) -> List[MemoryEntry]:
        """检索短期记忆。

        Args:
            persona_id: Persona ID，为空则检索所有。
            limit: 最大返回数。
            role: 按角色过滤，为空则不过滤。
            include_expired: 是否包含过期记忆。

        Returns:
            记忆条目列表（按时间倒序）。
        """
        with self._lock:
            entries: List[MemoryEntry] = []

            if persona_id:
                dq = self._short_term.get(persona_id, deque())
                entries = list(dq)
            else:
                for dq in self._short_term.values():
                    entries.extend(dq)

            # 过滤
            if not include_expired:
                entries = [e for e in entries if not e.is_expired]
            if role:
                entries = [e for e in entries if e.role == role]

            # 排序并截断
            entries.sort(key=lambda e: e.created_at, reverse=True)

            result = entries[:limit]
            for e in result:
                e.touch()

        self._bus.emit(Event(
            type=EventType.MEMORY_RETRIEVED,
            source="memory.store",
            data={"persona_id": persona_id, "count": len(result), "limit": limit},
        ))
        return result

    def search(
        self,
        query: str,
        persona_id: str = "",
        limit: int = 10,
    ) -> List[MemoryEntry]:
        """搜索短期记忆（TF-IDF 向量检索 + 子串回退）。

        v2.0 升级：使用 HybridSearcher 进行语义检索，
        替代旧的朴素子串匹配。当 TF-IDF 无结果时自动退回子串匹配。

        Args:
            query: 搜索关键词。
            persona_id: 限定 Persona，为空则搜索所有。
            limit: 最大返回数。

        Returns:
            匹配的记忆列表（按相关性排序）。
        """
        with self._lock:
            candidates: List[MemoryEntry] = []

            if persona_id:
                dq = self._short_term.get(persona_id, deque())
                candidates = list(dq)
            else:
                for dq in self._short_term.values():
                    candidates.extend(dq)

            # 过滤过期记忆
            candidates = [e for e in candidates if not e.is_expired]

            if not candidates:
                return []

            # 构建文档列表
            documents = [e.content for e in candidates]

            # 混合搜索
            search_results = self._searcher.search(query, documents)

            # 取 top-N
            result: List[MemoryEntry] = []
            for idx, score in search_results[:limit]:
                entry = candidates[idx]
                entry.touch()
                result.append(entry)

        return result

    # ------------------------------------------------------------------
    # 长期记忆持久化
    # ------------------------------------------------------------------

    def _get_storage_path(self, persona_id: str) -> str:
        """获取长期记忆文件路径。"""
        safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in persona_id)
        return os.path.join(self._storage_dir, f"{safe_name}.json")

    def _persist(self, entry: MemoryEntry) -> None:
        """将记忆条目持久化到磁盘。

        P1修复：使用文件锁（fcntl/msvcrt）保护读-改-写操作，
        防止多进程/多线程并发写入导致数据丢失。
        """
        path = self._get_storage_path(entry.persona_id)
        lock_path = path + ".lock"
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(path), exist_ok=True)

            # 获取文件锁（跨进程安全）
            import platform
            lock_fd = None
            if platform.system() == "Windows":
                import msvcrt
                lock_fd = open(lock_path, "w")
                msvcrt.locking(lock_fd.fileno(), msvcrt.LK_LOCK, 1)
            else:
                import fcntl
                lock_fd = open(lock_path, "w")
                fcntl.flock(lock_fd.fileno(), fcntl.LOCK_EX)

            try:
                # 读取现有数据
                existing: List[Dict[str, Any]] = []
                if os.path.exists(path):
                    with open(path, "r", encoding="utf-8") as f:
                        existing = json.load(f)

                # 去重（基于 ID）
                if any(e.get("id") == entry.id for e in existing):
                    return

                # 追加新条目
                existing.append(entry.to_dict())

                # 限制文件大小（最多 500 条）
                if len(existing) > 500:
                    existing = existing[-500:]

                # 写入（原子写入：先写临时文件再重命名）
                tmp_path = path + ".tmp"
                with open(tmp_path, "w", encoding="utf-8") as f:
                    json.dump(existing, f, ensure_ascii=False, indent=2)
                os.replace(tmp_path, path)
            finally:
                if lock_fd:
                    lock_fd.close()
                    # 清理锁文件（best-effort）
                    try:
                        os.remove(lock_path)
                    except OSError:
                        pass

        except Exception as e:
            logger.error("持久化记忆失败: %s — %s", path, e)

    def load_long_term(self, persona_id: str) -> List[MemoryEntry]:
        """从磁盘加载长期记忆。

        Args:
            persona_id: Persona ID。

        Returns:
            记忆列表。
        """
        path = self._get_storage_path(persona_id)
        if not os.path.exists(path):
            return []

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            entries = []
            for item in data:
                try:
                    entry = MemoryEntry.from_dict(item)
                    if not entry.is_expired:
                        entries.append(entry)
                except Exception:
                    continue

            return entries
        except Exception as e:
            logger.error("加载长期记忆失败: %s — %s", path, e)
            return []

    def sync_to_short_term(self, persona_id: str) -> int:
        """将长期记忆同步到短期记忆。

        Args:
            persona_id: Persona ID。

        Returns:
            同步的条目数。
        """
        entries = self.load_long_term(persona_id)
        count = 0
        with self._lock:
            if persona_id not in self._short_term:
                self._short_term[persona_id] = deque(maxlen=self._short_term_capacity)
            for entry in entries:
                existing_ids = {e.id for e in self._short_term[persona_id]}
                if entry.id not in existing_ids:
                    self._short_term[persona_id].append(entry)
                    count += 1
        if count:
            logger.info("长期记忆同步到短期: persona=%s, count=%d", persona_id, count)
        return count

    # ------------------------------------------------------------------
    # 清理
    # ------------------------------------------------------------------

    def clear_short_term(self, persona_id: str = "") -> int:
        """清除短期记忆。

        Args:
            persona_id: 指定 Persona，为空则清除所有。

        Returns:
            清除的条目数。
        """
        with self._lock:
            if persona_id:
                count = len(self._short_term.get(persona_id, deque()))
                self._short_term.pop(persona_id, None)
            else:
                count = sum(len(d) for d in self._short_term.values())
                self._short_term.clear()

        self._bus.emit(Event(
            type=EventType.MEMORY_CLEARED,
            source="memory.store",
            data={"persona_id": persona_id, "count": count},
        ))
        return count

    def clear_long_term(self, persona_id: str = "") -> int:
        """清除长期记忆文件。

        Args:
            persona_id: 指定 Persona，为空则清除所有。

        Returns:
            清除的文件数。
        """
        count = 0
        if persona_id:
            path = self._get_storage_path(persona_id)
            if os.path.exists(path):
                os.remove(path)
                count = 1
        else:
            for fname in os.listdir(self._storage_dir):
                if fname.endswith(".json"):
                    os.remove(os.path.join(self._storage_dir, fname))
                    count += 1

        if count:
            self._bus.emit(Event(
                type=EventType.MEMORY_CLEARED,
                source="memory.store",
                data={"persona_id": persona_id or "all", "files_deleted": count},
            ))
        return count

    def _is_entry_valid(self, item: Dict[str, Any]) -> bool:
        """检查长期记忆条目的 TTL 是否仍然有效。

        处理 naive/aware datetime 兼容性。
        """
        ttl = item.get("ttl", 0.0)
        if ttl <= 0:
            return True
        try:
            created = datetime.fromisoformat(item["created_at"])
        except (KeyError, ValueError, TypeError):
            return False
        if created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        elapsed = (datetime.now(timezone.utc) - created).total_seconds()
        return elapsed <= ttl

    def purge_expired(self) -> int:
        """清除所有过期的长期记忆条目。

        Returns:
            清除的条目数。
        """
        total = 0
        for fname in os.listdir(self._storage_dir):
            if not fname.endswith(".json"):
                continue
            path = os.path.join(self._storage_dir, fname)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                valid = [
                    item for item in data
                    if item.get("ttl", 0) <= 0 or
                    self._is_entry_valid(item)
                ]
                removed = len(data) - len(valid)
                if removed > 0:
                    with open(path, "w", encoding="utf-8") as f:
                        json.dump(valid, f, ensure_ascii=False, indent=2)
                total += removed
            except Exception:
                continue
        if total:
            logger.info("已清除 %d 条过期长期记忆", total)
        return total

    # ------------------------------------------------------------------
    # 统计
    # ------------------------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        """获取统计信息。"""
        with self._lock:
            st_count = sum(len(d) for d in self._short_term.values())
            persona_st = {
                pid: len(dq)
                for pid, dq in self._short_term.items()
            }

        lt_files = [f for f in os.listdir(self._storage_dir) if f.endswith(".json")]
        lt_count = 0
        for fname in lt_files:
            try:
                with open(os.path.join(self._storage_dir, fname), "r", encoding="utf-8") as f:
                    lt_count += len(json.load(f))
            except Exception:
                pass

        return {
            "short_term_total": st_count,
            "short_term_by_persona": persona_st,
            "long_term_total": lt_count,
            "long_term_files": len(lt_files),
            "storage_dir": self._storage_dir,
            "capacity": self._short_term_capacity,
        }
