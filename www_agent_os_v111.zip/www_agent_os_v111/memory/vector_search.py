"""
Vector Search — 基于 TF-IDF 的轻量向量检索

零外部依赖实现，支持中英文混合文本：
- 字符级 bigram 分词（适配中文，无需 jieba）
- TF-IDF 向量化
- 余弦相似度计算

用于 MemoryStore.search() 替代朴素子串匹配。

版本: 1.0.0
"""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Dict, List, Set, Tuple


# ------------------------------------------------------------------
# 分词
# ------------------------------------------------------------------

def tokenize(text: str) -> List[str]:
    """中英文混合分词。

    策略：
    - 英文：按空格/标点分词，转小写
    - 中文：字符级 bigram（2-gram）
    - 数字：连续数字作为一个 token

    Args:
        text: 输入文本。

    Returns:
        token 列表。
    """
    text = text.lower().strip()
    tokens: List[str] = []

    # 提取英文单词和数字
    word_pattern = re.compile(r"[a-z]+|\d+")
    for match in word_pattern.finditer(text):
        tokens.append(match.group())

    # 提取中文字符并生成 bigram
    chinese_chars = re.findall(r"[\u4e00-\u9fff]", text)
    for i in range(len(chinese_chars) - 1):
        tokens.append(chinese_chars[i] + chinese_chars[i + 1])

    # 单个中文字符也作为 token（覆盖单字查询）
    for ch in chinese_chars:
        tokens.append(ch)

    return tokens


# ------------------------------------------------------------------
# TF-IDF 向量化器
# ------------------------------------------------------------------

class TfidfVectorizer:
    """轻量 TF-IDF 向量化器。

    Usage::

        vec = TfidfVectorizer()
        vec.fit(["文档1内容", "文档2内容"])
        scores = vec.search("查询文本", ["文档1内容", "文档2内容"])
        # scores = [(index, score), ...] 按相似度降序
    """

    def __init__(self) -> None:
        self._idf: Dict[str, float] = {}
        self._vocabulary: Set[str] = set()
        self._doc_count: int = 0

    def fit(self, documents: List[str]) -> None:
        """从文档集合学习 IDF 权重。

        Args:
            documents: 文档文本列表。
        """
        self._doc_count = len(documents)
        if self._doc_count == 0:
            return

        # 统计每个 token 出现在多少个文档中
        doc_freq: Counter = Counter()
        for doc in documents:
            tokens = set(tokenize(doc))  # 去重：每篇文档只计一次
            for token in tokens:
                doc_freq[token] += 1

        self._vocabulary = set(doc_freq.keys())

        # 计算 IDF: log((N + 1) / (df + 1)) + 1  (平滑处理)
        for token, df in doc_freq.items():
            self._idf[token] = math.log((self._doc_count + 1) / (df + 1)) + 1

    def _transform(self, text: str) -> Dict[str, float]:
        """将单篇文本转为 TF-IDF 向量（稀疏表示）。"""
        tokens = tokenize(text)
        if not tokens:
            return {}

        tf = Counter(tokens)
        total = len(tokens)

        vector: Dict[str, float] = {}
        for token, count in tf.items():
            tf_val = count / total
            idf_val = self._idf.get(token, 0.0)
            vector[token] = tf_val * idf_val

        return vector

    @staticmethod
    def _cosine_similarity(vec1: Dict[str, float], vec2: Dict[str, float]) -> float:
        """计算两个稀疏向量的余弦相似度。"""
        if not vec1 or not vec2:
            return 0.0

        # 点积
        common_keys = set(vec1.keys()) & set(vec2.keys())
        dot_product = sum(vec1[k] * vec2[k] for k in common_keys)

        if dot_product == 0:
            return 0.0

        # 模长
        norm1 = math.sqrt(sum(v * v for v in vec1.values()))
        norm2 = math.sqrt(sum(v * v for v in vec2.values()))

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return dot_product / (norm1 * norm2)

    def search(
        self,
        query: str,
        documents: List[str],
        threshold: float = 0.01,
    ) -> List[Tuple[int, float]]:
        """搜索与查询最相似的文档。

        Args:
            query: 查询文本。
            documents: 文档列表。
            threshold: 最低相似度阈值，低于此值的文档不返回。

        Returns:
            [(doc_index, similarity_score), ...] 按相似度降序排列。
        """
        if not documents:
            return []

        # 如果尚未 fit，自动 fit
        if not self._idf:
            self.fit(documents)

        query_vec = self._transform(query)

        results: List[Tuple[int, float]] = []
        for i, doc in enumerate(documents):
            doc_vec = self._transform(doc)
            sim = self._cosine_similarity(query_vec, doc_vec)
            if sim >= threshold:
                results.append((i, sim))

        results.sort(key=lambda x: x[1], reverse=True)
        return results

    @property
    def vocabulary_size(self) -> int:
        """词汇表大小。"""
        return len(self._vocabulary)


# ------------------------------------------------------------------
# 混合搜索引擎（TF-IDF + 子串回退）
# ------------------------------------------------------------------

class HybridSearcher:
    """混合搜索引擎：TF-IDF 向量检索 + 子串匹配回退。

    搜索策略：
    1. 使用 TF-IDF 计算所有候选文档与查询的相似度
    2. 如果 TF-IDF 有结果（score >= threshold），返回向量检索结果
    3. 如果 TF-IDF 无结果，退回子串匹配

    Usage::

        searcher = HybridSearcher()
        results = searcher.search("查询", ["文档1", "文档2", "文档3"])
        # results = [(index, score), ...]
    """

    def __init__(self, threshold: float = 0.01) -> None:
        self._vectorizer = TfidfVectorizer()
        self._threshold = threshold

    def search(
        self,
        query: str,
        documents: List[str],
    ) -> List[Tuple[int, float]]:
        """混合搜索。

        Args:
            query: 查询文本。
            documents: 候选文档列表。

        Returns:
            [(doc_index, score), ...] 按相关性降序。
            score 范围 0.0~1.0（TF-IDF 模式）或 0.5/1.0（子串模式）。
        """
        if not documents:
            return []

        # 向量检索
        vec_results = self._vectorizer.search(query, documents, self._threshold)

        if vec_results:
            return vec_results

        # 回退：子串匹配
        query_lower = query.lower()
        substring_results: List[Tuple[int, float]] = []
        for i, doc in enumerate(documents):
            doc_lower = doc.lower()
            if query_lower in doc_lower:
                # 精确匹配 = 1.0，部分匹配 = 0.5
                score = 1.0 if query_lower == doc_lower else 0.5
                substring_results.append((i, score))

        substring_results.sort(key=lambda x: x[1], reverse=True)
        return substring_results

    def fit(self, documents: List[str]) -> None:
        """预热向量模型。"""
        self._vectorizer.fit(documents)
