"""
Persona 基类 — 第三阶段：Persona 体系建立

定义 Persona 状态机、数据模型、生命周期钩子。
继承此基类的所有 Persona 子类获得统一的状态管理和序列化能力。

依赖最小化：Python 3.10+ 标准库
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Optional


class PersonaState(Enum):
    """Persona 生命周期状态机（技术文档第2章 13 阶段 FSM）。

    完整生命周期：
    CREATE → INSTALL → LOAD → RUNNING ⇄ BUSY ⇄ IDLE
                                  ↓
                                SLEEP → ARCHIVE → RESTORE → LOAD
                                  ↑        ↓
                                  └────────┘

    特殊转换（RUNNING/BUSY/IDLE 下触发）：
    - UPGRADE: 更新 Prompt / 模型 / 工具 / 技能（保持身份）
    - SPLIT:   高负载 → 自动分裂出子 Persona
    - MERGE:   子 Persona 经验合并回父 Persona

    终态（从任何状态可进入，不可逆）：
    - DESTROY: 永久删除（前置检查：无未完成Workflow、无依赖）

    V1 兼容别名（文档13阶段 → 代码5状态映射）：
    - CREATE/INSTALL/LOAD → UNINITIALIZED (简化)
    - RUNNING → IDLE (默认子状态)
    - BUSY → BUSY
    - IDLE → IDLE
    - SLEEP/ARCHIVE/RESTORE → TERMINATED (简化)
    - UPGRADE/SPLIT/MERGE → BUSY (简化)
    - DESTROY → TERMINATED
    - ERROR → ERROR (不变)
    """

    # ── 文档13阶段（v2.0 完整模式） ──
    CREATE = auto()        # 生成 PersonaManifest，仅"设计图纸"
    INSTALL = auto()       # 编译 Prompt、绑定模型、注册工具、分配记忆
    LOAD = auto()          # 加载到内存，分配运行时资源，进入待命
    RUNNING = auto()       # 活动状态，可接收任务（子状态：BUSY/IDLE）
    BUSY = auto()          # 正在执行 Workflow 步骤，不可接收新任务
    IDLE = auto()          # 无任务，等待调度，保持热启动
    SLEEP = auto()         # 释放部分内存（模型卸载），保留记忆和注册
    ARCHIVE = auto()       # 打包为 .persona 文件，释放全部资源（冷存储）
    RESTORE = auto()       # 从 .persona 解压恢复中
    UPGRADE = auto()       # 更新 Prompt/模型/工具/技能（保持 UUID）
    SPLIT = auto()         # 高负载时自动分裂子 Persona
    MERGE = auto()         # 子 Persona 经验合并回父 Persona
    DESTROY = auto()       # 永久删除（不可逆终态）

    # ── V1 兼容别名 ──
    UNINITIALIZED = auto()  # 兼容旧版：v1 中表示 CREATE+INSTALL+LOAD
    TERMINATED = auto()     # 兼容旧版：v1 中表示 DESTROY/SLEEP/ARCHIVE
    ERROR = auto()          # 错误状态（保持）


# ── 完整状态转移约束矩阵（技术文档 §2.3） ──
# Y = 允许, N = 禁止, C1 = 无未完成Workflow时允许, C2 = 前置检查通过
#
# 注意：此矩阵为 V2.0 完整模式预留。当前 V1 兼容模式下，
# transition_to() 使用 _VALID_TRANSITIONS（5 状态简化版）。
# 当 USE_NEW_ARCH flag 全面启用后，将切换到此完整矩阵。
# 参见 docs/design_alignment_report.md
_FULL_TRANSITIONS: dict[PersonaState, set[PersonaState]] = {
    # CREATE → INSTALL（唯一合法转换）
    PersonaState.CREATE: {PersonaState.INSTALL},
    # INSTALL → LOAD（唯一合法转换）
    PersonaState.INSTALL: {PersonaState.LOAD},
    # LOAD → RUNNING（唯一合法转换）
    PersonaState.LOAD: {PersonaState.RUNNING},
    # RUNNING → BUSY / IDLE / SLEEP / ARCHIVE（C1: 无未完成Workflow）
    PersonaState.RUNNING: {
        PersonaState.BUSY, PersonaState.IDLE,
        PersonaState.SLEEP, PersonaState.ARCHIVE,
        PersonaState.UPGRADE, PersonaState.SPLIT, PersonaState.MERGE,
        PersonaState.DESTROY,  # C2
    },
    # BUSY → IDLE（任务完成/超时/被中断）
    PersonaState.BUSY: {PersonaState.IDLE, PersonaState.ERROR, PersonaState.DESTROY},
    # IDLE → BUSY / SLEEP / ARCHIVE / UPGRADE / SPLIT / MERGE / DESTROY
    PersonaState.IDLE: {
        PersonaState.BUSY, PersonaState.SLEEP, PersonaState.ARCHIVE,
        PersonaState.UPGRADE, PersonaState.SPLIT, PersonaState.DESTROY,
    },
    # SLEEP → RUNNING（热唤醒）/ ARCHIVE（冷封存）/ DESTROY
    PersonaState.SLEEP: {PersonaState.RUNNING, PersonaState.ARCHIVE, PersonaState.DESTROY},
    # ARCHIVE → RESTORE / DESTROY
    PersonaState.ARCHIVE: {PersonaState.RESTORE, PersonaState.DESTROY},
    # RESTORE → LOAD → RUNNING
    PersonaState.RESTORE: {PersonaState.LOAD},
    # UPGRADE → RUNNING（升级完成后自动唤醒）
    PersonaState.UPGRADE: {PersonaState.RUNNING},
    # SPLIT → RUNNING（分裂完成后父继续运行）
    PersonaState.SPLIT: {PersonaState.RUNNING},
    # MERGE → RUNNING（合并完成后继续）
    PersonaState.MERGE: {PersonaState.RUNNING},
    # DESTROY → 无（终态，不可逆）
    PersonaState.DESTROY: set(),
    # ERROR → IDLE（恢复）/ DESTROY
    PersonaState.ERROR: {PersonaState.IDLE, PersonaState.DESTROY},
    # ── V1 兼容 ──
    PersonaState.UNINITIALIZED: {
        PersonaState.IDLE, PersonaState.TERMINATED,
        PersonaState.CREATE, PersonaState.INSTALL, PersonaState.LOAD,
        PersonaState.RUNNING,
    },
    PersonaState.TERMINATED: set(),
}

# V1 兼容别名：旧版 5 状态转移（保持向后兼容）
_VALID_TRANSITIONS: dict[PersonaState, set[PersonaState]] = {
    PersonaState.UNINITIALIZED: {PersonaState.IDLE, PersonaState.TERMINATED},
    PersonaState.IDLE: {PersonaState.BUSY, PersonaState.TERMINATED},
    PersonaState.BUSY: {PersonaState.IDLE, PersonaState.ERROR, PersonaState.BUSY},
    PersonaState.ERROR: {PersonaState.IDLE, PersonaState.TERMINATED, PersonaState.BUSY},
    PersonaState.TERMINATED: set(),
}


# ==================================================================
# 技术文档 §1.2 要求的新属性类型（v1.0 占位实现）
# ==================================================================

class PersonaRole(str, Enum):
    """Persona 角色类型（技术文档 §1.2）。"""
    HOST = "host"               # 指挥者，负责意图识别、任务分解、调度
    SPECIALIST = "specialist"   # 领域专家，处理特定领域深度任务
    WORKER = "worker"           # 通用工作者，处理常规任务
    EXECUTOR = "executor"       # 执行者，纯工具/脚本执行
    SUPERVISOR = "supervisor"   # 监督者，监控质量和安全


class PermissionLevel(str, Enum):
    """权限等级（技术文档 Security Architecture）。"""
    L0 = "L0"  # 只读查询
    L1 = "L1"  # 创建非系统文件
    L2 = "L2"  # 修改用户文件
    L3 = "L3"  # 删除用户文件 / 修改系统配置
    L4 = "L4"  # 删除系统文件 / 格式化 / 注册表操作（需人类确认）


@dataclass
class ModelBinding:
    """模型绑定（技术文档 §1.2 Model 属性）。"""
    model_name: str = ""
    provider: str = "ollama"
    tier: str = "mid"                    # low / mid / high
    fallback_model: str = ""
    context_length: int = 4096
    temperature: float = 0.7


@dataclass
class PersonalityProfile:
    """五维人格向量（OCEAN，技术文档 §5.1.3）。"""
    openness: float = 0.5
    conscientiousness: float = 0.5
    extraversion: float = 0.5
    agreeableness: float = 0.5
    neuroticism: float = 0.5

    def to_dict(self) -> dict[str, float]:
        return {"o": self.openness, "c": self.conscientiousness,
                "e": self.extraversion, "a": self.agreeableness,
                "n": self.neuroticism}


@dataclass
class Lineage:
    """演化谱系（技术文档 §5.1.6）。"""
    parent_id: str = ""
    generation: int = 1
    child_ids: list[str] = field(default_factory=list)
    origin: str = "manual"              # manual / split / inherit
    split_history: list[dict[str, Any]] = field(default_factory=list)
    merge_history: list[dict[str, Any]] = field(default_factory=list)
    evolution_log: list[dict[str, Any]] = field(default_factory=list)

    def log_event(self, event: str, detail: str = "") -> None:
        import datetime
        self.evolution_log.append({
            "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "event": event,
            "detail": detail,
        })


@dataclass
class Persona:
    """Persona 数据模型 — 技术文档 §1.2 15核心属性 + 运行时统计。

    包含身份、角色、能力、人格、权限、模型绑定、版本、状态机、
    谱系链路和生命周期钩子。所有子类继承此基类。
    """

    # ---- 身份字段 ----
    persona_id: str
    """唯一标识符，如 'host'、's1_software'。"""

    name: str
    """显示名称，如 '指挥者 Marvis'、'软件专员'。"""

    description: str = ""
    """一句话角色描述。"""

    # ---- 能力字段 ----
    capabilities: list[str] = field(default_factory=list)
    """能力标签列表，用于语义匹配。例如 ['软件管理', '安装', '卸载', '应用']。"""

    core_prompt: str = ""
    """核心 prompt 内容，从旧 SKILL.md 迁移，保留原意与关键规范。"""

    # ---- 技术文档 §1.2 15核心属性扩展 ----
    role: PersonaRole = PersonaRole.WORKER
    """角色类型：HOST/SPECIALIST/WORKER/EXECUTOR/SUPERVISOR。"""

    personality: PersonalityProfile = field(default_factory=PersonalityProfile)
    """五维人格向量（OCEAN）。"""

    model_binding: ModelBinding = field(default_factory=ModelBinding)
    """模型绑定：模型名/提供商/上下文长度/温度。"""

    permission_level: PermissionLevel = PermissionLevel.L2
    """权限等级：L0-L4。"""

    lineage: Lineage = field(default_factory=Lineage)
    """演化谱系：父ID/代数/子ID/演化日志。"""

    # ---- 版本字段 ----
    version: str = "1.0.0"
    """Persona 版本号，遵循 SemVer。"""

    # ---- 状态字段 ----
    state: PersonaState = PersonaState.UNINITIALIZED
    """当前生命周期状态。"""

    created_at: float = field(default_factory=time.time)
    """创建时间（Unix 时间戳）。"""

    activated_at: float = 0.0
    """最近激活时间。"""

    deactivated_at: float = 0.0
    """最近停用时间。"""

    memory_refs: list[str] = field(default_factory=list)
    """关联的记忆库引用（如记忆文件路径）。"""

    # ---- 运行时统计（从旧 PersonaManager.Persona 迁移） ----
    task_count: int = 0
    task_score: float = 0.0
    incentive_stars: int = 3
    penalty_stars: int = 0
    last_task_time: float = 0.0
    success_count: int = 0
    failure_count: int = 0

    # ---- 元数据 ----
    icon: str = "?"
    color: str = "#3b82f6"
    model: str = ""
    scope_keywords: list[str] = field(default_factory=list)

    # ==================================================================
    # 属性
    # ==================================================================

    @property
    def net_incentive(self) -> int:
        """净激励值 = 激励星 - 惩戒星。"""
        return self.incentive_stars - self.penalty_stars

    @property
    def success_rate(self) -> float:
        """历史成功率 (0.0 ~ 1.0)。"""
        total = self.success_count + self.failure_count
        if total == 0:
            return 1.0
        return self.success_count / total

    @property
    def idle_seconds(self) -> float:
        """距上次任务的空闲秒数。"""
        if self.last_task_time == 0:
            return float("inf")
        return time.time() - self.last_task_time

    @property
    def status(self) -> str:
        """V1 兼容状态字符串。

        映射 PersonaState → V1 status:
        - IDLE / RUNNING / BUSY → "active"
        - SLEEP / UNINITIALIZED → "inactive"
        - ARCHIVE → "archived"
        - TERMINATED / DESTROY → "archived"
        - ERROR → "inactive"
        """
        _ACTIVE_STATES = {PersonaState.IDLE, PersonaState.RUNNING, PersonaState.BUSY}
        _ARCHIVED_STATES = {PersonaState.ARCHIVE, PersonaState.TERMINATED, PersonaState.DESTROY}
        if self.state in _ACTIVE_STATES:
            return "active"
        if self.state in _ARCHIVED_STATES:
            return "archived"
        return "inactive"

    # ==================================================================
    # 状态机方法
    # ==================================================================

    def transition_to(self, target: PersonaState) -> bool:
        """状态转移。合法转移返回 True，非法转移返回 False 且不改变状态。"""
        if target in _VALID_TRANSITIONS.get(self.state, set()):
            old = self.state
            self.state = target
            if target == PersonaState.IDLE and old == PersonaState.UNINITIALIZED:
                self.activated_at = time.time()
            elif target == PersonaState.TERMINATED:
                self.deactivated_at = time.time()
            return True
        return False

    def can_transition_to(self, target: PersonaState) -> bool:
        """检查是否可转移到目标状态。"""
        return target in _VALID_TRANSITIONS.get(self.state, set())

    # ==================================================================
    # 生命周期钩子（子类可覆写）
    # ==================================================================

    def on_activate(self) -> None:
        """激活时调用。子类覆写以执行初始化逻辑。"""
        self.transition_to(PersonaState.IDLE)

    def on_deactivate(self) -> None:
        """停用时调用。子类覆写以执行清理逻辑。"""
        self.transition_to(PersonaState.TERMINATED)

    def on_error(self, error: Exception) -> None:
        """错误时调用。子类覆写以执行错误恢复逻辑。"""
        self.state = PersonaState.ERROR

    # ==================================================================
    # 序列化
    # ==================================================================

    def to_dict(self) -> dict[str, Any]:
        """序列化为字典。"""
        return {
            "persona_id": self.persona_id,
            "name": self.name,
            "description": self.description,
            "capabilities": self.capabilities,
            "version": self.version,
            "state": self.state.name,
            "created_at": self.created_at,
            "activated_at": self.activated_at,
            "deactivated_at": self.deactivated_at,
            "memory_refs": self.memory_refs,
            "task_count": self.task_count,
            "task_score": self.task_score,
            "incentive_stars": self.incentive_stars,
            "penalty_stars": self.penalty_stars,
            "last_task_time": self.last_task_time,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "icon": self.icon,
            "color": self.color,
            "model": self.model,
            "scope_keywords": self.scope_keywords,
            # ── 技术文档 §1.2 新增 15 核心属性 ──
            "role": self.role.value,
            "personality": self.personality.to_dict(),
            "model_binding": {
                "model_name": self.model_binding.model_name,
                "provider": self.model_binding.provider,
                "tier": self.model_binding.tier,
                "fallback_model": self.model_binding.fallback_model,
                "context_length": self.model_binding.context_length,
                "temperature": self.model_binding.temperature,
            },
            "permission_level": self.permission_level.value,
            "lineage": {
                "parent_id": self.lineage.parent_id,
                "generation": self.lineage.generation,
                "child_ids": self.lineage.child_ids,
                "origin": self.lineage.origin,
            },
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Persona:
        """从字典反序列化。

        兼容 V1 和 V2 格式：
        - V1 的 `role` (str) 自动映射到 `description`
        - V1 的 `status` (str) 自动映射到对应的 PersonaState
        """
        # V1 兼容：role (str) → description
        description = data.get("description", "")
        if not description and data.get("role"):
            # V1 的 role 是自由文本描述，映射到 V2 的 description
            description = data["role"]

        # 状态解析（支持 V1 status 字符串和 V2 state 名称）
        state_str = data.get("state", "")
        if not state_str and data.get("status"):
            # V1 status 字符串 → PersonaState 映射
            status_map = {
                "active": PersonaState.IDLE,
                "inactive": PersonaState.SLEEP,
                "archived": PersonaState.ARCHIVE,
            }
            state = status_map.get(data["status"], PersonaState.UNINITIALIZED)
        else:
            try:
                state = PersonaState[state_str] if state_str else PersonaState.UNINITIALIZED
            except KeyError:
                state = PersonaState.UNINITIALIZED

        # 反序列化新属性
        role_str = data.get("role", "worker")
        try:
            role = PersonaRole(role_str)
        except ValueError:
            role = PersonaRole.WORKER

        perm_str = data.get("permission_level", "L2")
        try:
            permission_level = PermissionLevel(perm_str)
        except ValueError:
            permission_level = PermissionLevel.L2

        personality_data = data.get("personality", {})
        personality = PersonalityProfile(
            openness=personality_data.get("o", 0.5),
            conscientiousness=personality_data.get("c", 0.5),
            extraversion=personality_data.get("e", 0.5),
            agreeableness=personality_data.get("a", 0.5),
            neuroticism=personality_data.get("n", 0.5),
        )

        mb_data = data.get("model_binding", {})
        model_binding = ModelBinding(
            model_name=mb_data.get("model_name", ""),
            provider=mb_data.get("provider", "ollama"),
            tier=mb_data.get("tier", "mid"),
            fallback_model=mb_data.get("fallback_model", ""),
            context_length=mb_data.get("context_length", 4096),
            temperature=mb_data.get("temperature", 0.7),
        )

        lineage_data = data.get("lineage", {})
        lineage = Lineage(
            parent_id=lineage_data.get("parent_id", ""),
            generation=lineage_data.get("generation", 1),
            child_ids=lineage_data.get("child_ids", []),
            origin=lineage_data.get("origin", "manual"),
        )

        return cls(
            persona_id=data.get("persona_id", ""),
            name=data.get("name", ""),
            description=description,
            capabilities=data.get("capabilities", []),
            version=data.get("version", "1.0.0"),
            state=state,
            created_at=data.get("created_at", 0.0),
            activated_at=data.get("activated_at", 0.0),
            deactivated_at=data.get("deactivated_at", 0.0),
            memory_refs=data.get("memory_refs", []),
            task_count=data.get("task_count", 0),
            task_score=data.get("task_score", 0.0),
            incentive_stars=data.get("incentive_stars", 3),
            penalty_stars=data.get("penalty_stars", 0),
            last_task_time=data.get("last_task_time", 0.0),
            success_count=data.get("success_count", 0),
            failure_count=data.get("failure_count", 0),
            icon=data.get("icon", "?"),
            color=data.get("color", "#3b82f6"),
            model=data.get("model", ""),
            scope_keywords=data.get("scope_keywords", []),
            role=role,
            personality=personality,
            model_binding=model_binding,
            permission_level=permission_level,
            lineage=lineage,
        )

    # ==================================================================
    # 工具方法
    # ==================================================================

    def __repr__(self) -> str:
        return (
            f"Persona(id={self.persona_id!r}, name={self.name!r}, "
            f"state={self.state.name}, version={self.version})"
        )

    def __hash__(self) -> int:
        return hash(self.persona_id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Persona):
            return NotImplemented
        return self.persona_id == other.persona_id
