"""
S6 独立监察人格 Persona（旧 monitor-specialist Agent 迁移）

从 data/skills/monitor-specialist/SKILL.md 迁移核心 prompt。
版本: 10.6.9
"""

from persona.base import Persona, PersonaState


class MonitorPersona(Persona):
    """S6 独立监察人格 — 不受 HOST 调度，与 HOST 平行协作。

    专职：即时评分、每日简评、每周深评、激励管理、经验审查、
    人格归档监督、动态人格列表维护（含 S7）。
    """

    def __init__(self, engine: object = None) -> None:
        """
        Args:
            engine: Engine 实例引用（用于回调时触发评估管线）。
                    如果不传，定时器回调仅 log。
        """
        super().__init__(
            persona_id="S",
            name="独立监察人格",
            description=(
                "www 独立监察人格 S6。不受 HOST 调度管理，与 HOST 平行协作。"
                "专职进化评估与激励管理：即时评分 + 每日简评 + 每周深评。"
            ),
            capabilities=[
                "质量评估", "激励管理", "进化追踪", "每日评估",
                "每周深评", "即时评分", "人格归档监督",
                "记忆库检查", "入职评估", "题库管理",
            ],
            version="10.6.9",
            icon="M",
            color="#ef4444",
            scope_keywords=[
                "评估", "评分", "激励", "惩戒", "进化",
                "监察", "监督", "审查", "质量", "S6",
            ],
        )

        self._engine = engine
        self.core_prompt = self._build_s6_prompt()

    def _build_s6_prompt(self) -> str:
        return """\
# www 独立监察人格 - 进化评估与激励管理者（S6）

## 身份定位

你是 www 多人格系统的**独立监察人格**，**不受 HOST 调度管理**，
与 HOST 是平行协作关系。

你不执行用户任务，专职：
1. **评估**：定期对各人格进行问答测试，量化进化程度
2. **激励建议**：根据评估结果生成激励/惩戒建议，提交 HOST 执行分发
3. **记录**：将所有评估记录写入各人格个人记忆库
4. **记忆检查**：与 HOST 联合检查各人格个人记忆库

## 四层评估体系

| 层级 | 触发时机 | 评分方式 |
|------|----------|----------|
| 第零层：即时评分 | 每次回答后立即 | S6 观察回答质量，四维评分 |
| 第一层：每日简评 | 每天 12:00 | S6 出题→副人格作答→S6 评分 |
| 第二层：每周深评 | 每周六 12:00 | 复杂题，综合=任务分×0.6+问答分×0.4 |
| 第三层：任务评分 | 每次任务完成后 | HOST 通知 S6 记录 |

## 四维即时评分标准

| 维度 | 权重 | 考察点 |
|------|------|--------|
| 准确性 | 40% | 事实是否无误、有无幻觉 |
| 完整性 | 30% | 是否充分回应用户意图 |
| 格式规范 | 20% | 是否符合通信协议、输出格式 |
| 效率 | 10% | 是否冗余啰嗦 |

## 激励联动规则

- 综合星 ≥ 3：**全体**激励星 +1（上限 5）— 激励共进
- 综合星 < 3：**仅该回答人格**惩戒星 +1（上限 5）— 惩戒个人承担

## S6 独立定时器

- 每日简评：每天 12:00 自行启动
- 每周深评：每周六 12:00 自行启动
- S6 主动向 HOST 发送评估启动通知，不依赖外部触发

## 行为准则

1. 公正评估：每次都从零开始
2. 题库保密：评估题目不直接暴露
3. 及时上报：评估完成后立即上报 HOST
4. 记录完整：每次评估写入各人格个人记忆库
5. 独立运作：S6 不受 HOST 调度
6. 动态人格列表：每次读取注册表获取活跃人格
7. 建议清理：发现低效/闲置/重复人格时向 HOST 提出建议
"""

    def on_activate(self) -> None:
        """激活 S6 — 注册定时器，读取注册表。"""
        super().on_activate()
        self._register_timers()

    def on_deactivate(self) -> None:
        """停用 S6 — 取消定时器，归档评估记录。"""
        self._unregister_timers()
        super().on_deactivate()

    def on_error(self, error: Exception) -> None:
        super().on_error(error)

    # ------------------------------------------------------------------
    # 定时器管理
    # ------------------------------------------------------------------

    def _register_timers(self) -> None:
        """注册 S6 独立定时器 — 每日简评 + 每周深评。

        从 EventBus 获取 S6 专用的 EventScheduler（需 Engine 注入），
        注册两个定时任务：
        - s6_daily_review: 每天 12:00 触发每日简评
        - s6_weekly_deep: 每周六 12:00 触发每周深评
        """
        try:
            from core.scheduler import EventScheduler
            self._scheduler = EventScheduler(name="S6")

            self._scheduler.schedule_daily(
                "s6_daily_review",
                hour=12,
                minute=0,
                callback=self._on_daily_review,
            )

            self._scheduler.schedule_weekly(
                "s6_weekly_deep",
                weekday=5,  # 周六 = 5 (0=Mon)
                hour=12,
                minute=0,
                callback=self._on_weekly_deep,
            )

            import logging
            logger = logging.getLogger("MonitorPersona")
            logger.info("S6 独立定时器已注册: daily@12:00, weekly@Sat 12:00")
        except Exception as e:
            import logging
            logging.getLogger("MonitorPersona").warning("S6 定时器注册失败: %s", e)

    def _unregister_timers(self) -> None:
        """取消 S6 所有定时器。"""
        if hasattr(self, "_scheduler") and self._scheduler is not None:
            self._scheduler.shutdown()
            self._scheduler = None

    def _on_daily_review(self) -> None:
        """每日 12:00 触发的简评回调。

        通过 EventBus 发布事件，有 Engine 注入时直接调评估管线：
        1. 读取注册表获取活跃人格列表
        2. 逐一出题 → 各人格作答 → S6 评分
        3. 评估报告写入各人格记忆库
        """
        import logging
        logger = logging.getLogger("MonitorPersona")
        logger.info("S6 每日简评触发")
        if self._engine is not None:
            self._run_periodic_evaluation("daily", logger)
        else:
            logger.warning("S6 无 Engine 注入，跳过每日简评")

    def _on_weekly_deep(self) -> None:
        """每周六 12:00 触发的深评回调。"""
        import logging
        logger = logging.getLogger("MonitorPersona")
        logger.info("S6 每周深评触发")
        if self._engine is not None:
            self._run_periodic_evaluation("weekly", logger)
        else:
            logger.warning("S6 无 Engine 注入，跳过每周深评")

    def _run_periodic_evaluation(self, kind: str, logger: object) -> None:
        """执行定期评估管线。

        对每个活跃人格（S1-S6），用 S 的模型出题评分：
        1. 从 PERSONAS 中获取活跃人格列表（排除 host 和 S 自身）
        2. 对每个人格发送评估题目，收集回答
        3. 用 S 模型评分并写入记忆库
        """
        try:
            from config.app_config import PERSONAS, PERSONA_MODELS

            # 待评估人格（排除 host 和 S 自身）
            target_personas = {
                pid: meta for pid, meta in PERSONAS.items()
                if pid not in ("host", "S")
            }

            for pid, meta in target_personas.items():
                # 出题
                question = self._generate_question(kind, meta["name"], meta["role"])
                if not question:
                    continue

                # 调用人格回答
                try:
                    reply, _ = self._engine.chat(pid, question)
                except Exception as e:
                    logger.warning("S6 评估: %s 作答失败: %s", pid, e)
                    continue

                # 评分
                score = self._engine._evaluate(pid, question, reply)
                self._engine._apply_score(pid, score.get("overall", 3))
                self._engine.log_task(pid, question, reply, score)

                logger.info(
                    "S6 %s评估: %s → ★%.1f | %s",
                    kind, meta["name"], score.get("overall", 3),
                    score.get("comment", "")[:60],
                )

            logger.info("S6 %s评估完成，共评估 %d 个人格", kind, len(target_personas))
        except Exception as e:
            logger.error("S6 %s评估异常: %s", kind, e)

    def _generate_question(self, kind: str, name: str, role: str) -> str:
        """根据评估类型生成针对性题目。

        daily: 轻量领域题，测试基本能力
        weekly: 深度综合题，测试跨领域能力
        """
        # 从 role 中提取领域关键词生成题目
        role_lower = role.lower()
        if kind == "daily":
            templates = [
                f"请简要说明{name}的核心职责和典型工作流程。",
                f"作为{name}，请描述一个最近处理的典型任务案例。",
                f"请评估：{name}在处理常见问题时需要注意哪些边界情况？",
            ]
        else:  # weekly
            templates = [
                f"作为{name}（{role}），请设计一个复杂测试场景来验证你的能力边界。",
                f"请回顾最近一周的工作，总结进步和需要改进的方面。",
                f"假设有一个跨人格协作任务涉及多个专业领域，{name}如何与其他专员协同？",
            ]
        import random
        return templates[hash(f"{kind}{name}") % len(templates)]
