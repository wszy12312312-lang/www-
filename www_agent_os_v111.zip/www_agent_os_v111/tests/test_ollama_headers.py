"""Ollama 认证头测试 — 基于统一 Engine 架构。"""
import os
import importlib


def _reload_config_and_engine():
    """确保 config 读取当前环境变量，然后 reload engine 模块。"""
    import config.app_config as app_config
    importlib.reload(app_config)
    import core.engine as engine_mod
    importlib.reload(engine_mod)
    return engine_mod


def test_bearer_header(monkeypatch):
    """OLLAMA_AUTH_SCHEME=bearer 时发送 Bearer 令牌。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "secret123")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "bearer")
    engine_mod = _reload_config_and_engine()
    client = engine_mod.OllamaClient()
    headers = client._get_headers()
    assert headers.get("Authorization") == "Bearer secret123"
    assert headers.get("Content-Type") == "application/json"


def test_basic_header(monkeypatch):
    """OLLAMA_AUTH_SCHEME=basic 时发送 Basic 令牌。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "basickey")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "basic")
    engine_mod = _reload_config_and_engine()
    client = engine_mod.OllamaClient()
    headers = client._get_headers()
    assert headers.get("Authorization") == "Basic basickey"


def test_raw_header(monkeypatch):
    """OLLAMA_AUTH_SCHEME=raw 时发送原始令牌。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "rawkey")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "raw")
    engine_mod = _reload_config_and_engine()
    client = engine_mod.OllamaClient()
    headers = client._get_headers()
    assert headers.get("Authorization") == "rawkey"


def test_no_key(monkeypatch):
    """未设置 OLLAMA_API_KEY 时不发送 Authorization 头。"""
    monkeypatch.delenv("OLLAMA_API_KEY", raising=False)
    monkeypatch.delenv("OLLAMA_AUTH_SCHEME", raising=False)
    engine_mod = _reload_config_and_engine()
    client = engine_mod.OllamaClient()
    headers = client._get_headers()
    assert "Authorization" not in headers


def test_default_scheme_is_bearer(monkeypatch):
    """未设置 OLLAMA_AUTH_SCHEME 时默认使用 Bearer。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "default-token")
    monkeypatch.delenv("OLLAMA_AUTH_SCHEME", raising=False)
    engine_mod = _reload_config_and_engine()
    client = engine_mod.OllamaClient()
    headers = client._get_headers()
    assert headers.get("Authorization") == "Bearer default-token"


def test_unknown_scheme_falls_back_to_bearer(monkeypatch):
    """未知 OLLAMA_AUTH_SCHEME 时回退为 Bearer。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "token-x")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "unknown")
    engine_mod = _reload_config_and_engine()
    client = engine_mod.OllamaClient()
    headers = client._get_headers()
    assert headers.get("Authorization") == "Bearer token-x"


def test_scheme_case_insensitive(monkeypatch):
    """OLLAMA_AUTH_SCHEME 大小写不敏感。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "case-token")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "BEARER")
    engine_mod = _reload_config_and_engine()
    client = engine_mod.OllamaClient()
    headers = client._get_headers()
    assert headers.get("Authorization") == "Bearer case-token"


def test_engine_init_without_errors():
    """Engine 可以无错误初始化。"""
    engine_mod = _reload_config_and_engine()
    engine = engine_mod.Engine()
    assert engine.states is not None
    assert "host" in engine.states
    assert engine._checking is False
    assert engine._running is False
