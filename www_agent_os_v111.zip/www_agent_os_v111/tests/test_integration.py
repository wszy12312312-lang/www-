"""
Integration Tests — 端到端集成测试

测试覆盖：
- SQLite Memory 层
- Permission Layer
- MultiProvider Router
- Planner + Reflection
- Evaluator + Reward
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

# 将项目根目录加入 path
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))


class TestSQLiteMemory(unittest.TestCase):
    """P0-1: SQLite Memory 层集成测试。"""

    @classmethod
    def setUpClass(cls):
        """初始化测试数据库。"""
        from database.sqlite.connection import init_db, get_db
        cls.temp_dir = tempfile.TemporaryDirectory()
        cls.db_path = os.path.join(cls.temp_dir.name, "test_memory.db")

        # 覆盖默认路径
        import database.sqlite.connection as conn
        conn._DB_PATH = cls.db_path
        init_db()
        cls.db = get_db()

    @classmethod
    def tearDownClass(cls):
        cls.temp_dir.cleanup()

    def test_short_memory_crud(self):
        """短时记忆 增删改查。"""
        from core.memory.short_memory import ShortMemory

        sm = ShortMemory(session_id="test_session", persona_id="host")
        sm.add(role="user", content="Hello World")

        # 检索最近一条
        recent = sm.get_recent(limit=5)
        self.assertGreaterEqual(len(recent), 1)
        self.assertEqual(recent[0]["content"], "Hello World")

        # 超限清理
        for i in range(200):
            sm.add(role="user", content=f"msg_{i}")
        self.assertLessEqual(sm.count(), 150)  # 默认上限 100 + 容差

        # TTL 清理
        sm.cleanup_expired()
        self.assertGreaterEqual(sm.count(), 1)

    def test_long_memory_crud(self):
        """长时记忆 增删改查。"""
        from core.memory.long_memory import LongMemory

        lm = LongMemory(persona_id="host")

        lm.store(
            summary="用户喜欢 Python",
            category="preference",
            key_facts=["Python", "编程"],
            importance=0.8,
        )

        results = lm.search(query="Python", limit=5)
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("Python", results[0]["summary"])

        # 分类检索
        results = lm.get_by_category("preference")
        self.assertGreaterEqual(len(results), 1)

    def test_semantic_memory_init(self):
        """语义记忆初始化。"""
        from core.memory.semantic_memory import SemanticMemory
        sm = SemanticMemory()
        self.assertIsNotNone(sm)

        # 存储
        sm.store(text="深度学习是人工智能的子领域", embedding_id="test_001")
        self.assertTrue(sm.exists("test_001"))


class TestPermissionLayer(unittest.TestCase):
    """P0-2: 权限系统集成测试。"""

    def setUp(self):
        from security.permission import PermissionLayer
        policy_path = str(Path(__file__).parent.parent / "www_agent_os" / "security" / "policy.yaml")
        if not os.path.exists(policy_path):
            policy_path = str(Path(__file__).parent.parent / "security" / "policy.yaml")
        self.pl = PermissionLayer(policy_path) if os.path.exists(policy_path) else None

    def test_policy_loading(self):
        """策略文件加载。"""
        if not self.pl:
            self.skipTest("policy.yaml 未找到")
        self.assertIsNotNone(self.pl._policy)

    def test_admin_full_access(self):
        """Admin 角色拥有完全访问权限。"""
        if not self.pl:
            self.skipTest("policy.yaml 未找到")
        # 暴力方法：如果有 policy，直接验证
        self.assertTrue(hasattr(self.pl, "check"))

    def test_sandbox_blocks_dangerous(self):
        """沙箱拦截危险代码。"""
        from security.sandbox import CodeSandbox, SandboxConfig

        config = SandboxConfig(timeout_sec=5, max_memory_mb=64)
        sb = CodeSandbox(config)

        # 危险调用应被拦截
        result = sb.is_safe("import shutil; shutil.rmtree('/')")
        self.assertFalse(result)


class TestProviderRouter(unittest.TestCase):
    """P0-3: Provider 路由集成测试。"""

    def test_ollama_provider_creation(self):
        """Ollama Provider 创建。"""
        from models.provider.ollama import OllamaProvider
        op = OllamaProvider(host="http://localhost:11434")
        self.assertEqual(op.host, "http://localhost:11434")

    def test_openai_provider_creation(self):
        """OpenAI Provider 创建。"""
        from models.provider.openai import OpenAIProvider
        op = OpenAIProvider(api_key="sk-test")
        self.assertEqual(op.base_url, "https://api.openai.com/v1")

    def test_anthropic_provider_creation(self):
        """Anthropic Provider 创建。"""
        from models.provider.anthropic import AnthropicProvider
        ap = AnthropicProvider(api_key="sk-ant-test")
        self.assertEqual(ap.base_url, "https://api.anthropic.com")

    def test_router_registration(self):
        """路由器 Provider 注册。"""
        from models.provider import MultiProviderRouter, create_default_router
        from models.provider.ollama import OllamaProvider

        router = MultiProviderRouter()
        router.register("ollama", OllamaProvider(host="http://localhost:11434"))
        self.assertTrue(router.is_registered("ollama"))

    def test_router_health_check(self):
        """路由器健康检查（含离线 Provider）。"""
        from models.provider import MultiProviderRouter, create_default_router
        router = create_default_router("http://localhost:11434")
        status = router.check_all_health()
        self.assertIn("ollama", status)


class TestPlanner(unittest.TestCase):
    """P1-1: Planner 集成测试。"""

    def test_decompose_simple(self):
        """简单目标拆解。"""
        from core.planner import TaskDecomposer

        decomposer = TaskDecomposer()
        plan = decomposer.decompose("整理桌面文件与搜索发票")

        self.assertIsNotNone(plan)
        self.assertGreater(len(plan.subtasks), 0)
        self.assertTrue(plan.goal.startswith("整理桌面文件与搜索发票"))

    def test_plan_execution(self):
        """计划执行。"""
        from core.planner import Planner, TaskDecomposer

        planner = Planner()
        plan = planner.plan("分析文件并生成报告")

        self.assertEqual(len(plan.subtasks), 2)  # 分析 + 报告

    def test_reflection_loop(self):
        """反思循环。"""
        from core.planner import ReflectionLoop, SubTask, TaskStatus

        task = SubTask(
            id="t01",
            name="测试任务",
            status=TaskStatus.FAILED,
            error="timeout: 操作超时",
        )

        loop = ReflectionLoop()
        result = loop.reflect(task, output=None)

        self.assertEqual(result.type.name, "FAILURE")
        self.assertGreater(len(result.issues), 0)
        self.assertTrue(result.should_retry)


class TestEvaluator(unittest.TestCase):
    """P1-2: Evaluator 集成测试。"""

    def test_evaluate_perfect(self):
        """完美匹配评估。"""
        from core.evaluation import Evaluator

        ev = Evaluator()
        result = ev.evaluate(
            task_id="t001",
            task_description="搜索发票",
            output="找到 3 张发票",
            expected="找到 3 张发票",
        )

        self.assertGreaterEqual(result.accuracy, 0.7)
        self.assertGreaterEqual(result.overall_score, 0.5)

    def test_reward_computation(self):
        """奖励计算。"""
        from core.evaluation import Evaluator, RewardAggregator

        ev = Evaluator()
        result = ev.evaluate("t001", "测试", "output")
        reward = ev.compute_reward(result)

        self.assertGreaterEqual(reward.value, 0.0)
        self.assertLessEqual(reward.value, 1.0)

        # 聚合
        agg = RewardAggregator(decay_factor=0.9)
        v1 = agg.add(reward)
        v2 = agg.add(reward)
        self.assertGreater(v2, v1 * 0.8)


def run_all():
    """运行所有测试。"""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    suite.addTests(loader.loadTestsFromTestCase(TestSQLiteMemory))
    suite.addTests(loader.loadTestsFromTestCase(TestPermissionLayer))
    suite.addTests(loader.loadTestsFromTestCase(TestProviderRouter))
    suite.addTests(loader.loadTestsFromTestCase(TestPlanner))
    suite.addTests(loader.loadTestsFromTestCase(TestEvaluator))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print(f"\n{'='*60}")
    print(f"测试汇总: 运行 {result.testsRun}, "
          f"成功 {result.testsRun - len(result.failures) - len(result.errors)}, "
          f"失败 {len(result.failures)}, "
          f"错误 {len(result.errors)}")
    print(f"{'='*60}")

    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(run_all())
