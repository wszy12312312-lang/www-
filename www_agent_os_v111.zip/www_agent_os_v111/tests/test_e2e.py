"""E2E 端到端测试脚本 — 完整工作流验证。

Usage:
    py -m tests.test_e2e
"""

from __future__ import annotations

import json
import os
import sys
import time
import traceback
from pathlib import Path

# 添加项目根目录
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))


class E2ETestRunner:
    """端到端测试运行器。"""

    def __init__(self) -> None:
        self.passed: int = 0
        self.failed: int = 0
        self.skipped: int = 0
        self.results: list = []

    def _assert(self, condition: bool, msg: str) -> None:
        if not condition:
            raise AssertionError(msg)

    def run(self) -> None:
        print("=" * 60)
        print("  Agent OS v2.0 端到端测试")
        print("=" * 60)
        print()

        self._test("Memory 三层架构导入", self.test_memory_imports)
        self._test("Security 权限系统导入", self.test_security_imports)
        self._test("Provider 导入与路由", self.test_provider_imports)
        self._test("Planner 任务拆解", self.test_planner_workflow)
        self._test("Evaluator 评估循环", self.test_evaluator_workflow)
        self._test("UI Adapter 格式化", self.test_ui_adapter)
        self._test("Docker 配置文件存在", self.test_docker_files)
        self._test("Gateway v2.0 改造完整性", self.test_gateway_v2)

        print()
        print("=" * 60)
        print(f"  测试完成: {self.passed} 通过, {self.failed} 失败, {self.skipped} 跳过")
        print("=" * 60)

    def _test(self, name: str, fn) -> None:
        try:
            fn()
            self.passed += 1
            print(f"  [PASS] {name}")
        except Exception as e:
            self.failed += 1
            print(f"  [FAIL] {name}: {e}")

    def test_memory_imports(self) -> None:
        from core.memory import MemoryManager
        from core.memory.short_memory import ShortMemory
        from core.memory.long_memory import LongMemory
        from core.memory.semantic_memory import SemanticMemory
        from database.sqlite.connection import init_db, get_db

        init_db()
        db = get_db()
        self._assert(db is not None, "数据库连接失败")

    def test_security_imports(self) -> None:
        from security.permission import PermissionLayer
        from security.sandbox import CodeSandbox

        self._assert(PermissionLayer is not None, "PermissionLayer 导入失败")

    def test_provider_imports(self) -> None:
        from models.provider.ollama import OllamaProvider
        from models.provider.openai import OpenAIProvider
        from models.provider.anthropic import AnthropicProvider
        from models.provider import MultiProviderRouter, create_default_router

        router = create_default_router()
        health = router.check_health()
        self._assert("ollama" in health, "Ollama 未在默认路由中注册")

        # 验证 gateway v2 可导入
        from models.gateway import ModelGateway
        gw = ModelGateway()
        self._assert(gw.router is not None, "Gateway.router 未初始化")

    def test_planner_workflow(self) -> None:
        from core.planner import Planner, TaskDecomposer, ReflectionLoop
        from core.planner.planner import SubTask, TaskStatus

        planner = Planner()
        plan = planner.plan("整理文件并生成分析报告")
        self._assert(len(plan.subtasks) > 0, "Planner 未生成子任务")

        # 验证反思
        loop = ReflectionLoop()
        task = SubTask(id="t1", name="test", status=TaskStatus.FAILED, error="timeout")
        reflection = loop.reflect(task, None)
        self._assert(reflection.should_retry, "Reflection 应建议重试")

    def test_evaluator_workflow(self) -> None:
        from core.evaluation import Evaluator, RewardAggregator

        ev = Evaluator()
        result = ev.evaluate("t001", "搜索文件", "找到 5 个文件", expected="找到 5 个文件")
        self._assert(result.overall_score > 0.5, "评估分数异常低")

        reward = ev.compute_reward(result)
        agg = RewardAggregator()
        cumulative = agg.add(reward)
        self._assert(cumulative > 0, "奖励累积值为零")

    def test_ui_adapter(self) -> None:
        from api.ui_adapter import UIResponseFormatter, ProgressTracker, UIEventType

        resp = UIResponseFormatter.success({"message": "ok"}, {"task_id": "t1"})
        self._assert(resp["status"] == "success", "UI success 响应格式错误")

        tracker = ProgressTracker("task_1", total_steps=5)
        tracker.start("初始化")
        tracker.advance("处理中", 2)
        tracker.advance("处理中", 2)
        tracker.complete("完成")
        self._assert(len(tracker.get_events()) == 4, "ProgressTracker 事件数异常")

    def test_docker_files(self) -> None:
        root = _PROJECT_ROOT
        self._assert(os.path.exists(root / "Dockerfile"), "Dockerfile 缺失")
        self._assert(os.path.exists(root / "docker-compose.yml"), "docker-compose.yml 缺失")

    def test_gateway_v2(self) -> None:
        import ast

        gateway_path = _PROJECT_ROOT / "models" / "gateway.py"
        with open(gateway_path, "r", encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source)

        # 确认 _router 属性存在
        class_defs = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == "ModelGateway"]
        self._assert(len(class_defs) > 0, "ModelGateway 类未找到")

        method_names = {n.name for n in ast.walk(class_defs[0]) if isinstance(n, ast.FunctionDef)}
        self._assert("register_openai" in method_names, "register_openai 方法缺失")
        self._assert("register_anthropic" in method_names, "register_anthropic 方法缺失")
        self._assert("chat" in method_names, "chat 方法缺失")


def main() -> int:
    runner = E2ETestRunner()
    runner.run()
    return 0 if runner.failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
