"""
tools/code — 代码执行工具集 v1.0

安全 Python 代码执行（sandbox 约束）。

向 ToolRouter 注册以下工具：
- code_exec: 在沙箱中安全执行 Python 代码
- code_eval: 在沙箱中安全执行 Python 表达式
"""

import logging
from typing import Any, Dict, Optional

from tools.router import Tool, ToolParameter, ToolRouter

logger = logging.getLogger("tools.code")


def register_all(router: ToolRouter) -> int:
    """向 ToolRouter 注册所有 code 工具。"""
    count = 0
    for tool in [make_code_exec(), make_code_eval()]:
        if router.register(tool):
            count += 1
    logger.info("tools/code: 注册了 %d 个工具", count)
    return count


# ------------------------------------------------------------------
# 1. code_exec — 沙箱执行
# ------------------------------------------------------------------

def make_code_exec() -> Tool:
    return Tool(
        name="code_exec",
        description="在受限沙箱中安全执行 Python 代码。可用的模块: json, re, math, datetime, random, collections, statistics, decimal, csv(读取), string。禁止: os, subprocess, sys, open, importlib, requests, socket。",
        category="code",
        version="1.0.0",
        parameters=[
            ToolParameter(name="code", type="str", description="Python 代码", required=True),
            ToolParameter(name="timeout", type="int", description="最大执行秒数", required=False, default=5),
        ],
        handler=_code_exec_handler,
    )


def _code_exec_handler(code: str, timeout: int = 5) -> Dict[str, Any]:
    # 安全检查: 拒绝危险操作
    dangerous = ["os.", "subprocess", "__import__", "eval(", "exec(", "compile(",
                 "open(", "sys.", "importlib", "requests", "socket", "shutil",
                 "ctypes", "globals()", "locals()", "getattr(", "setattr("]
    for keyword in dangerous:
        if keyword in code:
            return {"error": f"代码包含危险操作: {keyword}", "result": None}

    # 允许的安全模块
    safe_globals = {
        "__builtins__": {
            "print": print, "len": len, "range": range, "int": int, "float": float,
            "str": str, "bool": bool, "list": list, "dict": dict, "set": set, "tuple": tuple,
            "sum": sum, "min": min, "max": max, "abs": abs, "round": round,
            "sorted": sorted, "enumerate": enumerate, "zip": zip, "map": map, "filter": filter,
            "any": any, "all": all, "isinstance": isinstance, "type": type,
            "True": True, "False": False, "None": None, "Exception": Exception,
        }
    }

    try:
        import json, re, math, datetime, random, collections, statistics, decimal, string, csv, io
        safe_globals.update({
            "json": json, "re": re, "math": math, "datetime": datetime,
            "random": random, "collections": collections, "statistics": statistics,
            "decimal": decimal, "string": string, "csv": csv, "io": io,
        })
    except ImportError:
        pass

    output = io.StringIO()
    safe_globals["__builtins__"]["print"] = lambda *a, **kw: output.write(" ".join(str(x) for x in a) + "\n")

    import threading
    result_container = {"result": None, "error": None, "timed_out": False}

    def _run():
        try:
            exec(code, safe_globals, {})
            result_container["result"] = "OK"
        except Exception as e:
            result_container["error"] = f"{type(e).__name__}: {e}"

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    thread.join(timeout=timeout)

    if thread.is_alive():
        result_container["timed_out"] = True

    return {
        "result": result_container["result"],
        "error": result_container["error"],
        "timed_out": result_container["timed_out"],
        "output": output.getvalue()[:5000] if output.getvalue() else "",
    }


# ------------------------------------------------------------------
# 2. code_eval — 表达式求值
# ------------------------------------------------------------------

def make_code_eval() -> Tool:
    return Tool(
        name="code_eval",
        description="安全执行 Python 数学表达式，返回结果。可用: math 函数, 基本算术。",
        category="code",
        version="1.0.0",
        parameters=[
            ToolParameter(name="expression", type="str", description="Python 表达式", required=True),
        ],
        handler=_code_eval_handler,
    )


def _code_eval_handler(expression: str) -> Dict[str, Any]:
    dangerous = ["os.", "__", "eval", "exec", "open", "import", "subprocess", "sys."]
    for kw in dangerous:
        if kw in expression:
            return {"error": f"表达式包含危险操作: {kw}", "result": None}
    try:
        import math
        safe = {"math": math, "pi": math.pi, "e": math.e,
                "sin": math.sin, "cos": math.cos, "tan": math.tan,
                "sqrt": math.sqrt, "log": math.log, "log10": math.log10,
                "pow": math.pow, "ceil": math.ceil, "floor": math.floor,
                "abs": abs, "round": round, "int": int, "float": float}
        result = eval(expression, {"__builtins__": {}}, safe)
        return {"result": result}
    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}", "result": None}
