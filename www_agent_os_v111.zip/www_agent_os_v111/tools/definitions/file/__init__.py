"""
tools/file — 文件工具集 v1.0

文件搜索、读写、格式转换（MD/CSV/JSON/TXT）。

向 ToolRouter 注册以下工具：
- file_search: 搜索文件（按名称/内容/后缀）
- file_read: 读取文本文件
- file_write: 写入文本文件
- file_convert: 文件格式转换（MD/CSV/JSON 之间）
- file_info: 获取文件元信息
"""

import os
import json as _json
import csv
import logging
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from tools.router import Tool, ToolParameter, ToolRouter

logger = logging.getLogger("tools.file")

# 安全路径检查白名单
SAFE_ROOTS = [
    os.path.expanduser("~"),
    os.path.join(os.path.expanduser("~"), "Downloads"),
    os.path.join(os.path.expanduser("~"), "Desktop"),
    os.path.join(os.path.expanduser("~"), "Documents"),
    os.getcwd(),
]
# 核心系统目录黑名单
DANGER_PATHS = [
    r"C:\Windows", r"C:\Windows\System32",
    "/System", "/Library", "/bin", "/sbin",
]


def _is_path_safe(path: str) -> Tuple[bool, str]:
    """检查路径是否在安全范围内。"""
    resolved = os.path.abspath(os.path.expanduser(path))
    for danger in DANGER_PATHS:
        if resolved.lower().startswith(danger.lower()):
            return False, f"禁止访问系统关键目录: {danger}"
    for safe in SAFE_ROOTS:
        safe_resolved = os.path.abspath(safe)
        if resolved.lower().startswith(safe_resolved.lower()):
            return True, ""
    return False, f"路径不在安全范围内: {path}。允许范围: {SAFE_ROOTS}"


def register_all(router: ToolRouter) -> int:
    """向 ToolRouter 注册所有 file 工具。"""
    count = 0
    for tool in [make_file_search(), make_file_read(), make_file_write(), make_file_convert(), make_file_info()]:
        if router.register(tool):
            count += 1
    logger.info("tools/file: 注册了 %d 个工具", count)
    return count


# ------------------------------------------------------------------
# 1. file_search
# ------------------------------------------------------------------

def make_file_search() -> Tool:
    return Tool(
        name="file_search",
        description="搜索文件（按名称/内容/后缀），支持 glob 和正则",
        category="file",
        version="1.0.0",
        parameters=[
            ToolParameter(name="pattern", type="str", description="搜索模式（glob 或关键词）", required=True),
            ToolParameter(name="search_dir", type="str", description="搜索根目录", required=False, default="~"),
            ToolParameter(name="search_content", type="bool", description="是否搜索文件内容", required=False, default=False),
            ToolParameter(name="max_results", type="int", description="最大结果数", required=False, default=50),
        ],
        handler=_file_search_handler,
    )


def _file_search_handler(pattern: str, search_dir: str = "~", search_content: bool = False, max_results: int = 50) -> Dict[str, Any]:
    base = os.path.expanduser(search_dir)
    if not os.path.isdir(base):
        return {"error": f"目录不存在: {base}"}
    results = []
    try:
        for root, dirs, files in os.walk(base):
            # 跳过隐藏目录和 node_modules
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("node_modules", "__pycache__", ".git")]
            for f in files:
                if len(results) >= max_results:
                    break
                match = pattern.lower() in f.lower()
                if not match and search_content:
                    # 内容搜索仅对文本文件
                    try:
                        fpath = os.path.join(root, f)
                        if os.path.getsize(fpath) > 5 * 1024 * 1024:  # 跳过 >5MB
                            continue
                        with open(fpath, "r", encoding="utf-8", errors="ignore") as fh:
                            content = fh.read(50000)
                            if pattern.lower() in content.lower():
                                match = True
                    except Exception:
                        continue
                if match:
                    results.append(os.path.join(root, f))
            if len(results) >= max_results:
                break
    except PermissionError:
        pass
    return {"results": results[:max_results], "count": len(results), "pattern": pattern, "searched_in": base}


# ------------------------------------------------------------------
# 2. file_read
# ------------------------------------------------------------------

def make_file_read() -> Tool:
    return Tool(
        name="file_read",
        description="读取文本文件内容（.txt/.md/.json/.csv/.py/.yaml/.xml等）",
        category="file",
        version="1.0.0",
        parameters=[
            ToolParameter(name="path", type="str", description="文件路径", required=True),
            ToolParameter(name="encoding", type="str", description="编码", required=False, default="utf-8"),
            ToolParameter(name="max_lines", type="int", description="最大行数", required=False, default=500),
        ],
        handler=_file_read_handler,
    )


def _file_read_handler(path: str, encoding: str = "utf-8", max_lines: int = 500) -> Dict[str, Any]:
    safe, err = _is_path_safe(path)
    if not safe:
        return {"error": err}
    if not os.path.isfile(path):
        return {"error": f"文件不存在: {path}"}
    size = os.path.getsize(path)
    if size > 20 * 1024 * 1024:
        return {"error": f"文件过大: {size / 1024 / 1024:.1f}MB (限制20MB)"}
    try:
        with open(path, "r", encoding=encoding) as f:
            lines = []
            for i, line in enumerate(f):
                if i >= max_lines:
                    break
                lines.append(line.rstrip("\n"))
        is_truncated = sum(1 for _ in open(path, "r", encoding=encoding, errors="ignore")) > max_lines
        return {
            "path": path, "lines": len(lines), "truncated": is_truncated,
            "size_bytes": size, "encoding": encoding,
            "content": "\n".join(lines),
        }
    except UnicodeDecodeError:
        if encoding == "utf-8":
            return _file_read_handler(path, encoding="gbk", max_lines=max_lines)
        return {"error": f"无法解码文件，尝试了 utf-8 和 gbk"}


# ------------------------------------------------------------------
# 3. file_write
# ------------------------------------------------------------------

def make_file_write() -> Tool:
    return Tool(
        name="file_write",
        description="写入内容到文件（覆盖或追加）",
        category="file",
        version="1.0.0",
        parameters=[
            ToolParameter(name="path", type="str", description="文件路径", required=True),
            ToolParameter(name="content", type="str", description="要写入的内容", required=True),
            ToolParameter(name="mode", type="str", description="写入模式（w=覆盖, a=追加）", required=False, default="w"),
            ToolParameter(name="encoding", type="str", description="编码", required=False, default="utf-8"),
        ],
        handler=_file_write_handler,
    )


def _file_write_handler(path: str, content: str, mode: str = "w", encoding: str = "utf-8") -> Dict[str, Any]:
    safe, err = _is_path_safe(path)
    if not safe:
        return {"error": err}
    if mode not in ("w", "a"):
        return {"error": f"不支持的模式: {mode}（仅支持 w/覆盖, a/追加）"}
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    written = len(content.encode(encoding))
    with open(path, mode, encoding=encoding) as f:
        f.write(content)
    return {"path": path, "mode": mode, "bytes_written": written, "encoding": encoding}


# ------------------------------------------------------------------
# 4. file_convert
# ------------------------------------------------------------------

def make_file_convert() -> Tool:
    return Tool(
        name="file_convert",
        description="文本格式转换（支持 md↔html, csv↔json↔md-table）",
        category="file",
        version="1.0.0",
        parameters=[
            ToolParameter(name="source", type="str", description="源文件路径 或 文本内容", required=True),
            ToolParameter(name="from_format", type="str", description="源格式: md/csv/json/txt", required=True),
            ToolParameter(name="to_format", type="str", description="目标格式: md/html/json/csv/txt", required=True),
            ToolParameter(name="is_file", type="bool", description="source 是文件路径还是文本", required=False, default=True),
        ],
        handler=_file_convert_handler,
    )


def _file_convert_handler(source: str, from_format: str, to_format: str, is_file: bool = True) -> Dict[str, Any]:
    fmt = lambda s: s.lower().strip()
    fm, to = fmt(from_format), fmt(to_format)

    content = source
    if is_file:
        safe, err = _is_path_safe(source)
        if not safe:
            return {"error": err}
        if not os.path.isfile(source):
            return {"error": f"文件不存在: {source}"}
        with open(source, "r", encoding="utf-8") as f:
            content = f.read()

    converters = {
        ("md", "html"): _md_to_html,
        ("csv", "json"): _csv_to_json,
        ("json", "csv"): _json_to_csv,
        ("csv", "md"): _csv_to_md,
        ("json", "md"): _json_to_md,
        ("md", "txt"): lambda c: c,  # 直接就是纯文本
        ("txt", "md"): lambda c: c,
        ("json", "json"): lambda c: _json.dumps(_json.loads(c), indent=2, ensure_ascii=False),
    }

    key = (fm, to)
    if key not in converters:
        supported = [(f, t) for f, t in converters if f == fm]
        return {"error": f"不支持 {fm}→{to} 的转换。{fm} 可转为: {[t for _,t in supported] if supported else '未知'}",
                "from": fm, "to": to}

    try:
        result = converters[key](content)
        return {"result": result, "from_format": fm, "to_format": to}
    except Exception as e:
        return {"error": f"转换失败: {e}", "from_format": fm, "to_format": to}


def _md_to_html(text: str) -> str:
    """简单的 Markdown→HTML（不依赖外部库）。"""
    lines = text.split("\n")
    result = []
    in_code = False
    for line in lines:
        if line.startswith("```"):
            if in_code:
                result.append("</code></pre>")
            else:
                result.append("<pre><code>")
            in_code = not in_code
            continue
        if in_code:
            result.append(line)
            continue
        if line.startswith("# "):
            result.append(f"<h1>{line[2:]}</h1>")
        elif line.startswith("## "):
            result.append(f"<h2>{line[3:]}</h2>")
        elif line.startswith("### "):
            result.append(f"<h3>{line[4:]}</h3>")
        elif line.startswith("- "):
            result.append(f"<li>{line[2:]}</li>")
        elif line.startswith("|"):
            result.append(f"<p class='table-row'>{line}</p>")
        elif line.strip():
            result.append(f"<p>{line}</p>")
        else:
            result.append("")
    return "\n".join(result)


def _csv_to_json(text: str) -> str:
    reader = csv.DictReader(io.StringIO(text))
    return _json.dumps([row for row in reader], indent=2, ensure_ascii=False)

import io

def _json_to_csv(text: str) -> str:
    data = _json.loads(text)
    if not isinstance(data, list) or not data:
        return text
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=data[0].keys())
    writer.writeheader()
    writer.writerows(data)
    return output.getvalue()


def _csv_to_md(text: str) -> str:
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return ""
    header = rows[0]
    sep = ["---" for _ in header]
    md_rows = ["| " + " | ".join(header) + " |", "| " + " | ".join(sep) + " |"]
    for row in rows[1:]:
        md_rows.append("| " + " | ".join(row) + " |")
    return "\n".join(md_rows)


def _json_to_md(text: str) -> str:
    data = _json.loads(text)
    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict):
        return _csv_to_md(_json_to_csv(text))
    return text


# ------------------------------------------------------------------
# 5. file_info
# ------------------------------------------------------------------

def make_file_info() -> Tool:
    return Tool(
        name="file_info",
        description="获取文件元信息（大小/创建时间/修改时间/类型）",
        category="file",
        version="1.0.0",
        parameters=[
            ToolParameter(name="path", type="str", description="文件路径", required=True),
        ],
        handler=_file_info_handler,
    )


def _file_info_handler(path: str) -> Dict[str, Any]:
    safe, err = _is_path_safe(path)
    if not safe:
        return {"error": err}
    if not os.path.exists(path):
        return {"error": f"文件不存在: {path}"}
    stat = os.stat(path)
    import datetime
    return {
        "path": path,
        "name": os.path.basename(path),
        "size_bytes": stat.st_size,
        "size_human": _human_size(stat.st_size),
        "created": datetime.datetime.fromtimestamp(stat.st_ctime).isoformat(),
        "modified": datetime.datetime.fromtimestamp(stat.st_mtime).isoformat(),
        "is_dir": os.path.isdir(path),
        "is_file": os.path.isfile(path),
        "suffix": os.path.splitext(path)[1].lower(),
    }


def _human_size(size: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"
