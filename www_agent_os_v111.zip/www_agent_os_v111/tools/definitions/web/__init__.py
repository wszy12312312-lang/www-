"""
tools/web — 网络工具集 v1.2

HTTP 请求、URL 解析、网页内容获取、浏览器控制、微信链接。

向 ToolRouter 注册以下工具：
- http_get: HTTP GET 请求
- http_post: HTTP POST 请求
- url_parse: URL 解析与验证
- web_fetch: 网页内容获取
- browser_open: 用默认浏览器打开URL
- wechat_deeplink: 生成微信/特殊协议深度链接
"""

import re
import os
import subprocess
import platform
import json as _json
import logging
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import urlparse, urljoin, parse_qs, urlencode

from tools.router import Tool, ToolParameter, ToolRouter

logger = logging.getLogger("tools.web")


def register_all(router: ToolRouter) -> int:
    """向 ToolRouter 注册所有 web 工具。返回注册数量。"""
    count = 0
    for tool in [make_http_get(), make_http_post(), make_url_parse(), make_web_fetch(),
                 make_browser_open(), make_wechat_deeplink()]:
        if router.register(tool):
            count += 1
    logger.info("tools/web: 注册了 %d 个工具", count)
    return count


# ------------------------------------------------------------------
# 1. http_get
# ------------------------------------------------------------------

def make_http_get() -> Tool:
    return Tool(
        name="http_get",
        description="发送 HTTP GET 请求并返回响应",
        category="web",
        version="1.0.0",
        parameters=[
            ToolParameter(name="url", type="str", description="请求 URL", required=True),
            ToolParameter(name="headers", type="dict", description="请求头 JSON", required=False, default=None),
            ToolParameter(name="timeout", type="int", description="超时秒数", required=False, default=30),
        ],
        handler=_http_get_handler,
    )


def _http_get_handler(url: str, headers: Optional[Dict] = None, timeout: int = 30) -> Dict[str, Any]:
    try:
        import requests
        resp = requests.get(url, headers=headers or {}, timeout=timeout, allow_redirects=True)
        content_type = resp.headers.get("Content-Type", "")
        body = resp.text[:50000] if "text" in content_type or "json" in content_type else f"[binary: {len(resp.content)} bytes]"
        return {"status_code": resp.status_code, "headers": dict(resp.headers), "body": body, "url": resp.url}
    except ImportError:
        return {"error": "requests 库未安装", "status_code": 0}
    except Exception as e:
        return {"error": str(e), "status_code": 0}


# ------------------------------------------------------------------
# 2. http_post
# ------------------------------------------------------------------

def make_http_post() -> Tool:
    return Tool(
        name="http_post",
        description="发送 HTTP POST 请求并返回响应",
        category="web",
        version="1.0.0",
        parameters=[
            ToolParameter(name="url", type="str", description="请求 URL", required=True),
            ToolParameter(name="data", type="dict", description="POST body JSON", required=False, default=None),
            ToolParameter(name="headers", type="dict", description="请求头 JSON", required=False, default=None),
            ToolParameter(name="timeout", type="int", description="超时秒数", required=False, default=30),
        ],
        handler=_http_post_handler,
    )


def _http_post_handler(url: str, data: Optional[Dict] = None, headers: Optional[Dict] = None, timeout: int = 30) -> Dict[str, Any]:
    try:
        import requests
        resp = requests.post(url, json=data or {}, headers=headers or {}, timeout=timeout)
        content_type = resp.headers.get("Content-Type", "")
        body = resp.text[:50000] if "text" in content_type or "json" in content_type else f"[binary: {len(resp.content)} bytes]"
        return {"status_code": resp.status_code, "headers": dict(resp.headers), "body": body, "url": resp.url}
    except ImportError:
        return {"error": "requests 库未安装", "status_code": 0}
    except Exception as e:
        return {"error": str(e), "status_code": 0}


# ------------------------------------------------------------------
# 3. url_parse
# ------------------------------------------------------------------

def make_url_parse() -> Tool:
    return Tool(
        name="url_parse",
        description="解析URL，提取scheme/host/path/query/fragment，识别微信/QQ等特殊协议",
        category="web",
        version="1.0.0",
        parameters=[
            ToolParameter(name="url", type="str", description="要解析的 URL", required=True),
        ],
        handler=_url_parse_handler,
    )


def _url_parse_handler(url: str) -> Dict[str, Any]:
    SPECIAL_SCHEMES = {
        "weixin": "微信链接，需在微信客户端中打开",
        "wx": "微信小程序链接",
        "mqq": "QQ 链接",
        "mqqapi": "QQ API 链接",
        "alipays": "支付宝链接",
        "taobao": "淘宝链接",
        "tmall": "天猫链接",
        "tbopen": "淘宝开放链接",
        "weibo": "微博链接",
        "douyin": "抖音链接",
        "snssdk1128": "抖音链接",
    }
    try:
        parsed = urlparse(url)
        scheme = parsed.scheme.lower()
        special_note = SPECIAL_SCHEMES.get(scheme, None)
        result = {
            "valid": True,
            "scheme": parsed.scheme,
            "host": parsed.hostname or "",
            "port": parsed.port,
            "path": parsed.path or "",
            "query": parse_qs(parsed.query),
            "fragment": parsed.fragment or "",
            "is_http": scheme in ("http", "https"),
            "is_special_protocol": scheme in SPECIAL_SCHEMES,
            "special_note": special_note,
        }
        return result
    except Exception as e:
        return {"valid": False, "error": str(e), "url": url[:200]}


# ------------------------------------------------------------------
# 4. web_fetch
# ------------------------------------------------------------------

def make_web_fetch() -> Tool:
    return Tool(
        name="web_fetch",
        description="获取网页HTML内容并提取文本（剔除 script/style 标签）",
        category="web",
        version="1.0.0",
        parameters=[
            ToolParameter(name="url", type="str", description="目标网页 URL", required=True),
            ToolParameter(name="extract_text", type="bool", description="是否提取纯文本", required=False, default=True),
            ToolParameter(name="max_length", type="int", description="最大返回长度", required=False, default=10000),
            ToolParameter(name="timeout", type="int", description="超时秒数", required=False, default=30),
        ],
        handler=_web_fetch_handler,
    )


def _web_fetch_handler(url: str, extract_text: bool = True, max_length: int = 10000, timeout: int = 30) -> Dict[str, Any]:
    try:
        import requests
        resp = requests.get(
            url,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
            timeout=timeout,
            allow_redirects=True,
        )
        if resp.status_code != 200:
            return {"error": f"HTTP {resp.status_code}", "status_code": resp.status_code, "url": resp.url}

        html = resp.text[:200000]
        title = ""
        text = html

        if extract_text:
            title_match = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
            if title_match:
                title = re.sub(r"<[^>]+>", "", title_match.group(1)).strip()

            # 去 script/style
            cleaned = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
            cleaned = re.sub(r"<style[^>]*>.*?</style>", "", cleaned, flags=re.DOTALL | re.IGNORECASE)
            # 基本 HTML→文本
            cleaned = re.sub(r"<br\s*/?>", "\n", cleaned)
            cleaned = re.sub(r"</p>", "\n", cleaned)
            cleaned = re.sub(r"</div>", "\n", cleaned)
            cleaned = re.sub(r"</li>", "\n", cleaned)
            cleaned = re.sub(r"<[^>]+>", "", cleaned)
            cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
            cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
            text = cleaned.strip()[:max_length]

        return {
            "status_code": resp.status_code,
            "url": resp.url,
            "title": title,
            "text": text,
            "encoding": resp.encoding or "unknown",
        }
    except ImportError:
        return {"error": "requests 库未安装"}
    except Exception as e:
        return {"error": str(e)}


# ------------------------------------------------------------------
# 5. browser_open — 用默认浏览器打开URL (v1.2 新增)
# ------------------------------------------------------------------

def make_browser_open() -> Tool:
    return Tool(
        name="browser_open",
        description="用系统默认浏览器打开指定URL。支持 http/https 链接和 file:// 本地文件。返回是否成功。",
        category="web",
        version="1.2.0",
        parameters=[
            ToolParameter(name="url", type="str", description="要打开的URL（http/https/file://）", required=True),
            ToolParameter(name="browser", type="str", description="指定浏览器路径（可选，不填=默认浏览器）", required=False, default=""),
        ],
        handler=_browser_open_handler,
    )


def _browser_open_handler(url: str, browser: str = "") -> Dict[str, Any]:
    """用系统默认浏览器打开URL。

    平台策略：
    - Windows: start 命令或 webbrowser 模块
    - macOS: open 命令
    - Linux: xdg-open 命令
    """
    # 安全检查：只允许 http/https/file 协议
    if not url:
        return {"success": False, "error": "URL 为空"}

    parsed = urlparse(url)
    allowed_schemes = {"http", "https", "file", ""}
    if parsed.scheme and parsed.scheme not in allowed_schemes:
        return {
            "success": False,
            "error": f"不支持的协议: {parsed.scheme}。仅支持 http/https/file。"
            f"对于微信/QQ等特殊协议，请使用 wechat_deeplink 工具。",
            "suggested_tool": "wechat_deeplink",
        }

    try:
        system = platform.system()
        if browser:
            # 指定浏览器
            subprocess.Popen([browser, url], shell=False)
        elif system == "Windows":
            # Windows: 使用 os.startfile 或 start 命令
            try:
                os.startfile(url)
            except Exception:
                subprocess.Popen(["cmd", "/c", "start", "", url], shell=True)
        elif system == "Darwin":
            subprocess.Popen(["open", url])
        else:
            subprocess.Popen(["xdg-open", url])

        return {
            "success": True,
            "url": url,
            "browser": browser or "系统默认浏览器",
            "platform": system,
            "message": f"已在{browser or '默认浏览器'}中打开 {url}",
        }
    except FileNotFoundError:
        return {"success": False, "error": f"找不到浏览器: {browser}"}
    except Exception as e:
        return {"success": False, "error": f"打开浏览器失败: {e}"}


# ------------------------------------------------------------------
# 6. wechat_deeplink — 微信/特殊协议深度链接 (v1.2 新增)
# ------------------------------------------------------------------

# 支持的特殊协议及其说明
SUPPORTED_DEEPLINKS = {
    "weixin": {
        "description": "微信链接",
        "prefix": "weixin://dl/business/?t=",
        "requires_app": "微信",
        "note": "需要安装微信客户端。链接将尝试唤起微信打开。",
    },
    "wx": {
        "description": "微信小程序",
        "prefix": "",
        "requires_app": "微信",
        "note": "微信小程序链接，需在微信中打开。可以尝试用微信扫一扫或在微信中粘贴。",
    },
    "mqq": {
        "description": "QQ 链接",
        "prefix": "",
        "requires_app": "QQ",
    },
    "alipays": {
        "description": "支付宝链接",
        "prefix": "",
        "requires_app": "支付宝",
    },
}


def make_wechat_deeplink() -> Tool:
    return Tool(
        name="wechat_deeplink",
        description="处理微信/QQ/支付宝等特殊协议链接。生成可在对应App中打开的深度链接或提供打开指导。",
        category="web",
        version="1.2.0",
        parameters=[
            ToolParameter(name="url", type="str", description="特殊协议URL（weixin://、wx://、mqq://等）", required=True),
            ToolParameter(name="action", type="str", description="操作: open(尝试打开)/generate(生成链接)/guide(仅给指导)", required=False, default="guide"),
        ],
        handler=_wechat_deeplink_handler,
    )


def _wechat_deeplink_handler(url: str, action: str = "guide") -> Dict[str, Any]:
    """处理微信等特殊协议链接。

    策略：
    1. 解析 URL 识别协议类型
    2. 尝试用 os.startfile 或 start 命令触发系统 URI handler
    3. 提供手动操作指导
    """
    parsed = urlparse(url)
    scheme = parsed.scheme.lower()

    if not scheme:
        return {"success": False, "error": "无法识别URL协议", "url": url[:200]}

    protocol_info = SUPPORTED_DEEPLINKS.get(scheme, {
        "description": f"{scheme} 协议",
        "prefix": "",
        "requires_app": "未知应用",
        "note": "此协议未在已知列表中，可能无法自动打开。",
    })

    result = {
        "scheme": scheme,
        "protocol_name": protocol_info["description"],
        "requires_app": protocol_info["requires_app"],
        "full_url": url,
        "host": parsed.hostname or "",
        "path": parsed.path or "",
        "query": parse_qs(parsed.query) if parsed.query else {},
    }

    if action == "open":
        # 尝试用系统 URI handler 打开
        try:
            system = platform.system()
            if system == "Windows":
                try:
                    os.startfile(url)
                    result["opened"] = True
                    result["message"] = f"已尝试用系统默认程序打开 {scheme}:// 链接"
                except Exception:
                    # startfile 对自定义协议通常失败，用 start 命令
                    try:
                        subprocess.Popen(["cmd", "/c", "start", "", url], shell=True)
                        result["opened"] = True
                        result["message"] = f"已尝试用 start 命令打开 {scheme}:// 链接"
                    except Exception as e2:
                        result["opened"] = False
                        result["error"] = f"无法自动打开: {e2}"
            else:
                result["opened"] = False
                result["error"] = f"{system} 平台不支持自动唤起 App"
        except Exception as e:
            result["opened"] = False
            result["error"] = str(e)

    # 始终附加手动操作指导
    result["manual_guide"] = _generate_manual_guide(scheme, url, protocol_info)
    result["success"] = True

    return result


def _generate_manual_guide(scheme: str, url: str, info: dict) -> str:
    """生成手动打开指导。"""
    app = info.get("requires_app", "对应应用")
    note = info.get("note", "")

    guides = []
    if scheme == "weixin":
        guides = [
            f"1. 确保已安装并登录{app}",
            "2. 在微信中点击链接或扫描二维码",
            "3. 或将链接复制到微信的「文件传输助手」中点击打开",
        ]
    elif scheme == "wx":
        guides = [
            f"1. 确保已安装并登录{app}",
            "2. 在微信中打开「发现」→「小程序」",
            "3. 搜索对应小程序名称",
            "4. 或请发链接的人提供小程序码",
        ]
    else:
        guides = [
            f"1. 确保已安装并登录{app}",
            f"2. 将此链接粘贴到{app}的搜索框或聊天框",
            f"3. 点击链接即可在{app}内打开",
        ]

    if note:
        guides.insert(0, f"注意：{note}")

    return "\n".join(guides)
