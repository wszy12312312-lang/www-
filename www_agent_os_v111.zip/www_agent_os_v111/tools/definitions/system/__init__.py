"""
tools/system — 系统工具集 v1.0

子进程安全封装、环境变量管理、系统信息查询、进程管理。

向 ToolRouter 注册以下工具：
- sys_run: 安全执行 shell 命令（受 sandbox 约束）
- sys_env_get: 获取环境变量
- sys_env_set: 设置环境变量
- sys_info: 获取系统基础信息
- sys_which: 查找可执行文件路径
"""

import os
import subprocess
import logging
import platform
from typing import Any, Dict, List, Optional, Tuple

from tools.router import Tool, ToolParameter, ToolRouter

logger = logging.getLogger("tools.system")

# 白名单命令（只允许这些命令执行）
ALLOWED_COMMANDS = {
    "winget", "choco", "scoop", "pip", "npm", "pnpm", "yarn", "cargo", "gem", "go",
    "python", "python3", "py", "node", "npm.cmd", "npx",
    "where", "which", "dir", "ls", "type", "cat",
    "echo", "date", "time", "ver", "whoami", "hostname",
    "systeminfo", "tasklist", "wmic", "sc", "net", "netstat",
    "ipconfig", "ping", "tracert", "nslookup", "curl", "wget",
    "reg", "powershell", "pwsh",
    "choco.exe", "scoop.ps1", "winget.exe",
    "ollama", "docker", "git", "wsl",
    # v1.2 新增：浏览器控制 / 桌面应用 / 网络工具
    "start", "explorer", "cmd", "rundll32",
    "webbrowser", "msedge", "chrome", "firefox", "brave",
    "notepad", "mspaint", "calc",
    "ssh", "telnet", "nmap",
}

# 黑名单命令模式
BLOCKED_COMMANDS = {
    "del", "erase", "rm", "rmdir", "rd", "format", "diskpart",
    "shutdown", "restart", "logoff", "taskkill",
    "move", "copy", "xcopy", "robocopy",
    "netsh", "route", "arp", "nbtstat",
    "regedit", "gpedit", "msconfig", "bcdedit",
}


def register_all(router: ToolRouter) -> int:
    """向 ToolRouter 注册所有 system 工具。"""
    count = 0
    for tool in [make_sys_run(), make_sys_env_get(), make_sys_env_set(), make_sys_info(), make_sys_which()]:
        if router.register(tool):
            count += 1
    logger.info("tools/system: 注册了 %d 个工具", count)
    return count


# ------------------------------------------------------------------
# 1. sys_run — 安全命令执行
# ------------------------------------------------------------------

def make_sys_run() -> Tool:
    return Tool(
        name="sys_run",
        description="安全执行系统命令（白名单控制）。返回 stdout/stderr 和退出码。",
        category="system",
        version="1.0.0",
        parameters=[
            ToolParameter(name="command", type="str", description="要执行的命令", required=True),
            ToolParameter(name="args", type="list", description="命令参数列表", required=False, default=None),
            ToolParameter(name="cwd", type="str", description="工作目录", required=False, default=None),
            ToolParameter(name="timeout", type="int", description="超时秒数", required=False, default=30),
        ],
        handler=_sys_run_handler,
    )


def _sys_run_handler(command: str, args: Optional[List[str]] = None, cwd: str = None, timeout: int = 30) -> Dict[str, Any]:
    # 安全检查
    cmd_lower = command.lower().rstrip(".exe").rstrip(".cmd").rstrip(".ps1")
    cmd_base = os.path.basename(command).lower()
    allowed_lower = {c.lower().rstrip(".exe").rstrip(".cmd") for c in ALLOWED_COMMANDS}
    blocked_lower = {c.lower() for c in BLOCKED_COMMANDS}

    if cmd_base in blocked_lower or cmd_lower in blocked_lower:
        return {"error": f"禁止执行的命令: {command}", "exit_code": -1}

    if cmd_base not in allowed_lower and cmd_lower not in allowed_lower:
        return {"error": f"命令不在白名单中: {command}。允许的命令包括: {sorted(allowed_lower)[:20]}", "exit_code": -1}

    try:
        full_args = [command] + (args or [])
        result = subprocess.run(
            full_args,
            cwd=cwd or os.getcwd(),
            capture_output=True,
            text=True,
            timeout=timeout,
            shell=False,
        )
        return {
            "exit_code": result.returncode,
            "stdout": result.stdout[:5000] if result.stdout else "",
            "stderr": result.stderr[:5000] if result.stderr else "",
        }
    except subprocess.TimeoutExpired:
        return {"error": f"命令超时 ({timeout}s)", "exit_code": -1}
    except FileNotFoundError:
        return {"error": f"找不到命令: {command}", "exit_code": -1}
    except Exception as e:
        return {"error": str(e), "exit_code": -1}


# ------------------------------------------------------------------
# 2. sys_env_get — 环境变量获取
# ------------------------------------------------------------------

def make_sys_env_get() -> Tool:
    return Tool(
        name="sys_env_get",
        description="获取环境变量值",
        category="system",
        version="1.0.0",
        parameters=[
            ToolParameter(name="name", type="str", description="环境变量名，不填则返回所有", required=False, default=""),
        ],
        handler=_sys_env_get_handler,
    )


def _sys_env_get_handler(name: str = "") -> Dict[str, Any]:
    if name:
        return {name: os.environ.get(name, f"[未设置] VAR={name}")}
    # 返回常用环境变量（过滤敏感信息）
    safe_keys = {"PATH", "HOME", "USERPROFILE", "USERNAME", "COMPUTERNAME",
                 "TEMP", "TMP", "APPDATA", "LOCALAPPDATA", "ProgramFiles",
                 "SystemRoot", "windir", "PROCESSOR_ARCHITECTURE",
                 "PYTHONPATH", "JAVA_HOME", "NODE_PATH",
                 "OLLAMA_HOST", "CONDA_PREFIX"}
    result = {}
    for key, val in os.environ.items():
        if key.upper() in {k.upper() for k in safe_keys}:
            result[key] = val
    return result


# ------------------------------------------------------------------
# 3. sys_env_set — 环境变量设置（仅当前进程）
# ------------------------------------------------------------------

def make_sys_env_set() -> Tool:
    return Tool(
        name="sys_env_set",
        description="设置当前进程的环境变量（不持久化，重启后失效）",
        category="system",
        version="1.0.0",
        parameters=[
            ToolParameter(name="name", type="str", description="变量名", required=True),
            ToolParameter(name="value", type="str", description="变量值", required=True),
        ],
        handler=_sys_env_set_handler,
    )


def _sys_env_set_handler(name: str, value: str) -> Dict[str, Any]:
    old = os.environ.get(name, "[未设置]")
    os.environ[name] = value
    return {"name": name, "old_value": old, "new_value": value, "persistent": False}


# ------------------------------------------------------------------
# 4. sys_info — 系统信息
# ------------------------------------------------------------------

def make_sys_info() -> Tool:
    return Tool(
        name="sys_info",
        description="获取系统基础信息（OS/CPU/内存/磁盘/Python版本）",
        category="system",
        version="1.0.0",
        handler=_sys_info_handler,
        parameters=[
            ToolParameter(name="include_network", type="bool", description="是否包含网络信息", required=False, default=False),
        ],
    )


def _sys_info_handler(include_network: bool = False) -> Dict[str, Any]:
    info = {
        "os": platform.system(),
        "os_version": platform.version(),
        "os_release": platform.release(),
        "architecture": platform.machine(),
        "python_version": platform.python_version(),
        "hostname": platform.node(),
    }

    try:
        import psutil
        info["cpu_cores_logical"] = psutil.cpu_count(logical=True)
        info["cpu_cores_physical"] = psutil.cpu_count(logical=False)
        mem = psutil.virtual_memory()
        info["memory_total_gb"] = round(mem.total / (1024**3), 1)
        info["memory_available_gb"] = round(mem.available / (1024**3), 1)
        info["memory_percent"] = mem.percent
        disk = psutil.disk_usage(os.getcwd())
        info["disk_total_gb"] = round(disk.total / (1024**3), 1)
        info["disk_free_gb"] = round(disk.free / (1024**3), 1)
    except ImportError:
        info["psutil"] = "未安装（部分系统信息不可用）"

    if include_network:
        try:
            import socket
            info["hostname_full"] = socket.gethostname()
            info["ip_address"] = socket.gethostbyname(socket.gethostname())
        except Exception:
            info["network"] = "获取失败"

    return info


# ------------------------------------------------------------------
# 5. sys_which — 查找可执行文件
# ------------------------------------------------------------------

def make_sys_which() -> Tool:
    return Tool(
        name="sys_which",
        description="查找可执行文件在 PATH 中的位置",
        category="system",
        version="1.0.0",
        parameters=[
            ToolParameter(name="command", type="str", description="可执行文件名", required=True),
        ],
        handler=_sys_which_handler,
    )


def _sys_which_handler(command: str) -> Dict[str, Any]:
    import shutil
    path = shutil.which(command)
    if path:
        return {"found": True, "path": path}
    # 额外搜索常见路径
    common_dirs = [
        os.path.join(os.environ.get("ProgramFiles", ""), command),
        os.path.join(os.environ.get("ProgramFiles(x86)", ""), command),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", command),
    ]
    for d in common_dirs:
        if os.path.exists(d):
            return {"found": True, "path": d}
    return {"found": False, "name": command}
