"""
RateLimiter — 令牌桶限流器（M06 修复）

为 LLM 调用提供 QPS 控制，替代仅有的 Semaphore 并发限制。

用法:
    from tools.rate_limiter import RateLimiter

    limiter = RateLimiter(rpm=10)
    with limiter:
        response = chat(...)

特性:
    - 令牌桶算法（burst 友好）
    - 线程安全（RLock）
    - 支持多桶（按 persona / tool 维度）
    - 超时等待 + 拒绝策略

版本: 1.0.0
"""

from __future__ import annotations

import threading
import time
from typing import Optional


class RateLimiter:
    """令牌桶限流器。

    特性:
    - 令牌桶：支持短时 burst（初始满桶）
    - 线程安全
    - 等待超时后抛出 RateLimitExceeded
    """

    def __init__(self, rpm: float = 10, burst: int = 0):
        """
        Args:
            rpm: 每分钟请求数。
            burst: 突发容量（额外 token 数）。0=自动取 rpm/2。
        """
        self._rpm = max(rpm, 1.0)
        self._rate = self._rpm / 60.0  # tokens/sec
        self._burst = burst if burst > 0 else max(1, int(self._rpm / 2))
        self._tokens = float(self._burst)
        self._last_refill = time.monotonic()
        self._lock = threading.RLock()

    def _refill(self) -> None:
        """补满令牌。"""
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(float(self._burst), self._tokens + elapsed * self._rate)
        self._last_refill = now

    def acquire(self, timeout: float = 30.0) -> bool:
        """获取一个令牌。

        Args:
            timeout: 等待超时秒数。

        Returns:
            True 成功获取令牌，False 超时。

        Raises:
            RateLimitExceeded: 等待超时。
        """
        deadline = time.monotonic() + timeout
        while True:
            with self._lock:
                self._refill()
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return True

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(0.1, remaining))

        return False

    def try_acquire(self) -> bool:
        """尝试获取令牌，不等待。

        Returns:
            True 成功，False 失败。
        """
        with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                return True
        return False

    # ------------------------------------------------------------------
    # 上下文管理器
    # ------------------------------------------------------------------

    def __enter__(self):
        if not self.acquire():
            raise RateLimitExceeded(f"限流超时 ({self._rpm} RPM)")
        return self

    def __exit__(self, *args):
        pass

    @property
    def available(self) -> float:
        """当前可用令牌数。"""
        with self._lock:
            self._refill()
            return self._tokens

    @property
    def rpm(self) -> float:
        return self._rpm


class RateLimitExceeded(Exception):
    """限流超出异常。"""
    pass


class MultiRateLimiter:
    """多桶限流器（M06 修复：按 persona 维度限流）。

    每个 key（persona_id / tool_name）独立令牌桶，
    key 不存在时自动创建。
    """

    def __init__(self, default_rpm: int = 10, per_key_rpm: Optional[dict[str, int]] = None):
        """
        Args:
            default_rpm: 默认 RPM（未指定的 key 使用）。
            per_key_rpm: 按 key 的 RPM 覆盖。
        """
        self._default_rpm = default_rpm
        self._per_key_rpm = per_key_rpm or {}
        self._buckets: dict[str, RateLimiter] = {}
        self._lock = threading.RLock()

    def acquire(self, key: str, timeout: float = 30.0) -> bool:
        """获取指定 key 的令牌。

        Args:
            key: 限流维度（如 persona_id）。
            timeout: 等待超时。

        Returns:
            True 成功。
        """
        bucket = self._get_bucket(key)
        return bucket.acquire(timeout)

    def try_acquire(self, key: str) -> bool:
        """尝试获取，不等待。"""
        return self._get_bucket(key).try_acquire()

    def _get_bucket(self, key: str) -> RateLimiter:
        with self._lock:
            if key not in self._buckets:
                rpm = self._per_key_rpm.get(key, self._default_rpm)
                self._buckets[key] = RateLimiter(rpm=rpm)
            return self._buckets[key]

    def __getitem__(self, key: str) -> RateLimiter:
        return self._get_bucket(key)

    def stats(self) -> dict:
        """各桶状态。"""
        with self._lock:
            return {k: {"rpm": b.rpm, "available": round(b.available, 1)}
                    for k, b in self._buckets.items()}
