"""
WWW Agent OS v10.7.0 — 应用配置

包含：
- Ollama 连接配置
- 人格-模型映射
- 人格元信息
- 路径常量
"""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_API_KEY = os.environ.get("OLLAMA_API_KEY", "")
OLLAMA_TIMEOUT = int(os.environ.get("OLLAMA_TIMEOUT", "120"))  # Ollama API 请求超时（秒）

# 人格-模型映射（每人格独立模型）
PERSONA_MODELS = {
    "host": "qwen3:14b",          # 9.0GB - 指挥调度，高智能
    "S": "gemma3:12b",            # 8.1GB - 元认知监控与监督评分
    "S1": "qwen2.5-coder:7b",     # 4.7GB - 软件操作，代码能力
    "S2": "qwen2.5-coder:1.5b",   # 1.0GB - 系统配置，轻量运维
    "S3": "llama3.2:3b",          # 2.0GB - 网络抓取，轻量浏览
    "S4": "qwen2.5:3b",           # 1.9GB - 文件处理，轻量整理
    "S5": "deepseek-r1:7b",       # 4.7GB - 深度检索，推理优先
    "S6": "qwen2.5:7b",           # 4.7GB - 日常聊天，对话流畅
}

# 人格元信息
PERSONAS = {
    "host": {"name": "指挥者", "icon": "H", "color": "#FF6B35", "role": "团队队长，全盘统筹调度"},
    "S":  {"name": "监察员", "icon": "S", "color": "#FF7675", "role": "元认知监控/质量把控"},
    "S1": {"name": "软件专员", "icon": "S1", "color": "#14B8A6", "role": "应用安装/卸载/管理"},
    "S2": {"name": "系统专员", "icon": "S2", "color": "#06B6D4", "role": "系统配置/运维/编程"},
    "S3": {"name": "网络专员", "icon": "S3", "color": "#10B981", "role": "网页获取/浏览器控制/微信链接/API调用"},
    "S4": {"name": "文件专员", "icon": "S4", "color": "#F59E0B", "role": "文件整理/格式转换"},
    "S5": {"name": "检索专员", "icon": "S5", "color": "#A855F7", "role": "网络搜索/信息聚合"},
    "S6": {"name": "聊天专员", "icon": "S6", "color": "#74B9FF", "role": "日常聊天/情感陪伴"},
}

SKILL_DIR = os.path.join(BASE_DIR, "data", "skills")
MEMORY_DIR = os.path.join(BASE_DIR, "data", "memory")
