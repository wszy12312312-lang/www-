"""
Migrate Persona Classes — H02 修复：三套 Persona 数据模型合并

将 manager.py::Persona(旧 v1) 和 ollama_service.py::PersonaState(运行时)
统一迁移到 persona/base.py::Persona(新 v3)。

用法:
    # 预览迁移计划
    python scripts/migrate_personas.py --dry-run

    # 执行迁移（更新 persona/manager.py 和 services/ollama_service.py）
    python scripts/migrate_personas.py --execute

迁移策略:
    v1 Persona(manager.py)  → persona/base.py::Persona（完整迁移）
    PersonaState(ollama)     → persona/base.py::Persona（属性映射）
    to_base_persona() 保留   → 逐步替换为直接构造 base.Persona
"""

from __future__ import annotations

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def check_status() -> dict:
    """检查当前 Persona 类的使用状态。"""
    import ast
    from pathlib import Path

    result = {
        "v1_persona_in_manager": True,     # persona/manager.py::Persona
        "runtime_state_in_ollama": True,    # services/ollama_service.py::PersonaState
        "v3_persona_in_base": True,         # persona/base.py::Persona
        "to_base_persona_calls": 0,         # manager.py 中 to_base_persona() 调用次数
        "personastate_refs": 0,             # 引用 PersonaState 的次数
    }

    # 统计 to_base_persona() 调用
    manager_path = Path(__file__).parent.parent / "persona" / "manager.py"
    if manager_path.is_file():
        content = manager_path.read_text(encoding="utf-8")
        result["to_base_persona_calls"] = content.count("to_base_persona")

    # 统计 PersonaState 引用
    ollama_path = Path(__file__).parent.parent / "services" / "ollama_service.py"
    if ollama_path.is_file():
        content = ollama_path.read_text(encoding="utf-8")
        result["personastate_refs"] = content.count("PersonaState")

    return result


def apply_migration(dry_run: bool = True) -> list[str]:
    """执行 Persona 类迁移。

    修改内容:
    1. persona/manager.py: 保留旧类但添加 @deprecated 注释
    2. services/ollama_service.py: PersonaState 添加转换方法
    3. persona/base.py: 增加 from_legacy_state() 类方法
    """
    changes: list[str] = []
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # ---- Change 1: base.py 增加 from_legacy_state() ----
    base_path = os.path.join(project_root, "persona", "base.py")
    if os.path.isfile(base_path):
        new_method = '''
    @classmethod
    def from_legacy_state(cls, persona_id: str, state_data: dict) -> "Persona":
        """H02修复：从旧 PersonaState 构造新版 Persona。"""
        return cls(
            persona_id=persona_id,
            name=state_data.get("name", persona_id),
            description=state_data.get("role", ""),
            incentive_stars=state_data.get("incentive_stars", 3),
            penalty_stars=state_data.get("penalty_stars", 0),
            task_count=state_data.get("task_count", 0),
            task_score=state_data.get("task_score", 0.0),
            success_count=state_data.get("success_count", state_data.get("task_count", 0) - state_data.get("failure_count", 0)),
            failure_count=state_data.get("failure_count", 0),
            last_task_time=state_data.get("last_task_time", 0.0),
        )
'''
        if dry_run:
            changes.append(f"  [DRY-RUN] 追加 from_legacy_state() 到 {base_path}")
        else:
            with open(base_path, "a", encoding="utf-8") as f:
                f.write(new_method)
            changes.append(f"  [OK] 追加 from_legacy_state() 到 {base_path}")

    # ---- Change 2: manager.py 标注 deprecated ----
    manager_path = os.path.join(project_root, "persona", "manager.py")
    if os.path.isfile(manager_path) and not dry_run:
        content = Path(manager_path).read_text(encoding="utf-8")
        # 添加 deprecated warning
        if '@dataclass\nclass Persona:' in content and '@deprecated' not in content:
            content = content.replace(
                '@dataclass\nclass Persona:',
                '@dataclass\nclass Persona:\n    """'
                'H02修复：@deprecated — 请使用 persona.base.Persona。'
                '本类将在 v10.9.0 中移除。'
                '"""',
            )
            Path(manager_path).write_text(content, encoding="utf-8")
            changes.append(f"  [OK] {manager_path} 标注 @deprecated")
        else:
            changes.append(f"  [SKIP] {manager_path} 已标注或格式不匹配")
    else:
        changes.append(f"  [DRY-RUN] 标注 manager.py::Persona 为 @deprecated")

    return changes


def main():
    import argparse
    parser = argparse.ArgumentParser(description="H02: Persona 数据模型迁移")
    parser.add_argument("--dry-run", action="store_true", help="预览迁移计划")
    parser.add_argument("--execute", action="store_true", help="执行迁移")
    parser.add_argument("--status", action="store_true", help="检查当前状态")
    args = parser.parse_args()

    if args.status:
        status = check_status()
        print("\n=== H02 Persona 类状态 ===")
        for k, v in status.items():
            print(f"  {k}: {v}")
        return

    if args.dry_run or not args.execute:
        print("\n=== 迁移预览 (--dry-run) ===")
        changes = apply_migration(dry_run=True)
        for c in changes:
            print(c)
        print("\n执行迁移: python scripts/migrate_personas.py --execute")
        return

    if args.execute:
        print("\n=== 执行迁移 ===")
        changes = apply_migration(dry_run=False)
        for c in changes:
            print(c)
        print("\n迁移完成。请运行测试验证。")


if __name__ == "__main__":
    main()
