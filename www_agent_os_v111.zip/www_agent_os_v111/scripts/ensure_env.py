#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WWW Agent OS 安装自检脚本

检查并自动安装所有运行时依赖：
1. Python 包 (requests, customtkinter)
2. Ollama 模型 (8 个模型)
3. 目录结构

用法: python scripts/ensure_env.py
"""

import os
import subprocess
import sys
from pathlib import Path

# Force UTF-8 on Windows to avoid GBK encode errors
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

PROJECT_ROOT = Path(__file__).resolve().parent.parent
REQUIRED_MODELS = {
    "host": "qwen3:14b",          # 9.0GB - 指挥调度
    "S":    "gemma3:12b",          # 8.1GB - 监察评分
    "S1":   "qwen2.5-coder:7b",   # 4.7GB - 软件操作
    "S2":   "qwen2.5-coder:1.5b", # 1.0GB - 系统配置
    "S3":   "llama3.2:3b",        # 2.0GB - 网络抓取
    "S4":   "qwen2.5:3b",         # 1.9GB - 文件处理
    "S5":   "deepseek-r1:7b",     # 4.7GB - 深度检索
    "S6":   "qwen2.5:7b",         # 4.7GB - 日常聊天
}
REQUIRED_DIRS = ["data/memory", "data/skills", "logs/events"]


def check_python_packages() -> bool:
    """检查并安装 Python 包依赖。"""
    missing = []
    for pkg in ["requests", "customtkinter"]:
        try:
            __import__(pkg.replace("-", "_").replace(".", "_"))
            print(f"  ✓ {pkg}")
        except ImportError:
            print(f"  ✗ {pkg} — 未安装，正在安装...")
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", pkg, "--quiet"],
                    capture_output=True, text=True, timeout=60,
                )
                if result.returncode == 0:
                    print(f"    → {pkg} 安装成功")
                else:
                    print(f"    → {pkg} 安装失败: {result.stderr.strip()}")
                    missing.append(pkg)
            except Exception as e:
                print(f"    → {pkg} 安装异常: {e}")
                missing.append(pkg)
    return len(missing) == 0


def check_ollama_models() -> bool:
    """检查 Ollama 模型是否已安装，缺失的自动 pull。"""
    print("\n  Ollama 模型检查...")
    try:
        import requests
        resp = requests.get("http://localhost:11434/api/tags", timeout=10)
        installed = {m["name"] for m in resp.json().get("models", [])}
        installed_bases = {m.split(":")[0] for m in installed}
    except Exception as e:
        print(f"  ✗ Ollama 服务不可用: {e}")
        return False

    all_ok = True
    for persona, model in REQUIRED_MODELS.items():
        model_base = model.split(":")[0]
        if model in installed or model_base in installed_bases:
            print(f"  ✓ {model} ({persona})")
        else:
            print(f"  ✗ {model} ({persona}) — 正在 pull...")
            try:
                result = subprocess.run(
                    ["ollama", "pull", model],
                    capture_output=True, text=True, timeout=600,
                )
                if result.returncode == 0:
                    print(f"    → {model} 安装成功")
                else:
                    print(f"    → {model} 安装失败: {result.stderr.strip()}")
                    all_ok = False
            except subprocess.TimeoutExpired:
                print(f"    → {model} pull 超时 (>10min)，请手动: ollama pull {model}")
                all_ok = False
            except Exception as e:
                print(f"    → {model} pull 异常: {e}")
                all_ok = False

    return all_ok


def check_directories() -> bool:
    """确保所需目录结构存在。"""
    print("\n  目录结构检查...")
    for d in REQUIRED_DIRS:
        path = PROJECT_ROOT / d
        path.mkdir(parents=True, exist_ok=True)
        print(f"  ✓ {d}")
    return True


def verify_models_online() -> bool:
    """快速验证每个模型是否可响应。"""
    print("\n  模型连通性验证...")
    try:
        import requests
    except ImportError:
        return False

    all_ok = True
    for persona, model in REQUIRED_MODELS.items():
        try:
            resp = requests.post(
                "http://localhost:11434/api/chat",
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": "ping"}],
                    "stream": False,
                    "options": {"num_predict": 1},
                },
                timeout=30,
            )
            if resp.status_code == 200:
                print(f"  ✓ {model} ({persona}) 在线")
            else:
                print(f"  ✗ {model} ({persona}) 返回 {resp.status_code}")
                all_ok = False
        except Exception as e:
            print(f"  ✗ {model} ({persona}) 无法连接: {e}")
            all_ok = False

    return all_ok


def main():
    print("=" * 60)
    print("  WWW Agent OS v11.0 环境自检")
    print("=" * 60)
    print(f"  Python: {sys.version}")
    print(f"  项目目录: {PROJECT_ROOT}")

    results = {}

    print("\n[1/4] Python 依赖")
    results["packages"] = check_python_packages()

    print("\n[2/4] 目录结构")
    results["dirs"] = check_directories()

    print("\n[3/4] Ollama 模型安装")
    results["models"] = check_ollama_models()

    if results["models"]:
        print("\n[4/4] 模型连通性")
        results["online"] = verify_models_online()
    else:
        results["online"] = False

    print("\n" + "=" * 60)
    print("  自检结果:")
    for key, status in results.items():
        label = {"packages": "Python 包", "dirs": "目录结构",
                 "models": "Ollama 模型", "online": "模型连通性"}[key]
        print(f"  {'✓' if status else '✗'} {label}")
    print("=" * 60)

    all_pass = all(results.values())
    if all_pass:
        print("\n✅ 环境就绪，可以启动 WWW Agent OS。")
    else:
        print("\n⚠️ 部分检查未通过，请修复后再启动。")

    return 0 if all_pass else 1


if __name__ == "__main__":
    sys.exit(main())
