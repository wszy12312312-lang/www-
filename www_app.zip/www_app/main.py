"""
www 多人格协作系统 v10.7.0
只与 HOST 指挥者交互，侧边栏为状态表，支持任务排队与中断
"""
import os
import shutil
import threading
import traceback
import queue
import customtkinter as ctk
from PIL import Image

from www_core import WWWSystem
from config import PERSONAS, PERSONA_MODELS

APP_DIR = os.path.dirname(os.path.abspath(__file__))

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

BG_MAIN = "#0f0f1a"
BG_SIDEBAR = "#0a0a16"
BG_CARD = "#16162a"
BG_INPUT = "#1a1a30"
BG_USER_BUBBLE = "#1d4ed8"
BG_BOT_BUBBLE = "#1e1e3a"
TEXT_PRIMARY = "#e2e8f0"
TEXT_SECONDARY = "#94a3b8"
TEXT_MUTED = "#64748b"
ACCENT = "#3b82f6"
ACCENT_HOVER = "#2563eb"
DANGER = "#ef4444"
DANGER_HOVER = "#dc2626"
BORDER = "#1e293b"


class ChatBubble(ctk.CTkFrame):
    def __init__(self, master, sender: str, text: str, color: str, is_user: bool = False, **kwargs):
        super().__init__(master, fg_color="transparent", corner_radius=0, **kwargs)
        self.grid_columnconfigure(0 if is_user else 1, weight=1)

        bubble_bg = BG_USER_BUBBLE if is_user else BG_BOT_BUBBLE
        txt_color = "#ffffff" if is_user else TEXT_PRIMARY

        bubble = ctk.CTkFrame(self, fg_color=bubble_bg, corner_radius=16)
        if is_user:
            bubble.grid(row=0, column=1, sticky="e", padx=(60, 12), pady=4)
        else:
            bubble.grid(row=0, column=0, sticky="w", padx=(12, 60), pady=4)

        # 左侧色条（仅非用户气泡）
        if not is_user:
            color_bar = ctk.CTkFrame(bubble, fg_color=color, corner_radius=0, width=3)
            color_bar.pack(side="left", fill="y")

        ctk.CTkLabel(bubble, text=sender, font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=color, anchor="w").pack(anchor="w", padx=14, pady=(10, 2))
        ctk.CTkLabel(bubble, text=text, font=ctk.CTkFont(size=14),
                     text_color=txt_color, wraplength=520, justify="left",
                     anchor="w").pack(anchor="w", padx=14, pady=(0, 10))


class SystemBubble(ctk.CTkFrame):
    def __init__(self, master, text: str, color: str = TEXT_MUTED, **kwargs):
        super().__init__(master, fg_color="transparent", corner_radius=0, **kwargs)
        ctk.CTkLabel(self, text=text, font=ctk.CTkFont(size=11), text_color=color,
                     wraplength=780, justify="left").pack(pady=3, anchor="w")


class StatusPanel(ctk.CTkFrame):
    """右侧状态检测表"""
    def __init__(self, master, system: WWWSystem, **kwargs):
        super().__init__(master, fg_color=BG_SIDEBAR, corner_radius=0, width=290, **kwargs)
        self.pack_propagate(False)
        self.grid_propagate(False)
        self.system = system
        self.cards: dict = {}
        self._build()

    def _build(self):
        # 标题
        header = ctk.CTkFrame(self, fg_color="transparent", height=50)
        header.pack(fill="x", padx=14, pady=(12, 6))
        header.pack_propagate(False)
        ctk.CTkLabel(header, text="状态检测表", font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=ACCENT).pack(side="left")

        self.global_status_label = ctk.CTkLabel(header, text="自检中...", font=ctk.CTkFont(size=11),
                                                  text_color="#f97316")
        self.global_status_label.pack(side="right", pady=(4, 0))

        ctk.CTkFrame(self, fg_color=BORDER, height=1).pack(fill="x", padx=14, pady=(0, 6))

        # 人格状态卡片滚动区
        self.scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=ACCENT
        )
        self.scroll.pack(fill="both", expand=True, padx=8, pady=(0, 4))

        # 任务队列区域
        queue_header = ctk.CTkFrame(self, fg_color="transparent", height=28)
        queue_header.pack(fill="x", padx=14, pady=(4, 2))
        queue_header.pack_propagate(False)
        ctk.CTkLabel(queue_header, text="任务队列", font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=TEXT_SECONDARY).pack(side="left")
        self.queue_count_label = ctk.CTkLabel(queue_header, text="0", font=ctk.CTkFont(size=11),
                                               text_color=TEXT_MUTED)
        self.queue_count_label.pack(side="right")

        self.queue_frame = ctk.CTkScrollableFrame(
            self, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=ACCENT, height=100
        )
        self.queue_frame.pack(fill="x", padx=8, pady=(0, 8))

        # 底部
        ctk.CTkLabel(self, text="Ollama 本地 · 8 模型独立运行",
                     font=ctk.CTkFont(size=10), text_color=TEXT_MUTED).pack(pady=(2, 10))

        self.refresh()

    def refresh(self):
        for card in self.cards.values():
            card.destroy()
        self.cards.clear()

        for pid in ["host", "S", "S1", "S2", "S3", "S4", "S5", "S6"]:
            meta = PERSONAS[pid]
            s = self.system.states[pid]
            card = StatusCard(self.scroll, pid, meta, s)
            card.pack(fill="x", pady=2)
            self.cards[pid] = card

    def refresh_status(self):
        """轻量刷新：只更新已有卡片的标签，不销毁重建"""
        total = len(self.system.states)

        for pid, card in self.cards.items():
            s = self.system.states[pid]
            card.refresh(s, PERSONA_MODELS.get(pid, "?"))

        checked = sum(1 for s in self.system.states.values() if s.model_online is not None)
        if self.system._checking or checked < total:
            self.global_status_label.configure(text=f"自检中 ({checked}/{total})", text_color="#f97316")
        else:
            offline = sum(1 for s in self.system.states.values() if s.model_online is False)
            if offline == 0:
                self.global_status_label.configure(text="全部就绪", text_color="#22c55e")
            else:
                self.global_status_label.configure(text=f"{offline} 个异常", text_color="#facc15")
        print(f"[refresh_status] checking={self.system._checking}, checked={checked}/{total}, states={[(pid, s.model_online) for pid, s in self.system.states.items()]}")

    def set_on_cancel(self, callback):
        """设置队列任务取消回调：callback(index)"""
        self._on_cancel = callback

    def update_queue(self, tasks: list):
        for w in self.queue_frame.winfo_children():
            w.destroy()
        for i, t in enumerate(tasks):
            frame = ctk.CTkFrame(self.queue_frame, fg_color=BG_CARD, corner_radius=8)
            frame.pack(fill="x", pady=2)
            prefix = "⏳" if i > 0 else ("▶" if self.system._running else "⏳")
            ctk.CTkLabel(frame, text=f"{prefix} {t[:30]}",
                         font=ctk.CTkFont(size=10), text_color=TEXT_SECONDARY,
                         anchor="w").pack(side="left", padx=8, pady=4)
            if i > 0 and hasattr(self, "_on_cancel"):
                idx = i  # capture for closure
                cancel_btn = ctk.CTkButton(
                    frame, text="✕", width=22, height=22,
                    font=ctk.CTkFont(size=10, weight="bold"),
                    fg_color="transparent", hover_color=DANGER_HOVER,
                    corner_radius=6, text_color=TEXT_MUTED,
                    command=lambda j=idx: self._on_cancel(j)
                )
                cancel_btn.pack(side="right", padx=(0, 6))
        self.queue_count_label.configure(text=str(len(tasks)))


class StatusCard(ctk.CTkFrame):
    def __init__(self, master, pid: str, meta: dict, state, **kwargs):
        color = meta["color"]
        super().__init__(master, fg_color=BG_CARD, corner_radius=8, **kwargs)

        # 图标
        icon = ctk.CTkFrame(self, fg_color=color, corner_radius=8, width=30, height=30)
        icon.pack(side="left", padx=(8, 8), pady=8)
        icon.pack_propagate(False)
        ctk.CTkLabel(icon, text=meta["icon"], font=ctk.CTkFont(size=11, weight="bold"),
                     text_color="white").place(relx=0.5, rely=0.5, anchor="center")

        # 信息
        info = ctk.CTkFrame(self, fg_color="transparent")
        info.pack(side="left", fill="x", expand=True, padx=(0, 4), pady=4)

        ctk.CTkLabel(info, text=meta["name"], font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=TEXT_PRIMARY, anchor="w").pack(anchor="w")

        self.model_label = ctk.CTkLabel(info, text="",
                                         font=ctk.CTkFont(size=9), text_color=TEXT_SECONDARY, anchor="w")
        self.model_label.pack(anchor="w")

        # 右侧：状态指示灯 + 激励数值
        right = ctk.CTkFrame(self, fg_color="transparent")
        right.pack(side="right", padx=(0, 8), pady=2)

        self.status_dot = ctk.CTkLabel(right, text="●", font=ctk.CTkFont(size=14),
                                        text_color="#f97316", width=20)
        self.status_dot.pack()

        self.status_text_label = ctk.CTkLabel(right, text="自检中", font=ctk.CTkFont(size=8),
                                                text_color="#f97316", width=30)
        self.status_text_label.pack()

        self.memory_label = ctk.CTkLabel(right, text="", font=ctk.CTkFont(size=8),
                                          text_color=TEXT_MUTED, width=30)
        self.memory_label.pack()

        self.incentive_label = ctk.CTkLabel(right, text="", font=ctk.CTkFont(size=9),
                                             text_color=TEXT_MUTED, width=30)
        self.incentive_label.pack()

        self.refresh(state, PERSONA_MODELS.get(pid, "?"))

    def refresh(self, state, model_name: str):
        # 模型名 + 状态文本
        self.model_label.configure(text=f"{model_name}  ·  {state.status_text}")

        # 激励数值
        incentive_text = f"+{state.net_incentive}" if state.net_incentive >= 0 else str(state.net_incentive)
        self.incentive_label.configure(text=incentive_text)

        # 状态灯 + 文字（直接使用 state.model_online，实时显示）
        online = state.model_online
        if online is True:
            self.status_dot.configure(text_color="#22c55e")
            self.status_text_label.configure(text="就绪", text_color="#22c55e")
        elif online is False:
            self.status_dot.configure(text_color="#facc15")
            self.status_text_label.configure(text="异常", text_color="#facc15")
        else:
            self.status_dot.configure(text_color="#f97316")
            self.status_text_label.configure(text="自检中", text_color="#f97316")

        # 记忆状态
        mem = state.memory_ok
        if mem is True:
            self.memory_label.configure(text="记忆·OK", text_color="#22c55e")
        elif mem is False:
            self.memory_label.configure(text="记忆·异常", text_color="#ef4444")
        else:
            self.memory_label.configure(text="记忆·检查中", text_color="#f97316")

class SkillsLibraryWindow(ctk.CTkToplevel):
    """技能库窗口：列出 skills/ 下所有技能，支持打开位置和删除"""

    def __init__(self, master):
        super().__init__(master)
        self.title("技能库")
        self.configure(fg_color=BG_MAIN)
        self.resizable(False, False)

        # 居中显示
        w, h = 600, 450
        self.update_idletasks()
        mx = master.winfo_x()
        my = master.winfo_y()
        mw = master.winfo_width()
        mh = master.winfo_height()
        x = mx + (mw - w) // 2
        y = my + (mh - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")

        self.skills_dir = os.path.join(APP_DIR, "skills")
        self._build()

    def _build(self):
        # 标题栏
        header = ctk.CTkFrame(self, fg_color="transparent", height=44)
        header.pack(fill="x", padx=16, pady=(12, 6))
        header.pack_propagate(False)
        ctk.CTkLabel(header, text="技能库", font=ctk.CTkFont(size=16, weight="bold"),
                     text_color=ACCENT).pack(side="left")
        ctk.CTkLabel(header, text="已安装的技能", font=ctk.CTkFont(size=11),
                     text_color=TEXT_MUTED).pack(side="right", pady=(4, 0))

        ctk.CTkFrame(self, fg_color=BORDER, height=1).pack(fill="x", padx=16, pady=(0, 6))

        # 滚动区域
        self.scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=ACCENT
        )
        self.scroll.pack(fill="both", expand=True, padx=12, pady=(0, 8))

        self._populate()

        # 关闭按钮
        btn_frame = ctk.CTkFrame(self, fg_color="transparent", height=44)
        btn_frame.pack(fill="x", padx=16, pady=(4, 12))
        btn_frame.pack_propagate(False)
        ctk.CTkButton(
            btn_frame, text="关闭", width=80, height=32,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=BG_CARD, hover_color=ACCENT_HOVER,
            corner_radius=8, border_width=1, border_color=BORDER,
            text_color=TEXT_SECONDARY, command=self.destroy
        ).pack(side="right")

    def _populate(self):
        for w in self.scroll.winfo_children():
            w.destroy()

        if not os.path.isdir(self.skills_dir):
            ctk.CTkLabel(self.scroll, text="暂无已安装的技能",
                         font=ctk.CTkFont(size=13), text_color=TEXT_MUTED).pack(pady=40)
            return

        try:
            entries = sorted([
                d for d in os.listdir(self.skills_dir)
                if os.path.isdir(os.path.join(self.skills_dir, d))
            ])
        except Exception:
            ctk.CTkLabel(self.scroll, text="无法读取 skills 目录",
                         font=ctk.CTkFont(size=13), text_color=DANGER).pack(pady=40)
            return

        if not entries:
            ctk.CTkLabel(self.scroll, text="暂无已安装的技能",
                         font=ctk.CTkFont(size=13), text_color=TEXT_MUTED).pack(pady=40)
            return

        for name in entries:
            self._add_skill_row(name)

    def _add_skill_row(self, name: str):
        row = ctk.CTkFrame(self.scroll, fg_color=BG_CARD, corner_radius=8)
        row.pack(fill="x", pady=3)

        ctk.CTkLabel(row, text=name, font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=TEXT_PRIMARY, anchor="w").pack(
            side="left", fill="x", expand=True, padx=12, pady=10)

        skill_dir = os.path.join(self.skills_dir, name)

        ctk.CTkButton(
            row, text="打开位置", width=72, height=28,
            font=ctk.CTkFont(size=11),
            fg_color=BG_CARD, hover_color=ACCENT_HOVER,
            corner_radius=6, border_width=1, border_color=BORDER,
            text_color=TEXT_SECONDARY,
            command=lambda d=skill_dir: self._open_location(d)
        ).pack(side="right", padx=(4, 6), pady=8)

        ctk.CTkButton(
            row, text="删除", width=56, height=28,
            font=ctk.CTkFont(size=11),
            fg_color="transparent", hover_color=DANGER_HOVER,
            corner_radius=6, border_width=1, border_color=DANGER,
            text_color=DANGER,
            command=lambda n=name, d=skill_dir: self._confirm_delete(n, d)
        ).pack(side="right", padx=(0, 4), pady=8)

    def _open_location(self, path: str):
        try:
            os.startfile(path)
        except Exception:
            pass

    def _confirm_delete(self, name: str, path: str):
        confirm = ConfirmDialog(
            self, title="确认删除",
            message=f"确定要删除技能「{name}」吗？\n此操作不可撤销。",
            confirm_text="删除", cancel_text="取消"
        )
        self.wait_window(confirm)
        if confirm.result:
            try:
                shutil.rmtree(path)
                self._populate()
            except Exception as e:
                ErrorDialog(self, title="删除失败",
                            message=f"无法删除技能「{name}」：\n{e}").grab_set()


class ConfirmDialog(ctk.CTkToplevel):
    """确认弹窗"""

    def __init__(self, master, title: str, message: str,
                 confirm_text: str = "确认", cancel_text: str = "取消"):
        super().__init__(master)
        self.result = False
        self.title(title)
        self.configure(fg_color=BG_MAIN)
        self.resizable(False, False)

        w, h = 380, 180
        self.update_idletasks()
        mx = master.winfo_x()
        my = master.winfo_y()
        mw = master.winfo_width()
        mh = master.winfo_height()
        x = mx + (mw - w) // 2
        y = my + (mh - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")

        ctk.CTkLabel(self, text=message, font=ctk.CTkFont(size=13),
                     text_color=TEXT_PRIMARY, wraplength=340,
                     justify="left").pack(padx=20, pady=(24, 16), anchor="w")

        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(side="bottom", fill="x", padx=20, pady=(0, 20))

        ctk.CTkButton(
            btn_frame, text=confirm_text, width=80, height=32,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=DANGER, hover_color=DANGER_HOVER,
            corner_radius=8, command=self._confirm
        ).pack(side="right", padx=(8, 0))

        ctk.CTkButton(
            btn_frame, text=cancel_text, width=80, height=32,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=BG_CARD, hover_color=ACCENT_HOVER,
            corner_radius=8, border_width=1, border_color=BORDER,
            text_color=TEXT_SECONDARY, command=self._cancel
        ).pack(side="right")

        self.grab_set()

    def _confirm(self):
        self.result = True
        self.destroy()

    def _cancel(self):
        self.result = False
        self.destroy()


class ErrorDialog(ctk.CTkToplevel):
    """错误提示弹窗"""

    def __init__(self, master, title: str, message: str):
        super().__init__(master)
        self.title(title)
        self.configure(fg_color=BG_MAIN)
        self.resizable(False, False)

        w, h = 380, 160
        self.update_idletasks()
        mx = master.winfo_x()
        my = master.winfo_y()
        mw = master.winfo_width()
        mh = master.winfo_height()
        x = mx + (mw - w) // 2
        y = my + (mh - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")

        ctk.CTkLabel(self, text=message, font=ctk.CTkFont(size=13),
                     text_color=TEXT_PRIMARY, wraplength=340,
                     justify="left").pack(padx=20, pady=(24, 16), anchor="w")

        ctk.CTkButton(
            self, text="确定", width=80, height=32,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            corner_radius=8, command=self.destroy
        ).pack(side="bottom", anchor="e", padx=20, pady=(0, 20))

        self.grab_set()


class WWWApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.system = WWWSystem()
        self.task_queue: list = []
        self._cancelled = False
        self._running = False
        self._setup_window()
        self._build_sidebar()
        self._build_chat_area()
        self._add_system_msg("www v10.7.0 — www 智能体 启动中…")
        self._start_status_timer()  # UI 就绪后启动状态刷新
        # 立即启动模型健康检查
        threading.Thread(target=self._do_model_check, daemon=True).start()

    def _setup_window(self):
        self.title("www 多人格协作系统 v10.7.0")
        self.geometry("1150x720")
        self.minsize(900, 540)
        self.configure(fg_color=BG_MAIN)

        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x = (sw - 1150) // 2
        y = (sh - 720) // 2
        self.geometry(f"+{x}+{y}")

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _do_model_check(self):
        self.system.check_all_models(progress_callback=self._on_model_checked)
        self.after(0, self.status_panel.refresh_status)
        self.after(0, self._refresh_host_status)

    def _on_model_checked(self, pid, done, total):
        """由 daemon 线程回调，调度到主线程实时刷新 UI"""
        self.after(0, self.status_panel.refresh_status)
        self.after(0, self._refresh_host_status)
        name = PERSONAS[pid]["name"]
        self.after(0, lambda n=name: self._add_system_msg(f"{n}自检完成，很高兴为您服务", "#22c55e"))
        if done == total:
            self.after(0, lambda: self._add_system_msg("www 已就绪，等待指令", "#22c55e"))

    def _start_status_timer(self):
        print(f"[_start_status_timer] tick, _checking={self.system._checking}")
        self.status_panel.refresh_status()
        self._refresh_host_status()
        self.after(15000, self._start_status_timer)

    def _refresh_host_status(self):
        """同步主聊天区头部 HOST 状态标签与模型自检/运行状态"""
        if self._running:
            print(f"[_refresh_host_status] SKIP (running)")
            return  # 任务执行中，由 _set_running 控制
        host = self.system.states["host"]
        model_name = PERSONA_MODELS["host"]
        if self.system._checking:
            self.status_label.configure(text="自检中", text_color="#f97316")
            self.host_model_label.configure(text=f" · {model_name}", text_color=TEXT_SECONDARY)
            print(f"[_refresh_host_status] checking → 自检中")
        elif host.model_online is True:
            self.status_label.configure(text="就绪", text_color="#22c55e")
            self.host_model_label.configure(text=f" · {model_name}", text_color=TEXT_SECONDARY)
            print(f"[_refresh_host_status] online=True → 就绪")
        elif host.model_online is False:
            self.status_label.configure(text="离线", text_color="#facc15")
            self.host_model_label.configure(text=f" · {model_name}", text_color=TEXT_SECONDARY)
            print(f"[_refresh_host_status] online=False → 离线")
        else:
            self.status_label.configure(text="自检中", text_color="#f97316")
            self.host_model_label.configure(text=f" · {model_name}", text_color=TEXT_SECONDARY)
            print(f"[_refresh_host_status] online=None → 自检中")

    def _build_sidebar(self):
        self.status_panel = StatusPanel(self, self.system)
        self.status_panel.set_on_cancel(self._cancel_queued_task)
        self.status_panel.pack(side="right", fill="y")

    def _build_chat_area(self):
        self.chat_frame = ctk.CTkFrame(self, fg_color=BG_MAIN, corner_radius=0)
        self.chat_frame.pack(side="left", fill="both", expand=True)
        self.chat_frame.grid_rowconfigure(0, weight=0)
        self.chat_frame.grid_rowconfigure(1, weight=1)
        self.chat_frame.grid_rowconfigure(2, weight=0)
        self.chat_frame.grid_columnconfigure(0, weight=1)

        # 头部
        header = ctk.CTkFrame(self.chat_frame, fg_color="transparent", height=52)
        header.grid(row=0, column=0, sticky="ew", padx=16, pady=(12, 0))
        header.grid_propagate(False)

        logo_path = os.path.join(APP_DIR, "logo.png")
        logo_img = ctk.CTkImage(Image.open(logo_path), size=(36, 36))
        ctk.CTkLabel(header, image=logo_img, text="").pack(side="left", padx=(0, 10))

        ctk.CTkLabel(header, text="www 智能体",
                     font=ctk.CTkFont(size=16, weight="bold"),
                     text_color=PERSONAS["host"]["color"]).pack(side="left")
        self.host_model_label = ctk.CTkLabel(header, text=" · qwen3:14b",
                     font=ctk.CTkFont(size=12), text_color=TEXT_SECONDARY)
        self.host_model_label.pack(side="left", pady=(3, 0))

        self.skills_btn = ctk.CTkButton(
            header, text="技能库", width=72, height=28,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=BG_CARD, hover_color=ACCENT_HOVER,
            corner_radius=8, border_width=1, border_color=BORDER,
            text_color=TEXT_SECONDARY, command=self._open_skills_library
        )
        self.skills_btn.pack(side="right", padx=(0, 10))

        self.status_label = ctk.CTkLabel(header, text="自检中",
                                          font=ctk.CTkFont(size=11), text_color="#f97316")
        self.status_label.pack(side="right")

        # 聊天滚动区
        self.chat_scroll = ctk.CTkScrollableFrame(
            self.chat_frame, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=ACCENT
        )
        self.chat_scroll.grid(row=1, column=0, sticky="nsew", padx=0, pady=(4, 0))
        self.chat_scroll.grid_columnconfigure(0, weight=1)

        # 输入区
        input_frame = ctk.CTkFrame(self.chat_frame, fg_color="transparent", height=62)
        input_frame.grid(row=2, column=0, sticky="ew", padx=16, pady=(6, 10))
        input_frame.grid_propagate(False)
        input_frame.grid_columnconfigure(0, weight=1)

        self.input_box = ctk.CTkTextbox(
            input_frame, font=ctk.CTkFont(size=13), fg_color=BG_INPUT,
            text_color=TEXT_PRIMARY, corner_radius=12, border_width=1,
            border_color=BORDER, height=48, wrap="word", activate_scrollbars=False
        )
        self.input_box.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        self.input_box.bind("<Control-Return>", lambda e: self._on_send_click())

        self.send_btn = ctk.CTkButton(
            input_frame, text="发送", width=64, height=38,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            corner_radius=10, command=self._on_send_click
        )
        self.send_btn.grid(row=0, column=1, sticky="ns", padx=(0, 4))

        self.interrupt_btn = ctk.CTkButton(
            input_frame, text="中断", width=64, height=38,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=DANGER, hover_color=DANGER_HOVER,
            corner_radius=10, command=self._on_interrupt_click
        )
        self.interrupt_btn.grid(row=0, column=2, sticky="ns")
        self.interrupt_btn.grid_remove()  # 初始隐藏

    def _open_skills_library(self):
        SkillsLibraryWindow(self)

    def _on_send_click(self):
        text = self.input_box.get("1.0", "end").strip()
        if not text:
            return
        self.input_box.delete("1.0", "end")

        self.task_queue.append(text)
        self.status_panel.update_queue(self.task_queue)

        if len(self.task_queue) == 1:
            self._process_next()

    def _on_interrupt_click(self):
        self._cancelled = True
        self._add_system_msg("⚠ 正在中断当前任务...", "#facc15")

    def _cancel_queued_task(self, index: int):
        """取消队列中指定位置的待执行任务"""
        if 0 < index < len(self.task_queue):
            removed = self.task_queue.pop(index)
            self._add_system_msg(f"已取消排队任务: {removed[:40]}", TEXT_MUTED)
            self.status_panel.update_queue(self.task_queue)

    def _process_next(self):
        if not self.task_queue:
            self._set_idle()
            return

        # 自检未完成时阻塞执行，等待自检完毕
        if self.system._checking:
            self._add_system_msg("模型自检中，请稍候...任务将在自检完成后自动执行", "#f97316")
            self.after(500, self._process_next)
            return

        task = self.task_queue[0]
        self._add_user_msg(task)
        self.status_panel.update_queue(self.task_queue)
        self._set_running()

        threading.Thread(target=self._execute_task, args=(task,), daemon=True).start()

    def _execute_task(self, task: str):
        try:
            dispatch_to, _ = self.system.host_dispatch(task)

            # 检查目标专员模型是否在线
            target_state = self.system.states.get(dispatch_to)
            if target_state and target_state.model_online is False:
                self.after(0, lambda pid=dispatch_to: self._on_reply(
                    pid,
                    f"[{PERSONAS[pid]['name']} 模型离线，无法处理此任务。请检查 Ollama 是否运行 {PERSONA_MODELS[pid]} 模型]",
                    "", {"overall": 0, "comment": "模型离线"}
                ))
                return

            # 显示调度决策
            dispatcher_name = PERSONAS[dispatch_to]["name"]
            self.after(0, lambda pid=dispatch_to, dn=dispatcher_name: self._add_system_msg(
                f"HOST 调度 → {PERSONAS[pid]['icon']} {dn}（{PERSONA_MODELS[pid]}）", ACCENT
            ))

            reply, reasoning = self.system.chat(dispatch_to, task)
            score = self.system.s6_evaluate(dispatch_to, task, reply)
            self.system.apply_score(dispatch_to, score.get("overall", 3))
            self.system.log_task(dispatch_to, task, reply, score)

            if self._cancelled:
                self.after(0, lambda r=reply: self._on_cancel(r))
            else:
                self.after(0, lambda pid=dispatch_to, r=reply, rs=reasoning, sc=score: self._on_reply(pid, r, rs, sc))
        except Exception:
            err = traceback.format_exc()
            if not self._cancelled:
                self.after(0, lambda: self._on_error(err))
        finally:
            try:
                self.system.save_all_memories()
            except Exception:
                pass

    def _on_reply(self, pid: str, reply: str, reasoning: str, score: dict):
        # 如果有思考过程，先显示
        if reasoning:
            self._add_reasoning_bubble(reasoning)
        self._add_bot_msg(pid, reply)
        overall = score.get("overall", 3)
        stars = "★" * int(overall) + "☆" * (5 - int(overall))
        self._add_system_msg(f"S Supervise  |  {stars}  {overall}/5  |  {score.get('comment', '')}")

        try:
            self.system.save_all_memories()
        except Exception:
            pass

        self.task_queue.pop(0)
        self.status_panel.refresh()
        self._process_next()

    def _on_cancel(self, partial_reply: str):
        self.task_queue.pop(0)
        self._add_system_msg("⚠ 任务已被中断", "#facc15")
        if partial_reply:
            self._add_system_msg(f"部分输出: {partial_reply[:200]}", TEXT_MUTED)
        self.status_panel.refresh()
        self._process_next()

    def _on_error(self, err: str):
        self._add_system_msg(f"错误: {err[:300]}", "#ef4444")
        self.task_queue.pop(0)
        self.status_panel.refresh()
        self._process_next()

    def _set_running(self):
        self._running = True
        self._cancelled = False
        self.system._running = True
        self.interrupt_btn.grid()
        self.status_label.configure(text="执行中...", text_color="#facc15")

    def _set_idle(self):
        self._running = False
        self.system._running = False
        self.interrupt_btn.grid_remove()
        self._refresh_host_status()
        self.status_panel.update_queue([])

    def _add_system_msg(self, text: str, color: str = TEXT_MUTED):
        SystemBubble(self.chat_scroll, text, color).pack(fill="x", pady=2)
        self._scroll_bottom()

    def _add_user_msg(self, text: str):
        ChatBubble(self.chat_scroll, "你", text, "#60a5fa", is_user=True).pack(fill="x")
        self._scroll_bottom()

    def _add_bot_msg(self, pid: str, text: str):
        meta = PERSONAS[pid]
        if not text:
            text = "（返回为空，请重试或切换模型）"
        ChatBubble(self.chat_scroll, f"{meta['icon']} {meta['name']}", text, meta["color"]).pack(fill="x")
        self._scroll_bottom()

    def _add_reasoning_bubble(self, reasoning: str):
        """显示模型的思考过程（浅灰折叠样式）"""
        frame = ctk.CTkFrame(self.chat_scroll, fg_color="transparent", corner_radius=0)
        frame.pack(fill="x", pady=2)
        ctk.CTkLabel(frame, text="💭 思考过程：", font=ctk.CTkFont(size=11, weight="bold"),
                     text_color="#9ca3af", anchor="w").pack(anchor="w", padx=16, pady=(4, 0))
        ctk.CTkLabel(frame, text=reasoning, font=ctk.CTkFont(size=11),
                     text_color="#6b7280", wraplength=780, justify="left",
                     anchor="w").pack(anchor="w", padx=16, pady=(0, 6))
        self._scroll_bottom()

    def _scroll_bottom(self):
        """智能滚动：仅当用户已在底部（≥95%）时才自动滚动到底部"""
        _, bottom_fraction = self.chat_scroll._parent_canvas.yview()
        if bottom_fraction >= 0.95:
            self.chat_scroll._parent_canvas.yview_moveto(1.0)

    def _on_close(self):
        """窗口关闭时保存所有记忆后退出"""
        try:
            self.system.shutdown()
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    os.makedirs(os.path.join(os.path.dirname(__file__), "memory"), exist_ok=True)
    app = WWWApp()
    app.mainloop()
