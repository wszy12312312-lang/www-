---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 27473ac333220fffa223537e117ab992_e59988fb7e1111f18d11525400e6dd8f
    ReservedCode1: i2tAXOdMvvpjQHJw/yJimLz8iBkcm1yXHUU+gZSLpGPXVOxaTVwgdlhTnY5eZWVW3DbxmR1S9wWid2lsFFFn8NdWTg21uGwut7ehx1KIMuqbRB0xv7aVjlWuQ9uqJoebA1oiM3GWWOwcA5e6+vJyM+GSiGfazB61b2JvA6D5Y8S4TsKZ082ghOyyolQ=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 27473ac333220fffa223537e117ab992_e59988fb7e1111f18d11525400e6dd8f
    ReservedCode2: i2tAXOdMvvpjQHJw/yJimLz8iBkcm1yXHUU+gZSLpGPXVOxaTVwgdlhTnY5eZWVW3DbxmR1S9wWid2lsFFFn8NdWTg21uGwut7ehx1KIMuqbRB0xv7aVjlWuQ9uqJoebA1oiM3GWWOwcA5e6+vJyM+GSiGfazB61b2JvA6D5Y8S4TsKZ082ghOyyolQ=
---

# www — 多人格协作智能体

基于 Ollama 的本地 8 人格 AI 助手。每个人格绑定独立模型——HOST 指挥调度、S 监督评分、S1~S6 各司其职（软件管理、系统运维、网络抓取、文件处理、深度检索、日常聊天），全离线运行，数据不出本机。
*（内容由AI生成，仅供参考）*
