"""
Dead Letter Queue — 死信队列

处理不可投递或失败的事件：
- 临时故障（如处理器异常）→ 重试 N 次后进入 DLQ
- 永久故障（如事件格式无效）→ 直接进入 DLQ
- 支持重新投递（重放到 EventBus）

版本: 1.0.0
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from events.bus import Event, EventBus

logger = logging.getLogger(__name__)


class DLQStatus(str, Enum):
    """死信状态。"""
    PENDING = "pending"        # 等待重试
    RETRYING = "retrying"      # 正在重试
    PERMANENT = "permanent"    # 永久失败，不再重试
    REPLAYED = "replayed"      # 已重放成功


@dataclass
class DeadLetter:
    """死信条目。

    Attributes:
        id: 死信唯一 ID。
        event: 原始事件。
        error: 失败原因。
        failed_at: 失败时间。
        retry_count: 已重试次数。
        max_retries: 最大重试次数。
        status: 当前状态。
        handler_name: 失败的处理器名称。
    """

    id: str = ""
    event: Optional[Event] = None
    error: str = ""
    failed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    retry_count: int = 0
    max_retries: int = 3
    status: DLQStatus = DLQStatus.PENDING
    handler_name: str = ""

    def __post_init__(self) -> None:
        if not self.id:
            import uuid
            self.id = f"dlq_{uuid.uuid4().hex[:12]}"


class DeadLetterQueue:
    """死信队列。

    特性：
    - JSONL 持久化存储
    - 可配置最大重试次数
    - 支持重放（replay）到 EventBus
    - 支持过滤（按事件类型/源/状态）

    Usage::

        dlq = DeadLetterQueue(storage_dir="./data/dlq")
        dlq.push(event, error="处理器超时", handler_name="task_handler")
        dlq.retry_pending(bus)  # 重试所有待处理死信
    """

    DEFAULT_STORAGE_DIR = "data/dlq"
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_COOLDOWN_SECONDS = 60.0

    def __init__(
        self,
        storage_dir: str = "",
        max_retries: int = 0,
        cooldown_seconds: float = 0.0,
    ) -> None:
        self._storage_dir = storage_dir or self.DEFAULT_STORAGE_DIR
        self._max_retries = max_retries or self.DEFAULT_MAX_RETRIES
        self._cooldown = cooldown_seconds or self.DEFAULT_COOLDOWN_SECONDS
        self._lock = threading.RLock()
        self._on_replay_success: Optional[Callable[[DeadLetter], None]] = None
        self._on_replay_failure: Optional[Callable[[DeadLetter, str], None]] = None

        os.makedirs(self._storage_dir, exist_ok=True)
        logger.info("DeadLetterQueue 已初始化: dir=%s", self._storage_dir)

    # ------------------------------------------------------------------
    # 推送
    # ------------------------------------------------------------------

    def push(
        self,
        event: Event,
        error: str = "",
        handler_name: str = "",
    ) -> DeadLetter:
        """将失败事件推入死信队列。

        Args:
            event: 失败的原始事件。
            error: 失败原因。
            handler_name: 失败的处理器名称。

        Returns:
            创建的 DeadLetter 对象。
        """
        dl = DeadLetter(
            event=event,
            error=error,
            handler_name=handler_name,
            max_retries=self._max_retries,
        )

        self._persist(dl)
        logger.warning(
            "DLQ 入队: id=%s, type=%s, error=%s, handler=%s",
            dl.id, self._event_type(event), error[:100], handler_name,
        )
        return dl

    @staticmethod
    def _event_type(event: Optional[Event]) -> str:
        if event is None:
            return "unknown"
        return event.type if isinstance(event.type, str) else event.type.value

    def _get_file_path(self) -> str:
        return os.path.join(self._storage_dir, "dead_letters.jsonl")

    def _persist(self, dl: DeadLetter) -> None:
        """持久化死信到 JSONL。"""
        event_data: Optional[Dict[str, Any]] = None
        if dl.event is not None:
            event_data = {
                "event_id": dl.event.event_id,
                "event_type": self._event_type(dl.event),
                "source": dl.event.source,
                "timestamp": dl.event.timestamp.isoformat(),
                "data": dl.event.data,
                "metadata": dl.event.metadata,
            }

        entry = {
            "id": dl.id,
            "event": event_data,
            "error": dl.error,
            "failed_at": dl.failed_at.isoformat(),
            "retry_count": dl.retry_count,
            "max_retries": dl.max_retries,
            "status": dl.status.value,
            "handler_name": dl.handler_name,
        }

        path = self._get_file_path()
        with self._lock:
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    # ------------------------------------------------------------------
    # 重试
    # ------------------------------------------------------------------

    def retry_pending(self, bus: EventBus) -> Dict[str, int]:
        """重试所有待处理死信。

        Args:
            bus: 用于重放的 EventBus。

        Returns:
            {'replayed': N, 'failed': M, 'skipped': K}。
        """
        all_dl = self.list_pending()
        result = {"replayed": 0, "failed": 0, "skipped": 0}

        for dl in all_dl:
            # 检查冷却期
            if dl.retry_count > 0:
                elapsed = (datetime.now(timezone.utc) - dl.failed_at).total_seconds()
                if elapsed < self._cooldown:
                    result["skipped"] += 1
                    continue

            if dl.event is None:
                dl.status = DLQStatus.PERMANENT
                result["failed"] += 1
                continue

            dl.status = DLQStatus.RETRYING
            dl.retry_count += 1
            dl.failed_at = datetime.now(timezone.utc)

            try:
                called = bus.emit(dl.event)
                if called > 0:
                    dl.status = DLQStatus.REPLAYED
                    result["replayed"] += 1
                    if self._on_replay_success:
                        self._on_replay_success(dl)
                    logger.info("DLQ 重放成功: id=%s", dl.id)
                else:
                    # 无匹配处理器
                    self._handle_retry_failure(dl, "无匹配处理器", result)
            except Exception as e:
                self._handle_retry_failure(dl, str(e), result)

            self._persist(dl)

        return result

    def _handle_retry_failure(
        self,
        dl: DeadLetter,
        error: str,
        result: Dict[str, int],
    ) -> None:
        """处理重试失败。"""
        dl.error = error
        if dl.retry_count >= dl.max_retries:
            dl.status = DLQStatus.PERMANENT
            result["failed"] += 1
            logger.error("DLQ 达最大重试次数: id=%s, retries=%d", dl.id, dl.retry_count)
        else:
            dl.status = DLQStatus.PENDING
            result["skipped"] += 1
        if self._on_replay_failure:
            self._on_replay_failure(dl, error)

    def set_replay_callbacks(
        self,
        on_success: Optional[Callable[[DeadLetter], None]] = None,
        on_failure: Optional[Callable[[DeadLetter, str], None]] = None,
    ) -> None:
        """设置重放回调。"""
        self._on_replay_success = on_success
        self._on_replay_failure = on_failure

    # ------------------------------------------------------------------
    # 查询
    # ------------------------------------------------------------------

    def list_all(self) -> List[DeadLetter]:
        """列出所有死信（按时间倒序）。"""
        dl_list = self._load_all()
        dl_list.sort(key=lambda d: d.failed_at, reverse=True)
        return dl_list

    def list_pending(self) -> List[DeadLetter]:
        """列出所有待重试死信。"""
        return [d for d in self._load_all()
                if d.status == DLQStatus.PENDING]

    def list_permanent(self) -> List[DeadLetter]:
        """列出所有永久失败死信。"""
        return [d for d in self._load_all()
                if d.status == DLQStatus.PERMANENT]

    def _load_all(self) -> List[DeadLetter]:
        """从 JSONL 加载全部死信。"""
        dl_list: List[DeadLetter] = []
        path = self._get_file_path()
        if not os.path.exists(path):
            return dl_list

        with self._lock:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            entry = json.loads(line)
                            dl = self._deserialize(entry)
                            dl_list.append(dl)
                        except (json.JSONDecodeError, KeyError):
                            continue
            except OSError:
                pass

        return dl_list

    @staticmethod
    def _deserialize(entry: Dict[str, Any]) -> DeadLetter:
        """从字典反序列化死信。"""
        event_data = entry.get("event")
        event = None
        if event_data:
            event = Event(
                type=event_data.get("event_type", ""),
                source=event_data.get("source", ""),
                data=event_data.get("data", {}),
                timestamp=datetime.fromisoformat(event_data["timestamp"])
                    if event_data.get("timestamp") else datetime.now(timezone.utc),
                event_id=event_data.get("event_id", ""),
                metadata=event_data.get("metadata", {}),
            )

        status_str = entry.get("status", "pending")
        try:
            status = DLQStatus(status_str)
        except ValueError:
            status = DLQStatus.PENDING

        return DeadLetter(
            id=entry.get("id", ""),
            event=event,
            error=entry.get("error", ""),
            failed_at=datetime.fromisoformat(entry["failed_at"])
                if entry.get("failed_at") else datetime.now(timezone.utc),
            retry_count=entry.get("retry_count", 0),
            max_retries=entry.get("max_retries", 3),
            status=status,
            handler_name=entry.get("handler_name", ""),
        )

    # ------------------------------------------------------------------
    # 统计与清理
    # ------------------------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        """获取统计信息。"""
        all_dl = self._load_all()
        return {
            "total": len(all_dl),
            "pending": sum(1 for d in all_dl if d.status == DLQStatus.PENDING),
            "permanent": sum(1 for d in all_dl if d.status == DLQStatus.PERMANENT),
            "replayed": sum(1 for d in all_dl if d.status == DLQStatus.REPLAYED),
            "storage_dir": self._storage_dir,
        }

    def clear_replayed(self) -> int:
        """清理已重放成功的死信。

        Returns:
            清理的条目数。
        """
        all_dl = self._load_all()
        to_keep = [d for d in all_dl if d.status != DLQStatus.REPLAYED]
        removed = len(all_dl) - len(to_keep)

        # 重写文件
        path = self._get_file_path()
        with self._lock:
            with open(path, "w", encoding="utf-8") as f:
                for dl in to_keep:
                    f.write(json.dumps(
                        DeadLetterQueue._serialize_for_write(dl),
                        ensure_ascii=False,
                    ) + "\n")

        if removed:
            logger.info("DLQ 清理已重放条目: %d 条", removed)
        return removed

    def clear_all(self) -> int:
        """清空所有死信。

        Returns:
            清理的条目数。
        """
        all_dl = self._load_all()
        count = len(all_dl)
        path = self._get_file_path()
        with self._lock:
            if os.path.exists(path):
                os.remove(path)
        logger.info("DLQ 全部清空: %d 条", count)
        return count

    @staticmethod
    def _serialize_for_write(dl: DeadLetter) -> Dict[str, Any]:
        event_data: Optional[Dict[str, Any]] = None
        if dl.event is not None:
            event_data = {
                "event_id": dl.event.event_id,
                "event_type": dl.event.type if isinstance(dl.event.type, str) else dl.event.type.value,
                "source": dl.event.source,
                "timestamp": dl.event.timestamp.isoformat(),
                "data": dl.event.data,
                "metadata": dl.event.metadata,
            }
        return {
            "id": dl.id,
            "event": event_data,
            "error": dl.error,
            "failed_at": dl.failed_at.isoformat(),
            "retry_count": dl.retry_count,
            "max_retries": dl.max_retries,
            "status": dl.status.value,
            "handler_name": dl.handler_name,
        }
