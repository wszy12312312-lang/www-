# events package — EventBus 三子组件
#
# 技术文档要求的 EventBus 三子组件：
#   - Dispatcher（bus.py）：发布/订阅 + 通配符匹配
#   - EventStore（store.py）：不可变追加日志 + 回放
#   - Dead Letter Queue（dead_letter_queue.py）：失败事件隔离与重试

from events.bus import Event, EventBus, EventType, EventHandler, get_default_bus
from events.store import EventStore
from events.dead_letter_queue import (
    DeadLetter,
    DeadLetterQueue,
    DLQStatus,
)

__all__ = [
    "Event",
    "EventBus",
    "EventType",
    "EventHandler",
    "get_default_bus",
    "EventStore",
    "DeadLetter",
    "DeadLetterQueue",
    "DLQStatus",
]
