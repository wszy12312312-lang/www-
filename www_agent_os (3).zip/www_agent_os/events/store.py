"""
EventStore — 事件持久化存储（追加日志）

按技术文档设计：
- 追加日志不可变，仅追加不修改
- JSONL 格式按天分文件
- 支持时间范围/事件类型/源模块过滤回放
- 可选 JSONL (开发) 或 PostgreSQL (生产)

版本: 1.0.0
"""

from __future__ import annotations

import json
import logging
import os
import threading
from datetime import datetime, timezone
from typing import Any, Dict, Generator, Iterator, List, Optional

from events.bus import Event

logger = logging.getLogger(__name__)


class EventStore:
    """事件追加日志存储。

    特性：
    - 不可变追加：只写不修改，保证审计可追溯。
    - JSONL 按天分文件：避免单文件过大。
    - 可配置保留策略（默认 90 天）。
    - 支持按时间/类型/源过滤回放。

    Usage::

        store = EventStore(storage_dir="./data/events")
        store.append(event)
        for event in store.replay(start=start_dt, end=end_dt):
            print(event.type)
    """

    DEFAULT_STORAGE_DIR = "data/events"
    DEFAULT_RETENTION_DAYS = 90
    FLUSH_INTERVAL = 100  # 每 N 条事件 flush 一次

    def __init__(
        self,
        storage_dir: str = "",
        retention_days: int = 0,
    ) -> None:
        self._storage_dir = storage_dir or self.DEFAULT_STORAGE_DIR
        self._retention_days = retention_days or self.DEFAULT_RETENTION_DAYS
        self._lock = threading.RLock()
        self._pending_count: int = 0
        self._total_appended: int = 0

        os.makedirs(self._storage_dir, exist_ok=True)
        logger.info(
            "EventStore 已初始化: dir=%s, retention=%d天",
            self._storage_dir, self._retention_days,
        )

    # ------------------------------------------------------------------
    # 追加
    # ------------------------------------------------------------------

    def _get_file_path(self, timestamp: Optional[datetime] = None) -> str:
        """按日期获取 JSONL 文件路径。"""
        ts = timestamp or datetime.now(timezone.utc)
        date_str = ts.strftime("%Y-%m-%d")
        return os.path.join(self._storage_dir, f"events-{date_str}.jsonl")

    def append(self, event: Event) -> None:
        """追加单条事件到日志（JSONL 格式）。"""
        entry = self._serialize_event(event)
        path = self._get_file_path()

        with self._lock:
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            self._pending_count += 1
            self._total_appended += 1

            if self._pending_count >= self.FLUSH_INTERVAL:
                f.flush()
                self._pending_count = 0

    def append_batch(self, events: List[Event]) -> int:
        """批量追加事件。

        Returns:
            写入的事件数。
        """
        count = 0
        with self._lock:
            for event in events:
                entry = self._serialize_event(event)
                path = self._get_file_path()
                with open(path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
                count += 1
            self._total_appended += count
        return count

    @staticmethod
    def _serialize_event(event: Event) -> Dict[str, Any]:
        """将 Event 序列化为可存储字典。"""
        event_type = event.type if isinstance(event.type, str) else event.type.value
        return {
            "event_id": event.event_id,
            "event_type": event_type,
            "event_version": event.event_version,
            "timestamp": event.timestamp.isoformat(),
            "source": event.source,
            "actor": event.actor,
            "correlation_id": event.correlation_id,
            "causation_id": event.causation_id,
            "payload": event.data,
            "metadata": event.metadata,
        }

    # ------------------------------------------------------------------
    # 回放
    # ------------------------------------------------------------------

    def replay(
        self,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
        event_type: str = "",
        source: str = "",
        limit: int = 0,
    ) -> Generator[Event, None, None]:
        """回放事件（时间倒序，即从最新到最旧）。

        Args:
            start: 起始时间（含），None 表示不限。
            end: 结束时间（含），None 表示不限。
            event_type: 事件类型过滤（支持通配符 *）。
            source: 源模块过滤。
            limit: 最大返回数，0 表示不限。

        Yields:
            Event 对象。
        """
        yielded = 0

        # 扫描 JSONL 文件（按日期排序，从新到旧）
        files = sorted(
            [f for f in os.listdir(self._storage_dir) if f.endswith(".jsonl")],
            reverse=True,
        )

        for fname in files:
            path = os.path.join(self._storage_dir, fname)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                    # 文件内也从后往前读（最新的在末尾）
                    for line in reversed(lines):
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            entry = json.loads(line)
                        except json.JSONDecodeError:
                            continue

                        # 时间过滤
                        ts_str = entry.get("timestamp", "")
                        if not ts_str:
                            continue
                        try:
                            ts = datetime.fromisoformat(ts_str)
                        except ValueError:
                            continue

                        if start and ts < start:
                            continue
                        if end and ts > end:
                            continue

                        # 类型过滤
                        et = entry.get("event_type", "")
                        if event_type:
                            if event_type == "*":
                                pass
                            elif "*" in event_type:
                                # 简单通配符匹配
                                import fnmatch
                                if not fnmatch.fnmatch(et, event_type):
                                    continue
                            elif et != event_type:
                                continue

                        # 源过滤
                        if source and entry.get("source", "") != source:
                            continue

                        event = Event(
                            type=et,
                            source=entry.get("source", ""),
                            data=entry.get("payload", {}),
                            timestamp=ts,
                            event_id=entry.get("event_id", ""),
                            event_version=entry.get("event_version", 1),
                            actor=entry.get("actor", ""),
                            correlation_id=entry.get("correlation_id", ""),
                            causation_id=entry.get("causation_id", ""),
                            metadata=entry.get("metadata", {}),
                        )
                        yielded += 1
                        yield event

                        if limit and yielded >= limit:
                            return
            except Exception:
                continue

    def get_file_range(self) -> Dict[str, str]:
        """获取存储文件的时间范围。

        Returns:
            {'earliest': '2026-07-01', 'latest': '2026-07-14'}
        """
        files = sorted([
            f for f in os.listdir(self._storage_dir) if f.endswith(".jsonl")
        ])
        if not files:
            return {"earliest": "", "latest": ""}
        return {
            "earliest": files[0].replace("events-", "").replace(".jsonl", ""),
            "latest": files[-1].replace("events-", "").replace(".jsonl", ""),
        }

    # ------------------------------------------------------------------
    # 统计
    # ------------------------------------------------------------------

    @property
    def total_appended(self) -> int:
        """已追加事件总数（本次运行期间）。"""
        return self._total_appended

    def stats(self) -> Dict[str, Any]:
        """获取存储统计信息。"""
        file_ranges = self.get_file_range()
        total_size = 0
        file_count = 0
        for fname in os.listdir(self._storage_dir):
            if fname.endswith(".jsonl"):
                total_size += os.path.getsize(os.path.join(self._storage_dir, fname))
                file_count += 1

        return {
            "storage_dir": self._storage_dir,
            "retention_days": self._retention_days,
            "file_count": file_count,
            "total_size_bytes": total_size,
            "total_appended": self._total_appended,
            "file_range": file_ranges,
        }

    # ------------------------------------------------------------------
    # 清理
    # ------------------------------------------------------------------

    def purge_expired(self) -> int:
        """清理超过保留天数的日志文件。

        Returns:
            删除的文件数。
        """
        removed = 0
        cutoff = (datetime.now(timezone.utc).timestamp() -
                  self._retention_days * 86400)

        for fname in os.listdir(self._storage_dir):
            if not fname.endswith(".jsonl"):
                continue
            path = os.path.join(self._storage_dir, fname)
            try:
                mtime = os.path.getmtime(path)
                if mtime < cutoff:
                    os.remove(path)
                    removed += 1
                    logger.info("EventStore 清理过期文件: %s", fname)
            except OSError:
                continue

        return removed
