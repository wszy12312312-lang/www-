@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo WWW Agent OS v10.7.0 - GUI Mode
echo.

REM Check if customtkinter is available
python -c "import customtkinter" 2>nul
if %errorlevel% neq 0 (
    echo [INFO] Installing dependencies...
    pip install -r requirements.txt -q
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to install dependencies. Run: pip install -r requirements.txt
        pause
        exit /b 1
    )
)

REM Locate pythonw.exe for no-console mode
set PYTHONW=
if exist "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe" set PYTHONW=%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe
if exist "%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe" set PYTHONW=%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe
if not defined PYTHONW set PYTHONW=pythonw.exe

if "%1"=="--debug" (
    python ui\legacy_gui.py
) else (
    "%PYTHONW%" ui\legacy_gui.py
)
