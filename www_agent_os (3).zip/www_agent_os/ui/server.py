"""
WWW Agent OS Web UI Server
本地静态资源服务 + 后端 API 反向代理
"""
import http.server
import urllib.request
import urllib.error
import os
import json
import re
import ssl
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
UI_DIR = Path(__file__).resolve().parent
BACKEND_BASE = "https://4kkphkhkxce9s.aiforce.cloud"
PORT = 8080

# 需要代理的 API 路径前缀
API_PROXY_PREFIXES = [
    f"/app/app_17a1pg6agkc/__runtime__/",
    "/app/app_17a1pg6agkc/api/",
]


class WWWProxyHandler(http.server.SimpleHTTPRequestHandler):
    """自定义请求处理器：静态文件 + API 反向代理"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(UI_DIR), **kwargs)

    def do_GET(self):
        # API 代理
        if self._should_proxy(self.path):
            self._proxy_request("GET")
            return
        # 根路径返回 index.html
        if self.path == "/" or self.path == "":
            self._serve_index()
            return
        # SPA fallback：非静态资源路径返回 index.html
        if not self._is_static_asset(self.path):
            self._serve_index()
            return
        super().do_GET()

    def do_POST(self):
        if self._should_proxy(self.path):
            self._proxy_request("POST")
            return
        self.send_error(404, "Not Found")

    def do_PUT(self):
        if self._should_proxy(self.path):
            self._proxy_request("PUT")
            return
        self.send_error(404, "Not Found")

    def do_DELETE(self):
        if self._should_proxy(self.path):
            self._proxy_request("DELETE")
            return
        self.send_error(404, "Not Found")

    def do_OPTIONS(self):
        if self._should_proxy(self.path):
            self._proxy_request("OPTIONS")
            return
        self.send_error(404, "Not Found")

    def do_PATCH(self):
        if self._should_proxy(self.path):
            self._proxy_request("PATCH")
            return
        self.send_error(404, "Not Found")

    def _should_proxy(self, path: str) -> bool:
        for prefix in API_PROXY_PREFIXES:
            if path.startswith(prefix):
                return True
        return False

    def _is_static_asset(self, path: str) -> bool:
        static_exts = {".js", ".css", ".html", ".png", ".jpg", ".jpeg",
                       ".gif", ".svg", ".ico", ".woff", ".woff2", ".ttf",
                       ".json", ".xml", ".txt", ".map", ".webp", ".mp4"}
        _, ext = os.path.splitext(path)
        return ext.lower() in static_exts or path.startswith("/assets/")

    def _serve_index(self):
        index_path = UI_DIR / "index.html"
        try:
            with open(index_path, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except FileNotFoundError:
            self.send_error(404, "index.html not found")

    def _proxy_request(self, method: str):
        target_url = BACKEND_BASE + self.path
        if self.path.find("?") == -1 and self.path.find("#") == -1:
            query = self.path.find("?") == -1
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length > 0 else None

        req = urllib.request.Request(target_url, data=body, method=method)

        # 转发关键请求头
        forward_headers = [
            "Content-Type", "Authorization", "Accept", "Accept-Language",
            "X-Requested-With", "X-CSRF-Token", "X-XSRF-TOKEN",
            "Referer", "Origin", "User-Agent"
        ]
        for h in forward_headers:
            val = self.headers.get(h)
            if val:
                req.add_header(h, val)

        # Cookie 转发
        cookie = self.headers.get("Cookie")
        if cookie:
            req.add_header("Cookie", cookie)

        # 忽略 SSL 验证（仅本地开发）
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        try:
            resp = urllib.request.urlopen(req, context=ctx, timeout=30)
            self.send_response(resp.status)
            for k, v in resp.getheaders():
                if k.lower() not in ("transfer-encoding", "connection"):
                    self.send_header(k, v)
            self.end_headers()
            self.wfile.write(resp.read())
        except urllib.error.HTTPError as e:
            self.send_response(e.code)
            self.end_headers()
            self.wfile.write(e.read())
        except Exception as e:
            print(f"[Proxy Error] {method} {self.path}: {e}")
            self.send_error(502, f"Backend unavailable: {e}")

    def log_message(self, format, *args):
        # 精简日志
        if "/assets/" in args[1] or "favicon" in args[1]:
            return
        print(f"[WWW-UI] {args[1]} - {args[0]}")


def main():
    print(f"""
========================================
  WWW Agent OS Web UI v10.7.0
========================================
  Local:    http://localhost:{PORT}
  Backend:  {BACKEND_BASE}
  UI Dir:   {UI_DIR}
========================================
""")
    server = http.server.HTTPServer(("0.0.0.0", PORT), WWWProxyHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[WWW-UI] Server stopped.")
        server.server_close()


if __name__ == "__main__":
    main()
