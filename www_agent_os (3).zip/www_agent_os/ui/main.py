"""
www 智能体协作系统 v10.7.0 — Desktop GUI
界面风格高度还原 Web UI；自检对接 check_all_models
"""
from __future__ import annotations
import os, sys, shutil, threading, traceback
from datetime import datetime
from pathlib import Path

_UI_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _UI_DIR.parent
sys.path.insert(0, str(_PROJECT_ROOT))

import customtkinter as ctk

from services.ollama_service import WWWSystem
from config.app_config import PERSONAS, PERSONA_MODELS


# ═══════════════════════════════════════════════════
# 配色
# ═══════════════════════════════════════════════════
C = {
    "bg_main":          "#0d1117",
    "bg_panel":         "#161b22",
    "bg_card":          "#161b22",
    "bg_input":         "#0d1117",
    "bg_user_bubble":   "#1a2332",
    "bg_bot_bubble":    "#161b22",
    "text_primary":     "#c9d1d9",
    "text_secondary":   "#8b949e",
    "text_muted":       "#484f58",
    "border":           "#30363d",
    "border_light":     "#21262d",
    "accent_blue":      "#58a6ff",
    "accent_green":     "#3fb950",
    "accent_red":       "#da3633",
    "accent_orange":    "#d29922",
    "accent_cyan":      "#39d2c0",
    "btn_send":         "#1f6feb",
    "btn_send_hover":   "#388bfd",
}

# 基准字体定义 (family, base_size, weight)
_FONT_BASE = {
    "title":    ("Microsoft YaHei UI", 16, "bold"),
    "heading":  ("Microsoft YaHei UI", 13, "bold"),
    "body":     ("Microsoft YaHei UI", 12),
    "small":    ("Microsoft YaHei UI", 11),
    "mono":     ("Consolas", 11),
    "mono_s":   ("Consolas", 10),
    "mono_xs":  ("Consolas", 9),
}

# 基准窗口尺寸 & 全局缩放
_BASE_W, _BASE_H = 1100, 700
_scale = 1.0

def scaled_font(key: str):
    """返回按当前窗口缩放比例的 CTkFont"""
    family, size, *rest = _FONT_BASE[key]
    weight = rest[0] if rest else "normal"
    return ctk.CTkFont(family=family, size=int(size * _scale), weight=weight)

# 延迟初始化 — 等 Tk 根窗口创建后再填充
FONT = {}


# ═══════════════════════════════════════════════════
# 后端桥接
# ═══════════════════════════════════════════════════
class BackendBridge:
    def __init__(self, system: WWWSystem):
        self.system = system

    def chat(self, persona_id: str, message: str, callback, progress_callback=None):
        def _run():
            try:
                if persona_id == "host":
                    # 检查是否有待处理的确认请求
                    if self.system.has_pending_confirmations():
                        # 用户回复确认请求 → 走恢复回路
                        final_reply, host_reasoning, host_analysis, sub_results = (
                            self.system.host_resume_with_confirmation(
                                user_decision=message,
                                pending_confirmations=self.system._pending_confirmations,
                                sub_results=self.system._last_sub_results,
                                host_reasoning=self.system._last_host_reasoning,
                                host_analysis=self.system._last_host_analysis,
                            )
                        )
                    else:
                        # 无待处理确认 → 正常编排
                        final_reply, host_reasoning, host_analysis, sub_results = (
                            self.system.host_orchestrate(message, progress_callback=progress_callback)
                        )
                    if not final_reply:
                        final_reply = "任务处理未产生有效结果，请重试或简化任务描述。"
                    callback(final_reply, host_reasoning, host_analysis, sub_results)
                else:
                    reply, _ = self.system.chat(persona_id, message)
                    callback(reply)
            except Exception as e:
                callback(f"[错误] {e}")
        threading.Thread(target=_run, daemon=True).start()

    def check_models(self, progress_callback):
        def _run():
            try:
                self.system.check_all_models(progress_callback=progress_callback)
            except Exception:
                traceback.print_exc()
        threading.Thread(target=_run, daemon=True).start()


# ═══════════════════════════════════════════════════
# 聊天气泡
# ═══════════════════════════════════════════════════
class ChatBubble(ctk.CTkFrame):
    def __init__(self, master, role: str, text: str, ts: str = "", **kw):
        is_user = (role == "user")
        bg = C["bg_user_bubble"] if is_user else C["bg_bot_bubble"]
        super().__init__(master, fg_color=C["bg_main"], corner_radius=0, **kw)

        inner = ctk.CTkFrame(self, fg_color=bg, corner_radius=10,
                             border_width=1, border_color=C["border_light"])
        inner.pack(anchor="w" if is_user else "e", padx=8, pady=3)

        role_name = "你" if is_user else "www"
        role_color = C["accent_blue"] if is_user else C["accent_green"]
        header = ctk.CTkFrame(inner, fg_color="transparent")
        header.pack(fill="x", padx=10, pady=(8, 0))
        ctk.CTkLabel(header, text=role_name, font=FONT["small"],
                     text_color=role_color).pack(side="left")
        if ts:
            ctk.CTkLabel(header, text=ts, font=FONT["mono_xs"],
                         text_color=C["text_muted"]).pack(side="right")

        lbl = ctk.CTkLabel(
            inner, text=text, font=FONT["body"], text_color=C["text_primary"],
            wraplength=520, justify="left", anchor="w",
        )
        lbl.pack(fill="x", padx=12, pady=(4, 10))
        self._text_label = lbl


# ═══════════════════════════════════════════════════
# 角色状态卡片
# ═══════════════════════════════════════════════════
class PersonaCard(ctk.CTkFrame):
    def __init__(self, master, pid: str, info: dict, system: WWWSystem, **kw):
        super().__init__(master, fg_color=C["bg_card"], corner_radius=8,
                         border_width=1, border_color=C["border_light"], **kw)
        self.pid = pid
        self.info = info
        self.system = system
        color = info.get("color", C["accent_blue"])

        # 上方：图标 + 名称 + 状态
        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=10, pady=(10, 2))

        icon = ctk.CTkFrame(top, width=36, height=36, fg_color=color, corner_radius=6)
        icon.pack(side="left")
        icon.pack_propagate(False)
        ctk.CTkLabel(icon, text=info.get("icon", pid[0].upper()),
                     font=FONT["mono"], text_color="#fff").pack(expand=True)

        mid = ctk.CTkFrame(top, fg_color="transparent")
        mid.pack(side="left", fill="x", expand=True, padx=(10, 0))
        ctk.CTkLabel(mid, text=info.get("name", pid), font=FONT["heading"],
                     text_color=C["text_primary"]).pack(anchor="w")
        ctk.CTkLabel(mid, text=PERSONA_MODELS.get(pid, "?"), font=FONT["mono_s"],
                     text_color=C["text_muted"]).pack(anchor="w")

        self._badge = ctk.CTkLabel(top, text="自检中", font=FONT["mono_xs"],
                                   text_color=C["accent_orange"])
        self._badge.pack(side="right")

        # 健康度进度条
        bar_bg = ctk.CTkFrame(self, fg_color=C["border_light"], height=5, corner_radius=3)
        bar_bg.pack(fill="x", padx=10, pady=(6, 2))
        self._bar = ctk.CTkFrame(bar_bg, fg_color=color, height=5, corner_radius=3, width=10)
        self._bar.place(relx=0, rely=0, relheight=1, relwidth=0.1)

        # 底部：评分
        bot = ctk.CTkFrame(self, fg_color="transparent")
        bot.pack(fill="x", padx=10, pady=(2, 10))
        ctk.CTkLabel(bot, text="评分", font=FONT["small"],
                     text_color=C["text_secondary"]).pack(side="left")
        self._score_lbl = ctk.CTkLabel(bot, text="—", font=FONT["mono_s"],
                                       text_color=C["accent_green"])
        self._score_lbl.pack(side="right")

    def refresh(self):
        """刷新卡片状态，无 health_score 时从已有字段推算"""
        try:
            state = self.system.states[self.pid]
        except KeyError:
            return

        # 健康分：优先 health_score，否则基于 task_score * 20 或 incent_stars * 20
        score_raw = getattr(state, "health_score", None)
        if score_raw is not None:
            score = score_raw
        elif state.task_score > 0:
            score = round(state.task_score * 20)
        else:
            score = state.incentive_stars * 20
        score = min(max(score, 0), 100)

        if state.model_online is True:
            self._badge.configure(text="就绪", text_color=C["accent_green"])
            self._bar.configure(fg_color=C["accent_green"])
            self._bar.place(relwidth=score / 100.0)
            self._score_lbl.configure(text=f"+{score}")
        elif state.model_online is False:
            self._badge.configure(text="离线", text_color=C["accent_red"])
            self._bar.configure(fg_color=C["accent_red"])
            self._bar.place(relwidth=max(0.05, score / 100.0))
            self._score_lbl.configure(text=f"{score}")
        else:
            self._badge.configure(text="自检中", text_color=C["accent_orange"])
            self._bar.configure(fg_color=self.info.get("color", C["accent_orange"]))
            self._bar.place(relwidth=0.125)
            self._score_lbl.configure(text="...")


# ═══════════════════════════════════════════════════
# 主窗口
# ═══════════════════════════════════════════════════
class WWWApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Tk 根窗口已创建，初始化字体
        global FONT
        FONT = {k: scaled_font(k) for k in _FONT_BASE}

        self.title("www 智能体协作系统 v10.7.0")
        self.geometry("1100x700")
        self.minsize(900, 540)
        self.configure(fg_color=C["bg_main"])
        ctk.set_appearance_mode("dark")
        try:
            ctk.set_default_color_theme("dark-blue")
        except Exception:
            pass
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.geometry(f"+{(sw - 1100) // 2}+{(sh - 700) // 2}")

        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.system = WWWSystem()
        self.bridge = BackendBridge(self.system)
        self._running = False
        self._interrupted = False
        self._task_queue: list = []
        self._persona_cards: dict[str, PersonaCard] = {}
        self._check_count = 0
        self._resize_after_id = None
        self._spin_stopped = False

        self._build_header()
        self._build_main_area()
        self._build_footer()

        self.after(300, self._start_health_check)

        # 启动横幅旋转动画
        self._spin_chars = ["◌", "○", "◌", "○"]
        self._spin_idx = 0
        self._spin_anim()

        # 窗口缩放 → 响应式字体
        self.bind("<Configure>", self._on_configure)

    # ── 头部 ──────────────────────────────────────
    def _build_header(self):
        bar = ctk.CTkFrame(self, fg_color=C["bg_panel"], height=52, corner_radius=0)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        logo = ctk.CTkFrame(bar, width=30, height=30, corner_radius=15, fg_color="#f59e0b")
        logo.pack(side="left", padx=(14, 8), pady=11)
        logo.pack_propagate(False)
        ctk.CTkLabel(logo, text="W", font=FONT["mono"], text_color="#fff").pack(expand=True)

        ctk.CTkLabel(bar, text="www智能体", font=FONT["title"],
                     text_color=C["text_primary"]).pack(side="left")
        self._model_label = ctk.CTkLabel(bar, text=PERSONA_MODELS.get("host", ""),
                                         font=FONT["mono_s"], text_color=C["text_muted"])
        self._model_label.pack(side="left", padx=(6, 0))

        right = ctk.CTkFrame(bar, fg_color="transparent")
        right.pack(side="right", padx=12)

        skills_btn = ctk.CTkButton(
            right, text="技能库", width=72, height=28, font=ctk.CTkFont(size=11),
            fg_color=C["bg_card"], hover_color=C["border"], corner_radius=6,
            border_width=1, border_color=C["border_light"],
            text_color=C["text_secondary"], command=self._open_skills,
        )
        skills_btn.pack(side="right", padx=(6, 0))

        self._status_dot = ctk.CTkLabel(right, text="● 自检中", font=FONT["mono_xs"],
                                        text_color=C["accent_orange"])
        self._status_dot.pack(side="right")

    # ── 主区域 ────────────────────────────────────
    def _build_main_area(self):
        main = ctk.CTkFrame(self, fg_color="transparent")
        main.pack(fill="both", expand=True)
        main.grid_columnconfigure(0, weight=3)
        main.grid_columnconfigure(1, weight=1)
        main.grid_rowconfigure(0, weight=1)
        self._build_chat(main)
        self._build_sidebar(main)

    def _build_chat(self, parent):
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.grid(row=0, column=0, sticky="nsew", padx=(4, 2), pady=4)
        frame.grid_rowconfigure(0, weight=0)
        frame.grid_rowconfigure(1, weight=1)
        frame.grid_rowconfigure(2, weight=0)
        frame.grid_columnconfigure(0, weight=1)

        # ── 状态横幅（聊天框上方，自检期间持续显示） ──
        self._banner = ctk.CTkFrame(frame, fg_color=C["bg_panel"], corner_radius=8,
                                    border_width=1, border_color=C["border_light"])
        self._banner.grid(row=0, column=0, sticky="ew", padx=6, pady=(4, 2))
        banner_inner = ctk.CTkFrame(self._banner, fg_color="transparent")
        banner_inner.pack(fill="x", padx=12, pady=6)
        self._banner_spin = ctk.CTkLabel(banner_inner, text="◌", font=FONT["mono_s"],
                                         text_color=C["text_muted"])
        self._banner_spin.pack(side="left", padx=(0, 6))
        # 三色分段：www / v10.7.0 / - 动态文案
        self._banner_p1 = ctk.CTkLabel(banner_inner, text="www", font=FONT["small"],
                                       text_color=C["text_muted"])
        self._banner_p1.pack(side="left")
        self._banner_p2 = ctk.CTkLabel(banner_inner, text="v10.7.0", font=FONT["small"],
                                       text_color=C["accent_cyan"])
        self._banner_p2.pack(side="left")
        self._banner_p3 = ctk.CTkLabel(banner_inner, text=" - www 智能体 启动中...",
                                       font=FONT["small"], text_color=C["text_muted"])
        self._banner_p3.pack(side="left")

        self._chat_scroll = ctk.CTkScrollableFrame(
            frame, fg_color="transparent",
            scrollbar_button_color=C["border"],
            scrollbar_button_hover_color=C["text_muted"],
        )
        self._chat_scroll.grid(row=1, column=0, sticky="nsew", pady=(4, 0))
        self._chat_scroll.grid_columnconfigure(0, weight=1)

        input_frame = ctk.CTkFrame(frame, fg_color=C["bg_panel"], corner_radius=10,
                                   border_width=1, border_color=C["border_light"])
        input_frame.grid(row=2, column=0, sticky="ew", padx=6, pady=(6, 8))

        inner = ctk.CTkFrame(input_frame, fg_color="transparent")
        inner.pack(fill="x", padx=8, pady=6)

        self._input = ctk.CTkTextbox(
            inner, font=FONT["body"], fg_color=C["bg_input"],
            text_color=C["text_primary"], height=48, corner_radius=8,
            activate_scrollbars=False, border_width=0,
        )
        self._input.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self._input.bind("<Return>", self._on_enter)
        self._input.bind("<Shift-Return>", lambda e: None)

        self._send_btn = ctk.CTkButton(
            inner, text="发送", width=68, height=36, font=FONT["body"],
            fg_color=C["btn_send"], hover_color=C["btn_send_hover"],
            command=self._send_message,
        )
        self._send_btn.pack(side="right")

        self._interrupt_btn = ctk.CTkButton(
            inner, text="中断", width=68, height=36, font=FONT["body"],
            fg_color=C["accent_red"], hover_color="#c62828",
            command=self._interrupt_task,
        )

    def _build_sidebar(self, parent):
        sidebar = ctk.CTkFrame(parent, fg_color=C["bg_panel"], corner_radius=8,
                               border_width=1, border_color=C["border_light"])
        sidebar.grid(row=0, column=1, sticky="nsew", padx=(2, 4), pady=4)

        hdr = ctk.CTkFrame(sidebar, fg_color="transparent")
        hdr.pack(fill="x", padx=12, pady=(12, 6))
        ctk.CTkLabel(hdr, text="状态检测表", font=FONT["heading"],
                     text_color=C["text_primary"]).pack(side="left")
        total = len(PERSONA_MODELS)
        self._check_label = ctk.CTkLabel(hdr, text=f"0/{total} 检测中", font=FONT["mono_s"],
                                         text_color=C["accent_orange"])
        self._check_label.pack(side="right")

        self._sidebar_scroll = ctk.CTkScrollableFrame(
            sidebar, fg_color="transparent", scrollbar_button_color=C["border"],
        )
        self._sidebar_scroll.pack(fill="both", expand=True, padx=8)

        for pid, info in PERSONAS.items():
            card = PersonaCard(self._sidebar_scroll, pid, info, self.system)
            card.pack(fill="x", pady=2)
            self._persona_cards[pid] = card

        sep = ctk.CTkFrame(sidebar, fg_color=C["border_light"], height=1)
        sep.pack(fill="x", padx=12, pady=(8, 6))

        qhdr = ctk.CTkFrame(sidebar, fg_color="transparent")
        qhdr.pack(fill="x", padx=12, pady=(2, 2))
        ctk.CTkLabel(qhdr, text="任务队列", font=FONT["heading"],
                     text_color=C["text_primary"]).pack(side="left")
        self._queue_count_lbl = ctk.CTkLabel(qhdr, text="0", font=FONT["mono_s"],
                                             text_color=C["text_muted"])
        self._queue_count_lbl.pack(side="right")
        self._queue_placeholder = ctk.CTkLabel(sidebar, text="暂无待处理任务", font=FONT["small"],
                                               text_color=C["text_muted"])
        self._queue_placeholder.pack(pady=(0, 10))
        self._queue_frame = ctk.CTkFrame(sidebar, fg_color="transparent")
        # 初始不 pack，有任务时才显示

        bot = ctk.CTkFrame(sidebar, fg_color="transparent")
        bot.pack(fill="x", padx=12, pady=(6, 10))
        ctk.CTkLabel(bot, text="Ollama 本地 · 8 模型独立运行",
                     font=FONT["mono_s"], text_color=C["text_muted"]).pack(side="left")

    # ── 底部 ──────────────────────────────────────
    def _build_footer(self):
        bar = ctk.CTkFrame(self, fg_color=C["bg_panel"], height=28, corner_radius=0)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        inner = ctk.CTkFrame(bar, fg_color="transparent")
        inner.pack(fill="x", padx=12, pady=4)
        ctk.CTkLabel(inner, text="● Ollama 本地", font=FONT["mono_xs"],
                     text_color=C["accent_green"]).pack(side="left")
        ctk.CTkLabel(inner, text="8 模型独立运行", font=FONT["mono_xs"],
                     text_color=C["text_muted"]).pack(side="left", padx=(4, 0))
        ctk.CTkLabel(inner, text="GPU 正常", font=FONT["mono_xs"],
                     text_color=C["text_muted"]).pack(side="right", padx=(8, 0))
        ctk.CTkLabel(inner, text="本地连接", font=FONT["mono_xs"],
                     text_color=C["text_muted"]).pack(side="right")

    # ── 发送消息 ──────────────────────────────────
    def _on_enter(self, event):
        if event.state & 0x4:
            return
        self._send_message()
        return "break"

    def _send_message(self):
        text = self._input.get("1.0", "end-1c").strip()
        if not text:
            return
        self._input.delete("1.0", "end")

        # 当前有任务在跑 → 加入队列
        if self._running:
            self._task_queue.append(text)
            self._update_queue_display()
            return

        self._running = True
        self._interrupted = False
        # 两按钮共存：发送 + 中断
        self._send_btn.pack_forget()
        self._send_btn.pack(side="right")
        self._interrupt_btn.pack(side="right")
        self._status_dot.configure(text="● 执行中", text_color=C["accent_cyan"])

        ts = datetime.now().strftime("%H:%M")
        self._add_bubble("user", text, ts)

        self._thinking_bubble = ChatBubble(self._chat_scroll, "assistant", "思考中…", ts)
        self._thinking_bubble.pack(fill="x", pady=3)
        self._scroll_bottom()

        self.bridge.chat("host", text, self._on_reply,
                         progress_callback=self._on_scoring_progress)

    def _on_scoring_progress(self, stage: str, detail: str):
        """评分进度回调：后台线程调用，评分完成后实时渲染气泡+刷新卡片"""
        if stage == "score":
            # 保留兼容：旧版 score stage 仅刷新侧边栏
            parts = detail.split(":")
            if len(parts) >= 2:
                pid = parts[0]
                def _refresh_card():
                    card = self._persona_cards.get(pid)
                    if card:
                        card.refresh()
                self.after(0, _refresh_card)

        elif stage == "subtask_scored":
            import json
            data = json.loads(detail)
            pid = data["persona"]
            name = data["name"]

            def _render_subtask_bubble():
                # 收集已完成人格，用于去重：同一人格只渲染一次
                if not hasattr(self, "_rendered_subtasks"):
                    self._rendered_subtasks = set()
                if pid in self._rendered_subtasks:
                    return
                self._rendered_subtasks.add(pid)

                if data.get("error"):
                    self._add_system_msg(f"{name}: {data['error']}", C["accent_red"])
                else:
                    thinking_text = data.get("reasoning", "")
                    if thinking_text:
                        self._add_bubble("assistant",
                                         f"**{name} 思考**\n{thinking_text[:300]}")

                    # 回复正文 + 评分
                    reply_lines = [f"**{name}**\n{data['reply'][:500]}"]
                    score = data.get("score")
                    if score is not None:
                        stars = "★" * int(round(score)) + "☆" * (5 - int(round(score)))
                        reply_lines.append(
                            f"\n── S监察员评分：{stars} {score:.1f}/5"
                        )
                        comment = data.get("comment", "")
                        if comment:
                            reply_lines.append(f"_{comment}_")
                    self._add_bubble("assistant", "\n".join(reply_lines))

                # 同时刷新侧边栏该人格卡片
                card = self._persona_cards.get(pid)
                if card:
                    try:
                        card.refresh()
                    except Exception:
                        pass
                self._scroll_bottom()

            self.after(0, _render_subtask_bubble)

    def _on_reply(self, reply: str, host_reasoning: str = "", host_analysis: str = "",
                  sub_results: list = None):
        def _update():
            if self._interrupted:
                return  # 已中断，丢弃此回复
            # 移除思考气泡
            if hasattr(self, "_thinking_bubble") and self._thinking_bubble.winfo_exists():
                self._thinking_bubble.destroy()
                del self._thinking_bubble

            # 副人格气泡已通过 _on_scoring_progress("subtask_scored") 增量渲染，
            # 此处不再重复渲染，仅清除去重标记供下一次任务使用
            if hasattr(self, "_rendered_subtasks"):
                del self._rendered_subtasks

            # 渲染 HOST 最终回复
            self._add_bubble("assistant", reply)
            self._running = False
            self._interrupt_btn.pack_forget()
            self._input.focus()
            self._scroll_bottom()
            self._safe_refresh()
            # 处理队列中的下一条消息
            self.after(0, self._process_queue)
        self.after(0, _update)

    def _interrupt_task(self):
        """中断当前正在执行的任务"""
        self._interrupted = True
        self._running = False

        # 移除思考气泡
        if hasattr(self, "_thinking_bubble") and self._thinking_bubble.winfo_exists():
            self._thinking_bubble.destroy()
            del self._thinking_bubble

        # 恢复按钮
        self._interrupt_btn.pack_forget()

        # 恢复状态
        self._status_dot.configure(text="● 就绪", text_color=C["accent_green"])
        self._input.focus()

        # 处理队列中的下一条消息
        self.after(0, self._process_queue)

    # ── 任务队列 ──────────────────────────────────
    def _process_queue(self):
        """队列非空且空闲时，取出下一条任务自动发送"""
        if self._running or not self._task_queue:
            # 队列空了，恢复单发送按钮
            self._send_btn.pack(side="right")
            return
        next_text = self._task_queue.pop(0)
        self._update_queue_display()
        # 将消息写入输入框并触发发送
        self._input.insert("1.0", next_text)
        self._send_message()

    def _remove_from_queue(self, index: int):
        """从任务队列中移除指定索引的任务"""
        if 0 <= index < len(self._task_queue):
            self._task_queue.pop(index)
            self._update_queue_display()

    def _update_queue_display(self):
        """刷新侧边栏任务队列 UI，每项附带×取消按钮"""
        count = len(self._task_queue)
        self._queue_count_lbl.configure(text=str(count),
                                        text_color=C["accent_orange"] if count else C["text_muted"])

        # 清空队列 frame 中的旧项
        for w in self._queue_frame.winfo_children():
            w.destroy()

        if count == 0:
            self._queue_frame.pack_forget()
            self._queue_placeholder.pack(pady=(0, 10))
        else:
            self._queue_placeholder.pack_forget()
            self._queue_frame.pack(fill="x", padx=8, pady=(2, 6))
            for i, task_text in enumerate(self._task_queue):
                short = task_text[:24] + "…" if len(task_text) > 24 else task_text

                # 每行用 frame 包裹 label + ×按钮
                row = ctk.CTkFrame(self._queue_frame, fg_color="transparent")
                row.pack(fill="x", pady=1)

                ctk.CTkLabel(
                    row,
                    text=f"#{i+1} {short}",
                    font=FONT["mono_s"],
                    text_color=C["text_muted"],
                    anchor="w",
                ).pack(side="left", fill="x", expand=True)

                ctk.CTkButton(
                    row,
                    text="×",
                    width=22,
                    height=22,
                    font=FONT["mono_s"],
                    fg_color="transparent",
                    hover_color=C["accent_red"],
                    text_color=C["text_muted"],
                    corner_radius=4,
                    command=lambda idx=i: self._remove_from_queue(idx),
                ).pack(side="right")

    # ── UI 辅助 ────────────────────────────────────
    def _add_bubble(self, role: str, text: str, ts: str = ""):
        ChatBubble(self._chat_scroll, role, text, ts).pack(fill="x", pady=3)

    def _add_system_msg(self, text: str, color: str = None):
        ctk.CTkLabel(self._chat_scroll, text=text, font=FONT["mono_s"],
                     text_color=color or C["text_muted"]).pack(pady=3)

    def _scroll_bottom(self):
        try:
            self._chat_scroll._parent_canvas.yview_moveto(1.0)
        except Exception:
            pass

    def _safe_refresh(self):
        """逐个 refresh 卡片，单张异常不影响其他"""
        for pid, card in self._persona_cards.items():
            try:
                card.refresh()
            except Exception:
                pass
        # 全局状态灯
        try:
            if self._running:
                self._status_dot.configure(text="● 执行中", text_color=C["accent_cyan"])
            else:
                states = [s for s in self.system.states.values() if s is not None]
                all_done = len(states) == len(PERSONA_MODELS) and all(
                    s.model_online is not None for s in states
                )
                if all_done:
                    if any(s.model_online for s in states):
                        self._status_dot.configure(text="● 就绪", text_color=C["accent_green"])
                    else:
                        self._status_dot.configure(text="● 离线", text_color=C["accent_orange"])
                # 未全部完成时保持"自检中"
        except Exception:
            pass

    # ── 健康检查 ──────────────────────────────────
    def _start_health_check(self):
        self._check_count = 0
        total = len(PERSONA_MODELS)

        def _on_progress(pid, done, t):
            self._check_count = done
            pname = PERSONAS.get(pid, {}).get("name", pid)
            def _update():
                label_text = f"{done}/{total} 检测中" if done < total else f"{done}/{total} 就绪"
                label_color = C["accent_orange"] if done < total else C["accent_green"]
                self._check_label.configure(text=label_text, text_color=label_color)
                # 更新横幅文案为当前完成的专员
                if done < total:
                    self._banner_p3.configure(text=f" - {pname}自检完成...")
                else:
                    self._spin_stopped = True
                    self._banner_spin.configure(text="●", text_color=C["accent_green"])
                    self._banner_p2.configure(text_color=C["accent_green"])
                    self._banner_p3.configure(text=" - www 智能体已就绪...",
                                              text_color=C["accent_green"])
                self._safe_refresh()
            self.after(0, _update)

        self.bridge.check_models(_on_progress)
        # 自检仅执行一次；后续状态通过聊天回复后的 _safe_refresh 更新

    # ── 响应式字体 ────────────────────────────────
    def _spin_anim(self):
        """横幅旋转动画（完成自检后自动停止）"""
        try:
            if not self._banner_spin.winfo_exists():
                return
            # 已停止动画则退出
            if getattr(self, "_spin_stopped", False):
                return
            self._spin_idx = (self._spin_idx + 1) % len(self._spin_chars)
            self._banner_spin.configure(text=self._spin_chars[self._spin_idx])
            self.after(800, self._spin_anim)
        except Exception:
            pass

    def _on_configure(self, event):
        """窗口尺寸变化时，防抖后更新字体缩放"""
        if event.widget != self:
            return
        if self._resize_after_id is not None:
            self.after_cancel(self._resize_after_id)
        self._resize_after_id = self.after(150, self._apply_font_scale)

    def _apply_font_scale(self):
        global _scale, FONT
        w = self.winfo_width()
        h = self.winfo_height()
        new_scale = round(max(w / _BASE_W, h / _BASE_H), 2)
        new_scale = max(0.8, min(new_scale, 1.8))
        if abs(new_scale - _scale) < 0.02:
            return
        _scale = new_scale
        FONT = {k: scaled_font(k) for k in _FONT_BASE}
        self._update_all_fonts(self)

    def _update_all_fonts(self, widget):
        """递归更新子树中所有带 font 属性的控件"""
        try:
            cur = widget.cget("font")
        except Exception:
            cur = None

        if cur is not None and not isinstance(cur, str):
            try:
                family = cur.cget("family") if hasattr(cur, "cget") else ""
                weight = cur.cget("weight") if hasattr(cur, "cget") else "normal"
            except Exception:
                family, weight = "", "normal"

            for key, (bf, _, *rest) in _FONT_BASE.items():
                bw = rest[0] if rest else "normal"
                if bf == family and bw == weight:
                    try:
                        widget.configure(font=FONT[key])
                    except Exception:
                        pass
                    break

        for child in widget.winfo_children():
            self._update_all_fonts(child)

    # ── 关闭 ──────────────────────────────────────
    def _on_close(self):
        try:
            self.system.shutdown()
        except Exception:
            pass
        self.destroy()

    # ── 技能库 ────────────────────────────────────
    def _open_skills(self):
        SkillsLibraryWindow(self)


class SkillsLibraryWindow(ctk.CTkToplevel):
    """技能库弹窗：列出 data/skills/ 下所有技能，支持打开位置和删除"""

    def __init__(self, master):
        super().__init__(master)
        self.title("技能库")
        self.configure(fg_color=C["bg_main"])
        self.resizable(False, False)

        from config.app_config import SKILL_DIR
        self.skills_dir = SKILL_DIR

        w, h = 600, 450
        self.update_idletasks()
        mx, my = master.winfo_x(), master.winfo_y()
        mw, mh = master.winfo_width(), master.winfo_height()
        x = mx + (mw - w) // 2
        y = my + (mh - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")

        self._build()

    def _build(self):
        header = ctk.CTkFrame(self, fg_color="transparent", height=44)
        header.pack(fill="x", padx=16, pady=(12, 6))
        header.pack_propagate(False)
        ctk.CTkLabel(
            header, text="技能库", font=ctk.CTkFont(size=16, weight="bold"),
            text_color=C["accent_blue"]
        ).pack(side="left")
        ctk.CTkLabel(
            header, text="已安装的技能", font=ctk.CTkFont(size=11),
            text_color=C["text_muted"]
        ).pack(side="right", pady=(4, 0))

        ctk.CTkFrame(self, fg_color=C["border"], height=1).pack(fill="x", padx=16, pady=(0, 6))

        self.scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=C["border"],
            scrollbar_button_hover_color=C["accent_blue"]
        )
        self.scroll.pack(fill="both", expand=True, padx=12, pady=(0, 8))

        self._populate()

        btn_frame = ctk.CTkFrame(self, fg_color="transparent", height=44)
        btn_frame.pack(fill="x", padx=16, pady=(4, 12))
        btn_frame.pack_propagate(False)
        ctk.CTkButton(
            btn_frame, text="关闭", width=80, height=32,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=C["bg_card"], hover_color=C["accent_blue"],
            corner_radius=8, border_width=1, border_color=C["border"],
            text_color=C["text_secondary"], command=self.destroy
        ).pack(side="right")

    def _populate(self):
        for w in self.scroll.winfo_children():
            w.destroy()

        if not os.path.isdir(self.skills_dir):
            ctk.CTkLabel(
                self.scroll, text="暂无已安装的技能",
                font=ctk.CTkFont(size=13), text_color=C["text_muted"]
            ).pack(pady=40)
            return

        try:
            entries = sorted(
                d for d in os.listdir(self.skills_dir)
                if os.path.isdir(os.path.join(self.skills_dir, d))
            )
        except Exception:
            ctk.CTkLabel(
                self.scroll, text="无法读取 skills 目录",
                font=ctk.CTkFont(size=13), text_color=C["accent_red"]
            ).pack(pady=40)
            return

        if not entries:
            ctk.CTkLabel(
                self.scroll, text="暂无已安装的技能",
                font=ctk.CTkFont(size=13), text_color=C["text_muted"]
            ).pack(pady=40)
            return

        for name in entries:
            self._add_skill_row(name)

    def _add_skill_row(self, name):
        row = ctk.CTkFrame(self.scroll, fg_color=C["bg_card"], corner_radius=8)
        row.pack(fill="x", pady=3)

        ctk.CTkLabel(
            row, text=name, font=ctk.CTkFont(size=13, weight="bold"),
            text_color=C["text_primary"], anchor="w"
        ).pack(side="left", fill="x", expand=True, padx=12, pady=10)

        skill_dir = os.path.join(self.skills_dir, name)

        ctk.CTkButton(
            row, text="打开位置", width=72, height=28,
            font=ctk.CTkFont(size=11),
            fg_color=C["bg_card"], hover_color=C["accent_blue"],
            corner_radius=6, border_width=1, border_color=C["border"],
            text_color=C["text_secondary"],
            command=lambda d=skill_dir: os.startfile(d)
        ).pack(side="right", padx=(4, 6), pady=8)

        ctk.CTkButton(
            row, text="删除", width=56, height=28,
            font=ctk.CTkFont(size=11),
            fg_color="transparent", hover_color="#dc2626",
            corner_radius=6, border_width=1, border_color=C["accent_red"],
            text_color=C["accent_red"],
            command=lambda n=name, d=skill_dir: self._confirm_delete(n, d)
        ).pack(side="right", padx=(0, 4), pady=8)

    def _confirm_delete(self, name, path):
        real_path = os.path.realpath(path)
        real_skills = os.path.realpath(self.skills_dir)
        if not (real_path.startswith(real_skills + os.sep) or real_path == real_skills):
            ctk.CTkLabel(
                self.scroll, text="路径校验失败，操作已阻止",
                font=ctk.CTkFont(size=13), text_color=C["accent_red"]
            ).pack(pady=10)
            return

        confirm = ConfirmDialog(
            self, title="确认删除",
            message=f"确定要删除技能「{name}」吗？\n此操作不可撤销。",
            confirm_text="删除", cancel_text="取消"
        )
        self.wait_window(confirm)
        if confirm.result:
            try:
                shutil.rmtree(path)
                self._populate()
            except Exception as e:
                ctk.CTkLabel(
                    self.scroll,
                    text=f"无法删除技能「{name}」：{e}",
                    font=ctk.CTkFont(size=13), text_color=C["accent_red"]
                ).pack(pady=10)


class ConfirmDialog(ctk.CTkToplevel):
    """通用确认弹窗"""

    def __init__(self, master, title="确认", message="",
                 confirm_text="确认", cancel_text="取消"):
        super().__init__(master)
        self.result = False
        self.title(title)
        self.configure(fg_color=C["bg_main"])
        self.resizable(False, False)

        w, h = 380, 180
        self.update_idletasks()
        mx, my = master.winfo_x(), master.winfo_y()
        mw, mh = master.winfo_width(), master.winfo_height()
        x = mx + (mw - w) // 2
        y = my + (mh - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")

        ctk.CTkLabel(
            self, text=message, font=ctk.CTkFont(size=13),
            text_color=C["text_primary"], wraplength=340, justify="left"
        ).pack(padx=20, pady=(24, 16), anchor="w")

        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(side="bottom", fill="x", padx=20, pady=(0, 20))

        ctk.CTkButton(
            btn_frame, text=confirm_text, width=80, height=32,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=C["accent_red"], hover_color="#dc2626",
            corner_radius=8, command=self._confirm
        ).pack(side="right", padx=(8, 0))

        ctk.CTkButton(
            btn_frame, text=cancel_text, width=80, height=32,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=C["bg_card"], hover_color=C["accent_blue"],
            corner_radius=8, border_width=1, border_color=C["border"],
            text_color=C["text_secondary"], command=self.destroy
        ).pack(side="right")

    def _confirm(self):
        self.result = True
        self.destroy()



if __name__ == "__main__":
    app = WWWApp()
    app.mainloop()
