@echo off
chcp 65001 >nul
cd /d "%~dp0"
start "" pythonw "%~dp0卸载-WWW_Agent_OS.py"
