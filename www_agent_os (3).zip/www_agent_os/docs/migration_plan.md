# WWW 智能体 |WWW Agent OS 渐进式迁移方。
> 版本: 1.0  
> 日期: 2026-07-13  
> 原则: 旧代码保留、新架构并存、增量重构、每阶段可独立验证 
> 基础文档: www_agent_os_完整技术文档合集docx + 第一轮代码审计报告(14 项发布

---

## 目录

1. [新旧系统全景对比](#1-新旧系统全景对比)
2. [迁移总览与依赖关系](#2-迁移总览与依赖关系
3. [第一阶段：项目骨架搭建](#3-第一阶段项目骨架搭建)
4. [第二阶段：HOST 入口迁移](#4-第二阶段host-入口迁移)
5. [第三阶段：Persona 体系建立](#5-第三阶段persona-体系建立)
6. [第四阶段：核心模块逐层迁移](#6-第四阶段核心模块逐层迁移)
7. [第五阶段：旧模块替换与收尾](#7-第五阶段旧模块替换与收尾)
8. [风险矩阵与回滚策略](#8-风险矩阵与回滚策略

---

## 1. 新旧系统全景对比

### 1.1 旧系统概览（基于审计报告。
| 维度 | 旧系统现状| 审计发现关联 |
|------|-----------|-------------|
| **文件结构** | 根目录 4 个 .py 文件扁平化布局；UI 组件类集中在 main.py（WWWApp 811 行、WWWSystem 553 行） | H01 错误堆栈泄露至 UI |
| **调度入口** | `host_dispatch()` 直接嵌入 `www_core.py`，用户消息未经消毒直接嵌入 LLM prompt | C02 Prompt 注入风险 |
| **Agent 定义** | `config.py` 中 PERSONAS 字典（ 个人（模型映射）；`install_www.py` 中重复映射| - |
| **记忆系统** | JSON 文件持久化；`search_similar_experiences()` 仅同 Agent 内关键词匹配 | C01 分发包含真实对话数据 |
| **工具调用** | 直接调用无路由层；技能删除无路径遍历防护 | H03 路径遍历；H04 下载无校验|
| **模型调用** | 硬编码 Ollama API（无认证、无 fallback）| H02 Ollama 无认证|
| **评估体系** | `s6_evaluate()` 内嵌入 WWWSystem 中，评分逻辑与调度耦合 | C02 评分亦可被 prompt 注入操纵 |
| **依赖/部署** | 依赖版本宽松；`pause` 阻塞自动化；子进程无超时；无重试退避| 中危 x3、低危 x3 |

### 1.2 目标架构（WWW Agent OS 技术文档）

| 维度 | 目标架构 |
|------|---------|
| **目录结构** | 20+ 目录，DDD 限界上下文分层：`app/`、`core/`、`services/`、`api/ui/` |
| **调度入口** | HOST 仅做意图解析→PersonaManager→Planner→Scheduler→WorkflowEngine 全链 |
| **Persona** | 完整生命周期 FSM（Generated→Active→Idle→Dormant→Archived→Retired），五维评分，支持克隆演化 |
| **记忆系统** | 五层记忆体系（Working/Short-Term/Long-Term/Experience/Knowledge），向量数据库（FAISS |
| **工具调用** | ToolRouter 七步管道（Auth→Lookup→Validation→RateLimit→CircuitBreaker→Execute→Audit），五级权限 L0-L4 |
| **模型调用** | ModelGateway 统一门面，多后端适配（Ollama/OpenAI/Anthropic），熔断机制 + fallback |
| **评估体系** | Supervisor 独立 Agent，评估管线独立于执行管线 |
| **安全架构** | 五层信任模型（User→HOST→Persona→ToolRouter→Tool/System），RBAC+Capability 权限矩阵 |

---

## 2. 迁移总览与依赖关系
### 2.1 五阶段路线图

```
第一阶段          第二阶段          第三阶段              第四阶段                     第五阶段
(骨架搭建)  ：(HOST 入口)  ：(Persona 体系)  ：(核心模块闭环)  │         (替换与收。

新建 www_agent_os/  HOST 入口实现   → Agent→Persona   EventBus→Persona          旧模块逐步下线
旧代码入 legacy/   PersonaMgr 链路  能力声明+评分     →Task→FileTool→Memory    提示词迁移格式转换
双轨并存          ；HOST 代理模式  8 个 Persona 就绪  最小闭环跑│             安全项逐一修复
```

### 2.2 模块依赖链（决定迁移顺序。
```
HOST → PersonaManager → PersonaRegistry → Persona 实例
                                                    │                         Planner → Scheduler → WorkflowEngine → Agent.execute()
                                                                        │                                          ToolRouter → ModelGateway → Tool/Sandbox
                                                                        │                                          Supervisor → MemoryManager → LearningEngine
```

---

## 3. 第一阶段：项目骨架搭。
### 3.1 目标

建立 `www_agent_os/` 新目录结构，旧代码完整移动`legacy/`，确保旧系统功能完全不受影响，新旧系统物理隔离但运行时可互操作。
### 3.2 新目录结构
```
www_agent_os/                         # 新架构根目录
├── app/                             # 应用入口（未来）
│  ├── __init__.py
│  ├── main.py                      # 新入口（第一阶段为空壳）
│  └── bootstrap.py                 # 依赖注入容器（第一阶段为空壳）
│├── core/                            # 核心域（：DDD 限界上下文）
│  ├── __init__.py
│  ├── interfaces.py                # 所有 ABC 接口集中定义。│  ├── host/                        # HOST 上下│  ├── planner/                     # 规划上下│  ├── scheduler/                   # 调度上下│  ├── workflow/                    # 工作流上下文
│  ├── router/                      # 路由上下：(ToolRouter)
│  ├── memory/                      # 记忆上下│  ├── knowledge/                   # 知识上下│  └── learning/                    # 学习上下│├── persona/                         # Persona 管理│  ├── __init__.py
│  ├── persona_manager.py           # 第一阶段为空│  ├── persona_registry.py          # 第一阶段为简单内存字│  ├── persona_generator.py
│  ├── persona_archive.py
│  ├── persona_evolution.py
│  ├── persona_scoring.py
│  ├── persona_installer.py
│  └── templates/
│      ├── creative.yaml
│      ├── analysis.yaml
│      ├── assistant.yaml
│      └── tool_specific.yaml
│├── models/                          # 模型网关
│  ├── __init__.py
│  ├── model_gateway.py             # 第一阶段：Ollama 代理
│  └── adapters/
│      ├── __init__.py
│      └── ollama_adapter.py
│├── tools/                           # 工具定义
│  ├── __init__.py
│  ├── registry.py
│  ├── router.py
│  ├── executor.py
│  ├── sandbox.py
│  ├── definitions/
│  │  ├── file/
│  │  ├── code/
│  │  ├── web/
│  │  └── system/
│  └── mcp_adapter.py
│├── database/                        # 数据库层
│  ├── __init__.py
│  ├── database_manager.py
│  ├── vector_store/
│  │  ├── __init__.py
│  │  └── faiss_store.py
│  └── repositories/
│      └── __init__.py
│├── config/                          # 配置管理
│  ├── __init__.py
│  ├── settings.py                  # Pydantic Settings
│  ├── default.yaml
│  └── personas/                    # 每个 Persona 一个配置文│      └── .gitkeep
│├── events/                          # Event Bus
│  ├── __init__.py
│  ├── event_bus.py
│  ├── event_types.py
│  └── event_store.py
│├── api/                             # API 层（未来│  ├── __init__.py
│  └── routes/
│      └── __init__.py
│├── ui/                              # UI 层（从旧 main.py 逐步迁移动│  ├── __init__.py
│  └── components/
│      └── __init__.py
│├── services/                        # 应用服务│  └── __init__.py
│├── legacy/                          # 旧代码完整保护│  ├── www_core.py                  # 原封不动移入
│  ├── config.py                    # 原封不动移入
│  ├── install_www.py               # 原封不动移入
│  └── main.py                      # 旧的 WWWApp + WWWSystem
│├── tests/
│  ├── __init__.py
│  └── unit/
│      └── __init__.py
│├── scripts/
│  ├── migrate_data.py              # 数据迁移脚本（空壳）
│  └── backup.py
│├── data/                            # 运行时数据（.gitignore│  ├── memory/                      # 从旧 memory 目录迁移
│  └── skills/                      # 从旧 skills 目录迁移
│├── logs/
├── docs/
├── requirements/
│  ├── base.txt
│  └── dev.txt
├── .gitignore
├── .env.example
├── pyproject.toml
├── README.md
└── LICENSE
```

### 3.3 依赖关系

- 本阶段无内部模块依赖，仅创建目录骨架和空壳文件- `legacy/` 中旧代码保持原有 `import` 关系（内部自洽）
- 新旧系统之间暂不建立任何导入关系

### 3.4 验收标准

| 编号 | 验收 | 验证方式 |
|------|--------|---------|
| S1.1 | `www_agent_os/` 根目录下所有子目录入`__init__.py` 已创 | `dir` 命令检查|
| S1.2 | `legacy/` 包含旧系统全部4 个.py 文件且内容与原始一 | `diff` 对比 |
| S1.3 | 旧系统可独立于新骨架运行（从 `legacy/main.py` 启动 | 启动时 main.py，确认UI 和对话功能正确|
| S1.4 | `data/memory/` ：`data/skills/` 已从旧路径迁移并确认内容完整 | 文件数量与原始一 |
| S1.5 | `pyproject.toml` 含项目元数据，`requirements/base.txt` 列出旧系统依 | 文件存在且格式合 |
| S1.6 | `.gitignore` 排除 `data/`、`logs/`、`__pycache__/`、`.env` | 检查.gitignore 内容 |

### 3.5 风险与注意事。
- 所：`__init__.py` 初始为空文件（仅占位），不写任何 `import` 语句，避免循环依赖。- `legacy/` 内旧代码：`import` 需要适配相对路径变化。- **审计修复机会**：C01（用户数据泄露）—在迁移 `data/memory/` 时清理真实用户对话数据，仅保留脱敏测试数据。
---

## 4~8. 后续阶段概要

详细内容见完整版 migration_plan.md（原始 844 行版本）。
| 阶段 | 核心任务 | 关键产出 | 预估 |
|------|---------|---------|------|
|  | HOST 入口 | InputSanitizer + PersonaManager 链路 + C02 修复 | 2  |
|  | Persona 体系 | 8 → Agent→Persona + 状态机 + 五维评分 | 3  |
| A~F | 核心模块闭环 | EventBus→Task→ToolRouter→ModelGateway→Memory 全链 | 6  |
|  | 替换与收 | 旧模块退出+ 提示词迁移+ 审计 14 项清除| 3  |

**核心安全原则**。- 全局 Feature Flag 开关，任一新模块异常可一键回退到旧链路
- 每个子阶段独立可验证，不出现"等第三阶段才能用"的情况。- 每批数据迁移先备份再执行，checksum 验证完整性。- 14 项审计发现逐项标注修复阶段，关联到对应模块改。
### Feature Flag 清单

| Flag | 默认证| 控制范围 |
|------|--------|---------|
| `USE_NEW_ARCH` | `false` | 全局：`true` 时所有新模块生效 |
| `USE_NEW_HOST` | `false` | HOST 入口 |
| `USE_NEW_PERSONA` | `false` | PersonaManager + Registry |
| `USE_NEW_PLANNER` | `false` | TaskPlanner |
| `USE_NEW_TOOL_ROUTER` | `false` | ToolRouter 七步管道 |
| `USE_NEW_MODEL_GATEWAY` | `false` | ModelGateway 统一入口 |
| `USE_NEW_MEMORY` | `false` | MemoryManager + FAISS |

### 时间估算

| 阶段 | 预估时间 | 关键产出 |
|------|---------|---------|
| 第一阶段 | 1  | 目录骨架 + legacy 隔离 |
| 第二阶段 | 2  | HOST 入口可用 + C02 修复 |
| 第三阶段 | 3  | 8 → Persona + 评分系统 |
| 第四阶段 A-F | 6  | 最小闭环跑 |
| 第五阶段 | 3  | 旧模块退出+ 审计清零 |
| **总计** | **约 15 天* | |

---
*本方案基于 www_agent_os_完整技术文档合集docx 和第一轮代码审计报告（14 项发现）制定义
