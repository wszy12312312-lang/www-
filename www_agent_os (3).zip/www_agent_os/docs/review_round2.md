---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 27473ac333220fffa223537e117ab992_d91fb2777ed811f18ce5525400826444
    ReservedCode1: 4tsVZBnP3scbCgwS0D+p2AI9otqb5Apb8/Oy6S72vCzLFhNfPFowWNtp4fNt7mAziM12I+3y0PKtS0ZFljNInXDqcRyyfAEbJbAx6EF71bXGG6bpQlWbb4DWhZN0rB/KSk4ux3wFdRP9tUAUHScZWTEdTpAlhBByJc7bPtTVQELP/voMF02AGEh2nXQ=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 27473ac333220fffa223537e117ab992_d91fb2777ed811f18ce5525400826444
    ReservedCode2: 4tsVZBnP3scbCgwS0D+p2AI9otqb5Apb8/Oy6S72vCzLFhNfPFowWNtp4fNt7mAziM12I+3y0PKtS0ZFljNInXDqcRyyfAEbJbAx6EF71bXGG6bpQlWbb4DWhZN0rB/KSk4ux3wFdRP9tUAUHScZWTEdTpAlhBByJc7bPtTVQELP/voMF02AGEh2nXQ=
---

# Round 2 审查报告

**日期**: 2026-07-14  
**审查范围**: legacy 22 项修复验证+ 新架构 8 文件健壮性审查 
**测试结果**: 193/193 全部通过

---

## 第一部分：Legacy 22 项修复验证
### 验证结果: 22/22 通过，无误修引入新问题
| 文件 | 验证 | 状态|
|------|--------|------|
| `legacy/www_core.py` | `_sanitize_user_input` 集成到`host_dispatch` / `s6_evaluate` | 通过 |
| `legacy/www_core.py` | `_get_ollama_headers` 在所有 Ollama 调用中使 | 通过 |
| `legacy/www_core.py` | `chat()` 异常收敛 + 指数退出| 通过 |
| `legacy/www_core.py` | `_extract_json` MAX_JSON_INPUT=102400 | 通过 |
| `legacy/main.py` | H01(堆栈泄露) + H03(路径遍历) | 通过 |
| `legacy/install_www.py` | H04(SHA256) + N01(模型映射) + N02(占位检查 + N05(timeout) | 通过 |
| `legacy/一件卸载_www.py` | N03(备份目录) + M05(stderr) | 通过 |
| `legacy/config.py` | OLLAMA_API_KEY + PERSONA_MODELS 导出 | 通过 |

### 备注
- `legacy/www_core.py` 导入 `OLLAMA_API_KEY` 在新架构下依赖`config/__init__.py` 桥接（见第二部分修复 1。
---

## 第二部分：新架构健壮性审查：发现与修复
### 修复 1: `config/__init__.py` ：缺少 OLLAMA_API_KEY 桥接（高。
- **问题**: `config/__init__.py` 作为新旧 config 兼容桥，缺少 `OLLAMA_API_KEY` 导出。当 `legacy/www_core.py` 执行 `from config import OLLAMA_API_KEY` 时，Python 优先找到项目根目录的 `config/` 包（而不是`legacy/config.py`），导致 `ImportError`。**影响**: `test_process_normal_input` 测试失败，整个 legacy 回退链路不可用。*修复**: ：`config/__init__.py` 中添：`OLLAMA_API_KEY = os.environ.get("OLLAMA_API_KEY", "")`，同时将 `OLLAMA_HOST` ：`OLLAMA_TIMEOUT` 改为从环境变量读取以保持：`legacy/config.py` 一致。
### 修复 2: `task/manager.py` ：`retry()` 未重置时间戳（中。
- **问题**: `retry()` 将任务状态从 FAILED 改为 PENDING，但未清除`started_at` ：`completed_at`。重试执行后 `duration_ms` 会包含上次失败的时间。*修复**: ：`retry()` 中重：`started_at = None`、`completed_at = None`、`result = ""`、`error = ""`。
### 修复 3: `tools/router.py` ：`register()` 行为与文档不一致（低）

- **问题**: `register()` 文档案"True 表示注册成功，False 表示名称冲突"，但代码永远返回 True。*修复**: 名称冲突时返回False。
### 修复 4: `events/bus.py` ：`emit_async()` 返回值始终为 0（中。
- **问题**: 原实现在新线程中：`called[0]` 写入结果，但 `return called[0]` 在线程启动后立即执行，此时线程尚未运行，返回值始终为 0。*修复**: 先在线程安全的锁内计算匹配的处理器数量，返回该计数作为预期值，线程内执行实现emit。
### 修复 5: `runtime/host.py` ：`_call_via_gateway` 错误当有效回复（中）

- **问题**: `ModelGateway.generate()` 在错误时返回 `"[<model>] generate 异常: ..."` 字符串而非抛异常。`_call_via_gateway` 不区分成：错误，错误字符串被当作有效回复传递给用户。*修复**: ：`_call_via_gateway` 中检测错误字符串模式并抛：`RuntimeError`，由上层 `_healthy_wrapper` 捕获并回退到旧链路。
### 修复 6: `memory/store.py` ：`purge_expired` 时区兼容性（中）

- **问题**: `purge_expired` 使用 `datetime.fromisoformat()` 解析存储时间，若存储的数据缺少时区信息（naive datetime），：`datetime.now(timezone.utc)`（aware datetime）相减会抛出 `TypeError`。**修复**: 提取 `_is_entry_valid()` 方法，统一处理 naive/aware datetime 兼容性：naive datetime 默认视为 UTC。
### 无需修复的审查结构
| 文件 | 审查 | 结论 |
|------|--------|------|
| `events/bus.py` | 线程安全 | RLock 正确使用，异常隔离有 |
| `events/bus.py` | 通配符匹配边 | `fnmatch.fnmatch` 覆盖正常，空模式无订阅 |
| `task/manager.py` | 状态流转完整 | `_VALID_TRANSITIONS` 覆盖所有合法转换|
| `task/manager.py` | 空值处理| 所有公开方法含 None 守卫 |
| `tools/router.py` | 参数验证边界 | `validate_params` 检查缺失必填和未知参数 |
| `tools/router.py` | 错误处理 | invoke 统一捕获异常并包 |
| `models/gateway.py` | 超时/重试/认证 | Retry 策略正确，超时可配，认证头构建正确|
| `memory/store.py` | 并发安全 | RLock 覆盖所有读写操 |
| `memory/store.py` | JSON 序列化异步| `_persist` / `load_long_term` 含 try/except |
| `runtime/host.py` | Feature Flag 切换边界 | 按模块粒度独立开关，设计合理 |
| `runtime/host.py` | HealthChecker 健壮 | 连续失败追踪 + 冷却期 + 自动恢复，设计完成|
| `core/input_sanitizer.py` | 注入防护覆盖 | 关键：正则+特殊字符三层过滤 |
| `core/input_sanitizer.py` | YAML 回退 | 用 Python 解析器作为 PyYAML 不可用时的降 |
| `persona/manager.py` | 空注册表降级 | `match()` 空列表返回空，`dispatch()` 返回默认 host |
| `persona/manager.py` | 双路匹配 | 关键词 + 能力标签取最大 |

---

## 第三部分：测试结构
| 测试套件 | 用例 | 结果 |
|----------|--------|------|
| `tests/test_stage2.py` | 46 | 全部通过 |
| `tests/test_stage3.py` | 51 | 全部通过 |
| `tests/test_stage4.py` | 62 | 全部通过 |
| `tests/test_stage5.py` | 34 | 全部通过 |
| **合计** | **193** | **全部通过** |

---

## 统计

- **Legacy 修复验证**: 22/22 通过
- **新架构审查文件*: 8 文件
- **发现问题**: 6 项（1 高 / 4 中 / 1 低）
- **已修复*: 6 项。- **测试**: 193/193 通过
*（内容由AI生成，仅供参考）*
