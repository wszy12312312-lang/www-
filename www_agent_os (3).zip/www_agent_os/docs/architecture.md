# WWW Agent OS 架构设计文档

版本: 2.0 | 日期: 2026-07-13 | 状态 Stage 1-5 交付

---

## 1. 架构总览

```
┌───────────────────────────────────────────────────────────────────│                       User Interface                           │                   (ui/legacy_gui.py (GUI)                        │└──────────────────────────┬──────────────────────────────────────│                           │ user_message
                           ┌───────────────────────────────────────────────────────────────────│                    runtime/host.py                              │                   HostEntry.process()                           │                                                                 ┌───────────────── ┌─────────────────── ┌──────────────────── │ │ InputSanitizer │ PersononaManager   │ Feature Flags   │ ：(C02 修复)     │──：(五维评分调度)    │──：(渐进开│       │ └───────────────── └─────────────────── └──────────────────── │                                                                 ┌────────────────────────────────────────────────────────────  │ │                   HealthChecker                          │  │   新模块异步：自动回退旧链路：冷却恢复 ：切换日志       │ └────────────────────────────────────────────────────────────  │└──────────────────────────┬──────────────────────────────────────│                           ↓ selected persona + task
         ┌─────────────────┼─────────────────│         │                │                 ┌───────────────  ┌───────────────  ┌───────────────── EventBus   │  TaskManager │  ToolRouter  │：(发布-订阅)  │◄──：(状态流转   │──►│ (工具路由)   │└──────┬──────│  └─────────────│  └──────┬──────│       │                                   │       │ ┌──────────────────────────────── │       └─►│        MemoryStore           │◄─│          ：(短期 LRU + 长期 JSON)       │          └──────────────────────────────│                            │                            │                   ┌─────────────────│                   │ ModelGateway   │                   ：(Ollama API)    │                   ：(认证 + 重试)    │                   └───────────────────```

## 2. 数据流图

```
用户输入
  ↓  [1. InputSanitizer] ───────────────────── 过滤注入关键：正则/转义
  ：(if USE_INPUT_SANITIZER)
  ↓  [2. PersonaManager.dispatch()] ────────────── 五维评分 ：匹配最佳 Persona
  ：(if USE_PERSONA_MANAGER, else fallback)
  ↓  [3. Persona.on_activate()] ─────────────── 状态转换 IDLE → BUSY
  │  ↓  [4. TaskManager.create_task()] ─────────── 发布 task_created 事件
  ：(if USE_TASK_MANAGER)
  ↓  [5. ToolRouter.route()] ────────────────── → Persona 路由到对应工具  ：(if USE_TOOL_ROUTER)
  ↓  [6. ModelGateway.generate()] ───────────── HTTP │ Ollama API
  ：(if USE_MODEL_GATEWAY)              (含认证头 + 重试)
  ↓  [7. MemoryStore.save()] ────────────────── 短期记忆 + 长期持久化  ：(if USE_MEMORY_STORE)
  ↓  [8. Persona.on_deactivate()] ───────────── 状态转换 BUSY → IDLE
  │  ↓  [9. EventBus.publish(task_completed)] ──── 通知所有订阅者  │ ：响应返回给用：```

## 3. 模块职责说明

### 3.1 Core 。
| 模块 | 文件 | 职责 | 依赖 |
|------|------|------|:--:|
| InputSanitizer | `core/input_sanitizer.py` | Prompt 注入过滤 (C02 修复): 关键词黑名单、正则匹配、字符转义、审计日志| YAML 规则文件 |

### 3.2 Persona 。
| 模块 | 文件 | 职责 | 依赖 |
|------|------|------|:--:|
| Persona 基类 | `persona/base.py` | `PersonaState` 枚举 (5 状态、生命周期钩子、序列化 |  |
| PersonaRegistry | `persona/registry.py` | 动态注入注销、按 ID/名称/能力标签查询、JSON 持久 | Persona base |
| PersonaManager | `persona/manager.py` | 五维评分匹配、双路匹配(关键：能力标签)、Registry 集成 | Registry, base |
| 8 个 Persona 子类 | `persona/*_persona.py` | 各人格的 core_prompt + 能力标签 | base |

### 3.3 核心模块闭环。
| 模块 | 文件 | 职责 | 依赖 |
|------|------|------|:--:|
| EventBus | `events/bus.py` | 单例发布-订阅，24 种事件类型、通配符匹配、线程安装|  |
| TaskManager | `task/manager.py` | Task CRUD、PENDING→RUNNING→COMPLETED/FAILED 状态流转、终态历 | EventBus |
| ToolRouter | `tools/router.py` | 注册/路由/参数验证、LLM function schema 导出、register_function 自动生成 | EventBus |
| ModelGateway | `models/gateway.py` | Ollama API 封装、Bearer/Basic 认证 (H02)、指数退避重试、流式输 | EventBus |
| MemoryStore | `memory/store.py` | 短期记忆 (deque LRU)、长期记录(JSON 持久化、搜索、TTL、同步| EventBus |

### 3.4 运行时层

| 模块 | 文件 | 职责 | 依赖 |
|------|------|------|:--:|
| HostEntry | `runtime/host.py` | 请求入口、Feature Flag 控制、模块级渐进开关、健康检查与自动回退、切换日志| 所有模块|

### 3.5 工具脚本

| 脚本 | 职责 | 模式 |
|------|------|------|
| `scripts/migrate_memory.py` | 旧 memory → MemoryStore 格式迁移 | dry-run + SHA256 校验 |
| `scripts/migrate_prompts.py` | SKILL.md → Persona prompt 提取 | 迁移报告生成 |
| `scripts/rollback.py` | 按阶段全量回滚 Feature Flag | 备份 + 恢复 |

## 4. 接口规范

### 4.1 HostEntry.process()

接口签名:

- 输入: user_message (str) ：原始用户输入
- 输出: ProcessResult (.persona_id, .persona_name, .reply, .score, .error, .flags_used)

### 4.2 PersonaManager.dispatch()

接口签名:

- 输入: user_message (str), user_preference (Optional[str])
- 输出: (persona: Persona, scores: Dict[str, float], reasoning: str)

### 4.3 ModelGateway.generate()

接口签名:

- 输入: persona_id (str), prompt (str), model (str), config (GenerationConfig), stream (bool)
- 输出: GenerationResult (.text, .model, .usage)

### 4.4 MemoryStore 接口

- save(persona_id, entry_type, content) ：None
- recall(persona_id, entry_type, limit) ：List[MemoryEntry]
- search(persona_id, query, limit) ：List[MemoryEntry]

### 4.5 EventBus 事件类型

| 事件 | 触发时机 | 携带数据 |
|------|---------|---------|
| `persona_activated` | Persona 被激：(IDLE→BUSY) | persona_id, persona_name |
| `persona_deactivated` | Persona 停用 (BUSY→IDLE) | persona_id |
| `task_created` | 任务创建 | task_id, persona_id |
| `task_started` | 任务开始执行(PENDING→RUNNING) | task_id |
| `task_completed` | 任务完成 (RUNNING→COMPLETED) | task_id, result |
| `task_failed` | 任务失败 (RUNNING→FAILED) | task_id, error |
| `model_request` | 模型调用 | persona_id, model |
| `model_response` | 模型调用 | persona_id, model, tokens |
| `memory_saved` | 记忆写入 | persona_id, entry_type |
| `error_occurred` | 任何错误发生成| module, error |

## 5. Feature Flag 架构

### 5.1 层级关系

```
USE_NEW_ARCH (全量)
  ├── USE_NEW_HOST (链路)
  │    └── USE_INPUT_SANITIZER (安全)
  ├── USE_NEW_PERSONA_SYSTEM (Persona 全量)
  │    ├── USE_NEW_PERSONA
  │    └── USE_PERSONA_MANAGER
  └── Stage 4 模块
        ├── USE_EVENT_BUS
        ├── USE_TASK_MANAGER
        ├── USE_TOOL_ROUTER
        ├── USE_MODEL_GATEWAY
        └── USE_MEMORY_STORE
```

### 5.2 回退逻辑

```
新模块调用：_healthy_wrapper()
                  │                  ├─ 成功 ：返回结果
                  │                  └─ 异常 → HealthChecker.record_failure()
                                │                                ├─ 连续失败 < 3 ：重试
                                │                                └─ 连续失败 >= 3 ：标记不健│                                                     │                                                     ├─ 自动回退到旧链路
                                                     ├─ 进入冷却：(300s)
                                                     ├─ 记录切换日志
                                                     │                                                     └─ 冷却期结构建尝试恢复
```

## 6. 项目状态
| 阶段 | 内容 | 交付 | 测试 | 状态|
|:--:|------|------|:--:|:--:|
| 1 | 项目骨架、Feature Flag、数据隔离| app/, config/, runtime/ |  |  |
| 2 | InputSanitizer、HOST 模块、安全增 | core/, runtime/host.py, feature_flags.yaml | 46 |  |
| 3 | Persona 体系：基类、8 子类、Registry、Manager | persona/ (11 文件) | 51 |  |
| 4 | 核心闭环：EventBus/Task/Tool/Gateway/Memory | events/, task/, tools/, models/, memory/ (5 文件) | 62 |  |
| 5 | 迁移脚本、审计清零、回滚、文档、验证| scripts/ (3), docs/ (2), tests/ (1) | 34 |  |

**当前测试总数**: 193 通过 (Stage 2: 46, Stage 3: 51, Stage 4: 62, Stage 5: 34)
