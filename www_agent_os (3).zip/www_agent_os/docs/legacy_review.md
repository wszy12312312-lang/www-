# Legacy 目录深度代码审查报告

**审查日期**: 2026-07-13  
**审查范围**: `C:\Users\wszy1\Desktop\www_agent_os\legacy\` 全部文件  
**审查方法**: 逐文件静态代码分析 + 对照 audit_report_round1.md 的 14 项发布 
**项目版本**: www v10.7.0 (legacy)

---

## 1. 审查文件清单

| 文件 | 大小 | 行数 | 角色 |
|------|------|:---:|------|
| `www_core.py` | 23KB | 593 | 核心逻辑（模型调用、调度、评分、记忆） |
| `main.py` | 33KB | 804 | GUI 主界面（CustomTkinter |
| `install_www.py` | 34KB | 907 | GUI 一键安装器 |
| `config.py` | 1.9KB | 38 | 全局配置 |
| `一件卸载_www.py` | 23KB | 529 | GUI 卸载 |
| `www智能.bat` | 0.7KB | 26 | 批处理启动器 |
| `www智能.vbs` | 0.2KB | 5 | VBS 无窗口启动器 |
| `一键下载.bat` | 0.1KB | 4 | 安装器入 |
| `下载模型.bat` | 0.9KB | 26 | 模型下载脚本 |

---

## 2. 对照审计报告的 14 项发现状态
> **结论：legacy/ 为原始项目源码，14 项发现全部处于未处理状态。* 下表逐一验证。
| 编号 | 等级 | 发现 | 状态| 验证位置 |
|------|:----:|------|:----:|---------|
| C01 | 🔴 Critical | 分发包含真实用户数据 | ⚠️ 未处理| `memory/` 目录在旧版分发中即存储|
| C02 | 🔴 Critical | LLM Prompt 注入 | ❌未修复| `www_core.py:236-289` user_message 直接嵌入 |
| H01 | 🟠 High | 错误堆栈泄露至 UI | ❌未修复| `main.py:447` traceback.format_exc()；`www_core.py:227` 异常对象直接回复 |
| H02 | 🟠 High | Ollama API 无认证| ❌未修复| `config.py:8` HTTP；`www_core.py:84` trust_env=False |
| H03 | 🟠 High | 技能删除无路径遍历防护 | ❌未修复| `main.py:256` shutil.rmtree(path) 无验证|
| H04 | 🟠 High | 安装器下载无完整性校 | ❌未修复| `install_www.py:625` urlretrieve → SHA256 |
| M01 | 🟡 Medium | 对话历史明文存储 | ❌未修复| `www_core.py:391-407` 全部 JSON 明文 |
| M02 | 🟡 Medium | _extract_json ReDoS 风险 | ❌未修复| `www_core.py:291-322` 多正则无输入长度限制 |
| M03 | 🟡 Medium | 依赖版本约束宽松 | ❌未修复| `install_www.py:28-35` 无版本上 |
| M04 | 🟡 Medium | VBS 依赖 PATH 搜索 | ❌未修复| `www智能.vbs:4` ：`pythonw.exe` |
| M05 | 🟡 Medium | 子进程超时控制不 | ❌未修复| `一件卸载_www.py:408` stderr 丢弃 |
| L01 | 🟢 Low | __pycache__ 残留 | ❌未修复| 构建流程未清除|
| L02 | 🟢 Low | pause 阻塞自动 | ❌未修复| `一键下载.bat:3`; `下载模型.bat:25` |
| L03 | 🟢 Low | 无重试指数退出| ❌未修复| `www_core.py:62-100` 固定间隔 |

---

## 3. 新增发现（首轮审计未覆盖的问题）

### [N01] config.py 和 install_www.py 的 PERSONA_MODELS 重复定义且存在命名不一。
**风险等级**: 🟡 Medium  
**文件**: `config.py:10-22` vs `install_www.py:67-82`  

**描述**:  
两个文件独立维护了相同语义的"人格→模块映射表：

- `config.py` 使用 `PERSONA_MODELS` 字典
- `install_www.py` 使用 `PERSONA_MODEL_MAP` 字典

当前版本键值一致，：`install_www.py` 还额外维护了 `PERSONA_NAMES` 映射作为显示名，：`config.py` ：`PERSONAS` 字典中 name 字段不包含 S-ID 前缀。两处独立维护在未来修改时极易出现不一致（如一方更新模型版本而另一方未改）。
此外，`install_www.py` ：`PLANS` 字典：`premium.model_overrides` 引用：`qwen2.5-coder:14b` ：`deepseek-r1:14b`，这些模型名：`config.py` 中不存在，如果安装器写入：`install_info.json` 被主程序读取，可能导致模型查找失败。
**修复建议**:  
1. ：`PERSONA_MODEL_MAP` ：`install_www.py` 移除，改：`from config import PERSONA_MODELS`  
2. `PLANS` 中的 `model_overrides` 引用必须：`PERSONA_MODELS` 中存在的键保持一。
---

### [N02] install_www.py: PROJECT_ZIP_URL 为占位 URL

**风险等级**: 🟡 Medium  
**文件**: `install_www.py:25`  

**代码**:
```python
PROJECT_ZIP_URL = "https://github.com/YOUR_USER/www-agent/releases/latest/download/www_project.zip"
```

**描述**:  
网络下载回退路径使用了 GitHub 占位 URL（`YOUR_USER`），在任何真实环境中均不可用。当安装器以独立模式运行（安装器文件不在项目目录下），`_copy_project_files()` 会走：`_download_project_files()` 分支，此时会因 URL 无效而抛异常，安装中断。
**修复建议**:  
1. 若项目已发布 Release，替换为真实 URL  
2. 若暂不提供网络下载，应在 `_download_project_files()` 中给出更明确的错误提示并提前告知用户必须将安装器与项目文件放在同一目录

---

### [N03] 一件卸载_www.py: 保留数据备份到系统临时目录，存在敏感数据泄露风险

**风险等级**: 🟠 High  
**文件**: `一件卸载_www.py:280-296`  

**代码**:
```python
memory_backup = os.path.join(
    os.environ.get("TEMP", SCRIPT_DIR),
    f"www_memory_bak_{int(time.time())}"
)
shutil.copytree(mem_path, memory_backup)
```

**描述**:  
当用户选择"保留记忆/技能数据时，卸载器先：`memory/` ：`skills/` 目录完整复制到系统临时目录（`%TEMP%`），删除安装目录后再从临时目录复制回原位。问题在于：

1. **临时目录公开可读**：Windows `%TEMP%` 目录默认所有本地用户可访问，复制过去的对话历史、评分记录等敏感数据在备份窗口期内对任何本地用户完全暴露
2. **备份未加密*：`shutil.copytree` 直接复制明文 JSON 文件，无任何加密措施
3. **清理不彻底**：如果卸载过程在恢复备份前中断（如进程被杀），敏感数据将永久残留在 `%TEMP%` 。
**影响**: 多用户共享主机场景下，敏感对话数据在卸载过程中被暴露。
**修复建议**:  
1. 使用内存中的数据结构暂存而非写入临时文件（小数据量场景完全可行）
2. 如必须写磁盘，写到安装目录同级隐藏目录而非 `%TEMP%`，并在完成后立即删除
3. 备份前对数据进行加密

---

### [N04] 下载模型.bat: 错误处理导致模型下载失败被静默忽。
**风险等级**: 🟡 Medium  
**文件**: `下载模型.bat`  

**代码**:
```batch
ollama pull qwen2.5-coder:1.5b
if %errorlevel% neq 0 echo [FAIL] qwen2.5-coder:1.5b & goto :next1
echo [OK] qwen2.5-coder:1.5b
:next1
```

**描述**:  
脚本使用 `goto` 跳过失败的模型，但最终总是输出 "All downloads finished."。无：3 个模型是否全部下载失败，用户都会看到成功信息，且 `errorlevel` 始终止0（被最后一个 echo 覆盖）。此外，没有启用 `setlocal enabledelayedexpansion`，在括号代码块内 `%errorlevel%` 不会实时更新。
**修复建议**:  
1. 使用 `setlocal enabledelayedexpansion` 并用 `!errorlevel!` 替代 `%errorlevel%`
2. 跟踪失败计数，最后根据计数输出不同的结束信息
3. 设置非零退出码以支持自动化调用方的错误检查
---

### [N05] install_www.py: urllib.request.urlretrieve 无超时参。
**风险等级**: 🟡 Medium  
**文件**: `install_www.py:625`  

**代码**:
```python
urllib.request.urlretrieve(OLLAMA_DOWNLOAD_URL, installer_exe)
```

**描述**:  
`urlretrieve` 未指定超时，在无网络或服务器无响应时会永久阻塞，且无法被 `_install_thread` 中的 `_CancelException` 中断（因为线程卡在同步I/O 上）。安装器 GUI 会完全冻结构
**修复建议**:  
1. 换用 `requests.get(url, stream=True, timeout=300)` 分块写入文件，支持超时和中断
2. 或用 `urllib.request.urlopen(url, timeout=300)` + 手动写文件
---

### [N06] 一件卸载_www.py: ollama rm 失败时 stderr 被丢弃，无诊断信。
**风险等级**: 🟢 Low  
**文件**: `一件卸载_www.py:408-414`  

**代码**:
```python
subprocess.run(["ollama", "rm", model], check=True, timeout=60,
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
```

**描述**:  
`stderr=subprocess.DEVNULL` 导致模型卸载失败时用户无法获知原因（：模型正在使用：权限不足"等）。日志仅输出 `"卸载失败（可能已被删除）"`，信息不足以排查问题。
**修复建议**:  
1. 将 stderr 捕获到变量，失败时输出到日志：`capture_output=True, text=True`
2. 记录 `returncode` ：`stderr` 内容

---

### [N07] www_core.py: _extract_json 输入无长度限制，正则匹配超长输入可能耗尽 CPU

**风险等级**: 🟡 Medium（补充 M02。 
**文件**: `www_core.py:291`  

**描述**:  
`_extract_json()` 方法对输：`text` 无长度限制。如果 LLM 返回异常超长输出（如幻觉生成 1MB 文本），`re.search(r'```(?:json)?\s*([\s\S]*?)```', cleaned)` 将在整个超长字符串上执行懒匹配，CPU 可能长时间占用。该方法的调用上下文（`s6_evaluate`）在 daemon 线程中运行，会导致线程阻塞。
**修复建议**:  
在方法入口添加输入截断：
```python
if len(text) > 50000:
    text = text[:50000]
```

---

### [N08] config.py 与主程序耦合：install_www.py 写入 install_info.json 模型名与运行时可能不一。
**风险等级**: 🟢 Low  
**文件**: `install_www.py:400-404` vs `config.py:10-22`  

**描述**:  
安装器允许用户在 GUI 中自定义模型名称（`model_entry_vars`），写入 `install_info.json` ：`model_map` 字段。但主程序（`main.py`）从不读取`install_info.json`，始终使：`config.py` 中硬编码：`PERSONA_MODELS`。如果用户安装时修改了 S4 的模型为 `qwen2.5:14b`，运行时会因 config.py 仍指：`qwen2.5:3b` 而无法使用用户自定义的模型。
**根本原因**: 安装器的模型配置与运行时的模型配置是两个独立的代码路径，不存在配置传递机制。
**修复建议**:  
1. 主程序启动时优先读取 `install_info.json` ：`model_map` 覆盖 `config.py` 默认证 
2. 或将安装器生成的配置写入一个独立的 `user_config.json` 供运行时读取

---

## 4. 新增代码质量问题

### 4.1 www智能.bat: errorlevel 在复合语句中的延迟展开问题

```batch
pip install -r requirements.txt -q
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install dependencies...
    pause
    exit /b 1
)
```

虽然此处括号代码块中 `%errorlevel%` 在外层条件判断之后不再使用，因此当前无 bug。但如果后续在括号块内增加条件判断，则会触发经典 batch 延迟展开陷阱。建议开头加 `setlocal enabledelayedexpansion`。
### 4.2 www_core.py: chat() 异常处理过度标记 model_online=False

```python
except Exception as e:
    state.model_online = False
    reply = f"[{model} 响应异常: {e}]"
```

任何异常（包括临时的 ConnectionError、Timeout）都会永久标记该人格离线。只有在手动重启应用后才会重新检查。见 `main.py:429`，一：`model_online is False`，所有后续该人格的任务都会被拒绝。
### 4.3 main.py: 状态卡片的 refresh 和 refresh_status 职责分离不一。
`StatusPanel.refresh()` ：`destroy()` 并重建所有卡片（重量级操作），：`refresh_status()` 仅更新卡片标签（轻量级）。但 `_process_next()` 中任务完成后调用 `self.status_panel.refresh()`（第 474 行），当任务频繁时会造成不必要的 UI 重建开销。应统一使用 `refresh_status()`。
---

## 5. 逐文件审查明。
### 5.1 www_core.py（核心逻辑：93 行）

| 问题 | 行号 | 严重 |
|------|:---:|:----:|
| `_ollama_post` 重试无指数退避（：2 次，固定间隔离| 62-86 | 🟢 Low |
| `trust_env = False` 绕过企业代理审计 | 84 | 🟠 High (H02) |
| `check_all_models` 异常静默吞掉 | 110 | 🟡 Medium |
| `get_system_prompt` 用户输入直接注入 skill prompt | 160-183 | 🔴 Critical (C02) |
| `chat()` 异常暴露原始错误信息 | 227 | 🟠 High (H01) |
| `chat()` 异常后永久标记 model_online=False | 226-229 | 🟡 Medium |
| `host_dispatch` 用户输入无净化直接嵌入 prompt | 236-252 | 🔴 Critical (C02) |
| `s6_evaluate` 用户输入无净化直接嵌入 prompt | 263-288 | 🔴 Critical (C02) |
| `_extract_json` 无输入长度限制，ReDoS 风险 | 291-322 | 🟡 Medium (M02) |
| `log_task` 明文写入日志 | 403-407 | 🟡 Medium (M01) |
| `_save_persona_memory` 明文存储 scores/history | 391-397 | 🟡 Medium (M01) |
| `states` 字典跨线程无锁并发读取| 全局 | 🟡 Medium |

### 5.2 main.py（GUI：04 行）

| 问题 | 行号 | 严重 |
|------|:---:|:----:|
| `_confirm_delete` 无路径遍历验证| 256-260 | 🟠 High (H03) |
| `_execute_task` 异常直接 traceback.format_exc() | 447-448 | 🟠 High (H01) |
| `_on_error` 错误信息直接展示到 UI | 482-484 | 🟠 High (H01) |
| `_process_next` 中冗余调用refresh() 而非 refresh_status() | 474 | 🟢 Low |
| `_cancelled` / `_running` 标志位无原子性保护| 全局 | 🟡 Medium |

### 5.3 install_www.py（安装器：07 行）

| 问题 | 行号 | 严重 |
|------|:---:|:----:|
| PROJECT_ZIP_URL 为占位 URL | 25 | 🟡 Medium (N02) |
| PERSONA_MODEL_MAP 和 config.py 重复定义 | 67-82 | 🟡 Medium (N01) |
| PERSONA_NAMES 命名格式和 config.py PERSONAS 不一 | 85-93 | 🟢 Low |
| PLANS premium 引用非标准模型名 | 112-113 | 🟡 Medium |
| `_ensure_deps` 无版本约束安装| 28-35 | 🟡 Medium (M03) |
| `urlretrieve` 无超 | 625 | 🟡 Medium (N05) |
| 下载 Ollama 无完整性校 | 625-632 | 🟠 High (H04) |
| 子进程异常静默吞 | 173 | 🟢 Low |
| 安装器与运行时配置脱 | 400-404 | 🟢 Low (N08) |

### 5.4 config.py（配置，38 行）

| 问题 | 行号 | 严重 |
|------|:---:|:----:|
| OLLAMA_HOST 使用 HTTP 明文 | 8 | 🟠 High (H02) |
| 模型映射到 install_www.py 独立维护 | 10-22 | 🟡 Medium (N01) |

### 5.5 一件卸载_www.py（卸载器：29 行）

| 问题 | 行号 | 严重 |
|------|:---:|:----:|
| 敏感数据备份到 %TEMP% | 280-296 | 🟠 High (N03) |
| ollama rm stderr 丢弃 | 408 | 🟢 Low (N06) |

### 5.6 批处理VBS 脚本

| 文件 | 问题 | 严重 |
|------|------|:----:|
| www智能.vbs | 依赖 PATH 搜索 pythonw.exe | 🟡 Medium (M04) |
| www智能.bat | 缺少 setlocal enabledelayedexpansion | 🟢 Low |
| 下载模型.bat | 失败静默忽略 + errorlevel 被覆盖| 🟡 Medium (N04) |
| 一键下载.bat | pause 阻塞自动 | 🟢 Low (L02) |

---

## 6. 汇总统计
| 等级 | 首轮审计 | 新增 | 合计 |
|------|:-------:|:---:|:---:|
| 🔴 Critical | 2 | 0 | **2** |
| 🟠 High | 4 | 1 (N03) | **5** |
| 🟡 Medium | 5 | 6 (N01/N02/N04/N05/N07/N08 + 若干补充) | **11** |
| 🟢 Low | 3 | 2 (N06 + 若干补充) | **5** |
| **合计** | **14** | **8** | **22** |

---

## 7. 结论

**legacy/ 目录中所：14 项首轮审计发现均未修复制* 此外，本轮深度审查还识别出 8 项新增问题，其中 1 项为高危（N03: 卸载时敏感数据备份至系统临时目录）。合计 22 项安全与质量问题待处理。
**最紧迫的三项行动**:
1. **C02** (Prompt Injection): `host_dispatch` ：`s6_evaluate` 中的用户输入净化——直接影响系统核心调度链的安全部2. **N03** (卸载敏感数据泄露): 修改备份策略，改用内存暂存或加密存储
3. **H03** (路径遍历): `SkillsLibraryWindow._confirm_delete` 增加 `os.path.realpath` 验证

---

*本报告基于legacy/ 目录静态代码分析生成，覆盖全部 9 个文件共：2971 行。
