@echo off
chcp 65001 >nul
cd /d "%~dp0"
start "" pythonw "%~dp0安装-WWW_Agent_OS.py"
