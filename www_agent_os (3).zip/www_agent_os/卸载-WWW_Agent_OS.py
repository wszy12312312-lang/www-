#!/usr/bin/env python3
"""
WWW Agent OS - 卸载向导 v1.0
customtkinter 深色 GUI：安装信息检测 → 选项确认 → 执行卸载
"""
import os
import sys
import json
import time
import shutil
import subprocess
import threading
from datetime import datetime

# ---------- 第三方依赖自动安装 ----------
def _ensure_deps():
    try:
        import customtkinter as ctk
    except ImportError:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "customtkinter", "-q"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        import customtkinter as ctk

_ensure_deps()

import customtkinter as ctk
from tkinter import messagebox

# ---------- 常量 ----------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = SCRIPT_DIR
SHORTCUT_PATH = os.path.join(os.path.expanduser("~"), "Desktop", "WWW Agent OS.lnk")
OLLAMA_API_BASE = "http://localhost:11434"


def check_ollama_installed():
    try:
        import requests
    except ImportError:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "requests", "-q"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        import requests
    try:
        r = requests.get(f"{OLLAMA_API_BASE}/api/tags", timeout=4)
        return r.status_code == 200
    except Exception:
        return False


# ======================================================================
#  GUI 卸载器
# ======================================================================
class UninstallerGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("WWW Agent OS 卸载向导")
        self.geometry("620x720")
        self.minsize(560, 640)
        self.configure(fg_color="#0d1117")

        self.info_data = None
        self.install_dir = PROJECT_DIR
        self.uninstalling = False
        self.log_msgs = []

        # 复选框变量（默认全部勾选）
        self.keep_memory = ctk.BooleanVar(value=True)
        self.keep_skills = ctk.BooleanVar(value=True)
        self.remove_models = ctk.BooleanVar(value=True)
        self.clean_pip_cache = ctk.BooleanVar(value=False)

        self._build_ui()
        self._detect_and_load()

    # ========== UI 构建 ==========
    def _build_ui(self):
        # ---- 标题 ----
        title_frame = ctk.CTkFrame(self, fg_color="transparent")
        title_frame.pack(fill="x", padx=24, pady=(20, 10))
        ctk.CTkLabel(
            title_frame, text="WWW Agent OS 卸载向导",
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color="#f85149"
        ).pack(anchor="w")
        ctk.CTkLabel(
            title_frame,
            text="将卸载 WWW Agent OS 程序文件，您可以选择保留记忆与技能数据",
            font=ctk.CTkFont(size=12), text_color="#8b949e"
        ).pack(anchor="w", pady=(2, 0))

        # ---- 安装信息 ----
        info_label = ctk.CTkFrame(self, fg_color="#161b22", corner_radius=8)
        info_label.pack(fill="x", padx=24, pady=(10, 4))
        ctk.CTkLabel(
            info_label, text="  检测到的安装信息",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#d2991b"
        ).pack(padx=14, pady=(10, 6), anchor="w")

        self.info_textbox = ctk.CTkTextbox(
            self, font=ctk.CTkFont(size=12, family="Consolas"),
            fg_color="#0d1117", text_color="#c9d1d9",
            corner_radius=8, height=120, wrap="word",
            border_width=1, border_color="#30363d"
        )
        self.info_textbox.pack(fill="x", padx=24, pady=(0, 10))

        # ---- 卸载选项 ----
        opt_label = ctk.CTkFrame(self, fg_color="#161b22", corner_radius=8)
        opt_label.pack(fill="x", padx=24, pady=(6, 4))
        ctk.CTkLabel(
            opt_label, text="  卸载选项（可取消勾选以保留对应数据）",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#d2991b"
        ).pack(padx=14, pady=(10, 6), anchor="w")

        opt_frame = ctk.CTkFrame(self, fg_color="#0d1117", corner_radius=8,
                                 border_width=1, border_color="#30363d")
        opt_frame.pack(fill="x", padx=24, pady=(0, 4))

        self._make_checkbox(
            opt_frame,
            "保留记忆数据（memory/ 目录不删除）",
            self.keep_memory,
            "#3fb950", "#238636",
            "你的对话记忆、历史记录等数据将被保留"
        )
        self._make_checkbox(
            opt_frame,
            "保留 Persona 技能数据（data/skills/ 目录不删除）",
            self.keep_skills,
            "#3fb950", "#238636",
            "自定义技能、Persona 配置等文件将被保留"
        )
        self._make_checkbox(
            opt_frame,
            "同时卸载 Ollama 模型（调用 ollama rm 删除相关模型）",
            self.remove_models,
            "#f85149", "#da3633",
            "注意：这将删除通过本安装器拉取的所有 Ollama 模型"
        )
        self._make_checkbox(
            opt_frame,
            "清理 pip 缓存",
            self.clean_pip_cache,
            "#d2991b", "#b0881a",
            "删除 pip 下载缓存以释放磁盘空间"
        )

        # ---- 日志 ----
        log_label = ctk.CTkFrame(self, fg_color="#161b22", corner_radius=8)
        log_label.pack(fill="x", padx=24, pady=(6, 4))
        ctk.CTkLabel(
            log_label, text="  执行日志",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#d2991b"
        ).pack(padx=14, pady=(10, 6), anchor="w")

        self.log_textbox = ctk.CTkTextbox(
            self, font=ctk.CTkFont(size=11, family="Consolas"),
            fg_color="#0d1117", text_color="#c9d1d9",
            corner_radius=8, height=180, wrap="word",
            border_width=1, border_color="#30363d"
        )
        self.log_textbox.pack(fill="both", expand=True, padx=24, pady=(0, 8))

        # ---- 按钮 ----
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=24, pady=(8, 16))

        ctk.CTkButton(
            btn_frame, text="取消", width=100, height=40,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#30363d", hover_color="#484f58",
            corner_radius=8, command=self.destroy
        ).pack(side="left")

        self.uninstall_btn = ctk.CTkButton(
            btn_frame, text="确认卸载", width=160, height=40,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color="#da3633", hover_color="#c42f2f",
            corner_radius=8, command=self._confirm_uninstall
        )
        self.uninstall_btn.pack(side="right")

    def _make_checkbox(self, parent, text, var, fg, hover, hint):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=10, pady=(8, 2))
        cb = ctk.CTkCheckBox(
            row, text="", variable=var,
            font=ctk.CTkFont(size=13), text_color="#c9d1d9",
            fg_color=fg, hover_color=hover,
            width=28, border_width=1
        )
        cb.pack(side="left")
        label = ctk.CTkLabel(
            row, text=text,
            font=ctk.CTkFont(size=13), text_color="#c9d1d9"
        )
        label.pack(side="left", padx=6)
        if hint:
            hint_label = ctk.CTkLabel(
                row, text=f"   ({hint})",
                font=ctk.CTkFont(size=10), text_color="#8b949e"
            )
            hint_label.pack(side="left")
        spacer = ctk.CTkFrame(parent, fg_color="transparent", height=6)
        spacer.pack(fill="x")

    # ========== 检测与加载 ==========
    def _detect_and_load(self):
        info_path = os.path.join(PROJECT_DIR, "install_info.json")

        if not os.path.exists(info_path):
            # 显示项目文件夹路径作为参考
            self._show_info_text(
                f"未找到安装信息文件。\n\n"
                f"项目文件夹: {PROJECT_DIR}\n"
                f"状态: {'存在' if os.path.isdir(PROJECT_DIR) else '不存在'}\n\n"
                "仍可继续卸载（删除项目目录和快捷方式）。"
            )
            return

        try:
            with open(info_path, "r", encoding="utf-8") as f:
                self.info_data = json.load(f)
        except Exception as e:
            self._show_info_text(f"读取安装信息失败: {e}")
            return

        install_path = self.info_data.get("install_path", "")
        if install_path and os.path.isdir(install_path):
            self.install_dir = install_path

        lines = [
            f"安装路径: {self.install_dir}",
            f"安装时间: {self.info_data.get('created', '未知')}",
            f"安装方案: {self.info_data.get('plan', '未知')}",
            f"已安装模型:",
        ]
        for m in self.info_data.get("models", []):
            lines.append(f"  - {m}")

        self.info_textbox.configure(state="normal")
        self.info_textbox.delete("1.0", "end")
        self.info_textbox.insert("end", "\n".join(lines))
        self.info_textbox.configure(state="disabled")

    def _show_info_text(self, text):
        self.info_textbox.configure(state="normal")
        self.info_textbox.delete("1.0", "end")
        self.info_textbox.insert("end", text)
        self.info_textbox.configure(state="disabled")

    def _log(self, msg: str):
        self.log_msgs.append(msg)
        self.after(0, self._flush_log)

    def _flush_log(self):
        self.log_textbox.configure(state="normal")
        self.log_textbox.delete("1.0", "end")
        self.log_textbox.insert("end", "\n".join(self.log_msgs[-60:]))
        self.log_textbox.see("end")
        self.log_textbox.configure(state="disabled")

    # ========== 卸载流程 ==========
    def _confirm_uninstall(self):
        if self.uninstalling:
            return

        keep_mem = self.keep_memory.get()
        keep_sk = self.keep_skills.get()
        rm_models = self.remove_models.get()
        clean_pip = self.clean_pip_cache.get()

        model_count = len(self.info_data.get("models", [])) if self.info_data else 0
        confirm_msg = (
            "确定要卸载 WWW Agent OS 吗？\n\n"
            f"安装路径: {self.install_dir}\n"
            f"保留记忆数据: {'是' if keep_mem else '否'}\n"
            f"保留 Persona 技能数据: {'是' if keep_sk else '否'}\n"
            f"卸载 Ollama 模型 ({model_count} 个): {'是' if rm_models else '否'}\n"
            f"清理 pip 缓存: {'是' if clean_pip else '否'}\n\n"
            "此操作不可撤销！"
        )

        result = messagebox.askyesno("确认卸载", confirm_msg, icon="warning")
        if not result:
            return

        self.uninstalling = True
        self.uninstall_btn.configure(state="disabled", text="卸载中...")
        self.log_msgs = []
        self._log("========== 开始卸载 WWW Agent OS ==========")

        threading.Thread(target=self._uninstall_thread, daemon=True).start()

    def _uninstall_thread(self):
        keep_mem = self.keep_memory.get()
        keep_sk = self.keep_skills.get()
        rm_models = self.remove_models.get()
        clean_pip = self.clean_pip_cache.get()
        install_dir = self.install_dir

        total = 4
        step = 0

        try:
            # ---- 1. 删除桌面快捷方式 ----
            step += 1
            self._log(f"[{step}/{total}] 正在删除桌面快捷方式...")
            if os.path.exists(SHORTCUT_PATH):
                os.remove(SHORTCUT_PATH)
                self._log("桌面快捷方式已删除")
            else:
                self._log("桌面快捷方式未找到（可能已被手动删除）")

            # ---- 2. 清理安装目录 ----
            step += 1
            self._log(f"[{step}/{total}] 正在清理安装目录: {install_dir}")

            if install_dir and os.path.isdir(install_dir):
                memory_backup = None
                skills_backup = None

                # 备份保留目录
                if keep_mem:
                    mem_path = os.path.join(install_dir, "memory")
                    if os.path.exists(mem_path):
                        memory_backup = os.path.join(
                            os.environ.get("TEMP", SCRIPT_DIR),
                            f"www_memory_bak_{int(time.time())}"
                        )
                        shutil.copytree(mem_path, memory_backup)
                        self._log("记忆数据已暂存备份")

                if keep_sk:
                    skills_path = os.path.join(install_dir, "data", "skills")
                    if os.path.exists(skills_path):
                        skills_backup = os.path.join(
                            os.environ.get("TEMP", SCRIPT_DIR),
                            f"www_skills_bak_{int(time.time())}"
                        )
                        shutil.copytree(skills_path, skills_backup)
                        self._log("技能数据已暂存备份")

                # 删除项目目录
                try:
                    shutil.rmtree(install_dir, ignore_errors=True)
                    self._log("安装目录已删除")
                except Exception as e:
                    self._log(f"删除目录时出现错误: {e}")
                    self._log("部分文件可能被占用，请手动清理残留")

                # 恢复保留目录
                if memory_backup or skills_backup:
                    os.makedirs(install_dir, exist_ok=True)

                if memory_backup:
                    shutil.copytree(memory_backup, os.path.join(install_dir, "memory"))
                    shutil.rmtree(memory_backup, ignore_errors=True)
                    self._log("记忆数据已还原到原位置")

                if skills_backup:
                    os.makedirs(os.path.join(install_dir, "data"), exist_ok=True)
                    shutil.copytree(skills_backup, os.path.join(install_dir, "data", "skills"))
                    shutil.rmtree(skills_backup, ignore_errors=True)
                    self._log("技能数据已还原到原位置")

                # 重写简化的 install_info.json（如保留了数据）
                if keep_mem or keep_sk:
                    remaining_info = {
                        "install_path": install_dir,
                        "preserved": {
                            "memory": keep_mem,
                            "skills": keep_sk,
                        },
                        "uninstalled_at": datetime.now().isoformat(),
                    }
                    info_dst = os.path.join(install_dir, "install_info.json")
                    try:
                        with open(info_dst, "w", encoding="utf-8") as f:
                            json.dump(remaining_info, f, ensure_ascii=False, indent=2)
                    except Exception:
                        pass
            else:
                self._log("安装目录不存在或为空，跳过清理")

            # ---- 3. 卸载 Ollama 模型 ----
            step += 1
            self._log(f"[{step}/{total}] 处理 Ollama 模型...")
            if rm_models and self.info_data:
                models = self.info_data.get("models", [])
                unique_models = list(dict.fromkeys(models))
                if unique_models:
                    if check_ollama_installed():
                        self._log(f"正在卸载 {len(unique_models)} 个模型...")
                        for model in unique_models:
                            self._log(f"  ollama rm {model} ...")
                            try:
                                subprocess.run(
                                    ["ollama", "rm", model],
                                    check=True, timeout=60,
                                    stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL
                                )
                                self._log(f"  {model} — 已卸载")
                            except subprocess.CalledProcessError:
                                self._log(f"  {model} — 卸载失败（可能已被删除）")
                            except FileNotFoundError:
                                self._log("  未找到 ollama 命令，跳过模型卸载")
                                break
                        self._log("Ollama 模型卸载完成")
                    else:
                        self._log("Ollama 服务未运行，跳过模型卸载")
                else:
                    self._log("没有需要卸载的模型记录")
            else:
                self._log("已选择保留模型，跳过卸载")

            # ---- 4. 清理 pip 缓存 ----
            step += 1
            self._log(f"[{step}/{total}] 处理 pip 缓存...")
            if clean_pip:
                try:
                    subprocess.run(
                        [sys.executable, "-m", "pip", "cache", "purge"],
                        check=True, timeout=60,
                        capture_output=True
                    )
                    self._log("pip 缓存已清理")
                except Exception as e:
                    self._log(f"清理 pip 缓存失败: {e}")
            else:
                self._log("已选择保留 pip 缓存，跳过清理")

            # ---- 完成 ----
            self._log("========== WWW Agent OS 卸载完成 ==========")
            self._build_result_summary(keep_mem, keep_sk)

        except Exception as e:
            self._log(f"卸载过程中出现未预期的错误: {e}")
            self._build_result_summary(keep_mem, keep_sk)
        finally:
            self.uninstalling = False

    def _build_result_summary(self, keep_mem: bool, keep_sk: bool):
        install_dir = self.install_dir

        summary_parts = ["WWW Agent OS 已卸载。\n"]
        if keep_mem:
            summary_parts.append(f"- 记忆数据已保留于: {install_dir}\\memory\\")
        else:
            summary_parts.append("- 记忆数据已删除")
        if keep_sk:
            summary_parts.append(f"- 技能数据已保留于: {install_dir}\\data\\skills\\")
        else:
            summary_parts.append("- 技能数据已删除")
        if self.remove_models.get():
            summary_parts.append("- Ollama 模型已卸载")
        else:
            summary_parts.append("- Ollama 模型已保留")
        if self.clean_pip_cache.get():
            summary_parts.append("- pip 缓存已清理")

        if keep_mem or keep_sk:
            summary_parts.append(f"\n保留的数据位于: {install_dir}")
            summary_parts.append("如需彻底清理，请手动删除该目录。")

        summary = "\n".join(summary_parts)

        self.after(0, lambda: messagebox.showinfo("卸载完成", summary))
        self.after(0, lambda: self.uninstall_btn.configure(
            state="disabled", text="已卸载",
            fg_color="#30363d"
        ))


# ======================================================================
if __name__ == "__main__":
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")
    app = UninstallerGUI()
    app.mainloop()
