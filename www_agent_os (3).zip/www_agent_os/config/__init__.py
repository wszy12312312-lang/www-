"""
config bridge — 向后兼容旧版 www_core.py 的导入路径。

提供 from config import OLLAMA_HOST, OLLAMA_TIMEOUT, PERSONA_MODELS, PERSONAS, SKILL_DIR, MEMORY_DIR
新 config 包统一导出这些符号。
"""

import os

# 项目根目录（config/ 的父目录）
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 以下常量与 app_config.py 保持一致

OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_API_KEY = os.environ.get("OLLAMA_API_KEY", "")   # H02: Ollama API 密钥认证
OLLAMA_TIMEOUT = int(os.environ.get("OLLAMA_TIMEOUT", "120"))  # Ollama API 请求超时（秒）

# 人格-模型映射（每人格独立模型）
PERSONA_MODELS = {
    "host": "qwen3:14b",
    "S": "gemma3:12b",
    "S1": "qwen2.5-coder:7b",
    "S2": "qwen2.5-coder:1.5b",
    "S3": "llama3.2:3b",
    "S4": "qwen2.5:3b",
    "S5": "deepseek-r1:7b",
    "S6": "qwen2.5:7b",
}

# 人格元信息
PERSONAS = {
    "host": {"name": "指挥者", "icon": "H", "color": "#FF6B35", "role": "团队队长，全盘统筹调度"},
    "S":  {"name": "监察员", "icon": "S", "color": "#FF7675", "role": "元认知监控/质量把控"},
    "S1": {"name": "软件专员", "icon": "S1", "color": "#14B8A6", "role": "应用安装/卸载/管理"},
    "S2": {"name": "系统专员", "icon": "S2", "color": "#06B6D4", "role": "系统配置/运维/编程"},
    "S3": {"name": "网络专员", "icon": "S3", "color": "#10B981", "role": "网页抓取/浏览器自动化"},
    "S4": {"name": "文件专员", "icon": "S4", "color": "#F59E0B", "role": "文件整理/格式转换"},
    "S5": {"name": "检索专员", "icon": "S5", "color": "#A855F7", "role": "网络搜索/信息聚合"},
    "S6": {"name": "聊天专员", "icon": "S6", "color": "#74B9FF", "role": "日常聊天/情感陪伴"},
}

# 路径调整为项目根目录下的 data/ 目录
SKILL_DIR = os.path.join(_PROJECT_ROOT, "data", "skills")
MEMORY_DIR = os.path.join(_PROJECT_ROOT, "data", "memory")
