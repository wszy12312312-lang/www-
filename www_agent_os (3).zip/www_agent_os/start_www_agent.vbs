' WWW Agent OS - Silent Launcher (No Console Window)
' Uses pythonw.exe to run in background without a black window.

Dim objShell, objFSO, projectDir, pythonwPath, pythonPath
Set objFSO = CreateObject("Scripting.FileSystemObject")

projectDir = objFSO.GetParentFolderName(WScript.ScriptFullName)
Set objShell = CreateObject("WScript.Shell")

pythonwPath = ""
pythonPath = ""

' 1. Known paths first
Dim dir
dir = "C:\Python312\pythonw.exe"
If objFSO.FileExists(dir) Then pythonwPath = dir
If pythonwPath = "" Then
    dir = "C:\Python311\pythonw.exe"
    If objFSO.FileExists(dir) Then pythonwPath = dir
End If
If pythonwPath = "" Then
    dir = "C:\Python310\pythonw.exe"
    If objFSO.FileExists(dir) Then pythonwPath = dir
End If

' 2. Search LOCALAPPDATA\Programs\Python
If pythonwPath = "" Then
    Dim localAppData, programsPython, folder
    localAppData = objShell.ExpandEnvironmentStrings("%LOCALAPPDATA%")
    programsPython = localAppData & "\Programs\Python"
    If objFSO.FolderExists(programsPython) Then
        For Each folder In objFSO.GetFolder(programsPython).SubFolders
            If InStr(folder.Name, "Python3") > 0 Then
                dir = folder.Path & "\pythonw.exe"
                If objFSO.FileExists(dir) Then
                    pythonwPath = dir
                    Exit For
                End If
            End If
        Next
    End If
End If

' 3. Fall back to python.exe
If pythonwPath = "" Then
    dir = "C:\Python312\python.exe"
    If objFSO.FileExists(dir) Then pythonPath = dir
End If
If pythonPath = "" Then
    dir = "C:\Python311\python.exe"
    If objFSO.FileExists(dir) Then pythonPath = dir
End If
If pythonPath = "" Then
    dir = "C:\Python310\python.exe"
    If objFSO.FileExists(dir) Then pythonPath = dir
End If
If pythonPath = "" Then pythonPath = pythonwPath
If pythonwPath = "" Then pythonwPath = pythonPath

' 4. Error if nothing found
If pythonwPath = "" Then
    MsgBox "Python not found!" & vbCrLf & vbCrLf & _
           "Please install Python 3.11+ from https://www.python.org/downloads/", vbCritical, "WWW Agent OS"
    WScript.Quit 1
End If

objShell.CurrentDirectory = projectDir
objShell.Run """" & pythonwPath & """ """ & projectDir & "\runtime\host.py""", 0, False

Set objShell = Nothing
Set objFSO = Nothing
