"""
Task Manager — 任务生命周期管理

提供：
- Task 数据类：封装任务的完整生命周期信息
- TaskStatus 枚举：PENDING → RUNNING → COMPLETED / FAILED / CANCELLED
- TaskManager：创建、状态流转、与 EventBus 集成

版本: 1.0.0
"""

from __future__ import annotations

import logging
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from events.bus import Event, EventBus, EventType, get_default_bus

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# TaskStatus 枚举
# ------------------------------------------------------------------

class TaskStatus(str, Enum):
    """任务状态枚举。

    状态流转：
        PENDING → RUNNING → COMPLETED
        PENDING → RUNNING → FAILED
        PENDING → CANCELLED
        RUNNING → FAILED
        RUNNING → CANCELLED
    """

    PENDING = "pending"        # 等待执行
    RUNNING = "running"        # 执行中
    COMPLETED = "completed"    # 已完成
    FAILED = "failed"          # 执行失败
    CANCELLED = "cancelled"    # 已取消


# 合法状态转移表
_VALID_TRANSITIONS: Dict[TaskStatus, set] = {
    TaskStatus.PENDING: {TaskStatus.RUNNING, TaskStatus.CANCELLED},
    TaskStatus.RUNNING: {TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED},
    TaskStatus.COMPLETED: set(),
    TaskStatus.FAILED: {TaskStatus.PENDING},  # 允许重试
    TaskStatus.CANCELLED: set(),
}


# ------------------------------------------------------------------
# Task 数据类
# ------------------------------------------------------------------

@dataclass
class Task:
    """任务数据类。

    封装任务的完整生命周期信息。

    Attributes:
        id: 任务唯一 ID（UUID v4）。
        persona_id: 分配给执行此任务的 Persona ID。
        input: 用户原始输入。
        status: 当前任务状态。
        created_at: 创建时间（UTC）。
        started_at: 开始执行时间。
        completed_at: 完成/失败时间。
        result: 任务执行结果文本。
        error: 错误信息（仅在 FAILED 状态）。
        metadata: 附加元数据字典。
    """

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    persona_id: str = ""
    input: str = ""
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: str = ""
    error: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def duration_ms(self) -> float:
        """任务执行耗时（毫秒）。"""
        if self.started_at is None:
            return 0.0
        end = self.completed_at or datetime.now(timezone.utc)
        return (end - self.started_at).total_seconds() * 1000

    @property
    def is_terminal(self) -> bool:
        """任务是否处于终态。"""
        return self.status in {TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED}

    def can_transition_to(self, target: TaskStatus) -> bool:
        """检查是否可以过渡到目标状态。"""
        return target in _VALID_TRANSITIONS.get(self.status, set())

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典。"""
        return {
            "id": self.id,
            "persona_id": self.persona_id,
            "input": self.input,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "result": self.result[:500] if self.result else "",
            "error": self.error,
            "metadata": self.metadata,
            "duration_ms": round(self.duration_ms, 1),
        }

    def __repr__(self) -> str:
        return f"Task(id={self.id[:8]}, persona={self.persona_id}, status={self.status.value})"


# ------------------------------------------------------------------
# TaskManager
# ------------------------------------------------------------------

class TaskManager:
    """任务管理器。

    负责：
    - 创建任务（PENDING）
    - 状态流转（PENDING → RUNNING → COMPLETED/FAILED）
    - 任务列表查询
    - 通过 EventBus 发布状态变更事件

    Usage::

        mgr = TaskManager(bus)
        task = mgr.create(persona_id="s4_file", input="找一份PDF")
        mgr.start(task.id)
        mgr.complete(task.id, result="找到了 3 份 PDF")
    """

    def __init__(self, bus: Optional[EventBus] = None) -> None:
        """初始化 TaskManager。

        Args:
            bus: EventBus 实例。不传则使用全局默认。
        """
        self._bus = bus or get_default_bus()
        self._tasks: Dict[str, Task] = {}
        self._lock = threading.RLock()
        self._history: List[Task] = []  # 终态任务历史（最近 100 条）
        logger.info("TaskManager 已初始化")

    @property
    def bus(self) -> EventBus:
        """获取绑定的 EventBus。"""
        return self._bus

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def create(
        self,
        persona_id: str,
        user_input: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Task:
        """创建新任务（PENDING 状态）。

        Args:
            persona_id: 分配的执行 Persona ID。
            user_input: 用户原始输入。
            metadata: 附加元数据。

        Returns:
            新创建的 Task 对象。
        """
        task = Task(
            persona_id=persona_id,
            input=user_input,
            metadata=metadata or {},
        )

        with self._lock:
            self._tasks[task.id] = task

        logger.info("任务已创建: %s", task)
        self._bus.emit(Event(
            type=EventType.TASK_CREATED,
            source="task.manager",
            data={"task_id": task.id, "persona_id": persona_id},
        ))
        return task

    def get(self, task_id: str) -> Optional[Task]:
        """按 ID 获取任务。

        Args:
            task_id: 任务 ID。

        Returns:
            Task 对象或 None。
        """
        with self._lock:
            return self._tasks.get(task_id)

    def list_by_status(self, status: TaskStatus) -> List[Task]:
        """按状态筛选任务。

        Args:
            status: 目标状态。

        Returns:
            任务列表。
        """
        with self._lock:
            return [t for t in self._tasks.values() if t.status == status]

    def list_active(self) -> List[Task]:
        """列出活跃任务（PENDING + RUNNING）。"""
        with self._lock:
            return [
                t for t in self._tasks.values()
                if t.status in {TaskStatus.PENDING, TaskStatus.RUNNING}
            ]

    def list_by_persona(self, persona_id: str) -> List[Task]:
        """按 Persona ID 筛选任务。"""
        with self._lock:
            return [t for t in self._tasks.values() if t.persona_id == persona_id]

    @property
    def count(self) -> int:
        """当前内存中的任务总数（含活跃和终态）。"""
        with self._lock:
            return len(self._tasks)

    # ------------------------------------------------------------------
    # 状态流转
    # ------------------------------------------------------------------

    def _transition(self, task_id: str, target: TaskStatus, **kwargs: Any) -> Optional[Task]:
        """内部状态转移。

        Args:
            task_id: 任务 ID。
            target: 目标状态。
            **kwargs: 附加更新的字段（如 result, error）。

        Returns:
            更新后的 Task 或 None（如果转移失败）。
        """
        with self._lock:
            task = self._tasks.get(task_id)
            if task is None:
                logger.warning("任务 %s 不存在", task_id)
                return None

            if not task.can_transition_to(target):
                logger.warning("非法状态转移: %s → %s", task.status, target)
                return None

            task.status = target
            for key, val in kwargs.items():
                if hasattr(task, key):
                    setattr(task, key, val)

            # 终态任务移入历史
            if task.is_terminal:
                self._history.append(task)
                if len(self._history) > 100:
                    self._history = self._history[-100:]

            return task

    def start(self, task_id: str) -> Optional[Task]:
        """将任务从 PENDING 转移到 RUNNING。

        Args:
            task_id: 任务 ID。

        Returns:
            更新后的 Task 或 None。
        """
        task = self._transition(task_id, TaskStatus.RUNNING, started_at=datetime.now(timezone.utc))
        if task:
            logger.info("任务开始执行: %s", task)
            self._bus.emit(Event(
                type=EventType.TASK_STARTED,
                source="task.manager",
                data={"task_id": task_id, "persona_id": task.persona_id},
            ))
        return task

    def complete(self, task_id: str, result: str = "") -> Optional[Task]:
        """将任务标记为 COMPLETED。

        Args:
            task_id: 任务 ID。
            result: 任务执行结果。

        Returns:
            更新后的 Task 或 None。
        """
        task = self._transition(
            task_id, TaskStatus.COMPLETED,
            result=result,
            completed_at=datetime.now(timezone.utc),
        )
        if task:
            logger.info("任务完成: %s (耗时 %.0fms)", task, task.duration_ms)
            self._bus.emit(Event(
                type=EventType.TASK_COMPLETED,
                source="task.manager",
                data={"task_id": task_id, "persona_id": task.persona_id, "duration_ms": task.duration_ms},
            ))
        return task

    def fail(self, task_id: str, error: str = "") -> Optional[Task]:
        """将任务标记为 FAILED。

        Args:
            task_id: 任务 ID。
            error: 错误描述。

        Returns:
            更新后的 Task 或 None。
        """
        task = self._transition(
            task_id, TaskStatus.FAILED,
            error=error,
            completed_at=datetime.now(timezone.utc),
        )
        if task:
            logger.error("任务失败: %s — %s", task, error)
            self._bus.emit(Event(
                type=EventType.TASK_FAILED,
                source="task.manager",
                data={"task_id": task_id, "persona_id": task.persona_id, "error": error},
            ))
        return task

    def cancel(self, task_id: str) -> Optional[Task]:
        """取消任务。

        Args:
            task_id: 任务 ID。

        Returns:
            更新后的 Task 或 None。
        """
        task = self._transition(
            task_id, TaskStatus.CANCELLED,
            completed_at=datetime.now(timezone.utc),
        )
        if task:
            logger.info("任务已取消: %s", task)
            self._bus.emit(Event(
                type=EventType.TASK_CANCELLED,
                source="task.manager",
                data={"task_id": task_id, "persona_id": task.persona_id},
            ))
        return task

    def retry(self, task_id: str) -> Optional[Task]:
        """重试失败的任务（重置为 PENDING）。

        Args:
            task_id: 任务 ID。

        Returns:
            新的 Task 或 None。
        """
        task = self._transition(task_id, TaskStatus.PENDING)
        if task:
            # 重置时间戳，避免 duration_ms 受上次执行干扰
            task.started_at = None
            task.completed_at = None
            task.result = ""
            task.error = ""
            logger.info("任务重试: %s", task)
        return task

    # ------------------------------------------------------------------
    # 统计
    # ------------------------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        """获取任务统计信息。"""
        with self._lock:
            status_counts: Dict[str, int] = {}
            for t in self._tasks.values():
                key = t.status.value
                status_counts[key] = status_counts.get(key, 0) + 1

            return {
                "total": len(self._tasks),
                "by_status": status_counts,
                "active": len(self.list_active()),
                "history_size": len(self._history),
            }

    def recent_history(self, n: int = 10) -> List[Dict[str, Any]]:
        """获取最近 N 条终态任务历史。

        Args:
            n: 返回数量。

        Returns:
            任务字典列表。
        """
        return [t.to_dict() for t in self._history[-n:]]

    def clear_completed(self) -> int:
        """清理已完成的终态任务，释放内存。

        Returns:
            清理的任务数。
        """
        with self._lock:
            to_remove = [
                tid for tid, t in self._tasks.items()
                if t.is_terminal
            ]
            for tid in to_remove:
                del self._tasks[tid]
            return len(to_remove)
