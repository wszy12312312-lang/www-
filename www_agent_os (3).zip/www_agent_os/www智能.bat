@echo off
chcp 65001 >nul 2>&1
title WWW Agent OS
setlocal enabledelayedexpansion

echo ========================================
echo   WWW v10.7.0 - Starting...
echo ========================================
echo.

:: ============================================================
:: Smart Python Detection
:: ============================================================
set "PYTHON="

for %%P in (
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
) do (
    if exist %%P (
        set "PYTHON=%%~P"
        goto :found
    )
)

for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
    if exist "%%D\python.exe" (
        set "PYTHON=%%D\python.exe"
        goto :found
    )
)

for /f "usebackq delims=" %%i in (
    `powershell -NoProfile -Command "Get-Command python -All 2>$null | ForEach-Object { $_.Source } | Where-Object { $_ -notmatch 'WindowsApps' -and (Test-Path $_) } | ForEach-Object { (Get-Item $_).Target 2>$null } | Where-Object { $_ } | Select-Object -First 1"`
) do set "PYTHON=%%i"

if not "!PYTHON!"=="" goto :found

for /f "usebackq delims=" %%i in (`where python3 2^>nul`) do (
    echo %%i | findstr /i "WindowsApps" >nul
    if errorlevel 1 (
        set "PYTHON=%%i"
        goto :found
    )
)

for /f "usebackq delims=" %%i in (`where python 2^>nul`) do (
    set "PYTHON=%%i"
    echo !PYTHON! | findstr /i "WindowsApps" >nul
    if errorlevel 1 (
        goto :found
    ) else (
        echo [ERROR] Only WindowsApps stub found. Install Python 3.11+ from https://www.python.org/downloads/
        pause
        exit /b 1
    )
)

echo [ERROR] Python not found!
pause
exit /b 1

:found
cd /d "%~dp0"

:: Install deps if needed
"!PYTHON!" -m pip install customtkinter requests Pillow -q 2>nul

:: Launch GUI (pythonw = no cmd window)
start "" "!PYTHON:python.exe=pythonw.exe!" "%~dp0ui\main.py"
exit /b 0
