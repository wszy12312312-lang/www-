# Memory Data Directory

**C01 Security Notice**: This directory is for sanitized/test data only.
Real user conversation data has been excluded from this repository.
When migrating from the old system, use `scripts/migrate_data.py` with the `--sanitize` flag.
