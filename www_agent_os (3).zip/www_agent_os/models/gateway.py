"""
ModelGateway — 模型网关

封装 Ollama API 调用，提供：
- API 认证支持（H02 修复）
- 模型列表查询
- 文本生成（同步 + 流式）
- 超时与重试机制
- 与 EventBus 集成

版本: 1.0.0
"""

from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Generator, List, Optional, Tuple

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from events.bus import Event, EventBus, EventType, get_default_bus

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# 数据类
# ------------------------------------------------------------------

@dataclass
class ModelInfo:
    """已安装模型信息。"""

    name: str
    modified_at: str = ""
    size: int = 0  # bytes
    digest: str = ""
    family: str = ""
    parameter_size: str = ""


@dataclass
class GenerationConfig:
    """文本生成配置。"""

    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    num_predict: int = -1  # -1 表示不限制
    repeat_penalty: float = 1.1
    seed: int = 0  # 0 表示随机
    num_ctx: int = 4096

    def to_dict(self) -> Dict[str, Any]:
        """转换为 Ollama options 字典，过滤默认值。"""
        result: Dict[str, Any] = {}
        if self.temperature != 0.7:
            result["temperature"] = self.temperature
        if self.top_p != 0.9:
            result["top_p"] = self.top_p
        if self.top_k != 40:
            result["top_k"] = self.top_k
        if self.num_predict > 0:
            result["num_predict"] = self.num_predict
        if self.repeat_penalty != 1.1:
            result["repeat_penalty"] = self.repeat_penalty
        if self.seed != 0:
            result["seed"] = self.seed
        if self.num_ctx != 4096:
            result["num_ctx"] = self.num_ctx
        return result


@dataclass
class ChatMessage:
    """聊天消息。"""

    role: str  # 'system', 'user', 'assistant'
    content: str

    def to_dict(self) -> Dict[str, str]:
        return {"role": self.role, "content": self.content}


@dataclass
class ModelResponse:
    """模型响应。"""

    content: str = ""
    reasoning: str = ""
    model: str = ""
    done: bool = True
    total_duration_ms: float = 0.0
    eval_count: int = 0
    error: str = ""


# ------------------------------------------------------------------
# ModelGateway
# ------------------------------------------------------------------

class ModelGateway:
    """模型网关 — Ollama API 封装。

    特性：
    - 修复 H02：支持 API 密钥认证（Bearer Token / Basic Auth）。
    - 连接池 + 自动重试（HTTPAdapter）。
    - 超时控制。
    - 流式输出支持。
    - EventBus 集成。

    Usage::

        gw = ModelGateway(host="http://localhost:11434")
        response = gw.chat("qwen2.5:7b", [ChatMessage("user", "Hello")])
        print(response.content)
    """

    # 默认配置
    DEFAULT_HOST = "http://localhost:11434"
    DEFAULT_TIMEOUT = 120  # 秒
    DEFAULT_MAX_RETRIES = 2

    def __init__(
        self,
        host: str = "",
        api_key: str = "",
        api_user: str = "",
        api_password: str = "",
        timeout: int = 0,
        max_retries: int = 0,
        bus: Optional[EventBus] = None,
    ) -> None:
        """初始化 ModelGateway。

        Args:
            host: Ollama API 地址，默认 http://localhost:11434。
            api_key: API 密钥（Bearer Token 认证，H02 修复）。
            api_user: 基本认证用户名（与 api_password 配合）。
            api_password: 基本认证密码。
            timeout: 请求超时秒数，默认 120。
            max_retries: 最大重试次数，默认 2。
            bus: EventBus 实例。
        """
        self.host = host.rstrip("/") if host else self.DEFAULT_HOST
        self.timeout = timeout or self.DEFAULT_TIMEOUT
        self.max_retries = max_retries if max_retries > 0 else self.DEFAULT_MAX_RETRIES

        # API 认证（H02）
        self._api_key = api_key
        self._api_user = api_user
        self._api_password = api_password

        # EventBus
        self._bus = bus or get_default_bus()

        # 构建 HTTP Session
        self._session = requests.Session()
        self._session.trust_env = False  # 绕过系统代理

        # 认证头
        self._auth_headers: Dict[str, str] = {}
        if api_key:
            self._auth_headers["Authorization"] = f"Bearer {api_key}"
            logger.info("ModelGateway: 使用 Bearer Token 认证")
        elif api_user and api_password:
            import base64
            creds = base64.b64encode(f"{api_user}:{api_password}".encode()).decode()
            self._auth_headers["Authorization"] = f"Basic {creds}"
            logger.info("ModelGateway: 使用 Basic Auth 认证")

        # 重试策略
        retry_strategy = Retry(
            total=self.max_retries,
            backoff_factor=1.0,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"],
        )
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=4,
            pool_maxsize=8,
        )
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)

        # 状态
        self._online: Optional[bool] = None
        self._lock = threading.RLock()

        logger.info("ModelGateway 已初始化: host=%s, timeout=%ds, retries=%d",
                     self.host, self.timeout, self.max_retries)

    @property
    def bus(self) -> EventBus:
        return self._bus

    @property
    def is_online(self) -> Optional[bool]:
        """Ollama 服务是否在线（None=未检测）。"""
        return self._online

    # ------------------------------------------------------------------
    # 底层 HTTP 请求
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        json_data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
        stream: bool = False,
    ) -> requests.Response:
        """发送 HTTP 请求到 Ollama API。

        Args:
            method: HTTP 方法 (GET/POST)。
            path: API 路径（如 '/api/tags'）。
            json_data: JSON 请求体。
            timeout: 超时（秒），默认使用实例 timeout。
            stream: 是否流式响应。

        Returns:
            requests.Response 对象。

        Raises:
            requests.RequestException: 请求失败。
        """
        url = f"{self.host}{path}"
        headers = {**self._auth_headers}

        if timeout is None:
            timeout = self.timeout

        if stream:
            timeout = max(timeout, 300)  # 流式最小 5 分钟

        logger.debug("Ollama %s %s", method, url)
        resp = self._session.request(
            method=method,
            url=url,
            json=json_data,
            headers=headers,
            timeout=timeout,
            stream=stream,
        )
        return resp

    # ------------------------------------------------------------------
    # API: 模型管理
    # ------------------------------------------------------------------

    def list_models(self) -> List[ModelInfo]:
        """查询已安装的模型列表。

        Returns:
            ModelInfo 列表。

        Raises:
            RuntimeError: 服务不可用。
        """
        try:
            resp = self._request("GET", "/api/tags")
            resp.raise_for_status()
            data = resp.json()
            models = []
            for m in data.get("models", []):
                details = m.get("details", {})
                models.append(ModelInfo(
                    name=m.get("name", ""),
                    modified_at=m.get("modified_at", ""),
                    size=m.get("size", 0),
                    digest=m.get("digest", ""),
                    family=details.get("family", ""),
                    parameter_size=details.get("parameter_size", ""),
                ))
            self._online = True
            return models
        except requests.RequestException as e:
            self._online = False
            raise RuntimeError(f"无法获取模型列表: {e}") from e

    def check_health(self) -> bool:
        """检查 Ollama 服务健康状态。

        Returns:
            True 表示服务在线。
        """
        try:
            resp = self._request("GET", "/api/tags", timeout=10)
            self._online = resp.status_code == 200
            return self._online
        except Exception:
            self._online = False
            return False

    def model_exists(self, model_name: str) -> bool:
        """检查指定模型是否已安装。

        Args:
            model_name: 模型名称（如 'qwen2.5:7b'）。

        Returns:
            True 表示已安装。
        """
        try:
            models = self.list_models()
            installed_names = {m.name for m in models}
            if model_name in installed_names:
                return True
            # 也检查不带标签的版本
            base = model_name.split(":")[0]
            for mn in installed_names:
                if mn == base or mn.startswith(base + ":"):
                    return True
            return False
        except Exception:
            return False

    # ------------------------------------------------------------------
    # API: 文本生成（同步）
    # ------------------------------------------------------------------

    def chat(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        include_reasoning: bool = False,
        timeout: Optional[int] = None,
    ) -> ModelResponse:
        """发送聊天请求，获取完整回复。

        Args:
            model: 模型名称。
            messages: 消息列表。
            system: 系统提示（将插入到消息开头）。
            config: 生成配置。
            include_reasoning: 是否获取思维链（reasoning_content）。
            timeout: 超时（秒），默认使用实例配置。

        Returns:
            ModelResponse 对象。
        """
        self._bus.emit(Event(
            type=EventType.MODEL_REQUESTED,
            source="model.gateway",
            data={"model": model, "message_count": len(messages)},
        ))

        # 构建请求体
        body: Dict[str, Any] = {
            "model": model,
            "messages": [],
            "stream": False,
        }

        if system:
            body["messages"].append({"role": "system", "content": system})

        for msg in messages:
            body["messages"].append(msg.to_dict())

        if config:
            body["options"] = config.to_dict()

        # Ollama 特有字段
        if include_reasoning:
            body["include_reasoning"] = True

        t0 = time.perf_counter()

        try:
            resp = self._request("POST", "/api/chat", json_data=body, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
            msg = data.get("message", {})
            t1 = time.perf_counter()

            result = ModelResponse(
                content=msg.get("content", ""),
                reasoning=msg.get("reasoning_content", "") or msg.get("thinking", ""),
                model=data.get("model", model),
                done=data.get("done", True),
                total_duration_ms=(t1 - t0) * 1000,
                eval_count=data.get("eval_count", 0),
            )

            # 回退：如果没有 reasoning，再请求一次不带 include_reasoning
            if include_reasoning and not result.reasoning and not result.content:
                try:
                    body.pop("include_reasoning", None)
                    resp2 = self._request("POST", "/api/chat", json_data=body, timeout=timeout)
                    data2 = resp2.json()
                    result.content = data2.get("message", {}).get("content", "")
                except Exception:
                    pass

            self._bus.emit(Event(
                type=EventType.MODEL_RESPONDED,
                source="model.gateway",
                data={
                    "model": model,
                    "content_length": len(result.content),
                    "duration_ms": round(result.total_duration_ms, 1),
                },
            ))
            return result

        except requests.RequestException as e:
            elapsed = (time.perf_counter() - t0) * 1000
            self._bus.emit(Event(
                type=EventType.MODEL_ERROR,
                source="model.gateway",
                data={"model": model, "error": str(e), "duration_ms": round(elapsed, 1)},
            ))
            return ModelResponse(
                error=f"[{model}] API 请求异常: {e}",
                model=model,
                total_duration_ms=elapsed,
            )

    # ------------------------------------------------------------------
    # API: 流式输出
    # ------------------------------------------------------------------

    def chat_stream(
        self,
        model: str,
        messages: List[ChatMessage],
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        include_reasoning: bool = False,
    ) -> Generator[str, None, None]:
        """流式聊天生成。

        Args:
            model: 模型名称。
            messages: 消息列表。
            system: 系统提示。
            config: 生成配置。
            include_reasoning: 是否获取思维链。

        Yields:
            增量文本片段。
        """
        body: Dict[str, Any] = {
            "model": model,
            "messages": [],
            "stream": True,
        }

        if system:
            body["messages"].append({"role": "system", "content": system})
        for msg in messages:
            body["messages"].append(msg.to_dict())
        if config:
            body["options"] = config.to_dict()
        if include_reasoning:
            body["include_reasoning"] = True

        self._bus.emit(Event(
            type=EventType.MODEL_REQUESTED,
            source="model.gateway",
            data={"model": model, "stream": True},
        ))

        try:
            resp = self._request("POST", "/api/chat", json_data=body, stream=True)
            resp.raise_for_status()

            for line in resp.iter_lines(decode_unicode=True):
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                    msg = chunk.get("message", {})
                    content = msg.get("content", "")
                    if content:
                        yield content
                    if chunk.get("done", False):
                        break
                except json.JSONDecodeError:
                    continue

            self._bus.emit(Event(
                type=EventType.MODEL_RESPONDED,
                source="model.gateway",
                data={"model": model, "stream": True},
            ))

        except requests.RequestException as e:
            self._bus.emit(Event(
                type=EventType.MODEL_ERROR,
                source="model.gateway",
                data={"model": model, "error": str(e), "stream": True},
            ))
            yield f"[{model}] 流式请求异常: {e}"

    # ------------------------------------------------------------------
    # API: 文本生成（generate，兼容旧接口）
    # ------------------------------------------------------------------

    def generate(
        self,
        model: str,
        prompt: str,
        system: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        raw: bool = False,
    ) -> str:
        """使用 /api/generate 生成文本（兼容旧版 API）。

        Args:
            model: 模型名称。
            prompt: 提示文本。
            system: 系统提示。
            config: 生成配置。
            raw: 是否禁用模板。

        Returns:
            生成的文本。
        """
        body: Dict[str, Any] = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "raw": raw,
        }
        if system:
            body["system"] = system
        if config:
            body["options"] = config.to_dict()

        try:
            resp = self._request("POST", "/api/generate", json_data=body)
            resp.raise_for_status()
            return resp.json().get("response", "")
        except requests.RequestException as e:
            return f"[{model}] generate 异常: {e}"

    # ------------------------------------------------------------------
    # 统计
    # ------------------------------------------------------------------

    def verify_auth(self) -> Tuple[bool, str]:
        """验证认证配置是否正确。

        Returns:
            (是否通过, 信息)。
        """
        if not self._auth_headers:
            return True, "未配置 API 认证（本地访问）"
        try:
            resp = self._request("GET", "/api/tags", timeout=10)
            if resp.status_code == 200:
                return True, "认证验证通过"
            elif resp.status_code == 401:
                return False, "认证失败: 401 Unauthorized"
            elif resp.status_code == 403:
                return False, "认证失败: 403 Forbidden"
            else:
                return False, f"认证验证返回: {resp.status_code}"
        except Exception as e:
            return False, f"认证验证异常: {e}"

    def close(self) -> None:
        """关闭 HTTP Session。"""
        self._session.close()
        logger.info("ModelGateway 已关闭")
