#!/usr/bin/env python3
"""
系统回滚脚本 — 支持按阶段回滚或全量回滚到旧系统。

功能：
- 按阶段回滚：--stage 1/2/3/4/5 恢复指定阶段的 feature_flags
- 全量回滚：--stage 0 或 --full 恢复所有开关到 false（旧系统状态）
- 保留新代码不删除，仅关闭 Feature Flag 开关
- 回滚前自动备份当前 feature_flags.yaml
- 支持 --preview 预览将要变更的开关

滚动更新的阶段划分：
  Stage 1: USE_NEW_ARCH
  Stage 2: USE_NEW_HOST, USE_INPUT_SANITIZER
  Stage 3: USE_NEW_PERSONA, USE_PERSONA_MANAGER, USE_NEW_PERSONA_SYSTEM
  Stage 4: USE_EVENT_BUS, USE_TASK_MANAGER, USE_TOOL_ROUTER, USE_MODEL_GATEWAY, USE_MEMORY_STORE
  Stage 5: 全部开关（Stage 1-4 的并集）

使用方式：
  python scripts/rollback.py --preview --stage 4     # 预览将关闭哪些开关
  python scripts/rollback.py --stage 4               # 回滚到 Stage 3 状态
  python scripts/rollback.py --full                  # 全量回滚到旧系统
  python scripts/rollback.py --stage 5               # 重新启用 Stage 5（前进）
  python scripts/rollback.py --restore backup_path   # 从备份恢复
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set

# ------------------------------------------------------------------
# 常量
# ------------------------------------------------------------------

# Stage → 该阶段引入的 Feature Flag 列表
# Stage 1: 基础架构
# Stage 2: 安全 + HOST
# Stage 3: Persona 体系
# Stage 4: 核心模块闭环
# Stage 5: 迁移与收尾（与 Stage 4 相同开关集）
STAGE_FLAGS: Dict[int, List[str]] = {
    1: [
        "USE_NEW_ARCH",
    ],
    2: [
        "USE_NEW_HOST",
        "USE_INPUT_SANITIZER",
    ],
    3: [
        "USE_NEW_PERSONA",
        "USE_PERSONA_MANAGER",
        "USE_NEW_PERSONA_SYSTEM",
    ],
    4: [
        "USE_EVENT_BUS",
        "USE_TASK_MANAGER",
        "USE_TOOL_ROUTER",
        "USE_MODEL_GATEWAY",
        "USE_MEMORY_STORE",
    ],
    5: [
        # 与 Stage 4 相同（迁移脚本没有独立的 Feature Flags）
        "USE_EVENT_BUS",
        "USE_TASK_MANAGER",
        "USE_TOOL_ROUTER",
        "USE_MODEL_GATEWAY",
        "USE_MEMORY_STORE",
    ],
}

# 所有已知的 Flag（不在此列表中的 Flag 不会被回滚脚本修改）
ALL_KNOWN_FLAGS: Set[str] = {
    "USE_NEW_ARCH",
    "USE_NEW_HOST",
    "USE_INPUT_SANITIZER",
    "USE_NEW_PERSONA",
    "USE_PERSONA_MANAGER",
    "USE_NEW_PERSONA_SYSTEM",
    "USE_EVENT_BUS",
    "USE_TASK_MANAGER",
    "USE_TOOL_ROUTER",
    "USE_MODEL_GATEWAY",
    "USE_MEMORY_STORE",
}

# 默认的 feature_flags.yaml 路径
DEFAULT_FLAGS_FILE = "feature_flags.yaml"

# 备份目录
BACKUP_DIR = "data/feature_flags_backups"


# ------------------------------------------------------------------
# Flag 文件解析
# ------------------------------------------------------------------

def parse_flags_file(filepath: str) -> Dict[str, str]:
    """解析 feature_flags.yaml 文件。

    保留注释和原始格式，返回 {KEY: "true"/"false"/value} 字典。

    Args:
        filepath: feature_flags.yaml 的路径。

    Returns:
        键值对字典，值为原始字符串（"true"/"false"/"3" 等）。
    """
    flags: Dict[str, str] = {}
    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if ":" in stripped:
                key, _, value = stripped.partition(":")
                key = key.strip()
                # 去除行内注释
                comment_pos = value.find(" #")
                if comment_pos >= 0:
                    value = value[:comment_pos]
                value = value.strip().strip('"').strip("'")
                flags[key] = value
    return flags


def read_raw_file(filepath: str) -> List[str]:
    """读取文件原始行。"""
    if not os.path.isfile(filepath):
        return []
    with open(filepath, "r", encoding="utf-8") as f:
        return f.readlines()


def write_raw_file(filepath: str, lines: List[str]) -> None:
    """写入文件原始行。"""
    with open(filepath, "w", encoding="utf-8", newline="\n") as f:
        f.writelines(lines)


# ------------------------------------------------------------------
# 回滚逻辑
# ------------------------------------------------------------------

def compute_rollback_plan(
    current_flags: Dict[str, str],
    target_stage: int,
) -> List[tuple]:
    """计算回滚计划：哪些 Flag 需要从 true 变为 false。

    "滚回到 Stage N" 的含义：
    - 关闭 Stage N, N-1, ..., 1 中高于目标阶段的 Flag
    - 即：保留 Stage 1..N 的 Flag 为启用，关闭 Stage N+1..5 的 Flag

    Args:
        current_flags: 当前 Flag 状态。
        target_stage: 目标阶段编号。0 表示全量回滚（全部 false）。5 表示全部启用。

    Returns:
        [(flag_name, current_value, new_value), ...]
    """
    changes: List[tuple] = []

    # 确定每个 Stage 的目标状态
    for stage in range(1, 6):
        for flag in STAGE_FLAGS.get(stage, []):
            current = current_flags.get(flag, "false")
            if stage <= target_stage:
                # 该阶段应启用
                if current.lower() == "false":
                    changes.append((flag, current, "true"))
            else:
                # 该阶段应关闭
                if current.lower() == "true":
                    changes.append((flag, current, "false"))

    return changes


def apply_rollback(filepath: str, changes: List[tuple]) -> None:
    """将变更应用到 feature_flags.yaml 文件。

    保持原始文件的其他内容（注释、空白行、未知 Flag 等）不变。
    """
    lines = read_raw_file(filepath)
    if not lines:
        print("错误: feature_flags.yaml 不存在")
        sys.exit(1)

    change_map: Dict[str, str] = {flag: new_val for flag, _, new_val in changes}

    new_lines: List[str] = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            new_lines.append(line)
            continue
        if ":" in stripped:
            key_part, _, rest = stripped.partition(":")
            key = key_part.strip()
            if key in change_map:
                # 找到注释位置
                comment_pos = rest.find(" #")
                if comment_pos >= 0:
                    comment = rest[comment_pos:]
                    new_line = f"{key}: {change_map[key]}{comment}\n"
                else:
                    new_line = f"{key}: {change_map[key]}\n"
                new_lines.append(new_line)
                continue
        new_lines.append(line)

    write_raw_file(filepath, new_lines)


# ------------------------------------------------------------------
# 备份与恢复
# ------------------------------------------------------------------

def backup_flags(filepath: str, project_root: str) -> str:
    """备份当前 feature_flags.yaml。

    Returns:
        备份文件路径。
    """
    backup_dir = os.path.join(project_root, BACKUP_DIR)
    os.makedirs(backup_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_name = f"feature_flags_{timestamp}.yaml"
    backup_path = os.path.join(backup_dir, backup_name)
    shutil.copy2(filepath, backup_path)
    return backup_path


def restore_from_backup(
    backup_path: str,
    target_path: str,
    project_root: str,
) -> bool:
    """从备份恢复 feature_flags.yaml。"""
    if not os.path.isfile(backup_path):
        print(f"错误: 备份文件不存在: {backup_path}")
        return False

    # 先备份当前文件
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    current_backup = os.path.join(
        project_root, BACKUP_DIR,
        f"feature_flags_before_restore_{timestamp}.yaml",
    )
    if os.path.isfile(target_path):
        os.makedirs(os.path.dirname(current_backup), exist_ok=True)
        shutil.copy2(target_path, current_backup)
        print(f"已备份当前文件: {current_backup}")

    shutil.copy2(backup_path, target_path)
    print(f"已从备份恢复: {backup_path}")
    return True


# ------------------------------------------------------------------
# 预览
# ------------------------------------------------------------------

def print_preview(changes: List[tuple], target_stage: int) -> None:
    """打印回滚预览。"""
    print("=" * 60)
    print(f"  回滚预览 — 到 Stage {target_stage}")
    print("=" * 60)
    if not changes:
        print("  无需变更，所有 Flag 已处于目标状态。")
        return

    true_to_false = [(f, c, n) for f, c, n in changes if n == "false"]
    false_to_true = [(f, c, n) for f, c, n in changes if n == "true"]

    if false_to_true:
        print("\n  将启用 (false → true):")
        for flag, current, new in false_to_true:
            print(f"    ✅ {flag}: {current} → {new}")

    if true_to_false:
        print("\n  将关闭 (true → false):")
        for flag, current, new in true_to_false:
            print(f"    ⛔ {flag}: {current} → {new}")

    print(f"\n  总计变更: {len(changes)} 项")
    print("=" * 60)


def print_current_status(filepath: str) -> None:
    """打印当前 Flag 状态。"""
    flags = parse_flags_file(filepath)
    print("=" * 60)
    print("  当前 Feature Flag 状态")
    print("=" * 60)
    for stage in range(1, 6):
        stage_flags = STAGE_FLAGS.get(stage, [])
        print(f"\n  Stage {stage}:")
        for flag in stage_flags:
            value = flags.get(flag, "N/A")
            icon = "🟢" if value.lower() == "true" else "⚪"
            print(f"    {icon} {flag}: {value}")
    print("=" * 60)


# ------------------------------------------------------------------
# CLI
# ------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="系统回滚脚本 — 按阶段关闭 Feature Flag",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
阶段说明:
  Stage 1: 基础架构 (USE_NEW_ARCH)
  Stage 2: 安全+HOST (USE_NEW_HOST, USE_INPUT_SANITIZER)
  Stage 3: Persona 体系 (USE_NEW_PERSONA, USE_PERSONA_MANAGER, USE_NEW_PERSONA_SYSTEM)
  Stage 4: 核心模块闭环 (EVENT_BUS, TASK_MANAGER, TOOL_ROUTER, MODEL_GATEWAY, MEMORY_STORE)
  Stage 5: 迁移收尾 (同 Stage 4)
  Stage 0 / --full: 全部关闭 → 回到纯旧系统

使用示例:
  python scripts/rollback.py --preview --stage 4    # 预览回退 Stage 4
  python scripts/rollback.py --stage 3              # 回到 Stage 3 状态
  python scripts/rollback.py --full                 # 全量回滚
  python scripts/rollback.py --stage 0              # 同 --full
  python scripts/rollback.py --restore backups/feature_flags_xxx.yaml
        """,
    )

    # 操作模式（互斥组）
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--stage",
        type=int,
        choices=[0, 1, 2, 3, 4, 5],
        default=None,
        help="回滚到指定阶段。0 = 全量回滚（全部 false），5 = 全部启用",
    )
    group.add_argument(
        "--full",
        action="store_true",
        help="全量回滚到旧系统（等同于 --stage 0）",
    )
    group.add_argument(
        "--restore",
        type=str,
        default="",
        metavar="BACKUP_PATH",
        help="从备份恢复 feature_flags.yaml",
    )

    parser.add_argument(
        "--preview",
        action="store_true",
        help="预览将要变更的 Flag（不实际执行）",
    )
    parser.add_argument(
        "--project-root",
        default="",
        help="项目根目录（默认自动推断）",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        help="显示当前 Flag 状态",
    )
    parser.add_argument(
        "--no-backup",
        action="store_true",
        help="跳过自动备份",
    )

    args = parser.parse_args()

    project_root = args.project_root or str(Path(__file__).resolve().parent.parent)
    flags_file = os.path.join(project_root, DEFAULT_FLAGS_FILE)

    if not os.path.isfile(flags_file):
        print(f"错误: 找不到 {flags_file}")
        sys.exit(1)

    # 显示状态
    print(f"项目根目录: {project_root}")
    if args.status:
        print_current_status(flags_file)
        return

    # 恢复模式
    if args.restore:
        ok = restore_from_backup(args.restore, flags_file, project_root)
        if ok:
            print_current_status(flags_file)
        sys.exit(0 if ok else 1)

    # 确定目标阶段
    if args.full:
        target_stage = 0
    elif args.stage is not None:
        target_stage = args.stage
    else:
        parser.print_help()
        print("\n错误: 请指定 --stage / --full / --restore")
        sys.exit(1)

    # 计算变更
    current_flags = parse_flags_file(flags_file)
    changes = compute_rollback_plan(current_flags, target_stage)

    if args.preview:
        print_preview(changes, target_stage)
        return

    if not changes:
        print(f"所有 Flag 已处于 Stage {target_stage} 的期望状态，无需变更。")
        return

    # 备份
    if not args.no_backup:
        backup_path = backup_flags(flags_file, project_root)
        print(f"已备份: {backup_path}")

    # 应用变更
    print(f"\n执行回滚 → Stage {target_stage}...")
    apply_rollback(flags_file, changes)
    print("完成！")

    # 显示变更摘要
    true_to_false = [(f, c, n) for f, c, n in changes if n == "false"]
    false_to_true = [(f, c, n) for f, c, n in changes if n == "true"]
    print(f"\n变更摘要:")
    if false_to_true:
        print(f"  启用: {', '.join(f for f, _, _ in false_to_true)}")
    if true_to_false:
        print(f"  关闭: {', '.join(f for f, _, _ in true_to_false)}")

    print_current_status(flags_file)


if __name__ == "__main__":
    main()
