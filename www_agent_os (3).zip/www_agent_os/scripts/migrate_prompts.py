#!/usr/bin/env python3
"""
提示词迁移脚本：从 data/skills/ 各 Agent 的 SKILL.md 提取 prompt，
转换为 Persona 的 core_prompt 格式并生成迁移报告。

源：data/skills/{agent}/SKILL.md
目标：生成迁移报告，列出已迁移和需人工审核的 prompt。

特性：
  - dry-run 模式（默认）：仅生成迁移报告
  - --execute 模式：将提取的 prompt 写入 persona_prompts/ 目录
  - 自动标注完整性（是否包含角色定义、能力范围、操作指南等关键段落）

使用方式：
  python scripts/migrate_prompts.py                    # 试运行，生成报告
  python scripts/migrate_prompts.py --execute          # 实际导出
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ------------------------------------------------------------------
# 常量
# ------------------------------------------------------------------

SKILLS_DIR = "data/skills"

# 各 Agent 对应的 Persona 映射
AGENT_TO_PERSONA: Dict[str, str] = {
    "host": "host_persona",
    "file-specialist": "file_persona",
    "chat-specialist": "chat_persona",
    "software-specialist": "software_persona",
    "system-specialist": "system_persona",
    "web-specialist": "web_persona",
    "search-specialist": "search_persona",
    "monitor-specialist": "monitor_persona",
}

# prompt 中的关键章节标记（用于完整性检测）
CRITICAL_SECTIONS: Dict[str, List[str]] = {
    "role_definition": [
        r"(?i)(身份|角色|你是|you are|identity|role\s*definition)",
        r"(?i)(name\s*:|名称|主人格|副人格|专员|specialist)",
    ],
    "capabilities": [
        r"(?i)(能力|职责|负责|擅长|capabilit|responsibilit|function)",
    ],
    "constraints": [
        r"(?i)(限制|禁止|不得|不允许|constraint|restriction|do\s*not)",
    ],
    "output_format": [
        r"(?i)(输出格式|回复格式|format|response\s*format|markdown|json)",
    ],
    "protocols": [
        r"(?i)(协议|流程|protocol|工作流|workflow|pipeline|确认流程)",
    ],
}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("migrate_prompts")


# ------------------------------------------------------------------
# 扫描
# ------------------------------------------------------------------

def scan_skill_files(project_root: str) -> List[Dict[str, Any]]:
    """扫描 data/skills/ 下所有 SKILL.md 文件。

    Returns:
        [{"agent_id": str, "persona_id": str, "file_path": str, "raw_content": str}, ...]
    """
    skills_dir = os.path.join(project_root, SKILLS_DIR)
    if not os.path.isdir(skills_dir):
        logger.error("skills 目录不存在: %s", skills_dir)
        return []

    results: List[Dict[str, Any]] = []

    for agent_dir in sorted(os.listdir(skills_dir)):
        agent_path = os.path.join(skills_dir, agent_dir)
        if not os.path.isdir(agent_path):
            continue

        skill_file = os.path.join(agent_path, "SKILL.md")
        if not os.path.isfile(skill_file):
            continue

        try:
            with open(skill_file, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            logger.warning("读取 %s 失败: %s", skill_file, e)
            continue

        persona_id = AGENT_TO_PERSONA.get(agent_dir, agent_dir)

        results.append({
            "agent_id": agent_dir,
            "persona_id": persona_id,
            "file_path": skill_file,
            "raw_content": content,
        })

    return results


# ------------------------------------------------------------------
# 解析与分析
# ------------------------------------------------------------------

def parse_skill_metadata(content: str) -> Dict[str, Any]:
    """从 SKILL.md 的 YAML front matter 中提取元数据。

    Returns:
        {"name": str, "description": str, "agent_created": bool, ...}
    """
    meta: Dict[str, Any] = {}

    # 尝试提取 YAML front matter (--- ... ---)
    fm_match = re.match(r"^---\s*\n(.*?)\n---", content, re.DOTALL)
    if fm_match:
        fm_text = fm_match.group(1)
        for line in fm_text.split("\n"):
            line = line.strip()
            if ":" in line and not line.startswith("#"):
                key, _, value = line.partition(":")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                # 简单的类型推断
                if value.lower() == "true":
                    meta[key] = True
                elif value.lower() == "false":
                    meta[key] = False
                elif value.isdigit():
                    meta[key] = int(value)
                else:
                    meta[key] = value

    return meta


def extract_core_prompt(content: str) -> str:
    """从 SKILL.md 中提取核心 prompt 内容（body 部分，去除 front matter 和注释）。"""
    # 去除 YAML front matter
    body = re.sub(r"^---\s*\n.*?\n---\s*\n", "", content, flags=re.DOTALL)

    # 去除变量说明注释块（以 # 开头的块注释）
    body = re.sub(r"^\s*#.*\n", "", body, flags=re.MULTILINE)

    # 去除多余的连续空行
    body = re.sub(r"\n{3,}", "\n\n", body)

    return body.strip()


def analyze_prompt_completeness(content: str) -> Dict[str, bool]:
    """分析 prompt 内容的完整性——检测关键章节是否涵盖。"""
    results: Dict[str, bool] = {}
    for section_name, patterns in CRITICAL_SECTIONS.items():
        found = False
        for pat in patterns:
            if re.search(pat, content):
                found = True
                break
        results[section_name] = found
    return results


def build_prompt_summary(raw_content: str) -> Dict[str, Any]:
    """构建单个 SKILL.md 的迁移摘要。"""
    meta = parse_skill_metadata(raw_content)
    core_prompt = extract_core_prompt(raw_content)
    completeness = analyze_prompt_completeness(raw_content)

    # 统计信息
    total_lines = raw_content.count("\n") + 1
    prompt_lines = core_prompt.count("\n") + 1
    total_chars = len(raw_content)
    prompt_chars = len(core_prompt)

    # 判断是否需要人工审核：关键章节缺失
    missing_sections = [k for k, v in completeness.items() if not v]

    return {
        "meta": meta,
        "core_prompt": core_prompt,
        "completeness": completeness,
        "missing_sections": missing_sections,
        "needs_review": len(missing_sections) > 0,
        "total_lines": total_lines,
        "prompt_lines": prompt_lines,
        "total_chars": total_chars,
        "prompt_chars": prompt_chars,
    }


# ------------------------------------------------------------------
# 迁移报告生成
# ------------------------------------------------------------------

def generate_migration_report(
    scan_results: List[Dict[str, Any]],
    project_root: str,
) -> str:
    """生成迁移报告（Markdown 格式）。

    Args:
        scan_results: 扫描结果列表。
        project_root: 项目根目录。

    Returns:
        Markdown 格式的迁移报告。
    """
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    summaries: List[Dict[str, Any]] = []

    for item in scan_results:
        summary = build_prompt_summary(item["raw_content"])
        summary["agent_id"] = item["agent_id"]
        summary["persona_id"] = item["persona_id"]
        summary["file_path"] = item["file_path"]
        summaries.append(summary)

    # 统计
    total_agents = len(summaries)
    migrated = sum(1 for s in summaries if not s["needs_review"])
    needs_review = sum(1 for s in summaries if s["needs_review"])
    total_prompt_chars = sum(s["prompt_chars"] for s in summaries)

    # 生成报告
    lines: List[str] = [
        f"# SKILL.md → Persona Prompt 迁移报告",
        f"",
        f"**生成时间**: {now_str}",
        f"**项目根目录**: `{project_root}`",
        f"",
        f"---",
        f"",
        f"## 概览",
        f"",
        f"| 维度 | 值 |",
        f"|------|-----|",
        f"| 扫描 Agent 数 | {total_agents} |",
        f"| 完整迁移 | {migrated} |",
        f"| 需人工审核 | {needs_review} |",
        f"| 总 prompt 字符数 | {total_prompt_chars:,} |",
        f"",
        f"---",
        f"",
        f"## 逐 Agent 详情",
        f"",
    ]

    for summary in summaries:
        agent_id = summary["agent_id"]
        persona_id = summary["persona_id"]
        meta = summary.get("meta", {})
        completeness = summary["completeness"]

        name = meta.get("name", agent_id)
        desc = meta.get("description", "—")
        agent_created = meta.get("agent_created", None)

        status = "✅ 完整" if not summary["needs_review"] else "⚠️ 需审核"

        lines.append(f"### {name} ({agent_id} → {persona_id}) {status}")
        lines.append("")
        lines.append(f"- **描述**: {desc}")
        if agent_created is not None:
            lines.append(f"- **Agent 已创建**: {agent_created}")
        lines.append(f"- **文件**: `{summary['file_path']}`")
        lines.append(f"- **总行数**: {summary['total_lines']} (prompt: {summary['prompt_lines']})")
        lines.append(f"- **总字符数**: {summary['total_chars']:,} (prompt: {summary['prompt_chars']:,})")
        lines.append("")
        lines.append("**章节完整性**:")
        lines.append("")
        for section, present in completeness.items():
            icon = "✅" if present else "❌"
            lines.append(f"- {icon} {section}")
        if summary["missing_sections"]:
            lines.append(f"\n⚠️ **缺少章节**: {', '.join(summary['missing_sections'])} → 需人工审核")
        lines.append("")
        lines.append("---")
        lines.append("")

    # 汇总表
    lines.append("## 迁移状态汇总")
    lines.append("")
    lines.append("| Agent | Persona | 行数 | 字符数 | 完整 | 需审核 |")
    lines.append("|-------|---------|-----:|-------:|:----:|:------:|")
    for summary in summaries:
        complete_count = sum(1 for v in summary["completeness"].values() if v)
        total_sections = len(summary["completeness"])
        status_icon = "✅" if not summary["needs_review"] else "⚠️"
        review_icon = "是" if summary["needs_review"] else "否"
        lines.append(
            f"| {summary['agent_id']} | {summary['persona_id']} "
            f"| {summary['prompt_lines']} | {summary['prompt_chars']:,} "
            f"| {status_icon} {complete_count}/{total_sections} | {review_icon} |"
        )
    lines.append("")

    # 建议
    lines.append("## 建议操作")
    lines.append("")
    for summary in summaries:
        if summary["needs_review"]:
            lines.append(
                f"- **{summary['agent_id']}**：缺少 {summary['missing_sections']} 章节，"
                f"建议人工补充后重新导入"
            )
    if needs_review == 0:
        lines.append("- 所有 prompt 已完整迁移，无需额外人工审核。")

    return "\n".join(lines)


def export_prompts(
    scan_results: List[Dict[str, Any]],
    project_root: str,
) -> Dict[str, str]:
    """导出提取的 core_prompt 到文件。

    Returns:
        {persona_id: output_path, ...}
    """
    output_dir = os.path.join(project_root, "data", "persona_prompts")
    os.makedirs(output_dir, exist_ok=True)

    outputs: Dict[str, str] = {}

    for item in scan_results:
        agent_id = item["agent_id"]
        persona_id = item["persona_id"]

        summary = build_prompt_summary(item["raw_content"])

        # 生成 persona prompt 文件（JSON 格式）
        prompt_data = {
            "persona_id": persona_id,
            "agent_source": agent_id,
            "source_file": item["file_path"],
            "extracted_at": datetime.now(timezone.utc).isoformat(),
            "meta": summary["meta"],
            "core_prompt": summary["core_prompt"],
            "completeness": summary["completeness"],
            "needs_review": summary["needs_review"],
        }

        output_path = os.path.join(output_dir, f"{persona_id}_prompt.json")
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(prompt_data, f, ensure_ascii=False, indent=2)

        outputs[persona_id] = output_path
        logger.info("导出: %s", output_path)

    return outputs


# ------------------------------------------------------------------
# CLI
# ------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="从 SKILL.md 提取 prompt 并生成迁移报告",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python scripts/migrate_prompts.py                    # 试运行，生成报告
  python scripts/migrate_prompts.py --execute          # 实际导出
  python scripts/migrate_prompts.py --report-only      # 仅生成报告不导出
        """,
    )
    parser.add_argument(
        "--project-root",
        default="",
        help="项目根目录（默认自动推断）",
    )
    parser.add_argument(
        "--execute",
        action="store_true",
        help="实际执行导出（默认为 dry-run）",
    )
    parser.add_argument(
        "--report-only",
        action="store_true",
        help="仅生成报告，不导出 prompt 文件（即使有 --execute）",
    )
    parser.add_argument(
        "--output-report",
        default="",
        help="迁移报告输出路径（默认输出到 stdout）",
    )

    args = parser.parse_args()

    project_root = args.project_root or str(Path(__file__).resolve().parent.parent)
    print(f"项目根目录: {project_root}")

    # 扫描
    logger.info("扫描 SKILL.md 文件...")
    scan_results = scan_skill_files(project_root)
    if not scan_results:
        logger.warning("未找到任何 SKILL.md 文件")
        return

    logger.info("发现 %d 个 Agent 的 SKILL.md", len(scan_results))

    # 生成报告
    report = generate_migration_report(scan_results, project_root)

    if args.output_report:
        with open(args.output_report, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"报告已保存: {args.output_report}")
    else:
        print(report)

    # 导出
    if args.execute and not args.report_only:
        print("\n导出 prompt 文件...")
        outputs = export_prompts(scan_results, project_root)
        print(f"\n共导出 {len(outputs)} 个 prompt 文件到 data/persona_prompts/")
        for persona_id, path in sorted(outputs.items()):
            print(f"  {persona_id}: {path}")
    elif not args.execute:
        print("\n[Dry-run] 使用 --execute 参数执行实际导出。")


if __name__ == "__main__":
    main()
