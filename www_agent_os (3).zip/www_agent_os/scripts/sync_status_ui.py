#!/usr/bin/env python3
"""
同步前端状态检测表的硬编码数据与后端实际评分数据。

从 data/memory/*/scores.json 读取真实评分，更新 index-HDekYfdd.js 中的 Vf 数组。
同时修复评分与状态显示逻辑不一致的问题（评分正值但显示"危急状态"）。

运行：python scripts/sync_status_ui.py
"""

import json
import os
import re
import sys
from pathlib import Path
from typing import Optional

PROJECT_ROOT = Path(__file__).resolve().parent.parent
MEMORY_DIR = PROJECT_ROOT / "data" / "memory"
JS_FILE = PROJECT_ROOT / "ui" / "assets" / "index-DHekYfdd.js"

# 人格元信息（与 config/app_config.py 保持一致）
PERSONAS = {
    "host": {"name": "指挥者", "role": "commander", "model": "qwen3:14b",      "avatarLetter": "H",  "avatarColor": "#FF6B35"},
    "S":    {"name": "监察员",   "role": "supervisor", "model": "gemma3:12b",        "avatarLetter": "S",  "avatarColor": "#FF7675"},
    "S1":   {"name": "软件专员", "role": "coder",      "model": "qwen2.5-coder:7b",  "avatarLetter": "S1", "avatarColor": "#14B8A6"},
    "S2":   {"name": "系统专员", "role": "sysadmin",   "model": "qwen2.5-coder:1.5b","avatarLetter": "S2", "avatarColor": "#06B6D4"},
    "S3":   {"name": "网络专员", "role": "web",        "model": "llama3.2:3b",        "avatarLetter": "S3", "avatarColor": "#10B981"},
    "S4":   {"name": "文件专员", "role": "file",       "model": "qwen2.5:3b",         "avatarLetter": "S4", "avatarColor": "#F59E0B"},
    "S5":   {"name": "检索专员", "role": "search",     "model": "deepseek-r1:7b",     "avatarLetter": "S5", "avatarColor": "#A855F7"},
    "S6":   {"name": "聊天专员", "role": "chat",       "model": "qwen2.5:7b",         "avatarLetter": "S6", "avatarColor": "#74B9FF"},
}


def load_score(pid: str) -> Optional[dict]:
    """从 memory/{pid}/scores.json 读取评分数据"""
    path = MEMORY_DIR / pid / "scores.json"
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"  [WARN] 无法读取 {path}: {e}")
        return None


def compute_status(incentive: int, penalty: int) -> str:
    """
    根据激励/惩戒星数计算状态。

    后端逻辑 (PersonaState.status_text):
    - net_incentive >= 3  → "激励状态"
    - net_incentive <= -3 → "惩戒状态"
    - else               → "正常"

    前端映射 (Uf 组件):
    - critical → 危急
    - warning  → 警告
    - normal   → 正常
    """
    net = incentive - penalty
    if net <= -3:
        return "critical"
    elif net < 0:
        return "warning"
    else:
        return "normal"


def compute_score_display(task_score: float, incentive: int, penalty: int) -> int:
    """
    计算前端显示的评分值。

    优先使用 task_score (1-5 评分均值取整)，无任务则基于激励星数。
    返回值范围 1-5。
    """
    if task_score > 0:
        return max(1, min(5, round(task_score)))
    # 无任务记录时基于激励星数
    net = incentive - penalty
    return max(1, min(5, 3 + net // 2))


def compute_progress(task_score: float, task_count: int) -> float:
    """
    计算进度百分比 (0-100)。

    task_score 映射到 0-100%：
    - task_score=5 → 100%
    - task_score=3 → 60%
    - task_score=0 → 50%（无任务默认值）
    """
    if task_count == 0:
        return 50.0
    return max(5.0, min(100.0, task_score / 5.0 * 100))


def generate_vf_js() -> str:
    """生成修正后的 Vf JavaScript 数组"""
    entries = []
    for pid, meta in PERSONAS.items():
        data = load_score(pid)
        if data is None:
            # 使用默认值
            incentive, penalty = 3, 0
            task_score, task_count = 0.0, 0
        else:
            incentive = data.get("incentive_stars", 3)
            penalty = data.get("penalty_stars", 0)
            task_score = data.get("task_score", 0.0)
            task_count = data.get("task_count", 0)

        status = compute_status(incentive, penalty)
        score = compute_score_display(task_score, incentive, penalty)
        progress = compute_progress(task_score, task_count)

        entry = (
            f'{{id:`{pid}`,name:`{meta["name"]}`,role:`{meta["role"]}`,'
            f'model:`{meta["model"]}`,status:`{status}`,progress:{progress:.0f},'
            f'score:{score},avatarLetter:`{meta["avatarLetter"]}`,'
            f'avatarColor:`{meta["avatarColor"]}`}}'
        )
        entries.append(entry)

    inner = ",".join(entries)
    return f"var Vf=[{inner}],"


def main():
    if not JS_FILE.exists():
        print(f"错误: 找不到 {JS_FILE}")
        sys.exit(1)

    original = JS_FILE.read_text(encoding="utf-8")

    # 匹配旧 Vf 定义（兼容旧版和已修复版本）
    pattern = r"var Vf=\[.*?\],"
    match = re.search(pattern, original)
    if not match:
        print("错误: 在 JS 文件中找不到 Vf 数组定义，请检查正则模式")
        sys.exit(1)

    old_vf = match.group(0)
    new_vf = generate_vf_js()

    if old_vf == new_vf:
        print("Vf 数据已经是最新，无需更新。")
        return

    updated = original.replace(old_vf, new_vf, 1)
    JS_FILE.write_text(updated, encoding="utf-8")

    # 打印变更摘要
    print(f"已更新 {JS_FILE}")
    print(f"  Old: {old_vf[:80]}...")
    print(f"  New: {new_vf[:80]}...")

    # 详细列出每个 Persona 的状态
    print("\n  当前评分状态：")
    for pid, meta in PERSONAS.items():
        data = load_score(pid)
        inc = data["incentive_stars"] if data else 3
        pen = data["penalty_stars"] if data else 0
        ts = data["task_score"] if data else 0.0
        tc = data["task_count"] if data else 0
        net = inc - pen
        status = compute_status(inc, pen)
        status_cn = {"critical": "危急", "warning": "警告", "normal": "正常"}[status]
        print(f"    {pid:>4s} {meta['name']:>5s} | 激励:{inc} 惩戒:{pen} "
              f"net:{net:+d} | task_score:{ts:.1f} tasks:{tc} | → {status_cn}")


if __name__ == "__main__":
    main()
