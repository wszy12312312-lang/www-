#!/usr/bin/env python3
"""
数据迁移脚本：将 legacy/memory/ 中的旧记忆数据迁移到新 MemoryStore 格式。

旧格式（legacy/memory/ 目录结构）：
  host/history.json       → [{"role": str, "content": str}, ...]
  host/scores.json        → {"incentive_stars": int, "score_log": [...]}
  host/experiences.json   → [{"time": str, "task": str, ...}, ...]
  {persona_id}/history.json
  {persona_id}/scores.json
  {persona_id}/experiences.json
  www_task_log.jsonl      → 每行一个 {"time": str, "persona": str, "question": str, "answer": str, "score": dict}

新格式（data/memory/）：
  {persona_id}.json       → [MemoryEntry.to_dict(), ...]

特性：
  - dry-run 模式（默认）：只输出迁移计划，不实际写入
  - 自动备份：迁移前备份旧数据到 data/memory/backup/
  - checksum 验证：备份后校验完整性
  - 增量迁移：不重复迁移已存在的记忆

使用方式：
  python scripts/migrate_memory.py --dry-run          # 试运行
  python scripts/migrate_memory.py --execute          # 实际迁移
  python scripts/migrate_memory.py --execute --force  # 强制覆盖
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ------------------------------------------------------------------
# 常量
# ------------------------------------------------------------------

# 旧记忆目录（相对于项目根目录）
LEGACY_MEMORY_DIR = "legacy/memory"

# 新记忆目录（相对于项目根目录）
NEW_MEMORY_DIR = "data/memory"

# 备份子目录
BACKUP_SUBDIR = "backup"

# 支持的角色映射
ROLE_MAP: Dict[str, str] = {
    "user": "user",
    "assistant": "assistant",
    "system": "system",
}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("migrate_memory")


# ------------------------------------------------------------------
# 工具函数
# ------------------------------------------------------------------

def sha256_file(filepath: str) -> str:
    """计算文件的 SHA256 哈希值。"""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_json(data: Any) -> str:
    """计算 JSON 可序列化数据的 SHA256。"""
    raw = json.dumps(data, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def ensure_dir(path: str) -> None:
    """确保目录存在。"""
    os.makedirs(path, exist_ok=True)


def now_iso() -> str:
    """返回当前 UTC ISO 时间字符串。"""
    return datetime.now(timezone.utc).isoformat()


# ------------------------------------------------------------------
# 旧数据扫描
# ------------------------------------------------------------------

def scan_legacy_memory(project_root: str) -> List[Dict[str, Any]]:
    """扫描 legacy/memory/ 下的所有旧记忆数据。

    Returns:
        发现列表，每个元素为 {"type": str, "persona_id": str, "source_path": str, "data": Any}
    """
    legacy_dir = os.path.join(project_root, LEGACY_MEMORY_DIR)
    if not os.path.isdir(legacy_dir):
        logger.error("旧记忆目录不存在: %s", legacy_dir)
        return []

    findings: List[Dict[str, Any]] = []

    # 1. 扫描各 persona 子目录
    for persona_dir in sorted(os.listdir(legacy_dir)):
        persona_path = os.path.join(legacy_dir, persona_dir)
        if not os.path.isdir(persona_path):
            continue

        # history.json
        history_file = os.path.join(persona_path, "history.json")
        if os.path.isfile(history_file):
            try:
                with open(history_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                findings.append({
                    "type": "history",
                    "persona_id": persona_dir,
                    "source_path": history_file,
                    "data": data,
                })
            except Exception as e:
                logger.warning("跳过 %s: %s", history_file, e)

        # scores.json
        scores_file = os.path.join(persona_path, "scores.json")
        if os.path.isfile(scores_file):
            try:
                with open(scores_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                findings.append({
                    "type": "scores",
                    "persona_id": persona_dir,
                    "source_path": scores_file,
                    "data": data,
                })
            except Exception as e:
                logger.warning("跳过 %s: %s", scores_file, e)

        # experiences.json
        exp_file = os.path.join(persona_path, "experiences.json")
        if os.path.isfile(exp_file):
            try:
                with open(exp_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                findings.append({
                    "type": "experiences",
                    "persona_id": persona_dir,
                    "source_path": exp_file,
                    "data": data,
                })
            except Exception as e:
                logger.warning("跳过 %s: %s", exp_file, e)

    # 2. www_task_log.jsonl
    task_log_file = os.path.join(legacy_dir, "www_task_log.jsonl")
    if os.path.isfile(task_log_file):
        tasks: List[Dict[str, Any]] = []
        try:
            with open(task_log_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            tasks.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
            if tasks:
                findings.append({
                    "type": "task_log",
                    "persona_id": "_task_log",
                    "source_path": task_log_file,
                    "data": tasks,
                })
        except Exception as e:
            logger.warning("跳过 %s: %s", task_log_file, e)

    return findings


# ------------------------------------------------------------------
# 格式转换
# ------------------------------------------------------------------

def _generate_memory_id(persona_id: str, content: str, timestamp: str, role: str) -> str:
    """生成简洁的记忆 ID。"""
    raw = f"{persona_id}:{content}:{timestamp}:{role}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]


def convert_history_to_entries(
    persona_id: str,
    history: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """将旧 history.json 转换为 MemoryEntry dict 列表。"""
    entries: List[Dict[str, Any]] = []
    for idx, item in enumerate(history):
        role = item.get("role", "user")
        content = item.get("content", "")
        if not content:
            continue
        ts = now_iso()
        entry_id = _generate_memory_id(persona_id, content, ts, role)
        entries.append({
            "id": entry_id,
            "persona_id": persona_id,
            "content": content,
            "role": role,
            "created_at": ts,
            "metadata": {
                "type": "history",
                "source": "migrate_memory",
                "index": idx,
            },
            "ttl": 86400 * 365,  # 1 年 TTL
            "access_count": 0,
        })
    return entries


def convert_scores_to_entries(
    persona_id: str,
    scores: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """将旧 scores.json 转换为 MemoryEntry dict 列表。"""
    entries: List[Dict[str, Any]] = []
    content = json.dumps(scores, ensure_ascii=False)
    ts = now_iso()
    entry_id = _generate_memory_id(persona_id, content, ts, "system")
    entries.append({
        "id": entry_id,
        "persona_id": persona_id,
        "content": content,
        "role": "system",
        "created_at": ts,
        "metadata": {
            "type": "scores",
            "source": "migrate_memory",
        },
        "ttl": 86400 * 365,
        "access_count": 0,
    })
    return entries


def convert_experiences_to_entries(
    persona_id: str,
    experiences: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """将旧 experiences.json 转换为 MemoryEntry dict 列表。"""
    entries: List[Dict[str, Any]] = []
    for idx, item in enumerate(experiences):
        content = json.dumps(item, ensure_ascii=False)
        ts = now_iso()
        entry_id = _generate_memory_id(persona_id, content, ts, "system")
        entries.append({
            "id": entry_id,
            "persona_id": persona_id,
            "content": content,
            "role": "system",
            "created_at": ts,
            "metadata": {
                "type": "experience",
                "source": "migrate_memory",
                "index": idx,
            },
            "ttl": 86400 * 365,
            "access_count": 0,
        })
    return entries


def convert_task_log_to_entries(
    tasks: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """将旧 www_task_log.jsonl 转换为 MemoryEntry dict 列表。"""
    entries: List[Dict[str, Any]] = []
    for idx, task in enumerate(tasks):
        persona_id = task.get("persona", "unknown")
        question = task.get("question", "")
        answer = task.get("answer", "")
        score = task.get("score", {})
        timestamp = task.get("time", now_iso())

        # 生成条目的内容
        content_obj = {
            "question": question,
            "answer": answer,
            "score": score,
        }
        content = json.dumps(content_obj, ensure_ascii=False)
        entry_id = _generate_memory_id(persona_id, content, timestamp, "system")

        entries.append({
            "id": entry_id,
            "persona_id": persona_id,
            "content": content,
            "role": "system",
            "created_at": timestamp,
            "metadata": {
                "type": "task_log",
                "source": "migrate_memory",
                "index": idx,
                "original_time": timestamp,
            },
            "ttl": 86400 * 365,
            "access_count": 0,
        })
    return entries


# ------------------------------------------------------------------
# 备份
# ------------------------------------------------------------------

def backup_legacy_memory(project_root: str) -> Tuple[str, Dict[str, str]]:
    """备份 legacy/memory/ 到 data/memory/backup/ 子目录。

    Returns:
        (backup_dir, {filepath: checksum}) 备份目录和校验和字典。
    """
    legacy_dir = os.path.join(project_root, LEGACY_MEMORY_DIR)
    backup_dir = os.path.join(project_root, NEW_MEMORY_DIR, BACKUP_SUBDIR)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_target = os.path.join(backup_dir, f"legacy_backup_{timestamp}")

    if not os.path.isdir(legacy_dir):
        logger.warning("legacy/memory 目录不存在，跳过备份")
        return backup_target, {}

    ensure_dir(backup_target)

    checksums: Dict[str, str] = {}
    for root, dirs, files in os.walk(legacy_dir):
        for fname in files:
            src = os.path.join(root, fname)
            rel = os.path.relpath(src, legacy_dir)
            dst = os.path.join(backup_target, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            checksums[rel] = sha256_file(src)

    logger.info("备份完成: %s (%d 个文件)", backup_target, len(checksums))
    return backup_target, checksums


def verify_backup(legacy_dir: str, backup_target: str, checksums: Dict[str, str]) -> bool:
    """通过校验和验证备份完整性。"""
    all_ok = True
    for rel_path, expected_hash in checksums.items():
        src = os.path.join(legacy_dir, rel_path)
        dst = os.path.join(backup_target, rel_path)
        if not os.path.isfile(dst):
            logger.error("备份缺失文件: %s", rel_path)
            all_ok = False
            continue
        actual = sha256_file(src)
        if actual != expected_hash:
            logger.error("校验和不匹配: %s (expected=%s, got=%s)", rel_path, expected_hash[:12], actual[:12])
            all_ok = False
    return all_ok


# ------------------------------------------------------------------
# 迁移执行
# ------------------------------------------------------------------

def build_migration_plan(findings: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    """构建迁移计划：将扫描结果转换为按 persona_id 分组的 MemoryEntry 列表。

    Returns:
        {persona_id: [entry_dict, ...]}
    """
    plan: Dict[str, List[Dict[str, Any]]] = {}

    for finding in findings:
        persona_id: str = finding["persona_id"]
        ftype: str = finding["type"]
        data: Any = finding["data"]

        if persona_id not in plan:
            plan[persona_id] = []

        if ftype == "history":
            plan[persona_id].extend(convert_history_to_entries(persona_id, data))
        elif ftype == "scores":
            plan[persona_id].extend(convert_scores_to_entries(persona_id, data))
        elif ftype == "experiences":
            plan[persona_id].extend(convert_experiences_to_entries(persona_id, data))
        elif ftype == "task_log":
            entries = convert_task_log_to_entries(data)
            for entry in entries:
                pid = entry["persona_id"]
                if pid not in plan:
                    plan[pid] = []
                plan[pid].append(entry)

    return plan


def execute_migration(
    project_root: str,
    plan: Dict[str, List[Dict[str, Any]]],
    force: bool = False,
) -> Dict[str, int]:
    """执行迁移，将 MemoryEntry 写入新格式文件。

    Args:
        project_root: 项目根目录。
        plan: 迁移计划。
        force: 是否强制覆盖已有文件。

    Returns:
        {persona_id: entry_count}
    """
    new_dir = os.path.join(project_root, NEW_MEMORY_DIR)
    ensure_dir(new_dir)

    results: Dict[str, int] = {}

    for persona_id, entries in plan.items():
        if not entries:
            continue

        safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in persona_id)
        target_path = os.path.join(new_dir, f"{safe_name}.json")

        # 检查是否已存在
        existing: List[Dict[str, Any]] = []
        if os.path.isfile(target_path):
            with open(target_path, "r", encoding="utf-8") as f:
                existing = json.load(f)

            if existing and not force:
                logger.info(
                    "跳过 %s：目标文件已有 %d 条记录（使用 --force 强制覆盖）",
                    persona_id, len(existing)
                )
                results[persona_id] = 0
                continue

        # 合并：去重（按 ID）
        existing_ids = {e.get("id", "") for e in existing}
        new_entries = [e for e in entries if e["id"] not in existing_ids]
        combined = existing + new_entries

        # 写入
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(combined, f, ensure_ascii=False, indent=2)

        results[persona_id] = len(new_entries)
        logger.info("写入 %s: %d 条新记录（总计 %d 条）", target_path, len(new_entries), len(combined))

    return results


# ------------------------------------------------------------------
# 报告
# ------------------------------------------------------------------

def print_dry_run_report(plan: Dict[str, List[Dict[str, Any]]]) -> None:
    """输出 dry-run 迁移计划。"""
    print("=" * 60)
    print("  迁移计划 (DRY RUN)")
    print("=" * 60)
    total = 0
    persona_count = 0
    for persona_id, entries in sorted(plan.items()):
        count = len(entries)
        if count == 0:
            continue
        persona_count += 1
        total += count
        # 统计类型
        type_counts: Dict[str, int] = {}
        for e in entries:
            t = e.get("metadata", {}).get("type", "unknown")
            type_counts[t] = type_counts.get(t, 0) + 1
        type_str = ", ".join(f"{k}={v}" for k, v in sorted(type_counts.items()))
        print(f"  {persona_id}: {count:4d} 条 ({type_str})")

    print("-" * 60)
    print(f"  总计: {total} 条记录, {persona_count} 个 Persona")
    print("=" * 60)
    print()
    print("使用 --execute 参数执行实际迁移。")


def print_migration_report(
    backup_dir: str,
    checksum_count: int,
    verify_ok: bool,
    results: Dict[str, int],
) -> None:
    """输出迁移执行报告。"""
    print("=" * 60)
    print("  迁移执行报告")
    print("=" * 60)
    print(f"  备份目录: {backup_dir}")
    print(f"  备份文件数: {checksum_count}")
    print(f"  校验验证: {'通过' if verify_ok else '失败'}")
    print()
    total = 0
    for persona_id, count in sorted(results.items()):
        if count > 0:
            print(f"  {persona_id}: +{count} 条")
            total += count
        else:
            print(f"  {persona_id}: 跳过（已存在）")
    print("-" * 60)
    print(f"  总计新增: {total} 条")
    print("=" * 60)


# ------------------------------------------------------------------
# CLI
# ------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="将旧 memory 数据迁移到新 MemoryStore 格式",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python scripts/migrate_memory.py                    # 试运行，查看计划
  python scripts/migrate_memory.py --execute          # 实际迁移
  python scripts/migrate_memory.py --execute --force  # 强制覆盖
        """,
    )
    parser.add_argument(
        "--project-root",
        default="",
        help="项目根目录（默认自动推断）",
    )
    parser.add_argument(
        "--execute",
        action="store_true",
        help="实际执行迁移（默认为 dry-run 试运行）",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="强制覆盖已有目标文件",
    )
    parser.add_argument(
        "--no-backup",
        action="store_true",
        help="跳过备份步骤",
    )
    parser.add_argument(
        "--no-verify",
        action="store_true",
        help="跳过校验步骤",
    )

    args = parser.parse_args()

    # 推断项目根目录
    project_root = args.project_root or str(Path(__file__).resolve().parent.parent)
    print(f"项目根目录: {project_root}")

    # 扫描
    logger.info("扫描旧记忆数据...")
    findings = scan_legacy_memory(project_root)
    if not findings:
        logger.warning("未发现任何旧记忆数据")
        return

    logger.info("发现 %d 个数据源", len(findings))

    # 构建迁移计划
    plan = build_migration_plan(findings)

    if not args.execute:
        print_dry_run_report(plan)
        return

    # ---- 实际迁移 ----
    print("\n开始实际迁移...")

    # 备份
    backup_dir = ""
    checksums: Dict[str, str] = {}
    verify_ok = True

    if not args.no_backup:
        logger.info("备份旧数据...")
        backup_dir, checksums = backup_legacy_memory(project_root)

        if not args.no_verify and checksums:
            logger.info("验证备份完整性...")
            legacy_dir = os.path.join(project_root, LEGACY_MEMORY_DIR)
            verify_ok = verify_backup(legacy_dir, backup_dir, checksums)
            if not verify_ok:
                logger.error("备份校验失败，迁移中止")
                sys.exit(1)
    else:
        print("警告: 已跳过备份步骤！")

    # 执行迁移
    results = execute_migration(project_root, plan, force=args.force)

    # 报告
    print_migration_report(backup_dir, len(checksums), verify_ok, results)


if __name__ == "__main__":
    main()
