#!/usr/bin/env python3
"""
WWW Agent OS 安装向导 v2.0
硬件检测 → 已有资源检测 → 模型配置选择 → 安装路径 → 三阶段安装 → 生成卸载器
"""
import os
import sys
import json
import time
import shutil
import subprocess
import threading
from datetime import datetime

# ---------- 依赖自动安装 ----------
def _ensure_deps():
    for pkg in ["customtkinter", "psutil"]:
        try:
            __import__(pkg)
        except ImportError:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", pkg, "-q"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )

_ensure_deps()

import customtkinter as ctk
import psutil
from tkinter import filedialog, messagebox, simpledialog

# ---------- 常量 ----------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INSTALL_DIR = os.path.join(os.path.expanduser("~"), "Desktop", "www_agent_os")
DESKTOP_DIR = os.path.join(os.path.expanduser("~"), "Desktop")

# ===================== 模型配置定义 =====================
CONFIG_PRESETS = {
    "low": {
        "label": "低配（轻量入门）",
        "tag_color": "#3fb950",
        "tag_icon": "🟢",
        "desc": "8GB RAM · 无独显 · ~5GB",
        "min_ram_gb": 8,
        "min_disk_gb": 5,
        "min_vram_gb": 0,
        "disk_est": "~5GB",
        "personas": [
            {"scene": "通用对话",   "model": "Qwen2.5-1.5B-Instruct",  "params": "1.5B",     "quant": "Q4_K_M"},
            {"scene": "代码生成",   "model": "StarCoder2-3B",           "params": "3B",       "quant": "Q4_K_M"},
            {"scene": "翻译",       "model": "NLLB-200-600M-Distilled", "params": "600M",     "quant": "FP16"},
            {"scene": "嵌入/检索",  "model": "BGE-small-zh-v1.5",       "params": "24M",      "quant": "FP16"},
        ],
        "ollama_models": ["qwen2.5:1.5b", "starcoder2:3b"],
        "embed_packages": ["sentence-transformers"],
    },
    "mid": {
        "label": "中配（均衡实用）",
        "tag_color": "#d2991b",
        "tag_icon": "🟡",
        "desc": "16GB RAM · 6GB+ VRAM · ~15GB",
        "min_ram_gb": 16,
        "min_disk_gb": 15,
        "min_vram_gb": 6,
        "disk_est": "~15GB",
        "personas": [
            {"scene": "通用对话+翻译", "model": "Qwen2.5-7B-Instruct",              "params": "7B",          "quant": "Q4_K_M"},
            {"scene": "代码生成",      "model": "DeepSeek-Coder-V2-Lite-Instruct",   "params": "16B(MoE 2.4B)", "quant": "Q4_K_M"},
            {"scene": "嵌入/检索",     "model": "BGE-M3",                            "params": "567M",        "quant": "FP16"},
        ],
        "ollama_models": ["qwen2.5:7b", "deepseek-coder-v2:16b"],
        "embed_packages": ["sentence-transformers"],
    },
    "high": {
        "label": "高配（性能旗舰）",
        "tag_color": "#f85149",
        "tag_icon": "🔴",
        "desc": "32GB+ RAM · 16GB+ VRAM · ~50GB",
        "min_ram_gb": 32,
        "min_disk_gb": 50,
        "min_vram_gb": 16,
        "disk_est": "~50GB",
        "personas": [
            {"scene": "通用对话/写作/翻译", "model": "Qwen2.5-32B-Instruct",         "params": "32B",            "quant": "Q4_K_M"},
            {"scene": "深度推理",           "model": "DeepSeek-R1-Distill-Qwen-32B",  "params": "32B",            "quant": "Q4_K_M"},
            {"scene": "代码生成",           "model": "DeepSeek-Coder-V2-Instruct",     "params": "236B(MoE 21B)",  "quant": "Q4_K_M"},
            {"scene": "嵌入/检索",          "model": "BGE-M3",                         "params": "567M",           "quant": "FP16"},
        ],
        "ollama_models": ["qwen2.5:32b", "deepseek-r1:32b"],
        "embed_packages": ["sentence-transformers"],
    },
}


# ===================== 硬件检测 =====================
class HardwareDetector:
    @staticmethod
    def get_cpu_info():
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "(Get-CimInstance Win32_Processor).Name"],
                capture_output=True, text=True, timeout=10
            )
            name = result.stdout.strip() if result.returncode == 0 else "未知"
            return {
                "name": name,
                "logical_cores": psutil.cpu_count(logical=True),
                "physical_cores": psutil.cpu_count(logical=False),
            }
        except Exception:
            return {"name": "未知", "logical_cores": 0, "physical_cores": 0}

    @staticmethod
    def get_ram_info():
        try:
            v = psutil.virtual_memory()
            return {
                "total_gb": round(v.total / (1024**3), 1),
                "available_gb": round(v.available / (1024**3), 1)
            }
        except Exception:
            return {"total_gb": 0, "available_gb": 0}

    @staticmethod
    def get_vram_info():
        gpus = []

        # 方法1：注册表检测（最可靠，支持 AMD/NVIDIA/Intel，无 uint32 溢出）
        # HardwareInformation.qwMemorySize 是 QWORD，可正确表示 >4GB 显存
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 '$guid = "{4d36e968-e325-11ce-bfc1-08002be10318}"; '
                 '$regPath = "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Class\\" + $guid; '
                 '$items = Get-ChildItem $regPath -ErrorAction SilentlyContinue; '
                 '$result = @(); '
                 'foreach ($item in $items) { '
                 '  if ($item.PSChildName -notmatch "^\\d{4}$") { continue }; '
                 '  $props = Get-ItemProperty $item.PSPath -ErrorAction SilentlyContinue; '
                 '  $desc = $props.DriverDesc; '
                 '  if (!$desc) { continue }; '
                 '  $deviceId = if ($props.MatchingDeviceId) { $props.MatchingDeviceId } else { "" }; '
                 '  if ($deviceId -like "ROOT\\*" -or $desc -like "*Virtual*" -or $desc -like "*Indirect*" -or $desc -like "*DisplayLink*") { continue }; '
                 '  $name = $desc; '
                 '  $memBytes = 0; '
                 '  if ($props."HardwareInformation.qwMemorySize" -and $props."HardwareInformation.qwMemorySize" -gt 0) { '
                 '    $memBytes = [uint64]$props."HardwareInformation.qwMemorySize" '
                 '  } else { '
                 '    $wmi = Get-CimInstance Win32_VideoController | Where-Object { $_.PNPDeviceID -eq $props.MatchingDeviceId }; '
                 '    if ($wmi -and $wmi.AdapterRAM) { $memBytes = [uint64]$wmi.AdapterRAM } '
                 '  }; '
                 '  if ($desc -like "*NVIDIA*" -and $memBytes -eq 0) { '
                 '    try { $ns = & nvidia-smi --query-gpu=name,memory.total --format=csv,noheader,nounits 2>$null; '
                 '      if ($ns) { $nvParts = $ns -split ","; if ($nvParts.Count -ge 2) { $memBytes = [uint64]([double]$nvParts[1].Trim() * 1048576) } } '
                 '    } catch {} '
                 '  }; '
                 '  if ($deviceId -like "PCI\\*") { $gpuType = "discrete" } '
                 '  elseif ($deviceId -like "ACPI\\*" -or $desc -like "*Intel*HD*" -or $desc -like "*Intel*UHD*" -or $desc -like "*Iris*" -or $desc -like "*Arc*") { $gpuType = "integrated" } '
                 '  elseif ($desc -like "*Radeon*" -or $desc -like "*GeForce*" -or $desc -like "*RTX*" -or $desc -like "*GTX*" -or $desc -like "*Quadro*" -or $desc -like "*Arc*") { $gpuType = "discrete" } '
                 '  else { $gpuType = "unknown" }; '
                 '  $vramGB = [math]::Round($memBytes / 1GB, 1); '
                 '  if ($vramGB -gt 128) { $vramGB = 0 }; '
                 '  $result += "$name|$vramGB|$gpuType" '
                 '}; '
                 '$result -join "`n"'],
                capture_output=True, text=True, timeout=20
            )
            if result.returncode == 0 and result.stdout.strip():
                for line in result.stdout.strip().split("\n"):
                    parts = line.strip().split("|", 2)
                    if len(parts) >= 2:
                        name = parts[0].strip()
                        try:
                            vram_gb = float(parts[1])
                        except ValueError:
                            vram_gb = 0
                        gpu_type = parts[2].strip() if len(parts) >= 3 else "unknown"
                        gpus.append({"name": name, "vram_gb": vram_gb, "gpu_type": gpu_type})
        except Exception:
            pass

        # 方法2：nvidia-smi 兜底（如果注册表方法没抓到任何 NVIDIA 卡）
        if not any("NVIDIA" in g["name"].upper() or "GeForce" in g["name"] or "RTX" in g["name"] or "GTX" in g["name"] for g in gpus):
            try:
                ns = subprocess.run(
                    ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=10
                )
                if ns.returncode == 0 and ns.stdout.strip():
                    for line in ns.stdout.strip().split("\n"):
                        parts = [p.strip() for p in line.split(",", 1)]
                        if len(parts) >= 2:
                            nv_name = parts[0]
                            try:
                                nv_vram_gb = round(float(parts[1]) / 1024, 1)
                            except ValueError:
                                continue
                            gpus.append({"name": nv_name, "vram_gb": nv_vram_gb, "gpu_type": "discrete"})
            except Exception:
                pass

        return gpus if gpus else [{"name": "未检测到显卡", "vram_gb": 0, "gpu_type": "unknown"}]

    @staticmethod
    def get_disk_info():
        drives = []
        for part in psutil.disk_partitions():
            if "fixed" in part.opts.lower() or part.fstype:
                try:
                    u = psutil.disk_usage(part.mountpoint)
                    drives.append({
                        "drive": part.device.rstrip("\\"),
                        "total_gb": round(u.total / (1024**3), 1),
                        "free_gb": round(u.free / (1024**3), 1),
                    })
                except Exception:
                    pass
        return drives

    @staticmethod
    def get_max_free_disk_gb():
        drives = HardwareDetector.get_disk_info()
        return max((d["free_gb"] for d in drives), default=0)

    @staticmethod
    def get_max_vram_gb():
        gpus = HardwareDetector.get_vram_info()
        return max((g["vram_gb"] for g in gpus), default=0)


# ===================== 已有资源检测 =====================
def check_ollama_installed():
    ollama_exe = shutil.which("ollama")
    if not ollama_exe:
        for p in [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Ollama", "ollama.exe"),
        ]:
            if os.path.exists(p):
                ollama_exe = p
                break
    running = False
    if ollama_exe:
        try:
            import requests
            r = requests.get("http://localhost:11434/api/tags", timeout=3)
            running = r.status_code == 200
        except Exception:
            pass
    return {"installed": ollama_exe is not None, "running": running, "exe": ollama_exe}


def get_existing_ollama_models():
    try:
        import requests
        r = requests.get("http://localhost:11434/api/tags", timeout=5)
        if r.status_code == 200:
            return [m["name"] for m in r.json().get("models", [])]
    except Exception:
        pass
    return []


# ===================== GUI 安装器 =====================
class InstallerGUI(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("WWW Agent OS 安装向导")
        self.geometry("780x860")
        self.minsize(700, 780)
        self.configure(fg_color="#0d1117")

        self.selected_config = ctk.StringVar(value="")
        self.install_dir = ctk.StringVar(value=DEFAULT_INSTALL_DIR)
        self.installing = False
        self.log_msgs = []
        self.custom_models = []
        self.hw = None
        self.ollama_status = None
        self.existing_models = []

        self._run_detection()
        self._build_ui()
        self.selected_config.trace_add("write", self._on_config_changed)

    # ========== 检测 ==========
    def _run_detection(self):
        self.hw = {
            "cpu": HardwareDetector.get_cpu_info(),
            "ram": HardwareDetector.get_ram_info(),
            "vram": HardwareDetector.get_vram_info(),
            "disks": HardwareDetector.get_disk_info(),
            "max_free_disk": HardwareDetector.get_max_free_disk_gb(),
            "max_vram": HardwareDetector.get_max_vram_gb(),
        }
        self.ollama_status = check_ollama_installed()
        if self.ollama_status["running"]:
            self.existing_models = get_existing_ollama_models()

    # ========== UI 构建 ==========
    def _build_ui(self):
        self.main_canvas = ctk.CTkScrollableFrame(self, fg_color="#0d1117", corner_radius=0)
        self.main_canvas.pack(fill="both", expand=True)
        self._build_title()
        self._build_hardware_panel()
        self._build_existing_panel()
        self._build_install_path()
        self._build_config_panel()
        self._build_model_table()
        self._build_log_panel()
        self._build_buttons()

    def _build_title(self):
        f = ctk.CTkFrame(self.main_canvas, fg_color="transparent")
        f.pack(fill="x", padx=24, pady=(16, 4))
        ctk.CTkLabel(f, text="WWW Agent OS 安装向导",
                     font=ctk.CTkFont(size=24, weight="bold"),
                     text_color="#58a6ff").pack(anchor="w")
        ctk.CTkLabel(f, text="硬件检测 · 智能配置推荐 · 一键安装",
                     font=ctk.CTkFont(size=12), text_color="#8b949e").pack(anchor="w", pady=(2,0))

    def _sec_label(self, text, color="#58a6ff"):
        f = ctk.CTkFrame(self.main_canvas, fg_color="#161b22", corner_radius=8)
        f.pack(fill="x", padx=24, pady=(12,4))
        ctk.CTkLabel(f, text=f"  {text}", font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=color).pack(padx=14, pady=(8,6), anchor="w")

    def _build_hardware_panel(self):
        self._sec_label("硬件检测", "#3fb950")
        card = ctk.CTkFrame(self.main_canvas, fg_color="#0d1117", corner_radius=8,
                            border_width=1, border_color="#30363d")
        card.pack(fill="x", padx=24, pady=(0,4))
        hw = self.hw
        ram_ok = hw["ram"]["total_gb"] >= 8

        cpu_name = hw["cpu"]["name"][:70]
        self._hw_row(card,
            f"CPU: {cpu_name}  |  {hw['cpu']['logical_cores']} 线程 ({hw['cpu']['physical_cores']} 物理核心)",
            "✓", "#3fb950")

        self._hw_row(card,
            f"RAM: {hw['ram']['total_gb']:.1f} GB 总量  |  可用 {hw['ram']['available_gb']:.1f} GB",
            "✓" if ram_ok else "✗",
            "#3fb950" if ram_ok else "#f85149")

        gpu_lines = []
        for g in hw["vram"]:
            type_tag = ""
            if g.get("gpu_type") == "discrete":
                type_tag = " [独显]"
            elif g.get("gpu_type") == "integrated":
                type_tag = " [集显]"
            gpu_lines.append(f"{g['name'][:50]}{type_tag}  |  {g['vram_gb']:.1f} GB")
        vram_color = "#d2991b" if hw["max_vram"] == 0 else "#3fb950"
        self._hw_row(card, "VRAM:\n" + "\n".join(gpu_lines) if gpu_lines else "VRAM: 无",
                     "✓" if hw["max_vram"] > 0 else "—", vram_color)

        disk_lines = [f"  {d['drive']}  总量 {d['total_gb']:.0f} GB  |  可用 {d['free_gb']:.0f} GB" for d in hw["disks"]]
        df = hw["max_free_disk"]
        dcolor = "#3fb950" if df >= 50 else ("#d2991b" if df >= 10 else "#f85149")
        self._hw_row(card, "磁盘:\n" + "\n".join(disk_lines) if disk_lines else "磁盘: 无",
                     "✓" if df >= 10 else "⚠", dcolor)

    def _hw_row(self, parent, text, status, color):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=10, pady=(3,1))
        ctk.CTkLabel(row, text=status, font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=color, width=24).pack(side="left")
        ctk.CTkLabel(row, text=text, font=ctk.CTkFont(size=11, family="Consolas"),
                     text_color="#c9d1d9", justify="left").pack(side="left", padx=4)

    def _build_existing_panel(self):
        self._sec_label("已有资源检测", "#d2991b")
        card = ctk.CTkFrame(self.main_canvas, fg_color="#0d1117", corner_radius=8,
                            border_width=1, border_color="#30363d")
        card.pack(fill="x", padx=24, pady=(0,4))

        if self.ollama_status["installed"]:
            t = f"Ollama: 已安装 ({self.ollama_status['exe']})"
            t += "  |  服务运行中" if self.ollama_status["running"] else "  |  服务未运行"
            self._hw_row(card, t, "✓", "#3fb950")
        else:
            self._hw_row(card, "Ollama: 未安装（将自动安装）", "—", "#8b949e")

        if self.existing_models:
            mt = "已有模型:\n  " + "\n  ".join(self.existing_models[:20])
            if len(self.existing_models) > 20:
                mt += f"\n  ... 共 {len(self.existing_models)} 个"
            self._hw_row(card, mt, "✓", "#3fb950")
        else:
            self._hw_row(card, "已有模型: 无", "—", "#8b949e")

    def _build_install_path(self):
        self._sec_label("安装路径", "#a371f7")
        card = ctk.CTkFrame(self.main_canvas, fg_color="#0d1117", corner_radius=8,
                            border_width=1, border_color="#30363d")
        card.pack(fill="x", padx=24, pady=(0,4))
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=10, pady=10)
        self.path_entry = ctk.CTkEntry(row, textvariable=self.install_dir,
            font=ctk.CTkFont(size=12, family="Consolas"),
            fg_color="#161b22", text_color="#c9d1d9",
            border_color="#30363d", corner_radius=6, height=36)
        self.path_entry.pack(side="left", fill="x", expand=True, padx=(0,8))
        ctk.CTkButton(row, text="浏览...", width=80, height=36, font=ctk.CTkFont(size=12),
                      fg_color="#30363d", hover_color="#484f58", corner_radius=6,
                      command=self._browse_dir).pack(side="right")
        ctk.CTkLabel(card, text="  安装路径将用于复制项目文件、安装依赖和生成卸载器",
                     font=ctk.CTkFont(size=10), text_color="#8b949e").pack(anchor="w", padx=14, pady=(0,8))

    def _browse_dir(self):
        p = filedialog.askdirectory(title="选择安装目录", initialdir=self.install_dir.get())
        if p:
            self.install_dir.set(p)

    def _build_config_panel(self):
        self._sec_label("配置方案", "#58a6ff")
        self.config_card = ctk.CTkFrame(self.main_canvas, fg_color="#0d1117", corner_radius=8,
                                        border_width=1, border_color="#30363d")
        self.config_card.pack(fill="x", padx=24, pady=(0,4))

        ram = self.hw["ram"]["total_gb"]
        vram = self.hw["max_vram"]
        disk = self.hw["max_free_disk"]

        if ram < 4:
            self._config_warning("内存不足 (最小需要 4GB)，无法安装任何配置", "#f85149")
            return

        self.config_widgets = {}
        best_key = None
        best_score = -1
        for key in ["low", "mid", "high", "custom"]:
            score = self._make_config_card(key, ram, vram, disk)
            if score is not None and score > best_score:
                best_score = score
                best_key = key

        # 自动选中评分最高的配置
        if best_key:
            self.selected_config.set(best_key)

    def _config_warning(self, text, color):
        w = ctk.CTkFrame(self.config_card, fg_color="transparent")
        w.pack(fill="x", padx=10, pady=8)
        ctk.CTkLabel(w, text=text, font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=color).pack()

    def _make_config_card(self, key, ram_gb, vram_gb, disk_free):
        """返回评分（0-100），用于自动推荐；返回 None 表示该配置不可用"""
        if key == "custom":
            cfg = {"label": "自定义", "tag_color": "#a371f7", "tag_icon": "🟣",
                   "desc": "自行指定每个模型",
                   "min_ram_gb": 8, "min_disk_gb": 5, "min_vram_gb": 0, "disk_est": "?"}
            disabled = ram_gb < 4
            stars = "—"
            score = 50 if not disabled else None
        else:
            cfg = CONFIG_PRESETS[key]
            # === 评分系统（0-100） ===
            score = 0
            warnings = []

            # RAM 评分（权重 40）
            if ram_gb >= cfg["min_ram_gb"] * 1.5:
                score += 40
            elif ram_gb >= cfg["min_ram_gb"]:
                score += 30
            elif ram_gb >= cfg["min_ram_gb"] * 0.75:
                score += 15
                warnings.append(f"RAM 偏低（建议 ≥{cfg['min_ram_gb']}GB，当前 {ram_gb:.0f}GB）")
            else:
                warnings.append(f"RAM 不足（建议 ≥{cfg['min_ram_gb']}GB，当前 {ram_gb:.0f}GB）")

            # VRAM 评分（权重 30）
            if vram_gb >= cfg["min_vram_gb"]:
                score += 30
            elif vram_gb >= cfg["min_vram_gb"] * 0.5:
                score += 15
                if cfg["min_vram_gb"] > 0:
                    warnings.append(f"VRAM 偏低（建议 ≥{cfg['min_vram_gb']}GB，当前 {vram_gb:.1f}GB）")
            elif cfg["min_vram_gb"] > 0:
                # 没有独显但 RAM 大，用 RAM 补偿部分评分
                if ram_gb >= cfg["min_ram_gb"] * 1.5:
                    score += 10
                    warnings.append(f"无独显，将使用 CPU 推理（RAM {ram_gb:.0f}GB 可部分补偿）")
                else:
                    warnings.append(f"无独显，CPU 推理性能有限")

            # 磁盘评分（权重 30）
            if disk_free >= cfg["min_disk_gb"] * 2:
                score += 30
            elif disk_free >= cfg["min_disk_gb"]:
                score += 20
            elif disk_free >= cfg["min_disk_gb"] * 0.5:
                score += 10
                warnings.append(f"磁盘紧张（可用 {disk_free:.0f}GB，建议 ≥{cfg['min_disk_gb']}GB）")
            else:
                warnings.append(f"磁盘不足（可用 {disk_free:.0f}GB，需要 ≥{cfg['min_disk_gb']}GB）")

            # === 推荐星级 ===
            if score >= 75:
                stars = "★★★ 推荐"
                star_color = "#3fb950"
            elif score >= 45:
                stars = "★★ 可用"
                star_color = "#d2991b"
            else:
                stars = "★ 勉强"
                star_color = "#f85149"

            # 极低 RAM 时仍禁用
            disabled = ram_gb < 4 or disk_free < cfg["min_disk_gb"] * 0.2
            if disabled:
                score = None

        row = ctk.CTkFrame(self.config_card, fg_color="transparent")
        row.pack(fill="x", padx=8, pady=(8,2))

        tag_color = cfg["tag_color"] if not disabled else "#484f58"
        rb = ctk.CTkRadioButton(row, text="", variable=self.selected_config, value=key,
            font=ctk.CTkFont(size=13),
            fg_color=tag_color, hover_color=tag_color,
            width=22, border_width_unchecked=2, border_color="#484f58",
            state="disabled" if disabled else "normal")
        rb.pack(side="left", padx=(4,6))
        self.config_widgets[key] = rb

        ctk.CTkLabel(row, text=f"{cfg['tag_icon']}  {cfg['label']}",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color="#484f58" if disabled else cfg["tag_color"]).pack(side="left")
        ctk.CTkLabel(row, text=f" — {cfg['desc']}",
                     font=ctk.CTkFont(size=11),
                     text_color="#484f58" if disabled else "#8b949e").pack(side="left", padx=4)

        # 星级 / 评价
        if key != "custom":
            ctk.CTkLabel(row, text=f"  {stars}",
                         font=ctk.CTkFont(size=11, weight="bold"),
                         text_color="#484f58" if disabled else star_color).pack(side="left", padx=8)

        # 警告信息
        if key != "custom" and warnings:
            warn_text = "  |  ".join(warnings)
            ctk.CTkLabel(row, text=warn_text,
                         font=ctk.CTkFont(size=9),
                         text_color="#d2991b").pack(side="left", padx=8)

        spacer = ctk.CTkFrame(self.config_card, fg_color="transparent", height=3)
        spacer.pack(fill="x")

        return score

    def _build_model_table(self):
        self._sec_label("Persona 模型详情", "#d2991b")
        self.table_frame = ctk.CTkFrame(self.main_canvas, fg_color="#0d1117", corner_radius=8,
                                        border_width=1, border_color="#30363d")
        self.table_frame.pack(fill="x", padx=24, pady=(0,8))
        self.table_content = ctk.CTkFrame(self.table_frame, fg_color="transparent")
        self.table_content.pack(fill="x", padx=10, pady=6)
        ctk.CTkLabel(self.table_content, text="请选择一个配置方案以查看模型详情",
                     font=ctk.CTkFont(size=11), text_color="#8b949e").pack(pady=12)

    def _on_config_changed(self, *args):
        key = self.selected_config.get()
        for w in self.table_content.winfo_children():
            w.destroy()

        if key == "custom":
            ctk.CTkLabel(self.table_content, text="自定义模式：点击安装后将逐项引导添加模型",
                         font=ctk.CTkFont(size=11), text_color="#a371f7").pack(pady=12)
            return

        cfg = CONFIG_PRESETS.get(key)
        if not cfg:
            return

        # 表头
        h = ctk.CTkFrame(self.table_content, fg_color="#161b22", corner_radius=4)
        h.pack(fill="x", pady=(0,2))
        for cn, cw in [("场景/人格", 22), ("模型", 36), ("参数量", 16), ("量化", 10)]:
            ctk.CTkLabel(h, text=cn, font=ctk.CTkFont(size=11, weight="bold"),
                         text_color="#58a6ff", width=cw*7).pack(side="left", padx=4, pady=4)

        for i, p in enumerate(cfg["personas"]):
            bg = "#161b22" if i % 2 == 0 else "#0d1117"
            pr = ctk.CTkFrame(self.table_content, fg_color=bg, corner_radius=2)
            pr.pack(fill="x")
            for v, w in zip([p["scene"], p["model"], p["params"], p["quant"]], [22, 36, 16, 10]):
                ctk.CTkLabel(pr, text=v, font=ctk.CTkFont(size=11, family="Consolas"),
                             text_color="#c9d1d9", width=w*7).pack(side="left", padx=4, pady=3)

        ctk.CTkLabel(self.table_content, text=f"预估磁盘占用: {cfg['disk_est']}",
                     font=ctk.CTkFont(size=10), text_color="#8b949e").pack(anchor="e", pady=(6,2))

    def _build_log_panel(self):
        self._sec_label("安装日志", "#d2991b")
        self.log_textbox = ctk.CTkTextbox(
            self.main_canvas, font=ctk.CTkFont(size=11, family="Consolas"),
            fg_color="#0d1117", text_color="#c9d1d9",
            corner_radius=8, height=150, wrap="word",
            border_width=1, border_color="#30363d")
        self.log_textbox.pack(fill="x", padx=24, pady=(0,8))

    def _build_buttons(self):
        bf = ctk.CTkFrame(self.main_canvas, fg_color="transparent")
        bf.pack(fill="x", padx=24, pady=(4,16))
        ctk.CTkButton(bf, text="取消", width=100, height=40,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#30363d", hover_color="#484f58",
            corner_radius=8, command=self.destroy).pack(side="left")
        self.install_btn = ctk.CTkButton(bf, text="开始安装", width=160, height=40,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color="#238636", hover_color="#2ea043",
            corner_radius=8, command=self._start_install)
        self.install_btn.pack(side="right")

    # ========== 日志 ==========
    def _log(self, msg):
        self.log_msgs.append(msg)
        self.after(0, self._flush_log)

    def _flush_log(self):
        self.log_textbox.configure(state="normal")
        self.log_textbox.delete("1.0", "end")
        self.log_textbox.insert("end", "\n".join(self.log_msgs[-80:]))
        self.log_textbox.see("end")
        self.log_textbox.configure(state="disabled")

    # ========== 安装入口 ==========
    def _start_install(self):
        config_key = self.selected_config.get()
        if not config_key:
            messagebox.showwarning("未选择", "请先选择一个配置方案。")
            return
        install_dir = self.install_dir.get().strip()
        if not install_dir:
            messagebox.showwarning("路径为空", "请指定安装路径。")
            return
        if os.path.exists(install_dir) and not os.path.isdir(install_dir):
            messagebox.showerror("路径错误", f"{install_dir} 已存在但不是目录。")
            return

        if config_key == "custom":
            self._custom_model_dialog()
            return

        cfg = CONFIG_PRESETS[config_key]

        # 确认对话框
        lines = [f"即将安装 [{cfg['label']}] 方案", "",
                 f"安装路径: {install_dir}",
                 f"磁盘占用约: {cfg['disk_est']}", "", "模型列表:"]
        for p in cfg["personas"]:
            tag = ""
            for em in self.existing_models:
                for om in cfg["ollama_models"]:
                    base1 = om.split(":")[0].lower()
                    base2 = em.split(":")[0].lower()
                    if base1 == base2 or om in em or em in om:
                        tag = " [已存在，跳过]"
                        break
                if tag:
                    break
            lines.append(f"  {p['scene']:22s} {p['model']:35s}{tag}")
        lines += ["", "确认开始安装？"]

        if not messagebox.askyesno("确认安装", "\n".join(lines)):
            return

        self._run_install(config_key)

    def _custom_model_dialog(self):
        self.custom_models = []
        while True:
            s = simpledialog.askstring("自定义模型 - 下载源",
                "选择下载源:\n  1 - Ollama\n  2 - ModelScope\n  3 - HuggingFace\n\n请输入 (1/2/3):", parent=self)
            if not s:
                return
            src = {"1": "ollama", "2": "modelscope", "3": "huggingface"}.get(s)
            if not src:
                continue

            name = simpledialog.askstring("自定义模型 - 名称",
                "模型名称（Ollama tag 或模型ID）:", parent=self)
            if not name:
                return

            params = simpledialog.askstring("自定义模型 - 参数量",
                "参数量标签（如 7B / 32B）:", parent=self)
            if not params:
                return

            quant = simpledialog.askstring("自定义模型 - 量化方式",
                "量化方式（默认 Q4_K_M）:", parent=self) or "Q4_K_M"

            usage = simpledialog.askstring("自定义模型 - 用途",
                "用途标签（如 通用对话 / 代码生成）:", parent=self)
            if not usage:
                return

            self.custom_models.append({
                "source": src, "name": name.strip(),
                "params": params.strip(), "quant": quant.strip(),
                "usage": usage.strip()
            })

            if not messagebox.askyesno("添加模型",
                f"已添加 {len(self.custom_models)} 个模型。继续添加？"):
                break

        if not self.custom_models:
            return

        lines = ["即将安装自定义配置:", ""]
        for m in self.custom_models:
            lines.append(f"  [{m['source']}] {m['name']} ({m['params']}, {m['quant']}) — {m['usage']}")
        lines += ["", "确认开始安装？"]
        if not messagebox.askyesno("确认安装", "\n".join(lines)):
            return
        self._run_install("custom")

    def _run_install(self, config_key):
        self.installing = True
        self.install_btn.configure(state="disabled", text="安装中...")
        self.log_msgs = []
        self._log("=" * 50)
        self._log("  WWW Agent OS 安装向导 v2.0")
        self._log("=" * 50)
        threading.Thread(target=self._install_thread, args=(config_key,), daemon=True).start()

    # ========== 安装线程 ==========
    def _install_thread(self, config_key):
        install_dir = self.install_dir.get().strip()
        py_exe = self._find_python()
        try:
            # ===== 阶段一：软件本体 =====
            self._log(""); self._log("【阶段一】软件本体安装"); self._log("-"*40)
            src_diff = os.path.abspath(SCRIPT_DIR) != os.path.abspath(install_dir)
            if src_diff:
                self._log(f"复制项目文件到: {install_dir}")
                try:
                    if os.path.exists(install_dir):
                        self._copy_merge(SCRIPT_DIR, install_dir)
                    else:
                        shutil.copytree(SCRIPT_DIR, install_dir,
                            ignore=shutil.ignore_patterns("__pycache__","*.pyc",".pytest_cache",".git"))
                    self._log("项目文件复制完成")
                except Exception as e:
                    self._log(f"复制失败: {e}")
                    self._install_failed(str(e)); return
            else:
                self._log("安装路径与源目录相同，跳过复制")

            # 依赖安装
            req_dir = os.path.join(install_dir, "requirements")
            found = False
            if os.path.isdir(req_dir):
                for fn in sorted(os.listdir(req_dir)):
                    if fn.endswith(".txt"):
                        self._pip_install(os.path.join(req_dir, fn), py_exe)
                        found = True
            root_req = os.path.join(install_dir, "requirements.txt")
            if not found and os.path.exists(root_req):
                self._pip_install(root_req, py_exe)

            # 快捷方式
            shortcut = os.path.join(DESKTOP_DIR, "WWW Agent OS.lnk")
            self._log("创建桌面快捷方式...")
            self._create_shortcut(shortcut, install_dir)

            # install_info.json
            info = {"install_path": install_dir, "plan": config_key,
                    "installed_at": datetime.now().isoformat(),
                    "phases": {"software": "completed"}}
            self._write_json(os.path.join(install_dir, "install_info.json"), info)
            self._log("软件本体安装完成")

            # ===== 阶段二：环境安装 =====
            self._log(""); self._log("【阶段二】环境安装 (Ollama + 模型)"); self._log("-"*40)

            os_stat = check_ollama_installed()
            if os_stat["installed"] and os_stat["running"]:
                self._log("Ollama: ✓ 已安装且运行中")
            elif os_stat["installed"]:
                self._log("Ollama: 已安装，尝试启动服务...")
                self._ensure_ollama_running(os_stat)
            else:
                self._log("Ollama: 未安装，开始安装...")
                if not self._install_ollama_with_retry():
                    self._log("⚠ Ollama 安装失败，请手动安装 https://ollama.com")
                    info["phases"]["ollama"] = "failed"
                else:
                    info["phases"]["ollama"] = "installed"

            os_stat = check_ollama_installed()
            info["phases"]["ollama"] = ("running" if os_stat["running"] else
                                        "installed" if os_stat["installed"] else "failed")

            # 下载模型
            mr = {"success": [], "skipped": [], "failed": []}
            if config_key == "custom":
                mr = self._download_custom_models(os_stat)
            else:
                mr = self._download_preset_models(config_key, os_stat)
            info["phases"]["models"] = mr
            info["models"] = mr["success"] + mr["skipped"]

            # 嵌入模型
            if config_key != "custom":
                cfg = CONFIG_PRESETS[config_key]
                for pkg in cfg.get("embed_packages", []):
                    self._log(f"pip install {pkg}")
                    subprocess.run([py_exe, "-m", "pip", "install", pkg, "-q"],
                                   capture_output=True, timeout=300)
                self._log("嵌入模型包安装完成")

            self._generate_model_config(config_key, install_dir)
            self._write_json(os.path.join(install_dir, "install_info.json"), info)
            self._log("环境安装完成")

            # ===== 阶段三：生成卸载器 =====
            self._log(""); self._log("【阶段三】生成卸载器"); self._log("-"*40)
            self._generate_uninstaller(install_dir)

            self._log(""); self._log("=" * 50)
            self._log("  WWW Agent OS 安装完成！")
            self._log("=" * 50)
            self.after(0, lambda: self._show_result(config_key, install_dir, mr, os_stat))

        except Exception as e:
            import traceback
            self._log(f"安装异常: {e}")
            self._log(traceback.format_exc())
            self._install_failed(str(e))

    # ========== 辅助方法 ==========
    def _find_python(self):
        for path in os.environ.get("PATH", "").split(os.pathsep):
            if "WindowsApps" in path:
                continue
            c = os.path.join(path, "python.exe")
            if os.path.exists(c):
                try:
                    r = subprocess.run([c, "--version"], capture_output=True, text=True, timeout=5)
                    if r.returncode == 0:
                        return c
                except Exception:
                    continue
        return sys.executable

    def _pip_install(self, req_path, py_exe):
        r = subprocess.run([py_exe, "-m", "pip", "install", "-r", req_path, "-q"],
                          capture_output=True, text=True, timeout=600)
        if r.returncode == 0:
            self._log("  依赖安装完成")
        else:
            self._log(f"  部分依赖安装失败: {r.stderr[:200]}")

    def _copy_merge(self, src, dst):
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                if item in ("__pycache__", ".pytest_cache", ".git"):
                    continue
                os.makedirs(d, exist_ok=True)
                self._copy_merge(s, d)
            else:
                if not os.path.exists(d):
                    shutil.copy2(s, d)

    def _create_shortcut(self, sp, install_dir):
        target = os.path.join(install_dir, "start_www_agent.bat")
        icon = os.path.join(install_dir, "logo_transparent_cropped.ico")
        try:
            ps = (
                f"$ws=New-Object -ComObject WScript.Shell;"
                f"$s=$ws.CreateShortcut('{sp}');"
                f"$s.TargetPath='{target}';"
                f"$s.WorkingDirectory='{install_dir}';"
                f"$s.IconLocation='{icon}';"
                f"$s.Save()"
            )
            subprocess.run(["powershell","-NoProfile","-Command",ps],
                          capture_output=True, timeout=10)
            self._log(f"  快捷方式: {sp}")
        except Exception as e:
            self._log(f"  创建快捷方式失败: {e}")

    def _ensure_ollama_running(self, status):
        try:
            if status.get("exe"):
                subprocess.Popen([status["exe"], "serve"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                for _ in range(10):
                    time.sleep(2)
                    if check_ollama_installed()["running"]:
                        self._log("Ollama 服务已启动")
                        return
        except Exception:
            pass
        self._log("⚠ 无法启动 Ollama 服务")

    def _install_ollama_with_retry(self):
        url = "https://ollama.com/download/OllamaSetup.exe"
        ip = os.path.join(os.environ.get("TEMP", SCRIPT_DIR), "OllamaSetup.exe")
        for attempt in range(3):
            self._log(f"尝试 {attempt+1}/3: 下载安装 Ollama...")
            try:
                import requests
                r = requests.get(url, stream=True, timeout=120)
                with open(ip, "wb") as f:
                    for c in r.iter_content(8192):
                        f.write(c)
                self._log("  静默安装中...")
                subprocess.run([ip, "/S"], check=True, timeout=180)
                time.sleep(3)
                for _ in range(15):
                    if check_ollama_installed()["running"]:
                        self._log("Ollama 安装成功")
                        return True
                    time.sleep(2)
                if check_ollama_installed()["installed"]:
                    self._ensure_ollama_running(check_ollama_installed())
                    return True
            except Exception as e:
                self._log(f"  失败: {e}")
            finally:
                if os.path.exists(ip):
                    try: os.remove(ip)
                    except: pass
            if attempt < 2:
                time.sleep(5)
        return False

    def _download_preset_models(self, config_key, os_stat):
        cfg = CONFIG_PRESETS[config_key]
        mr = {"success": [], "skipped": [], "failed": []}
        for model in cfg["ollama_models"]:
            self._log(f"模型: {model}")
            if self._model_exists(model):
                self._log(f"  ✓ 已存在，跳过下载")
                mr["skipped"].append(model)
                continue
            if self._pull_ollama_model(model):
                mr["success"].append(model)
            else:
                mr["failed"].append(model)
        return mr

    def _download_custom_models(self, os_stat):
        mr = {"success": [], "skipped": [], "failed": []}
        for m in self.custom_models:
            name = m["name"]
            self._log(f"模型: {name} [{m['source']}]")
            if self._model_exists(name):
                self._log(f"  ✓ 已存在，跳过下载")
                mr["skipped"].append(name)
                continue
            if m["source"] == "ollama":
                if self._pull_ollama_model(name):
                    mr["success"].append(name)
                else:
                    mr["failed"].append(name)
            else:
                self._log(f"  ⚠ {m['source']} 下载需手动执行")
                mr["failed"].append(name)
        return mr

    def _model_exists(self, name):
        for em in self.existing_models:
            if name in em or em in name:
                return True
            if name.split(":")[0].lower() == em.split(":")[0].lower():
                return True
        return False

    def _pull_ollama_model(self, model):
        for attempt in range(3):
            self._log(f"  ollama pull {model} (尝试 {attempt+1}/3)")
            try:
                r = subprocess.run(["ollama","pull",model],
                    capture_output=True, text=True, timeout=3600)
                if r.returncode == 0:
                    self._log(f"  ✓ 下载完成")
                    return True
                self._log(f"  失败: {r.stderr.strip()[-150:]}")
            except subprocess.TimeoutExpired:
                self._log("  超时")
            except FileNotFoundError:
                self._log("  ollama 命令未找到")
                return False
            except Exception as e:
                self._log(f"  错误: {e}")
            if attempt < 2:
                self._log("  等待 5 秒后重试...")
                time.sleep(5)
        self._log(f"  ✗ 下载失败（3 次尝试），请手动: ollama pull {model}")
        return False

    def _generate_model_config(self, config_key, install_dir):
        config = {"plan": config_key, "install_path": install_dir,
                  "created": datetime.now().isoformat()}
        if config_key != "custom":
            cfg = CONFIG_PRESETS[config_key]
            personas = {}
            for p in cfg["personas"]:
                k = p["scene"].replace(" ","_").replace("/","_")
                personas[k] = p["model"]
            config["personas"] = personas
            config["models"] = [p["model"] for p in cfg["personas"]]
            config["ollama_models"] = cfg["ollama_models"]
        else:
            personas = {}
            for m in self.custom_models:
                k = m["usage"].replace(" ","_").lower()
                personas[k] = m["name"]
            config["personas"] = personas
            config["models"] = [m["name"] for m in self.custom_models]
            config["custom_models"] = self.custom_models
        self._write_json(os.path.join(install_dir, "model_config.json"), config)
        self._log("model_config.json 已生成")

    def _generate_uninstaller(self, install_dir):
        up = os.path.join(install_dir, "卸载-WWW_Agent_OS.py")
        ub = os.path.join(install_dir, "卸载-WWW_Agent_OS.bat")
        if os.path.exists(up):
            self._log("卸载器已存在，跳过生成")
            return
        self._inline_uninstaller(up, install_dir)
        with open(ub, "w", encoding="utf-8") as f:
            f.write("@echo off\nchcp 65001 >nul\ncd /d \"%~dp0\"\nstart \"\" pythonw \"%~dp0卸载-WWW_Agent_OS.py\"\n")
        self._log(f"卸载器已生成: {up}")

    def _inline_uninstaller(self, path, install_dir):
        content = r'''#!/usr/bin/env python3
"""WWW Agent OS - 卸载向导（由安装器生成）"""
import os, sys, json, shutil, subprocess, threading, time
from datetime import datetime
def _ensure():
    try: import customtkinter as ctk
    except: subprocess.check_call([sys.executable,"-m","pip","install","customtkinter","-q"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);import customtkinter as ctk
_ensure()
import customtkinter as ctk
from tkinter import messagebox
INSTALL_DIR = r"''' + install_dir + r'''"
SHORTCUT = os.path.join(os.path.expanduser("~"),"Desktop","WWW Agent OS.lnk")
def chk_ollama():
    try:
        import requests
        return requests.get("http://localhost:11434/api/tags",timeout=3).status_code==200
    except: return False

class Uninstaller(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("WWW Agent OS 卸载向导")
        self.geometry("620x680");self.minsize(560,600)
        self.configure(fg_color="#0d1117")
        self.info_data=None;self.log_msgs=[]
        self.km=ctk.BooleanVar(value=True);self.ks=ctk.BooleanVar(value=True)
        self.rm=ctk.BooleanVar(value=True);self.cp=ctk.BooleanVar(value=False)
        self._ui();self._detect()
    def _ui(self):
        f=ctk.CTkFrame(self,fg_color="transparent");f.pack(fill="x",padx=24,pady=(20,8))
        ctk.CTkLabel(f,text="WWW Agent OS 卸载向导",font=ctk.CTkFont(size=24,weight="bold"),text_color="#f85149").pack(anchor="w")
        ctk.CTkLabel(f,text="将卸载程序文件，可选择保留记忆与技能数据",font=ctk.CTkFont(size=12),text_color="#8b949e").pack(anchor="w")
        self._sec("检测到的安装信息");self.itb=self._tb(100)
        self._sec("卸载选项")
        of=ctk.CTkFrame(self,fg_color="#0d1117",corner_radius=8,border_width=1,border_color="#30363d");of.pack(fill="x",padx=24)
        self._cb(of,"保留记忆数据 (memory/)",self.km,"#3fb950")
        self._cb(of,"保留 Persona 技能数据 (data/skills/)",self.ks,"#3fb950")
        self._cb(of,"同时卸载 Ollama 模型",self.rm,"#f85149")
        self._cb(of,"清理 pip 缓存",self.cp,"#d2991b")
        self._sec("执行日志");self.ltb=self._tb(160)
        bf=ctk.CTkFrame(self,fg_color="transparent");bf.pack(fill="x",padx=24,pady=(8,16))
        ctk.CTkButton(bf,text="取消",width=100,height=40,font=ctk.CTkFont(size=13,weight="bold"),fg_color="#30363d",hover_color="#484f58",corner_radius=8,command=self.destroy).pack(side="left")
        self.ub=ctk.CTkButton(bf,text="确认卸载",width=160,height=40,font=ctk.CTkFont(size=14,weight="bold"),fg_color="#da3633",hover_color="#c42f2f",corner_radius=8,command=self._ask)
        self.ub.pack(side="right")
    def _sec(self,t):
        f=ctk.CTkFrame(self,fg_color="#161b22",corner_radius=8);f.pack(fill="x",padx=24,pady=(8,4))
        ctk.CTkLabel(f,text=f"  {t}",font=ctk.CTkFont(size=14,weight="bold"),text_color="#d2991b").pack(padx=14,pady=(8,6),anchor="w")
    def _tb(self,h):
        t=ctk.CTkTextbox(self,font=ctk.CTkFont(size=11,family="Consolas"),fg_color="#0d1117",text_color="#c9d1d9",corner_radius=8,height=h,wrap="word",border_width=1,border_color="#30363d");t.pack(fill="x",padx=24);return t
    def _cb(self,p,t,v,c):
        r=ctk.CTkFrame(p,fg_color="transparent");r.pack(fill="x",padx=10,pady=(6,2))
        ctk.CTkCheckBox(r,text="",variable=v,font=ctk.CTkFont(size=13),fg_color=c,hover_color=c,width=28,border_width=1).pack(side="left")
        ctk.CTkLabel(r,text=t,font=ctk.CTkFont(size=13),text_color="#c9d1d9").pack(side="left",padx=6)
    def _detect(self):
        ip=os.path.join(INSTALL_DIR,"install_info.json")
        if os.path.exists(ip):
            with open(ip,"r",encoding="utf-8") as f:self.info_data=json.load(f)
            lines=[f"安装路径: {INSTALL_DIR}",f"安装方案: {self.info_data.get('plan','未知')}",f"安装时间: {self.info_data.get('installed_at','未知')}","模型:"]
            for m in self.info_data.get("models",[]):lines.append(f"  - {m}")
        else:
            lines=[f"项目目录: {INSTALL_DIR}",f"状态: {'存在' if os.path.isdir(INSTALL_DIR) else '不存在'}"]
        self.itb.configure(state="normal");self.itb.delete("1.0","end");self.itb.insert("end","\n".join(lines));self.itb.configure(state="disabled")
    def _log(self,m):self.log_msgs.append(m);self.after(0,self._fl)
    def _fl(self):
        self.ltb.configure(state="normal");self.ltb.delete("1.0","end");self.ltb.insert("end","\n".join(self.log_msgs[-50:]));self.ltb.see("end");self.ltb.configure(state="disabled")
    def _ask(self):
        km,ks,rm,cp=self.km.get(),self.ks.get(),self.rm.get(),self.cp.get()
        mc=len(self.info_data.get("models",[])) if self.info_data else 0
        msg=f"确定要卸载 WWW Agent OS 吗？\n\n安装路径: {INSTALL_DIR}\n保留记忆: {'是' if km else '否'}\n保留技能: {'是' if ks else '否'}\n卸载模型 ({mc}个): {'是' if rm else '否'}\n清理 pip: {'是' if cp else '否'}\n\n此操作不可撤销！"
        if not messagebox.askyesno("确认",msg,icon="warning"):return
        self.ub.configure(state="disabled",text="卸载中...");self.log_msgs=[]
        self._log("========== 开始卸载 ==========")
        threading.Thread(target=self._run,daemon=True).start()
    def _run(self):
        km,ks,rm,cp=self.km.get(),self.ks.get(),self.rm.get(),self.cp.get()
        try:
            if os.path.exists(SHORTCUT):os.remove(SHORTCUT);self._log("快捷方式已删除")
            else:self._log("快捷方式未找到")
            if os.path.isdir(INSTALL_DIR):
                mb,sb=None,None
                if km:
                    mp=os.path.join(INSTALL_DIR,"memory")
                    if os.path.exists(mp):
                        mb=os.path.join(os.environ.get("TEMP",""),f"www_mem_{int(time.time())}")
                        shutil.copytree(mp,mb);self._log("记忆已暂存")
                if ks:
                    sp=os.path.join(INSTALL_DIR,"data","skills")
                    if os.path.exists(sp):
                        sb=os.path.join(os.environ.get("TEMP",""),f"www_sk_{int(time.time())}")
                        shutil.copytree(sp,sb);self._log("技能已暂存")
                shutil.rmtree(INSTALL_DIR,ignore_errors=True);self._log("安装目录已删除")
                if mb or sb:
                    os.makedirs(INSTALL_DIR,exist_ok=True)
                    if mb:shutil.copytree(mb,os.path.join(INSTALL_DIR,"memory"));shutil.rmtree(mb,ignore_errors=True);self._log("记忆已还原")
                    if sb:
                        os.makedirs(os.path.join(INSTALL_DIR,"data"),exist_ok=True)
                        shutil.copytree(sb,os.path.join(INSTALL_DIR,"data","skills"));shutil.rmtree(sb,ignore_errors=True);self._log("技能已还原")
            if rm and self.info_data:
                ms=list(dict.fromkeys(self.info_data.get("models",[])))
                if ms and chk_ollama():
                    for m in ms:
                        self._log(f"ollama rm {m}")
                        try:subprocess.run(["ollama","rm",m],check=True,timeout=60,capture_output=True);self._log(f"  ✓ {m}")
                        except:self._log(f"  ✗ {m}")
            if cp:
                try:subprocess.run([sys.executable,"-m","pip","cache","purge"],check=True,timeout=60,capture_output=True);self._log("pip 缓存已清理")
                except:self._log("pip 缓存清理失败")
            self._log("========== 卸载完成 ==========")
            parts=["WWW Agent OS 已卸载。\n"]
            if km:parts.append(f"记忆数据保留于: {INSTALL_DIR}\\memory\\")
            if ks:parts.append(f"技能数据保留于: {INSTALL_DIR}\\data\\skills\\")
            self.after(0,lambda:messagebox.showinfo("卸载完成","\n".join(parts)))
        except Exception as e:self._log(f"错误: {e}")
        finally:self.after(0,lambda:self.ub.configure(state="disabled",text="已卸载",fg_color="#30363d"))

if __name__=="__main__":
    ctk.set_appearance_mode("dark");ctk.set_default_color_theme("dark-blue")
    Uninstaller().mainloop()
'''
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    def _show_result(self, config_key, install_dir, mr, os_stat):
        if config_key == "custom":
            pl = "自定义"
        else:
            pl = CONFIG_PRESETS.get(config_key, {}).get("label", config_key)
        lines = ["WWW Agent OS 安装完成", "",
                 f"软件本体: ✓ 已安装",
                 f"安装路径: {install_dir}",
                 "桌面快捷方式: ✓ 已创建", "",
                 f"Ollama: {'✓ 已安装' if os_stat.get('installed') else '⚠ 已跳过'}",
                 "", "模型下载:"]
        for m in mr.get("success", []):
            lines.append(f"  ✓ {m}")
        for m in mr.get("skipped", []):
            lines.append(f"  ✓ {m}（已存在，跳过）")
        for m in mr.get("failed", []):
            lines.append(f"  ✗ {m}（跳过，请手动安装）")
        lines += ["", f"配置方案: {pl}"]
        messagebox.showinfo("安装完成", "\n".join(lines))
        self.install_btn.configure(state="disabled", text="已完成", fg_color="#30363d")

    def _install_failed(self, reason):
        self.after(0, lambda: messagebox.showerror("安装失败", f"安装过程出错:\n{reason}"))
        self.after(0, lambda: self.install_btn.configure(
            state="normal", text="重试安装", fg_color="#238636"))
        self.installing = False

    @staticmethod
    def _write_json(path, data):
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


# ===================== 入口 =====================
if __name__ == "__main__":
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")
    app = InstallerGUI()
    app.mainloop()
