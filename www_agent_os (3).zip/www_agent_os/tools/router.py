"""
ToolRouter — 工具注册与路由

提供：
- Tool 数据类：封装工具元信息和执行接口
- ToolRouter：注册工具、按名称路由、参数验证
- 与 EventBus 集成

版本: 1.0.0
"""

from __future__ import annotations

import inspect
import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from events.bus import Event, EventBus, EventType, get_default_bus

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Tool 定义
# ------------------------------------------------------------------

@dataclass
class ToolParameter:
    """工具参数定义。

    Attributes:
        name: 参数名。
        type: Python 类型名（如 'str', 'int', 'bool'）。
        description: 参数说明。
        required: 是否必填。
        default: 默认值。
    """

    name: str
    type: str = "str"
    description: str = ""
    required: bool = True
    default: Any = None


@dataclass
class Tool:
    """工具定义。

    Attributes:
        name: 工具唯一名称（如 'file_read', 'web_fetch'）。
        description: 工具功能描述。
        category: 工具分类（'file', 'web', 'system', 'search' 等）。
        parameters: 参数列表。
        handler: 工具执行函数，签名为 (params: dict) → Any。
        enabled: 是否启用。
        version: 工具版本。
    """

    name: str
    description: str = ""
    category: str = "general"
    parameters: List[ToolParameter] = field(default_factory=list)
    handler: Optional[Callable[..., Any]] = None
    enabled: bool = True
    version: str = "1.0.0"

    def to_schema(self) -> Dict[str, Any]:
        """导出为 JSON Schema 风格字典。"""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "version": self.version,
            "parameters": {
                p.name: {
                    "type": p.type,
                    "description": p.description,
                    "required": p.required,
                    "default": p.default,
                }
                for p in self.parameters
            },
        }

    def validate_params(self, params: Dict[str, Any]) -> List[str]:
        """验证调用参数。

        Args:
            params: 传入的参数字典。

        Returns:
            错误信息列表（空列表表示验证通过）。
        """
        errors: List[str] = []

        # 检查必填参数
        provided = set(params.keys())
        for p in self.parameters:
            if p.required and p.name not in provided:
                errors.append(f"缺少必填参数 '{p.name}'（{p.description}）")

        # 检查未知参数
        known = {p.name for p in self.parameters}
        unknown = provided - known
        if unknown:
            errors.append(f"未知参数: {', '.join(sorted(unknown))}")

        return errors

    def __call__(self, **params: Any) -> Any:
        """执行工具。

        Args:
            **params: 工具参数。

        Returns:
            工具执行结果。

        Raises:
            RuntimeError: 工具未绑定 handler 或未启用。
        """
        if not self.handler:
            raise RuntimeError(f"工具 '{self.name}' 未绑定 handler")
        if not self.enabled:
            raise RuntimeError(f"工具 '{self.name}' 已禁用")
        return self.handler(**params)


# ------------------------------------------------------------------
# ToolRouter
# ------------------------------------------------------------------

class ToolRouter:
    """工具路由器。

    负责：
    - 注册工具（name → Tool）
    - 按名称路由调用
    - 参数验证
    - 工具列表导出（供 LLM function-calling）
    - 通过 EventBus 发布工具调用事件

    Usage::

        router = ToolRouter(bus)

        router.register(Tool(
            name="echo",
            description="回显输入",
            parameters=[ToolParameter(name="text", type="str", required=True)],
            handler=lambda text: f"Echo: {text}",
        ))

        result = router.invoke("echo", text="hello")
    """

    def __init__(self, bus: Optional[EventBus] = None) -> None:
        """初始化 ToolRouter。

        Args:
            bus: EventBus 实例。不传则使用全局默认。
        """
        self._bus = bus or get_default_bus()
        self._tools: Dict[str, Tool] = {}
        self._lock = threading.RLock()
        logger.info("ToolRouter 已初始化")

    @property
    def bus(self) -> EventBus:
        """获取绑定的 EventBus。"""
        return self._bus

    # ------------------------------------------------------------------
    # 注册
    # ------------------------------------------------------------------

    def register(self, tool: Tool) -> bool:
        """注册工具。

        Args:
            tool: 工具定义。

        Returns:
            True 表示注册成功，False 表示名称冲突。

        Raises:
            ValueError: 工具缺少 handler。
        """
        if not tool.handler:
            raise ValueError(f"工具 '{tool.name}' 缺少 handler")

        with self._lock:
            if tool.name in self._tools:
                logger.warning("工具 '%s' 已存在，覆盖旧定义", tool.name)
                self._tools[tool.name] = tool
                return False
            else:
                self._tools[tool.name] = tool

        logger.info("工具已注册: %s (v%s, category=%s)", tool.name, tool.version, tool.category)
        self._bus.emit(Event(
            type=EventType.TOOL_REGISTERED,
            source="tool.router",
            data={"tool_name": tool.name, "category": tool.category},
        ))
        return True

    def unregister(self, name: str) -> bool:
        """注销工具。

        Args:
            name: 工具名称。

        Returns:
            是否成功注销。
        """
        with self._lock:
            if name in self._tools:
                del self._tools[name]
                logger.info("工具已注销: %s", name)
                return True
            return False

    def get(self, name: str) -> Optional[Tool]:
        """按名称获取工具定义。"""
        with self._lock:
            return self._tools.get(name)

    def list_all(self) -> List[Tool]:
        """列出所有已注册工具（仅启用的）。"""
        with self._lock:
            return [t for t in self._tools.values() if t.enabled]

    def list_by_category(self, category: str) -> List[Tool]:
        """按分类列出工具。"""
        with self._lock:
            return [
                t for t in self._tools.values()
                if t.enabled and t.category == category
            ]

    def export_schemas(self) -> List[Dict[str, Any]]:
        """导出所有工具 schema（用于 LLM function-calling）。"""
        with self._lock:
            return [t.to_schema() for t in self._tools.values() if t.enabled]

    # ------------------------------------------------------------------
    # 路由
    # ------------------------------------------------------------------

    def invoke(self, name: str, **params: Any) -> Any:
        """按名称路由并执行工具。

        执行流程：
        1. 查找工具
        2. 验证参数
        3. 执行 handler
        4. 发布事件

        Args:
            name: 工具名称。
            **params: 工具参数。

        Returns:
            工具执行结果。

        Raises:
            KeyError: 工具未注册。
            ValueError: 参数验证失败。
            RuntimeError: 工具执行异常。
        """
        tool = self.get(name)
        if tool is None:
            raise KeyError(f"工具 '{name}' 未注册")

        if not tool.enabled:
            raise RuntimeError(f"工具 '{name}' 已禁用")

        # 参数验证
        errors = tool.validate_params(params)
        if errors:
            raise ValueError(f"工具 '{name}' 参数验证失败: {'; '.join(errors)}")

        # 执行
        logger.info("调用工具: %s(%s)", name, {k: str(v)[:60] for k, v in params.items()})
        try:
            result = tool(**params)
        except Exception as exc:
            self._bus.emit(Event(
                type=EventType.TOOL_ERROR,
                source="tool.router",
                data={"tool_name": name, "error": str(exc)},
            ))
            raise RuntimeError(f"工具 '{name}' 执行异常: {exc}") from exc

        self._bus.emit(Event(
            type=EventType.TOOL_INVOKED,
            source="tool.router",
            data={"tool_name": name, "success": True},
        ))
        return result

    # ------------------------------------------------------------------
    # 便捷注册方法
    # ------------------------------------------------------------------

    def register_function(
        self,
        name: str,
        fn: Callable[..., Any],
        description: str = "",
        category: str = "general",
    ) -> Tool:
        """从普通函数自动生成 Tool 并注册。

        Args:
            name: 工具名称。
            fn: 函数。
            description: 功能描述。
            category: 分类。

        Returns:
            生成的 Tool 对象。
        """
        sig = inspect.signature(fn)
        parameters: List[ToolParameter] = []

        for param_name, param in sig.parameters.items():
            if param_name in ("self", "cls"):
                continue
            param_type = "str"
            if param.annotation is not inspect.Parameter.empty:
                raw = param.annotation
                param_type = raw.__name__ if hasattr(raw, "__name__") else str(raw)

            required = param.default is inspect.Parameter.empty
            default = None if required else param.default

            parameters.append(ToolParameter(
                name=param_name,
                type=param_type,
                description="",
                required=required,
                default=default,
            ))

        tool = Tool(
            name=name,
            description=description,
            category=category,
            parameters=parameters,
            handler=fn,
        )
        self.register(tool)
        return tool

    @property
    def count(self) -> int:
        """已注册工具总数。"""
        with self._lock:
            return len(self._tools)
