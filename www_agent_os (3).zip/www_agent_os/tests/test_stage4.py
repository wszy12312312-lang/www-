"""
Stage 4 集成测试：EventBus → Task → ToolRouter → ModelGateway → Memory

测试覆盖：
- EventBus：订阅/发布/通配符/并发
- TaskManager：创建/状态流转/非法转移
- ToolRouter：注册/路由/参数验证/错误处理
- ModelGateway：初始化/认证/配置
- MemoryStore：存储/检索/搜索/持久化/清理
- 闭环集成：EventBus 贯穿所有模块
"""

import os
import sys
import tempfile
import threading
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path

# 添加项目根目录到 sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from events.bus import Event, EventBus, EventType, get_default_bus
from task.manager import Task, TaskManager, TaskStatus
from tools.router import Tool, ToolParameter, ToolRouter
from models.gateway import (
    ModelGateway, GenerationConfig, ChatMessage, ModelResponse, ModelInfo
)
from memory.store import MemoryEntry, MemoryStore


# ======================================================================
# 4A: EventBus 测试
# ======================================================================

class TestEventBus(unittest.TestCase):
    """EventBus 单元测试。"""

    def setUp(self) -> None:
        self.bus = EventBus(name="test")

    def tearDown(self) -> None:
        self.bus.clear()

    def test_01_subscribe_and_emit(self):
        """基本订阅/发布流程。"""
        received: list[Event] = []

        @self.bus.on("task.created")
        def handler(event: Event) -> None:
            received.append(event)

        self.bus.emit(Event(type="task.created", data={"task_id": "123"}))
        self.assertEqual(len(received), 1)
        self.assertEqual(received[0].data["task_id"], "123")

    def test_02_enum_event_type(self):
        """EventType 枚举兼容。"""
        received: list[Event] = []

        self.bus.subscribe(EventType.TASK_COMPLETED.value, lambda e: received.append(e))
        self.bus.emit(Event(type=EventType.TASK_COMPLETED, data={"id": "x"}))
        self.assertEqual(len(received), 1)
        self.assertEqual(received[0].data["id"], "x")

    def test_03_wildcard_subscription(self):
        """通配符订阅。"""
        task_events: list[str] = []
        all_events: list[str] = []

        self.bus.subscribe("task.*", lambda e: task_events.append(e.type if isinstance(e.type, str) else e.type.value))
        self.bus.subscribe("*", lambda e: all_events.append(e.type if isinstance(e.type, str) else e.type.value))

        self.bus.emit(Event(type="task.created"))
        self.bus.emit(Event(type="task.completed"))
        self.bus.emit(Event(type="persona.activated"))

        self.assertEqual(task_events, ["task.created", "task.completed"])
        self.assertEqual(len(all_events), 3)

    def test_04_unsubscribe(self):
        """取消订阅。"""
        received: list[Event] = []

        def handler(event: Event) -> None:
            received.append(event)

        self.bus.subscribe("test.event", handler)
        self.bus.emit(Event(type="test.event"))
        self.assertEqual(len(received), 1)

        self.bus.unsubscribe("test.event", handler)
        self.bus.emit(Event(type="test.event"))
        self.assertEqual(len(received), 1)  # 未变化

    def test_05_handler_exception_isolation(self):
        """单个处理器异常不影响其他处理器。"""
        called: list[str] = []

        def good(event: Event) -> None:
            called.append("good")

        def bad(event: Event) -> None:
            raise RuntimeError("handler error")

        self.bus.subscribe("test", good)
        self.bus.subscribe("test", bad)
        self.bus.emit(Event(type="test"))
        self.assertIn("good", called)

    def test_06_thread_safety(self):
        """多线程并发订阅/发布。"""
        errors: list[Exception] = []

        def publisher() -> None:
            for _ in range(50):
                try:
                    self.bus.emit(Event(type="concurrent.test", data={"n": _}))
                except Exception as e:
                    errors.append(e)

        threads = [threading.Thread(target=publisher) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(len(errors), 0)
        self.assertEqual(self.bus.event_count, 200)

    def test_07_get_default_bus_singleton(self):
        """全局默认 EventBus 单例。"""
        bus1 = get_default_bus()
        bus2 = get_default_bus()
        self.assertIs(bus1, bus2)

    def test_08_exact_match_no_wildcard(self):
        """无通配符的精确匹配。"""
        received: list[Event] = []

        self.bus.subscribe("exact.match", lambda e: received.append(e))
        self.bus.emit(Event(type="exact.match"))
        self.bus.emit(Event(type="exact.mismatch"))
        self.assertEqual(len(received), 1)

    def test_09_subscriber_stats(self):
        """订阅统计。"""
        self.bus.subscribe("a.*", lambda e: None)
        self.bus.subscribe("b.*", lambda e: None)
        self.bus.subscribe("c.exact", lambda e: None)

        self.assertEqual(self.bus.subscriber_count, 3)
        stats = self.bus.list_subscribers()
        self.assertIn("a.*", stats)
        self.assertIn("c.exact", stats)

    def test_10_emit_returns_called_count(self):
        """emit 返回被调用处理器数。"""
        self.bus.subscribe("test.count", lambda e: None)
        self.bus.subscribe("test.count", lambda e: None)
        self.bus.subscribe("test.other", lambda e: None)

        called = self.bus.emit(Event(type="test.count"))
        self.assertEqual(called, 2)


# ======================================================================
# 4B: Task Manager 测试
# ======================================================================

class TestTaskManager(unittest.TestCase):
    """TaskManager 单元测试。"""

    def setUp(self) -> None:
        self.bus = EventBus(name="task_test")
        self.mgr = TaskManager(bus=self.bus)

    def test_01_create_task(self):
        """创建任务。"""
        task = self.mgr.create(persona_id="s4", user_input="找文件")
        self.assertEqual(task.status, TaskStatus.PENDING)
        self.assertEqual(task.persona_id, "s4")
        self.assertEqual(task.input, "找文件")
        self.assertIsNotNone(task.id)

    def test_02_status_transition_normal(self):
        """正常状态流转：PENDING → RUNNING → COMPLETED。"""
        task = self.mgr.create("s4", "测试")
        self.mgr.start(task.id)
        task = self.mgr.get(task.id)
        self.assertEqual(task.status, TaskStatus.RUNNING)
        self.assertIsNotNone(task.started_at)

        self.mgr.complete(task.id, result="完成")
        task = self.mgr.get(task.id)
        self.assertEqual(task.status, TaskStatus.COMPLETED)
        self.assertEqual(task.result, "完成")
        self.assertTrue(task.is_terminal)

    def test_03_status_transition_fail(self):
        """PENDING → RUNNING → FAILED。"""
        task = self.mgr.create("s1", "安装软件")
        self.mgr.start(task.id)
        self.mgr.fail(task.id, error="安装失败")
        task = self.mgr.get(task.id)
        self.assertEqual(task.status, TaskStatus.FAILED)
        self.assertEqual(task.error, "安装失败")

    def test_04_cancel_pending(self):
        """取消 PENDING 任务。"""
        task = self.mgr.create("s2", "配置")
        self.mgr.cancel(task.id)
        task = self.mgr.get(task.id)
        self.assertEqual(task.status, TaskStatus.CANCELLED)

    def test_05_illegal_transition(self):
        """禁止非法状态转移（COMPLETED → RUNNING）。"""
        task = self.mgr.create("s3", "抓取")
        self.mgr.start(task.id)
        self.mgr.complete(task.id)
        result = self.mgr.start(task.id)
        self.assertIsNone(result)  # 拒绝转移

    def test_06_retry_failed_task(self):
        """重试失败任务。"""
        task = self.mgr.create("s5", "搜索")
        self.mgr.start(task.id)
        self.mgr.fail(task.id, error="超时")
        retried = self.mgr.retry(task.id)
        self.assertIsNotNone(retried)
        self.assertEqual(retried.status, TaskStatus.PENDING)

    def test_07_event_integration(self):
        """TaskManager 与 EventBus 集成。"""
        events: list[str] = []

        @self.bus.on("task.*")
        def collector(event: Event) -> None:
            evt = event.type if isinstance(event.type, str) else event.type.value
            events.append(evt)

        task = self.mgr.create("s4", "找文件")
        self.mgr.start(task.id)
        self.mgr.complete(task.id, "完成")

        self.assertIn("task.created", events)
        self.assertIn("task.started", events)
        self.assertIn("task.completed", events)

    def test_08_stats_and_history(self):
        """统计信息与历史记录。"""
        for i in range(5):
            t = self.mgr.create(f"s{i%3+1}", f"任务{i}")
            self.mgr.start(t.id)
            self.mgr.complete(t.id, f"结果{i}")

        stats = self.mgr.stats()
        self.assertEqual(stats["total"], 5)
        self.assertEqual(stats["active"], 0)

        history = self.mgr.recent_history(3)
        self.assertEqual(len(history), 3)

    def test_09_clear_completed(self):
        """清理已完成任务。"""
        for i in range(10):
            t = self.mgr.create("s4", f"任务{i}")
            self.mgr.start(t.id)
            self.mgr.complete(t.id)

        self.assertEqual(self.mgr.count, 10)
        removed = self.mgr.clear_completed()
        self.assertEqual(removed, 10)
        self.assertEqual(self.mgr.count, 0)

    def test_10_list_by_status(self):
        """按状态筛选。"""
        t1 = self.mgr.create("s4", "任务1")
        t2 = self.mgr.create("s4", "任务2")
        self.mgr.start(t1.id)

        pending = self.mgr.list_by_status(TaskStatus.PENDING)
        running = self.mgr.list_by_status(TaskStatus.RUNNING)
        self.assertEqual(len(pending), 1)
        self.assertEqual(len(running), 1)


# ======================================================================
# 4C: ToolRouter 测试
# ======================================================================

class TestToolRouter(unittest.TestCase):
    """ToolRouter 单元测试。"""

    def setUp(self) -> None:
        self.bus = EventBus(name="tool_test")
        self.router = ToolRouter(bus=self.bus)

    def test_01_register_and_invoke(self):
        """注册工具并调用。"""
        tool = Tool(
            name="echo",
            description="回显文本",
            parameters=[ToolParameter(name="text", type="str", required=True)],
            handler=lambda text: f"Echo: {text}",
        )
        self.router.register(tool)
        result = self.router.invoke("echo", text="hello")
        self.assertEqual(result, "Echo: hello")

    def test_02_validation_missing_required(self):
        """参数验证：缺失必填参数。"""
        tool = Tool(
            name="add",
            description="加法",
            parameters=[
                ToolParameter(name="a", type="int", required=True),
                ToolParameter(name="b", type="int", required=True),
            ],
            handler=lambda a, b: a + b,
        )
        self.router.register(tool)

        with self.assertRaises(ValueError) as ctx:
            self.router.invoke("add", a=1)
        self.assertIn("缺少必填参数", str(ctx.exception))

    def test_03_validation_unknown_params(self):
        """参数验证：未知参数。"""
        tool = Tool(name="noop", handler=lambda: "ok")
        self.router.register(tool)

        with self.assertRaises(ValueError) as ctx:
            self.router.invoke("noop", unknown=123)
        self.assertIn("未知参数", str(ctx.exception))

    def test_04_unregistered_tool(self):
        """调用未注册工具。"""
        with self.assertRaises(KeyError):
            self.router.invoke("nonexistent")

    def test_05_disabled_tool(self):
        """禁用工具拒绝调用。"""
        tool = Tool(
            name="disabled_tool",
            handler=lambda: "ok",
            enabled=False,
        )
        self.router.register(tool)

        with self.assertRaises(RuntimeError) as ctx:
            self.router.invoke("disabled_tool")
        self.assertIn("已禁用", str(ctx.exception))

    def test_06_handler_exception_propagation(self):
        """工具异常向上传播。"""
        tool = Tool(
            name="exploding",
            handler=lambda: (_ for _ in ()).throw(ValueError("BOOM")),
        )
        self.router.register(tool)

        with self.assertRaises(RuntimeError) as ctx:
            self.router.invoke("exploding")
        self.assertIn("BOOM", str(ctx.exception))

    def test_07_list_and_export(self):
        """列出工具与导出 schema。"""
        self.router.register(Tool(
            name="t1", category="file", handler=lambda: None,
        ))
        self.router.register(Tool(
            name="t2", category="web",
            parameters=[ToolParameter(name="url", type="str", required=True)],
            handler=lambda url: f"fetch {url}",
        ))

        all_tools = self.router.list_all()
        self.assertEqual(len(all_tools), 2)

        schemas = self.router.export_schemas()
        self.assertEqual(len(schemas), 2)
        self.assertTrue(any(s["name"] == "t2" for s in schemas))

        file_tools = self.router.list_by_category("file")
        self.assertEqual(len(file_tools), 1)
        self.assertEqual(file_tools[0].name, "t1")

    def test_08_unregister(self):
        """注销工具。"""
        self.router.register(Tool(name="temp", handler=lambda: None))
        self.assertTrue(self.router.unregister("temp"))
        self.assertFalse(self.router.unregister("not_exist"))

    def test_09_register_function_auto(self):
        """自动从函数注册。"""
        def add(a: int, b: int) -> int:
            """加法运算。"""
            return a + b

        tool = self.router.register_function("math_add", add, description="加法", category="math")
        result = self.router.invoke("math_add", a=3, b=7)
        self.assertEqual(result, 10)
        self.assertEqual(tool.category, "math")

    def test_10_event_integration(self):
        """ToolRouter 与 EventBus 集成。"""
        events: list[str] = []

        @self.bus.on("tool.*")
        def collector(event: Event) -> None:
            evt = event.type if isinstance(event.type, str) else event.type.value
            events.append(evt)

        self.router.register(Tool(name="test", handler=lambda: "ok"))
        self.router.invoke("test")

        self.assertIn("tool.registered", events)
        self.assertIn("tool.invoked", events)


# ======================================================================
# 4D: ModelGateway 测试
# ======================================================================

class TestModelGateway(unittest.TestCase):
    """ModelGateway 单元测试（不依赖实际 Ollama 服务）。"""

    def test_01_initialization_defaults(self):
        """默认初始化。"""
        gw = ModelGateway()
        self.assertEqual(gw.host, "http://localhost:11434")
        self.assertEqual(gw.timeout, 120)
        self.assertFalse(gw.is_online)
        gw.close()

    def test_02_custom_config(self):
        """自定义配置初始化。"""
        gw = ModelGateway(
            host="http://10.0.0.1:8080",
            timeout=30,
            max_retries=1,
        )
        self.assertEqual(gw.host, "http://10.0.0.1:8080")
        self.assertEqual(gw.timeout, 30)
        gw.close()

    def test_03_bearer_auth_h02(self):
        """Bearer Token 认证（H02 修复）。"""
        gw = ModelGateway(api_key="sk-test-key-12345")
        self.assertIn("Authorization", gw._auth_headers)
        self.assertEqual(gw._auth_headers["Authorization"], "Bearer sk-test-key-12345")
        gw.close()

    def test_04_basic_auth(self):
        """Basic Auth 认证。"""
        gw = ModelGateway(api_user="admin", api_password="secret")
        self.assertIn("Authorization", gw._auth_headers)
        self.assertTrue(gw._auth_headers["Authorization"].startswith("Basic "))
        gw.close()

    def test_05_no_auth(self):
        """无认证配置。"""
        gw = ModelGateway()
        self.assertEqual(gw._auth_headers, {})
        gw.close()

    def test_06_generation_config(self):
        """GenerationConfig 序列化。"""
        config = GenerationConfig(temperature=0.5, top_p=0.8)
        d = config.to_dict()
        self.assertEqual(d["temperature"], 0.5)
        self.assertEqual(d["top_p"], 0.8)
        self.assertNotIn("top_k", d)  # 默认值不导出

    def test_07_chat_message(self):
        """ChatMessage 序列化。"""
        msg = ChatMessage(role="user", content="Hello")
        self.assertEqual(msg.to_dict(), {"role": "user", "content": "Hello"})

    def test_08_model_response(self):
        """ModelResponse 默认值。"""
        resp = ModelResponse()
        self.assertEqual(resp.content, "")
        self.assertTrue(resp.done)

    def test_09_verify_auth_locally(self):
        """无认证时 verify_auth 返回 True。"""
        gw = ModelGateway()
        ok, info = gw.verify_auth()
        self.assertTrue(ok)
        gw.close()

    def test_10_event_bus_integration(self):
        """ModelGateway 与 EventBus 集成（通过属性）。"""
        bus = EventBus()
        gw = ModelGateway(bus=bus)
        self.assertIs(gw.bus, bus)
        gw.close()


# ======================================================================
# 4E: Memory Store 测试
# ======================================================================

class TestMemoryStore(unittest.TestCase):
    """MemoryStore 单元测试。"""

    def setUp(self) -> None:
        self.tempdir = tempfile.mkdtemp(prefix="memory_test_")
        self.bus = EventBus(name="memory_test")
        self.store = MemoryStore(storage_dir=self.tempdir, short_term_capacity=50, bus=self.bus)

    def tearDown(self) -> None:
        import shutil
        shutil.rmtree(self.tempdir, ignore_errors=True)

    def test_01_save_and_retrieve(self):
        """保存并检索短期记忆。"""
        self.store.save_message("s4", "用户: 帮我找一份PDF", role="user")
        time.sleep(0.01)  # 确保时间戳有区分
        self.store.save_message("s4", "助手: 找到了 3 份PDF", role="assistant")

        memories = self.store.retrieve(persona_id="s4", limit=10)
        self.assertEqual(len(memories), 2)
        self.assertEqual(memories[0].role, "assistant")  # 最新在前
        self.assertEqual(memories[1].role, "user")

    def test_02_save_conversation_batch(self):
        """批量保存对话。"""
        messages = [
            ("user", "帮我安装Python"),
            ("assistant", "正在执行安装..."),
            ("user", "确认安装"),
        ]
        ids = self.store.save_conversation("s1", messages)
        self.assertEqual(len(ids), 3)

        memories = self.store.retrieve(persona_id="s1")
        self.assertEqual(len(memories), 3)

    def test_03_search_by_keyword(self):
        """关键词搜索。"""
        self.store.save_message("s4", "用户: 找一份关于深度学习的PDF", role="user")
        self.store.save_message("s4", "用户: 帮我安装VS Code", role="user")

        results = self.store.search("深度学习")
        self.assertEqual(len(results), 1)
        self.assertIn("深度学习", results[0].content)

        results_empty = self.store.search("不存在的内容")
        self.assertEqual(len(results_empty), 0)

    def test_04_persistence_and_load(self):
        """长期记忆持久化与加载。"""
        self.store.save_message("s4", "持久化测试消息", role="user", persist=True)

        # 加载
        entries = self.store.load_long_term("s4")
        self.assertGreaterEqual(len(entries), 1)
        self.assertTrue(any("持久化测试" in e.content for e in entries))

    def test_05_sync_long_to_short(self):
        """长期记忆同步到短期。"""
        self.store.save_message("s5", "长期记忆内容", role="user", persist=True)

        # 清除短期
        self.store.clear_short_term("s5")

        # 同步
        synced = self.store.sync_to_short_term("s5")
        self.assertGreaterEqual(synced, 1)

        memories = self.store.retrieve(persona_id="s5")
        self.assertGreaterEqual(len(memories), 1)

    def test_06_clear_short_term(self):
        """清除短期记忆。"""
        self.store.save_message("s4", "消息1", role="user")
        self.store.save_message("s4", "消息2", role="assistant")

        self.assertEqual(len(self.store.retrieve(persona_id="s4")), 2)
        cleared = self.store.clear_short_term("s4")
        self.assertEqual(cleared, 2)
        self.assertEqual(len(self.store.retrieve(persona_id="s4")), 0)

    def test_07_clear_long_term(self):
        """清除长期记忆文件。"""
        self.store.save_message("s4", "持久化1", role="user", persist=True)
        self.assertGreaterEqual(len(self.store.load_long_term("s4")), 1)

        cleared = self.store.clear_long_term("s4")
        self.assertEqual(cleared, 1)

    def test_08_memory_ttl_expiry(self):
        """TTL 过期检查。"""
        entry = MemoryEntry(
            persona_id="s4",
            content="过期记忆",
            role="user",
            ttl=1.0,  # 1 秒
        )
        self.store.save(entry)
        time.sleep(1.2)

        memories = self.store.retrieve(persona_id="s4")
        self.assertEqual(len(memories), 0)  # 已过期

    def test_09_access_count_and_touch(self):
        """访问计数与更新时间。"""
        entry = MemoryEntry(persona_id="s4", content="测试", role="user")
        self.store.save(entry)

        # 第一次检索
        memories = self.store.retrieve(persona_id="s4")
        self.assertEqual(len(memories), 1)
        self.assertEqual(memories[0].access_count, 1)  # 首次 touch

    def test_10_stats(self):
        """统计信息。"""
        self.store.save_message("s1", "msg", role="user")
        self.store.save_message("s2", "msg", role="user", persist=True)
        self.store.save_message("s2", "msg2", role="assistant")

        stats = self.store.stats()
        self.assertEqual(stats["short_term_total"], 3)
        self.assertIn("s1", stats["short_term_by_persona"])
        self.assertIn("s2", stats["short_term_by_persona"])

    def test_11_event_integration(self):
        """MemoryStore 与 EventBus 集成。"""
        events: list[str] = []

        @self.bus.on("memory.*")
        def collector(event: Event) -> None:
            evt = event.type if isinstance(event.type, str) else event.type.value
            events.append(evt)

        self.store.save_message("s4", "hello", role="user")
        self.store.retrieve(persona_id="s4")

        self.assertIn("memory.stored", events)
        self.assertIn("memory.retrieved", events)

    def test_12_capacity_limit(self):
        """短期记忆容量限制（deque maxlen）。"""
        small_store = MemoryStore(storage_dir=self.tempdir, short_term_capacity=5)

        for i in range(10):
            small_store.save_message("s4", f"消息{i}", role="user")

        memories = small_store.retrieve(persona_id="s4")
        self.assertLessEqual(len(memories), 5)


# ======================================================================
# 4F: 闭环集成测试
# ======================================================================

class TestStage4Integration(unittest.TestCase):
    """Stage 4 闭环集成测试。

    验证 EventBus → Task → ToolRouter → ModelGateway → Memory 完整链路。
    """

    def setUp(self) -> None:
        self.bus = EventBus(name="integration")
        self.task_mgr = TaskManager(bus=self.bus)
        self.tool_router = ToolRouter(bus=self.bus)
        self.tempdir = tempfile.mkdtemp(prefix="stage4_int_")
        self.memory = MemoryStore(storage_dir=self.tempdir, bus=self.bus)

    def tearDown(self) -> None:
        import shutil
        self.bus.clear()
        shutil.rmtree(self.tempdir, ignore_errors=True)

    def test_01_full_pipeline_events(self):
        """完整链路事件验证：创建任务 → 执行工具 → 存储记忆 → 完成任务。"""
        collected: list[dict] = []

        @self.bus.on("*")
        def collector(event: Event) -> None:
            evt = event.type if isinstance(event.type, str) else event.type.value
            collected.append({"type": evt, "source": event.source, "data": event.data})

        # 注册工具
        self.tool_router.register(Tool(
            name="file_find",
            description="查找文件",
            parameters=[ToolParameter(name="filename", type="str", required=True)],
            handler=lambda filename: f"找到文件: {filename}.pdf",
        ))

        # 创建任务
        task = self.task_mgr.create(persona_id="s4", user_input="找一份合同")
        self.task_mgr.start(task.id)

        # 模拟执行工具
        result = self.tool_router.invoke("file_find", filename="租赁合同")
        self.task_mgr.complete(task.id, result=result)

        # 存储记忆
        self.memory.save_message("s4", "用户: 找一份合同", role="user", persist=True)
        self.memory.save_message("s4", f"助手: {result}", role="assistant", persist=True)

        # 验证事件链路
        event_types = [c["type"] for c in collected]
        self.assertIn("task.created", event_types)
        self.assertIn("task.started", event_types)
        self.assertIn("task.completed", event_types)
        self.assertIn("tool.invoked", event_types)
        self.assertIn("memory.stored", event_types)

        # 验证记忆可检索
        memories = self.memory.retrieve(persona_id="s4")
        self.assertGreaterEqual(len(memories), 2)

    def test_02_error_propagation(self):
        """错误传播链路：工具异常 → 任务失败 → 错误事件。"""
        error_events: list[Event] = []

        @self.bus.on("error.*")
        def error_collector(event: Event) -> None:
            error_events.append(event)

        self.tool_router.register(Tool(
            name="risky_tool",
            handler=lambda: (_ for _ in ()).throw(RuntimeError("模拟错误")),
        ))

        task = self.task_mgr.create(persona_id="s2", user_input="执行风险操作")
        self.task_mgr.start(task.id)

        try:
            self.tool_router.invoke("risky_tool")
        except RuntimeError:
            pass

        self.task_mgr.fail(task.id, error="工具执行异常")

        final_task = self.task_mgr.get(task.id)
        self.assertEqual(final_task.status, TaskStatus.FAILED)

    def test_03_multi_persona_parallel(self):
        """多 Persona 并行任务。"""
        tasks = []
        for pid in ["s1", "s2", "s3", "s4"]:
            t = self.task_mgr.create(persona_id=pid, user_input=f"任务-{pid}")
            self.task_mgr.start(t.id)
            self.task_mgr.complete(t.id, f"完成-{pid}")
            self.memory.save_message(pid, f"任务: {t.input}", role="user")
            tasks.append(t)

        for pid in ["s1", "s2", "s3", "s4"]:
            mem = self.memory.retrieve(persona_id=pid)
            self.assertGreaterEqual(len(mem), 1)

            persona_tasks = self.task_mgr.list_by_persona(pid)
            self.assertEqual(len(persona_tasks), 1)
            self.assertEqual(persona_tasks[0].status, TaskStatus.COMPLETED)

    def test_04_bus_isolation(self):
        """EventBus 隔离性：不同实例互不干扰。"""
        bus_a = EventBus(name="A")
        bus_b = EventBus(name="B")

        a_events: list[str] = []
        b_events: list[str] = []

        bus_a.on("*")(lambda e: a_events.append(e.type if isinstance(e.type, str) else e.type.value))
        bus_b.on("*")(lambda e: b_events.append(e.type if isinstance(e.type, str) else e.type.value))

        bus_a.emit(Event(type="a.event"))
        bus_b.emit(Event(type="b.event"))

        self.assertIn("a.event", a_events)
        self.assertNotIn("b.event", a_events)
        self.assertIn("b.event", b_events)
        self.assertNotIn("a.event", b_events)

    def test_05_memory_lifecycle(self):
        """记忆全生命周期：存储 → 检索 → 搜索 → 同步 → 清除。"""
        pid = "s4"
        # 存储
        self.memory.save_message(pid, "用户喜欢蓝色主题", role="user", persist=True)
        self.memory.save_message(pid, "用户需要月度财务报表", role="user", persist=True)

        # 检索
        all_mem = self.memory.retrieve(persona_id=pid)
        self.assertEqual(len(all_mem), 2)

        # 搜索
        results = self.memory.search("蓝色", persona_id=pid)
        self.assertEqual(len(results), 1)

        # 持久化加载
        loaded = self.memory.load_long_term(pid)
        self.assertGreaterEqual(len(loaded), 2)

        # 清除短期 → 同步回短期
        self.memory.clear_short_term(pid)
        self.assertEqual(len(self.memory.retrieve(persona_id=pid)), 0)
        self.memory.sync_to_short_term(pid)
        self.assertGreaterEqual(len(self.memory.retrieve(persona_id=pid)), 2)

        # 清除长期
        self.memory.clear_long_term(pid)
        self.assertEqual(len(self.memory.load_long_term(pid)), 0)


# ======================================================================
# Feature Flags 测试
# ======================================================================

class TestStage4FeatureFlags(unittest.TestCase):
    """Stage 4 Feature Flags 验证。"""

    def _parse_flags(self) -> dict:
        ff_path = PROJECT_ROOT / "feature_flags.yaml"
        with open(ff_path, "r", encoding="utf-8") as f:
            content = f.read()

        result: dict = {}
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                if "#" in line:
                    hash_pos = line.find("#")
                    if hash_pos > 0:
                        line = line[:hash_pos].strip()
                key, val = line.split(":", 1)
                key = key.strip()
                val = val.strip()
                if val.lower() == "true":
                    result[key] = True
                elif val.lower() == "false":
                    result[key] = False
                else:
                    result[key] = val
        return result

    def test_01_event_bus_default_false(self):
        """USE_EVENT_BUS 默认 false。"""
        flags = self._parse_flags()
        self.assertIn("USE_EVENT_BUS", flags)
        self.assertFalse(flags["USE_EVENT_BUS"])

    def test_02_task_manager_default_false(self):
        """USE_TASK_MANAGER 默认 false。"""
        flags = self._parse_flags()
        self.assertIn("USE_TASK_MANAGER", flags)
        self.assertFalse(flags["USE_TASK_MANAGER"])

    def test_03_tool_router_default_false(self):
        """USE_TOOL_ROUTER 默认 false。"""
        flags = self._parse_flags()
        self.assertIn("USE_TOOL_ROUTER", flags)
        self.assertFalse(flags["USE_TOOL_ROUTER"])

    def test_04_model_gateway_default_false(self):
        """USE_MODEL_GATEWAY 默认 false。"""
        flags = self._parse_flags()
        self.assertIn("USE_MODEL_GATEWAY", flags)
        self.assertFalse(flags["USE_MODEL_GATEWAY"])

    def test_05_memory_store_default_false(self):
        """USE_MEMORY_STORE 默认 false。"""
        flags = self._parse_flags()
        self.assertIn("USE_MEMORY_STORE", flags)
        self.assertFalse(flags["USE_MEMORY_STORE"])


# ======================================================================
# 入口
# ======================================================================

if __name__ == "__main__":
    unittest.main(verbosity=2)
