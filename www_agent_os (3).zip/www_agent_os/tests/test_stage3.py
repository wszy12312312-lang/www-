"""
第三阶段验收测试：Persona 体系建立

测试覆盖：
- 8 个 Persona 子类正确实例化
- PersonaState 状态机流转
- Persona 基类序列化/反序列化
- PersonaRegistry 注册/查询/持久化
- PersonaManager 集成 Registry 后五维评分匹配
- 旧 SKILL.md prompt 内容完整性
- feature_flags USE_NEW_PERSONA_SYSTEM 存在且默认 false

Key: YTM-3R7-QGP9-B4FD-K1NM
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

# 确保项目根目录在 sys.path 中
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


# ======================================================================
# Test 1: Persona 基类 & 状态机
# ======================================================================

class TestPersonaBase(unittest.TestCase):
    """测试 Persona 基类与状态机。"""

    @classmethod
    def setUpClass(cls) -> None:
        from persona.base import Persona, PersonaState
        cls.Persona = Persona
        cls.PersonaState = PersonaState

    def test_01_default_state_uninitialized(self) -> None:
        """新 Persona 默认状态为 UNINITIALIZED。"""
        p = self.Persona(
            persona_id="test",
            name="测试",
            description="测试用 Persona",
            capabilities=["测试"],
            version="1.0.0",
        )
        self.assertEqual(p.state, self.PersonaState.UNINITIALIZED)

    def test_02_state_transition_valid(self) -> None:
        """合法状态转移：UNINITIALIZED → IDLE → BUSY → IDLE。"""
        p = self.Persona(
            persona_id="test",
            name="测试",
            description="测试用",
            capabilities=["测试"],
            version="1.0.0",
        )
        # UNINITIALIZED → IDLE
        result = p.transition_to(self.PersonaState.IDLE)
        self.assertTrue(result)
        self.assertEqual(p.state, self.PersonaState.IDLE)

        # IDLE → BUSY
        result = p.transition_to(self.PersonaState.BUSY)
        self.assertTrue(result)
        self.assertEqual(p.state, self.PersonaState.BUSY)

        # BUSY → IDLE
        result = p.transition_to(self.PersonaState.IDLE)
        self.assertTrue(result)
        self.assertEqual(p.state, self.PersonaState.IDLE)

    def test_03_state_transition_error(self) -> None:
        """合法状态转移：IDLE → BUSY → ERROR → IDLE。"""
        p = self.Persona(
            persona_id="test",
            name="测试",
            description="测试用",
            capabilities=["测试"],
            version="1.0.0",
        )
        p.transition_to(self.PersonaState.IDLE)
        p.transition_to(self.PersonaState.BUSY)
        self.assertTrue(p.transition_to(self.PersonaState.ERROR))
        self.assertEqual(p.state, self.PersonaState.ERROR)

        # 从 ERROR 可回到 IDLE
        self.assertTrue(p.transition_to(self.PersonaState.IDLE))

    def test_04_state_transition_invalid(self) -> None:
        """非法状态转移应被拒绝：UNINITIALIZED → BUSY（跳过 IDLE）。"""
        p = self.Persona(
            persona_id="test",
            name="测试",
            description="测试用",
            capabilities=["测试"],
            version="1.0.0",
        )
        result = p.transition_to(self.PersonaState.BUSY)
        self.assertFalse(result)
        self.assertEqual(p.state, self.PersonaState.UNINITIALIZED)

    def test_05_state_terminated_irreversible(self) -> None:
        """TERMINATED 状态不可逆。"""
        p = self.Persona(
            persona_id="test",
            name="测试",
            description="测试用",
            capabilities=["测试"],
            version="1.0.0",
        )
        p.transition_to(self.PersonaState.IDLE)
        self.assertTrue(p.transition_to(self.PersonaState.TERMINATED))

        # 不可从 TERMINATED 转移
        self.assertFalse(p.transition_to(self.PersonaState.IDLE))
        self.assertFalse(p.transition_to(self.PersonaState.BUSY))
        self.assertEqual(p.state, self.PersonaState.TERMINATED)

    def test_06_serialization_roundtrip(self) -> None:
        """to_dict → from_dict 往返测试。"""
        p = self.Persona(
            persona_id="test",
            name="测试",
            description="测试用 Persona",
            capabilities=["测试", "能力A"],
            version="2.0.0",
            icon="T",
            color="#ff0000",
        )
        p.transition_to(self.PersonaState.IDLE)

        data = p.to_dict()
        restored = self.Persona.from_dict(data)

        self.assertEqual(restored.persona_id, "test")
        self.assertEqual(restored.name, "测试")
        self.assertEqual(restored.description, "测试用 Persona")
        self.assertEqual(restored.capabilities, ["测试", "能力A"])
        self.assertEqual(restored.version, "2.0.0")
        self.assertEqual(restored.icon, "T")
        self.assertEqual(restored.color, "#ff0000")
        self.assertEqual(restored.state, self.PersonaState.IDLE)

    def test_07_hashable(self) -> None:
        """Persona 可哈希。"""
        p1 = self.Persona(persona_id="a", name="A", description="", capabilities=[])
        p2 = self.Persona(persona_id="a", name="A", description="", capabilities=[])
        p3 = self.Persona(persona_id="b", name="B", description="", capabilities=[])

        self.assertEqual(hash(p1), hash(p2))
        self.assertNotEqual(hash(p1), hash(p3))

    def test_08_lifecycle_hooks(self) -> None:
        """生命周期钩子被调用。"""
        calls: list[str] = []

        class HookPersona(self.Persona):
            def on_activate(self) -> None:
                calls.append("activate")
                super().on_activate()

            def on_deactivate(self) -> None:
                calls.append("deactivate")
                super().on_deactivate()

            def on_error(self, error: Exception) -> None:
                calls.append(f"error:{type(error).__name__}")
                super().on_error(error)

        p = HookPersona(
            persona_id="hook",
            name="Hook",
            description="",
            capabilities=[],
        )
        # 直接调用生命周期钩子
        p.on_activate()
        self.assertIn("activate", calls)

        p.transition_to(self.PersonaState.BUSY)
        p.on_error(ValueError("test error"))
        self.assertIn("error:ValueError", calls)

    def test_09_net_incentive(self) -> None:
        """净激励计算正确。"""
        p = self.Persona(
            persona_id="test", name="测试", description="", capabilities=[],
            incentive_stars=4, penalty_stars=1,
        )
        self.assertEqual(p.net_incentive, 3)

    def test_10_success_rate(self) -> None:
        """成功率计算正确。"""
        p = self.Persona(
            persona_id="test", name="测试", description="", capabilities=[],
            success_count=8, failure_count=2,
        )
        self.assertAlmostEqual(p.success_rate, 0.8, places=5)

        # 无任务时默认 1.0
        p2 = self.Persona(persona_id="new", name="新", description="", capabilities=[])
        self.assertEqual(p2.success_rate, 1.0)


# ======================================================================
# Test 2: 8 个 Persona 子类实例化
# ======================================================================

class TestAllPersonas(unittest.TestCase):
    """测试所有 8 个 Persona 子类正确实例化且 prompt 完整。"""

    def _assert_persona_valid(self, persona, expected_id: str) -> None:
        """通用验证：Persona 子类字段完整性。"""
        self.assertIsNotNone(persona)
        self.assertTrue(hasattr(persona, "persona_id"))
        self.assertTrue(hasattr(persona, "core_prompt"))
        self.assertTrue(len(persona.core_prompt) > 200,
                        f"{expected_id} prompt 过短 ({len(persona.core_prompt)} 字符)")
        self.assertTrue(len(persona.capabilities) >= 3,
                        f"{expected_id} 能力标签太少 ({len(persona.capabilities)})")
        self.assertTrue(len(persona.version) > 0)

    def test_01_host_persona(self) -> None:
        from persona.host_persona import HostPersona
        p = HostPersona()
        self._assert_persona_valid(p, "host")
        self.assertEqual(p.persona_id, "host")
        self.assertIn("五层架构", p.core_prompt)
        self.assertIn("调度", p.core_prompt)
        self.assertIn("STATE-1", p.core_prompt)
        self.assertIn("S1", p.core_prompt)

    def test_02_software_persona(self) -> None:
        from persona.software_persona import SoftwarePersona
        p = SoftwarePersona()
        self._assert_persona_valid(p, "s1_software")
        self.assertIn("安装", p.core_prompt)
        self.assertIn("卸载", p.core_prompt)
        self.assertIn("S1", p.core_prompt)

    def test_03_system_persona(self) -> None:
        from persona.system_persona import SystemPersona
        p = SystemPersona()
        self._assert_persona_valid(p, "s2_system")
        self.assertIn("注册表", p.core_prompt)
        self.assertIn("环境变量", p.core_prompt)
        self.assertIn("S2", p.core_prompt)

    def test_04_web_persona(self) -> None:
        from persona.web_persona import WebPersona
        p = WebPersona()
        self._assert_persona_valid(p, "s3_web")
        self.assertIn("爬取", p.core_prompt)
        self.assertIn("浏览器", p.core_prompt)
        self.assertIn("S3", p.core_prompt)

    def test_05_file_persona(self) -> None:
        from persona.file_persona import FilePersona
        p = FilePersona()
        self._assert_persona_valid(p, "s4_file")
        self.assertIn("文件", p.core_prompt)
        self.assertIn("搜索", p.core_prompt)
        self.assertIn("S4", p.core_prompt)

    def test_06_search_persona(self) -> None:
        from persona.search_persona import SearchPersona
        p = SearchPersona()
        self._assert_persona_valid(p, "s5_search")
        self.assertIn("检索", p.core_prompt)
        self.assertIn("搜索", p.core_prompt)
        self.assertIn("S5", p.core_prompt)

    def test_07_chat_persona(self) -> None:
        from persona.chat_persona import ChatPersona
        p = ChatPersona()
        self._assert_persona_valid(p, "s7_chat")
        self.assertIn("聊天", p.core_prompt)
        self.assertIn("六维", p.core_prompt)
        self.assertIn("S7", p.core_prompt)

    def test_08_monitor_persona(self) -> None:
        from persona.monitor_persona import MonitorPersona
        p = MonitorPersona()
        self._assert_persona_valid(p, "s6_monitor")
        self.assertIn("监察", p.core_prompt)
        self.assertIn("评分", p.core_prompt)
        self.assertIn("S6", p.core_prompt)


# ======================================================================
# Test 3: PersonaRegistry
# ======================================================================

class TestPersonaRegistry(unittest.TestCase):
    """测试 PersonaRegistry 注册/注销/查询/持久化。"""

    @classmethod
    def setUpClass(cls) -> None:
        from persona.base import Persona
        cls.Persona = Persona

    def setUp(self) -> None:
        from persona.registry import PersonaRegistry
        self.registry = PersonaRegistry()

    def _make_persona(self, pid: str, name: str, caps: list[str]) -> "Persona":
        return self.Persona(
            persona_id=pid,
            name=name,
            description=f"{name} 的描述",
            capabilities=caps,
            version="1.0.0",
        )

    def test_01_register_new(self) -> None:
        """注册新 Persona 返回 True。"""
        p = self._make_persona("a", "A", ["能力1"])
        self.assertTrue(self.registry.register(p))
        self.assertEqual(self.registry.count(), 1)

    def test_02_register_duplicate(self) -> None:
        """注册重复 ID 返回 False。"""
        p = self._make_persona("a", "A", ["能力1"])
        self.registry.register(p)
        self.assertFalse(self.registry.register(p))
        self.assertEqual(self.registry.count(), 1)

    def test_03_unregister(self) -> None:
        """注销 Persona。"""
        p = self._make_persona("a", "A", ["能力1"])
        self.registry.register(p)
        removed = self.registry.unregister("a")
        self.assertIsNotNone(removed)
        self.assertEqual(self.registry.count(), 0)

    def test_04_unregister_missing(self) -> None:
        """注销不存在的 Persona 返回 None。"""
        self.assertIsNone(self.registry.unregister("nonexistent"))

    def test_05_get_by_id(self) -> None:
        """按 ID 精确查找。"""
        p = self._make_persona("abc", "测试", ["能力1"])
        self.registry.register(p)
        self.assertIsNotNone(self.registry.get("abc"))
        self.assertIsNone(self.registry.get("xyz"))

    def test_06_find_by_name(self) -> None:
        """按名称模糊查找。"""
        self.registry.register(self._make_persona("s1", "软件专员", ["软件"]))
        self.registry.register(self._make_persona("s2", "系统专员", ["系统"]))
        results = self.registry.find_by_name("软件")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].persona_id, "s1")

    def test_07_find_by_capability_intersection(self) -> None:
        """能力标签交集匹配。"""
        self.registry.register(self._make_persona("a", "A", ["软件管理", "安装"]))
        self.registry.register(self._make_persona("b", "B", ["软件管理"]))
        results = self.registry.find_by_capability(["软件管理", "安装"], mode="intersection")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].persona_id, "a")

    def test_08_find_by_capability_union(self) -> None:
        """能力标签并集匹配。"""
        self.registry.register(self._make_persona("a", "A", ["软件管理"]))
        self.registry.register(self._make_persona("b", "B", ["系统运维"]))
        results = self.registry.find_by_capability(["软件管理", "系统运维"], mode="union")
        self.assertEqual(len(results), 2)

    def test_09_find_by_capability_best_match(self) -> None:
        """能力标签最佳匹配。"""
        self.registry.register(self._make_persona("a", "A", ["软件管理", "安装", "卸载", "更新"]))
        self.registry.register(self._make_persona("b", "B", ["软件管理"]))
        results = self.registry.find_by_capability(["软件管理", "安装", "卸载"], mode="best_match")
        self.assertGreaterEqual(len(results), 2)
        self.assertEqual(results[0].persona_id, "a")  # 匹配更多标签排第一

    def test_10_preload_defaults(self) -> None:
        """预加载 8 个默认 Persona。"""
        count = self.registry.preload_defaults()
        self.assertEqual(count, 8)
        self.assertIn("host", self.registry)
        self.assertIn("s1_software", self.registry)
        self.assertIn("s7_chat", self.registry)
        self.assertIn("s6_monitor", self.registry)

    def test_11_stats(self) -> None:
        """统计信息正确。"""
        self.registry.preload_defaults()
        stats = self.registry.stats()
        self.assertEqual(stats["total"], 8)
        self.assertIn("UNINITIALIZED", stats["by_state"])

    def test_12_serialization_roundtrip(self) -> None:
        """Registry 持久化往返。"""
        self.registry.preload_defaults()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8") as f:
            tmp_path = f.name

        try:
            self.registry.save_to_file(tmp_path)
            self.assertTrue(os.path.isfile(tmp_path))

            # 新建 registry 加载
            from persona.registry import PersonaRegistry
            r2 = PersonaRegistry()
            loaded = r2.load_from_file(tmp_path)
            self.assertEqual(loaded, 8)
            self.assertEqual(r2.count(), 8)
        finally:
            os.unlink(tmp_path)


# ======================================================================
# Test 4: PersonaManager 集成
# ======================================================================

class TestPersonaManagerIntegration(unittest.TestCase):
    """测试 PersonaManager 与 PersonaRegistry 集成。"""

    @classmethod
    def setUpClass(cls) -> None:
        from persona.registry import PersonaRegistry
        cls.Registry = PersonaRegistry

    def setUp(self) -> None:
        from persona.manager import PersonaManager
        self.manager = PersonaManager()

    def test_01_registry_disabled_by_default(self) -> None:
        """Registry 默认未启用。"""
        self.assertFalse(self.manager._use_registry)
        self.assertIsNone(self.manager.registry)

    def test_02_enable_registry(self) -> None:
        """启用 Registry 后预加载 8 个 Persona。"""
        reg = self.manager.enable_registry()
        self.assertTrue(self.manager._use_registry)
        self.assertEqual(reg.count(), 8)
        self.assertIsNotNone(self.manager.registry)

    def test_03_registry_syncs_existing_personas(self) -> None:
        """Registry 启用后同步已注册的 v1.0 Persona。"""
        from persona.manager import Persona as OldPersona

        self.manager.register(OldPersona(
            persona_id="custom", name="自定义",
            scope_keywords=["自定义", "专属"],
        ))
        self.manager.enable_registry()
        self.assertIn("custom", self.manager.registry)

    def test_04_match_by_capability_via_manager(self) -> None:
        """通过 Manager 按能力标签匹配。"""
        self.manager.enable_registry()
        results = self.manager.match_by_capability(["文件搜索", "文档问答"])
        self.assertGreater(len(results), 0)
        self.assertTrue(any(p.persona_id == "s4_file" for p in results))

    def test_05_match_by_capability_fallback(self) -> None:
        """Registry 未启用时退回关键词匹配。"""
        from persona.manager import Persona as OldPersona

        self.manager.register(OldPersona(
            persona_id="s4", name="文件专员",
            scope_keywords=["文件", "文档", "搜索"],
        ))
        results = self.manager.match_by_capability(["文件", "搜索"])
        self.assertGreater(len(results), 0)
        self.assertEqual(results[0].persona_id, "s4")

    def test_06_dispatch_uses_registry(self) -> None:
        """调度时 Registry 启用的双路匹配有合理的分数。"""
        self.manager.enable_registry()
        best, score, all_ranks = self.manager.dispatch("帮我找一个PDF文档并转换成Word")
        self.assertIsNotNone(best)
        self.assertGreaterEqual(score.total, 0.0)

    def test_07_dispatch_software_intent(self) -> None:
        """软件安装类意图匹配 S1。"""
        self.manager.enable_registry()
        best, score, _ = self.manager.dispatch("帮我安装Python和VS Code")
        # S1 应该得分最高
        self.assertIn(best.persona_id, ["s1_software", "S1"])

    def test_08_dispatch_system_intent(self) -> None:
        """系统运维类意图匹配 S2。"""
        self.manager.enable_registry()
        best, score, _ = self.manager.dispatch("帮我配置环境变量PATH")
        self.assertIn(best.persona_id, ["s2_system", "S2"])

    def test_09_status_report(self) -> None:
        """状态报告生成正确。"""
        self.manager.enable_registry()
        report = self.manager.status_report()
        self.assertIn("人格", report)
        self.assertIn("激励", report)

    def test_10_v1_backward_compatible(self) -> None:
        """v1.0 API 保持兼容。"""
        from persona.manager import Persona as OldPersona

        self.manager.register(OldPersona(
            persona_id="test", name="测试",
            scope_keywords=["测试"],
        ))
        self.assertIsNotNone(self.manager.get("test"))
        results = self.manager.match("这是一条测试消息")
        self.assertGreater(len(results), 0)
        self.manager.task_started("test")
        self.manager.task_completed("test", success=True)


# ======================================================================
# Test 5: Prompt 完整性
# ======================================================================

class TestPromptIntegrity(unittest.TestCase):
    """验证旧 SKILL.md prompt 内容完整迁移到新 Persona。"""

    def _check_prompt_contains(self, persona, expected_phrases: list[str], label: str) -> None:
        prompt = persona.core_prompt
        for phrase in expected_phrases:
            self.assertIn(phrase, prompt, f"{label} 缺失关键内容: '{phrase}'")

    def test_01_host_prompt(self) -> None:
        from persona.host_persona import HostPersona
        p = HostPersona()
        self._check_prompt_contains(p, [
            "主人格 HOST",
            "五层架构",
            "观察感知",
            "调度决策",
            "融合输出",
            "守护安全",
            "进化学习",
            "STATE-1",
            "STATE-2",
            "STATE-3",
            "STATE-5",
            "S1 软件专员",
            "S7 聊天专员",
            "S6 监察人格",
            "确认流程管理（CFM）",
        ], "host")

    def test_02_software_prompt(self) -> None:
        from persona.software_persona import SoftwarePersona
        p = SoftwarePersona()
        self._check_prompt_contains(p, [
            "软件专员",
            "S1",
            "安装管理",
            "卸载与清理",
            "确认流程转发协议",
            "行为准则",
        ], "software")

    def test_03_system_prompt(self) -> None:
        from persona.system_persona import SystemPersona
        p = SystemPersona()
        self._check_prompt_contains(p, [
            "系统专员",
            "S2",
            "注册表",
            "环境变量",
            "操作前备份",
            "行为准则",
        ], "system")

    def test_04_web_prompt(self) -> None:
        from persona.web_persona import WebPersona
        p = WebPersona()
        self._check_prompt_contains(p, [
            "网络专员",
            "S3",
            "浏览器自动化",
            "合规第一",
            "行为准则",
        ], "web")

    def test_05_file_prompt(self) -> None:
        from persona.file_persona import FilePersona
        p = FilePersona()
        self._check_prompt_contains(p, [
            "文件专员",
            "S4",
            "文档问答",
            "格式转换",
            "行为准则",
        ], "file")

    def test_06_search_prompt(self) -> None:
        from persona.search_persona import SearchPersona
        p = SearchPersona()
        self._check_prompt_contains(p, [
            "检索专员",
            "S5",
            "多源验证",
            "标准引用",
            "行为准则",
        ], "search")

    def test_07_chat_prompt(self) -> None:
        from persona.chat_persona import ChatPersona
        p = ChatPersona()
        self._check_prompt_contains(p, [
            "聊天专员",
            "S7",
            "六维",
            "五维画像",
            "自适应人格调整",
            "智能上下文压缩",
            "成长四阶段",
        ], "chat")

    def test_08_monitor_prompt(self) -> None:
        from persona.monitor_persona import MonitorPersona
        p = MonitorPersona()
        self._check_prompt_contains(p, [
            "独立监察人格",
            "S6",
            "四层评估体系",
            "即时评分",
            "每日简评",
            "每周深评",
            "四维即时评分标准",
            "激励联动规则",
        ], "monitor")


# ======================================================================
# Test 6: Feature Flags
# ======================================================================

class TestFeatureFlags(unittest.TestCase):
    """验证 feature_flags.yaml 包含 USE_NEW_PERSONA_SYSTEM 且默认 false。"""

    def _parse_feature_flags(self) -> dict:
        """纯 Python YAML 解析（无需 yaml 模块）。"""
        ff_path = PROJECT_ROOT / "feature_flags.yaml"
        with open(ff_path, "r", encoding="utf-8") as f:
            content = f.read()

        result: dict = {}
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                # 去除行尾注释
                if "#" in line:
                    hash_pos = line.find("#")
                    if hash_pos > 0:
                        line = line[:hash_pos].strip()
                key, val = line.split(":", 1)
                key = key.strip()
                val = val.strip()
                if val.lower() == "true":
                    result[key] = True
                elif val.lower() == "false":
                    result[key] = False
                elif val.replace("-", "").replace(".", "").isdigit():
                    if "." in val:
                        result[key] = float(val)
                    else:
                        result[key] = int(val)
                else:
                    result[key] = val.replace('"', "").replace("'", "")
        return result

    def test_01_flag_exists(self) -> None:
        ff_path = PROJECT_ROOT / "feature_flags.yaml"
        self.assertTrue(ff_path.is_file(), f"feature_flags.yaml 不存在: {ff_path}")

        with open(ff_path, "r", encoding="utf-8") as f:
            content = f.read()

        self.assertIn("USE_NEW_PERSONA_SYSTEM", content,
                      "feature_flags.yaml 缺少 USE_NEW_PERSONA_SYSTEM")

    def test_02_flag_default_false(self) -> None:
        data = self._parse_feature_flags()
        self.assertIn("USE_NEW_PERSONA_SYSTEM", data)
        self.assertFalse(
            data["USE_NEW_PERSONA_SYSTEM"],
            "USE_NEW_PERSONA_SYSTEM 必须默认 false"
        )

    def test_03_only_version_is_true(self) -> None:
        """除版本号外，所有 feature flag 默认 false。"""
        data = self._parse_feature_flags()
        for key, value in data.items():
            if isinstance(value, bool):
                self.assertFalse(
                    value,
                    f"{key} 必须默认 false，当前为 {value}"
                )


if __name__ == "__main__":
    unittest.main(verbosity=2)
