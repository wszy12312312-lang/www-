# WWW Agent OS

WWW 智能体渐进式迁移项目 — 从单体桌面应用到模块化 Agent OS。
> **迁移状态**: 旧代码已全部合并到新架构，`legacy/` 目录已消除。所有模块统一从新路径导入。
> **迁移方案**: [migration_plan.md](docs/migration_plan.md)  
> **代码审计**: [audit_report_round1.md](docs/audit_report_round1.md)  
> **审计清零**: [audit_closure_report.md](docs/audit_closure_report.md)  
> **架构文档**: [architecture.md](docs/architecture.md)

---

## 目录结构

```
www_agent_os/
├── core/                          # 核心安全模块
│     ├── input_sanitizer.py         #   Prompt 注入过滤：(C02 修复)
│     └── __init__.py
│   ├── persona/                       # Persona 人格体系
│     ├── base.py                    #   Persona 基类 + 状态机
│     ├── manager.py                 #   PersonaManager (五维评分调度)
│     ├── registry.py                #   PersonaRegistry (动态注册)
│     ├── host_persona.py            #   主人格 Marvis
│     ├── software_persona.py        #   软件专员
│     ├── system_persona.py          #   系统专员
│     ├── web_persona.py             #   网络专员
│     ├── file_persona.py            #   文件专员
│     ├── search_persona.py          #   检索专员  ├── chat_persona.py            #   聊天专员
│     ├── monitor_persona.py         #   独立监察
│     └── __init__.py
│   ├── events/                        # 事件总线
│     ├── bus.py                     #   EventBus (24 种事件类型
│     └── __init__.py
│   ├── task/                          # 任务管理
│     ├── manager.py                 #   TaskManager (5 状态流转
│     └── __init__.py
│   ├── tools/                         # 工具路由
│     ├── router.py                  #   ToolRouter (注册/路由/参数验证)
│     └── __init__.py
│   ├── models/                        # 模型网关
│     ├── gateway.py                 #   ModelGateway (Ollama + 认证)
│     └── __init__.py
│   ├── memory/                        # 记忆存储
│     ├── store.py                   #   MemoryStore (短期+长期)
│     └── __init__.py
│   ├── runtime/                       # 运行时入口
│   │   ├── host.py                    #   HostEntry (Feature Flag 控制 + 健康检查)
│     └── __init__.py
│   ├── config/                        # 配置
│     ├── sanitizer_rules.yaml       #   输入过滤规则
│     ├── app_config.py              #   应用配置（从旧 config.py 迁移）
│     └── __init__.py
│   ├── scripts/                       # 工具脚本
│     ├── migrate_memory.py          #   旧记忆 → MemoryStore 迁移
│     ├── migrate_prompts.py         #   SKILL.md → Persona prompt 迁移
│     └── rollback.py                #   按阶段回滚 Feature Flag
│   ├── tests/                         # 测试
│     ├── test_stage2.py             #   Stage 2: InputSanitizer + Host (46 cases)
│     ├── test_stage3.py             #   Stage 3: Persona 体系 (51 cases)
│     ├── test_stage4.py             #   Stage 4: 核心模块闭环 (62 cases)
│     └── test_stage5.py             #   Stage 5: 迁移与收尾
│   ├── docs/                          # 文档
│     ├── migration_plan.md          #   五阶段迁移方案
│     ├── audit_report_round1.md     #   第一轮代码审计报告
│     ├── audit_closure_report.md    #   审计清零报告
│     └── architecture.md            #   架构设计文档
│   ├── data/                          # 运行时数据
│   │   ├── skills/                    #   技能描述文件（8 个 Agent）
│     ├── memory/                    #   新记忆存储
│   │   └── persona_prompts/           #   提取的 prompt 文件
│   ├── api/                           # API 层（预留）
│   │   └── routes/
│   ├── app/                           # 应用入口（预留）
│   ├── database/                      # 数据库层（预留）
│     ├── repositories/
│     └── vector_store/
│   ├── requirements/                  # 依赖管理
│     ├── base.txt
│     └── dev.txt
│   ├── services/                      # 服务层
│   │   └── ollama_service.py          #   Ollama 服务封装（原 www_core.py）
│   ├── ui/                            # UI 组件
│   │   └── legacy_gui.py              #   桌面 GUI（原 main.py）
│   ├── feature_flags.yaml             # 全局 Feature Flag 开关
├── README.md                      # 本文档
└── .gitignore
```

---

## 安装指南

项目根目录提供了**一键下载安装脚本**，只需运行一个批处理文件即可完成全部环境配置。

### 下载脚本：`下载-WWW_Agent_OS.bat`

双击运行后显示四档配置菜单，按需选择：

| 配置 | 适用硬件 | 模型组合 | 磁盘占用 |
|------|---------|---------|---------|
| **低配** | 8GB RAM，无独显 | Qwen2.5-1.5B + StarCoder2-3B + BGE-small | ~5GB |
| **中配** | 16GB RAM，6GB+ VRAM | Qwen2.5-7B + DeepSeek-Coder-V2-Lite + BGE-M3 | ~15GB |
| **高配** | 32GB+ RAM，16GB+ VRAM | Qwen2.5-32B + DeepSeek-R1-32B + DeepSeek-Coder-V2 + BGE-M3 | ~50GB |
| **自定义** | 自行指定 | 交互式选择模型来源、名称、参数量、量化方式 | 视选择而定 |

脚本自动完成以下工作：
- 检测并配置 Python 环境（自动跳过 WindowsApps 存根）
- 安装项目 Python 依赖
- 检测 / 自动安装 Ollama（低配中配必需，高配优选）
- 下载对应配置的大模型（下载失败自动重试一次）
- 生成 `model_config.json` 配置文件
- 运行 `python runtime/host.py --version` 验证安装

> **提示**：安装前请确认磁盘有足够空间。Ollama 模型文件默认存储在 `C:\Users\<用户名>\.ollama\`。

### 卸载脚本：`卸载-WWW_Agent_OS.bat`

如需完全移除，双击运行卸载脚本，将清理：

- 程序本体（`www_agent_os\` 目录）
- 模型文件与配置
- 桌面快捷方式
- 可选：卸载 Ollama
- 可选：清理 pip 缓存

> **注意**：卸载操作不可逆，运行前请确认已备份重要数据。

---

## 快速开始
### 一键启动（推荐）
项目根目录提供了启动脚本，双击即可运行：

| 启动方式 | 文件 | 说明 |
|---------|------|------|
| **桌面快捷方式** | `WWW Agent OS` (桌面) | 双击桌面图标一键启动|
| **命令行窗口** | `start_www_agent.bat` | 带控制台窗口，可查看启动日志 |
| **后台静默** | `start_www_agent.vbs` | 无窗口后台运行，不弹黑窗 |

**bat 脚本功能**：
- 自动检测 Python 路径（`C:\Python311` ：`C:\Python312` ：系统 PATH）- 启动新架构 `runtime/host.py`
- 窗口保持打开以便查看输出

**vbs 脚本功能**：
- 使用 `pythonw.exe` 无窗口启动
- 适合设置为开机自启或后台常驻

### 运行测试
编辑 `feature_flags.yaml`，按需开启：

```yaml
# 渐进式启用（从低阶段开始）
USE_NEW_ARCH: false           # 全量开关
USE_NEW_HOST: false           # 新 HOST 调度
USE_INPUT_SANITIZER: false    # Prompt 注入防护
USE_PERSONA_MANAGER: false    # 五维评分调度
USE_EVENT_BUS: false          # 事件总线
USE_TASK_MANAGER: false       # 任务管理
USE_TOOL_ROUTER: false        # 工具路由
USE_MODEL_GATEWAY: false      # 模型网关（含认证）USE_MEMORY_STORE: false       # 统一记忆存储
```

### 运行测试

```bash
# 全部测试
python -m pytest tests/ -v

# 按阶段python -m pytest tests/test_stage2.py -v
python -m pytest tests/test_stage3.py -v
python -m pytest tests/test_stage4.py -v
python -m pytest tests/test_stage5.py -v
```

### 数据迁移

```bash
# 试运行（预览迁移计划）python scripts/migrate_memory.py

# 实际执行
python scripts/migrate_memory.py --execute

# Prompt 迁移报告
python scripts/migrate_prompts.py
```

### 回滚

```bash
# 查看当前状态python scripts/rollback.py --status

# 预览回滚到 Stage 3
python scripts/rollback.py --preview --stage 3

# 执行回滚
python scripts/rollback.py --stage 3

# 全量回滚到旧系统
python scripts/rollback.py --full
```

---

## Feature Flag 使用说明

### 开关层级
`feature_flags.yaml` 中的 Flag 按四个层级组织：

| 层级 | Flag | 说明 |
|------|------|------|
| **全量** | `USE_NEW_ARCH` | 开启后等同于所有模块 Flag 全开 |
| **链路** | `USE_NEW_HOST` | 控制新 HOST 入口 + 与 `www_core.py` 的切换|
| **子系统* | `USE_NEW_PERSONA / USE_PERSONA_MANAGER / USE_NEW_PERSONA_SYSTEM` | 控制 Persona 调度链路 |
| **模块** | `USE_EVENT_BUS / USE_TASK_MANAGER / USE_TOOL_ROUTER / USE_MODEL_GATEWAY / USE_MEMORY_STORE` | 各模块独立开：|

### 运行原理

每个模块的启用受其自身 Flag 和父级 Flag 的**逻辑与**控制。
```python
@property
def use_model_gateway(self) -> bool:
    return bool(
        self._flags.get("USE_MODEL_GATEWAY", False)
        or self._flags.get("USE_NEW_ARCH", False)
    )
```

### 健康检查与自动回退

`runtime/host.py` 内置 `HealthChecker`：- 新模块异常时自动回退到旧链路
- 连续失败 3 次后标记不健康，进入 300s 冷却期。
- 冷却期结束后自动尝试恢复
- 所有切换事件记录到 `logs/switch/switch_log.jsonl`

---

## 新旧系统切换指南

### 切换策略

```
Stage 0 (旧系统)          Stage 5 (全量新架构
     │                         │
     ├─ USE_INPUT_SANITIZER     ├─ USE_EVENT_BUS
     ├─ USE_NEW_HOST            ├─ USE_TASK_MANAGER
     ├─ USE_PERSONA_MANAGER     ├─ USE_TOOL_ROUTER
     │                            ├─ USE_MODEL_GATEWAY
     │                            └─ USE_MEMORY_STORE
```

### 推荐启用顺序

1. **Stage 2**: `USE_INPUT_SANITIZER` ：在旧链路上增加安全层
2. **Stage 3**: `USE_NEW_HOST` + `USE_PERSONA_MANAGER` ：替换调度逻辑
3. **Stage 4**: 按需逐个开启模块 Flag，渐进替换执行层4. **验证**: 运行对应阶段测试确认无误后继续。
### 紧急回滚
```bash
python scripts/rollback.py --full     # 一键全量回滚python scripts/rollback.py --stage N  # 回滚到指定阶：```

回滚仅修：`feature_flags.yaml`，不删除新代码。
---

## 开发指南
### 项目约定

- Python 3.10+
- 标准库优先，第三方依赖最小化
- 所有公开 API 有类型注解和 docstring
- 新模块通过 Feature Flag 控制，默：`false`

### 添加新模块
1. ：`feature_flags.yaml` 中添：`USE_NEW_FEATURE: false`
2. ：`runtime/host.py` 中添加对应的 Flag getter property
3. 在 `runtime/host.py` 的 `TRACKED_MODULES` 中注册健康检查
4. 实现 `process()` 中的集成逻辑（配合 `_healthy_wrapper`）
5. 编写 `tests/test_stageN.py` 中的测试

### 代码审计与合规
- 审计报告: `docs/audit_report_round1.md` (14 项发现
- 清零报告: `docs/audit_closure_report.md` (7 已修复 / 7 不适用 / 0 待修复
- 审计状态：**全部适用项已清零**

---

## 安全说明

- 旧版记忆数据已迁移至 `data/memory/`，新系统独立读写
- 用户输入经过 `InputSanitizer` 过滤后才进入调度链- ModelGateway 支持 API 认证（Bearer / Basic Auth）- 错误详情仅记录在内部日志，不暴露给终端用户- 所有破坏性操作（删除、覆盖）走确认流程
## 许可证
内部项目。