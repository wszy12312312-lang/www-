# core / memory package
