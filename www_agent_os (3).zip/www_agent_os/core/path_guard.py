"""
路径遍历防护工具 — 修复 H03：技能删除/文件操作无路径遍历校验。

提供路径安全校验函数，确保文件操作（删除、移动、读写）不会越出
指定的安全根目录。适用于技能管理、文件整理等需要防护路径遍历攻击的场景。

用法:
    from core.path_guard import PathGuard

    guard = PathGuard(allowed_root="/path/to/skills")

    # 校验单个路径
    safe_path = guard.validate("/path/to/skills/subdir/skill1")

    # 批量校验
    safe_paths = guard.validate_batch([
        "/path/to/skills/skill1",
        "/path/to/skills/skill2",
    ])

    # 快速检查（返回 bool）
    is_safe = guard.is_safe("/path/to/skills/subdir")

防护机制:
    - 符号链接解析：使用 os.path.realpath() 解析所有符号链接后再判断
    - 大小写规范化：Windows 上使用 os.path.normcase() 统一大小写
    - 白名单校验：仅允许字母、数字、连字符、下划线、点、路径分隔符
    - 空白目录名拒绝：路径组件含纯空白字符拒绝访问
"""

import os
import re
from typing import List, Optional, Set


class PathTraversalError(ValueError):
    """路径遍历攻击检测异常。"""

    def __init__(self, path: str, reason: str):
        self.path = path
        self.reason = reason
        super().__init__(f"路径遍历拒绝: {path} — {reason}")


class PathGuard:
    """路径遍历防护器。

    Parameters
    ----------
    allowed_root : str
        允许操作的安全根目录（绝对路径）。
    allow_symlinks_outside : bool
        是否允许符号链接指向根目录外（默认 False——拒绝外部链接）。
    """

    # 白名单：目录名/文件名允许的字符
    _NAME_WHITELIST = re.compile(r'^[a-zA-Z0-9_\-.]+$')

    # 禁止作为路径组件名的模式
    _FORBIDDEN_NAMES: Set[str] = {'.', '..', ''}

    def __init__(self, allowed_root: str, allow_symlinks_outside: bool = False):
        self._allowed_root = os.path.realpath(os.path.abspath(allowed_root))
        self._allow_symlinks_outside = allow_symlinks_outside

        # Windows 大小写规范化
        if os.name == 'nt':
            self._allowed_root = os.path.normcase(self._allowed_root)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def is_safe(self, path: str) -> bool:
        """快速检查路径是否安全（不抛异常）。"""
        try:
            self.validate(path)
            return True
        except PathTraversalError:
            return False

    def validate(self, path: str) -> str:
        """校验单个路径，通过则返回规范化后的绝对路径。

        Raises
        ------
        PathTraversalError
            路径不安全时抛出
        """
        if not path or not isinstance(path, str):
            raise PathTraversalError(str(path) if path else "<empty>",
                                     "路径为空或非字符串")

        # 1. 解析为绝对路径
        abs_path = os.path.abspath(path)
        real_path = os.path.realpath(abs_path)

        # 2. Windows 大小写规范化
        if os.name == 'nt':
            real_path = os.path.normcase(real_path)

        # 3. 检查路径是否在允许的根目录内
        if not self._is_within_root(real_path):
            raise PathTraversalError(
                path,
                f"路径不在允许范围内 (root={self._allowed_root})"
            )

        # 4. 检查路径组件名是否合规
        self._validate_path_components(real_path)

        # 5. 符号链接检查
        if not self._allow_symlinks_outside:
            if os.path.islink(abs_path):
                link_target = os.readlink(abs_path)
                real_target = os.path.realpath(
                    os.path.join(os.path.dirname(abs_path), link_target)
                )
                if not self._is_within_root(real_target):
                    raise PathTraversalError(
                        path,
                        f"符号链接目标在允许范围外: {link_target}"
                    )

        return real_path

    def validate_batch(self, paths: List[str]) -> List[str]:
        """批量校验路径，任一失败则全部拒绝。

        Raises
        ------
        PathTraversalError
            任一路径不安全时抛出
        """
        validated = []
        for p in paths:
            validated.append(self.validate(p))
        return validated

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _is_within_root(self, path: str) -> bool:
        """判断路径是否在 allowed_root 子树内。"""
        sep = os.sep
        return path == self._allowed_root or path.startswith(self._allowed_root + sep)

    def _validate_path_components(self, path: str) -> None:
        """递归校验每个路径组件。

        拒绝:
        - 空组件名
        - 纯空白组件名
        - 包含非白名单字符的组件名
        """
        # 从 allowed_root 之后开始检查（自身路径不限制）
        rel = os.path.relpath(path, self._allowed_root)
        if rel == '.':
            return  # 就是根目录本身

        parts = rel.split(os.sep)
        for part in parts:
            if part in self._FORBIDDEN_NAMES:
                # '.' / '..' 已被 realpath 规范化，这里作为最后防线
                continue

            if not part.strip():
                raise PathTraversalError(
                    path,
                    f"路径组件包含空白名称: '{part}'"
                )

            if not self._NAME_WHITELIST.match(part):
                raise PathTraversalError(
                    path,
                    f"路径组件含非法字符: '{part}'"
                )


# ---------------------------------------------------------------------------
# 便捷函数（无状态、无实例化）
# ---------------------------------------------------------------------------

def is_safe_path(path: str, allowed_root: str,
                 allow_symlinks_outside: bool = False) -> bool:
    """便捷函数：快速检查路径是否在允许范围内。"""
    return PathGuard(allowed_root, allow_symlinks_outside).is_safe(path)


def validate_path(path: str, allowed_root: str,
                  allow_symlinks_outside: bool = False) -> str:
    """便捷函数：校验路径，通过则返回规范化绝对路径。"""
    return PathGuard(allowed_root, allow_symlinks_outside).validate(path)
