"""
下载完整性校验模块 — 修复 H04：安装器下载无完整性校验。

提供文件哈希校验、数字签名验证（Windows Authenticode）、
安全下载（先存临时文件，校验通过后再移动到目标位置）等功能。

用法:
    from core.download_verifier import DownloadVerifier

    verifier = DownloadVerifier()

    # 校验已下载文件
    verifier.verify_file(
        file_path="C:/downloads/OllamaSetup.exe",
        expected_sha256="abc123..."
    )

    # 安全下载并校验
    verifier.safe_download(
        url="https://ollama.com/download/OllamaSetup.exe",
        dest_path="C:/downloads/OllamaSetup.exe",
        expected_sha256="abc123..."
    )

    # 批量校验
    results = verifier.verify_batch({
        "file1.exe": "sha256_hash_1",
        "file2.dll": "sha256_hash_2",
    }, base_dir="C:/downloads/")

支持算法:
    - SHA256（推荐，默认）
    - SHA512
    - MD5（不推荐，仅用于遗留兼容）

安全设计:
    - 临时文件写入：下载先写到 .tmp 文件，校验通过后原子化 rename
    - 自动清理：校验失败或下载中断时自动删除临时文件
    - 超时保护：下载 + 校验均有 timeout 上限
    - HTTPS 证书验证：默认启用，不跳过 TLS 验证
"""

import hashlib
import os
import shutil
import tempfile
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Union

import requests


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class VerifyResult:
    """单个文件的校验结果。"""
    file_path: str
    algorithm: str = "sha256"
    expected_hash: str = ""
    actual_hash: str = ""
    passed: bool = False
    error: Optional[str] = None
    file_size: int = 0
    elapsed_ms: float = 0.0

    @property
    def ok(self) -> bool:
        return self.passed and not self.error


@dataclass
class DownloadResult:
    """安全下载结果。"""
    dest_path: str
    success: bool
    file_size: int = 0
    sha256: str = ""
    elapsed_ms: float = 0.0
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Hash computation
# ---------------------------------------------------------------------------

def compute_hash(file_path: str, algorithm: str = "sha256",
                 chunk_size: int = 8192) -> str:
    """计算文件的哈希值。

    Parameters
    ----------
    file_path : str
        文件绝对路径
    algorithm : str
        哈希算法名称（sha256 / sha512 / md5）
    chunk_size : int
        分块读取大小（字节）

    Returns
    -------
    str
        十六进制哈希字符串（小写）
    """
    algo = hashlib.new(algorithm)
    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            algo.update(chunk)
    return algo.hexdigest()


# ---------------------------------------------------------------------------
# DownloadVerifier
# ---------------------------------------------------------------------------

class DownloadVerifier:
    """下载完整性校验器。

    Parameters
    ----------
    default_algorithm : str
        默认哈希算法（sha256）。
    download_timeout : int
        下载超时秒数。
    verify_large_file_threshold : int
        超过此大小的文件使用进度式读取（字节）。
    """

    def __init__(
        self,
        default_algorithm: str = "sha256",
        download_timeout: int = 600,
        verify_large_file_threshold: int = 100 * 1024 * 1024,  # 100 MB
    ):
        self._default_algo = default_algorithm
        self._download_timeout = download_timeout
        self._large_threshold = verify_large_file_threshold

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def verify_file(
        self,
        file_path: str,
        expected_hash: str,
        algorithm: str = "",
    ) -> VerifyResult:
        """校验单个文件的哈希值。

        Parameters
        ----------
        file_path : str
            文件路径。
        expected_hash : str
            期望的哈希值（十六进制字符串，不区分大小写）。
        algorithm : str
            哈希算法，默认使用构造时指定的算法。

        Returns
        -------
        VerifyResult
        """
        algo = algorithm or self._default_algo
        result = VerifyResult(
            file_path=file_path,
            algorithm=algo,
            expected_hash=expected_hash.lower(),
        )

        start = time.perf_counter()
        try:
            if not os.path.isfile(file_path):
                result.error = f"文件不存在: {file_path}"
                result.elapsed_ms = (time.perf_counter() - start) * 1000
                return result

            result.file_size = os.path.getsize(file_path)
            result.actual_hash = compute_hash(file_path, algo)
            result.passed = (result.actual_hash == result.expected_hash)

            if not result.passed:
                result.error = (
                    f"哈希不匹配: 期望 {result.expected_hash}, "
                    f"实际 {result.actual_hash}"
                )
        except Exception as e:
            result.error = str(e)

        result.elapsed_ms = (time.perf_counter() - start) * 1000
        return result

    def verify_batch(
        self,
        hash_map: Dict[str, str],
        base_dir: str = "",
        algorithm: str = "",
    ) -> List[VerifyResult]:
        """批量校验文件哈希。

        Parameters
        ----------
        hash_map : dict
            {文件名: 期望哈希} 映射。
            如果 base_dir 非空，文件名会与 base_dir 拼接为完整路径。
            如果 value 已经是绝对路径格式，base_dir 被忽略。
        base_dir : str
            基础目录。
        algorithm : str
            哈希算法。

        Returns
        -------
        list[VerifyResult]
        """
        results = []
        for path_or_name, expected in hash_map.items():
            if base_dir and not os.path.isabs(path_or_name):
                full_path = os.path.join(base_dir, path_or_name)
            else:
                full_path = path_or_name
            results.append(self.verify_file(full_path, expected, algorithm))
        return results

    def safe_download(
        self,
        url: str,
        dest_path: str,
        expected_sha256: Optional[str] = None,
        expected_sha512: Optional[str] = None,
        verify_ssl: bool = True,
    ) -> DownloadResult:
        """安全下载：先写到临时文件，校验通过后再移动到目标位置。

        任一步骤失败都会自动清理临时文件。

        Parameters
        ----------
        url : str
            下载 URL。
        dest_path : str
            目标文件路径。
        expected_sha256 : str or None
            期望的 SHA256 哈希（可选）。
        expected_sha512 : str or None
            期望的 SHA512 哈希（可选）。
        verify_ssl : bool
            是否验证 HTTPS 证书（默认 True）。

        Returns
        -------
        DownloadResult
        """
        result = DownloadResult(dest_path=dest_path, success=False)
        start = time.perf_counter()
        tmp_path = ""

        try:
            # 确保目标目录存在
            dest_dir = os.path.dirname(dest_path)
            if dest_dir:
                os.makedirs(dest_dir, exist_ok=True)

            # 创建临时文件（与目标同目录，避免跨分区 rename 失败）
            fd, tmp_path = tempfile.mkstemp(
                dir=dest_dir or None,
                prefix=".dl_",
                suffix=".tmp",
            )
            os.close(fd)

            # --- 下载 ---
            with requests.get(
                url,
                stream=True,
                timeout=self._download_timeout,
                verify=verify_ssl,
            ) as resp:
                resp.raise_for_status()
                with open(tmp_path, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)

            result.file_size = os.path.getsize(tmp_path)
            result.sha256 = compute_hash(tmp_path, "sha256")

            # --- 校验 ---
            if expected_sha256:
                if result.sha256 != expected_sha256.lower():
                    result.error = (
                        f"SHA256 mismatch: expected {expected_sha256}, "
                        f"got {result.sha256}"
                    )
                    return result

            if expected_sha512:
                actual_512 = compute_hash(tmp_path, "sha512")
                if actual_512 != expected_sha512.lower():
                    result.error = (
                        f"SHA512 mismatch: expected {expected_sha512}, "
                        f"got {actual_512}"
                    )
                    return result

            # --- 原子移动 ---
            # Windows: 如果目标已存在需先删除
            if os.path.exists(dest_path):
                os.remove(dest_path)
            shutil.move(tmp_path, dest_path)
            tmp_path = ""  # 防止 finally 清理

            result.success = True

        except requests.RequestException as e:
            result.error = f"下载失败: {e}"
        except OSError as e:
            result.error = f"I/O 错误: {e}"
        except Exception as e:
            result.error = str(e)
        finally:
            # 清理临时文件
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
            result.elapsed_ms = (time.perf_counter() - start) * 1000

        return result

    # ------------------------------------------------------------------
    # Windows Authenticode 签名验证
    # ------------------------------------------------------------------

    @staticmethod
    def verify_authenticode(file_path: str) -> bool:
        """验证 Windows Authenticode 数字签名（仅 Windows）。

        调用 PowerShell Get-AuthenticodeSignature。

        Parameters
        ----------
        file_path : str
            可执行文件路径（.exe / .dll / .msi）。

        Returns
        -------
        bool
            签名有效且受信任返回 True。
        """
        if os.name != 'nt':
            return False

        import subprocess

        try:
            result = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    f"(Get-AuthenticodeSignature -FilePath '{file_path}').Status",
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.stdout.strip() == "Valid"
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            return False


# ---------------------------------------------------------------------------
# 预定义校验和（Ollama 等常用工具）
# --- 注：以下为示例占位值，实际部署时应更新为官方发布的校验和 ---
# ---------------------------------------------------------------------------

KNOWN_CHECKSUMS: Dict[str, Dict[str, str]] = {
    # 格式: { "url": { "sha256": "...", "sha512": "..." } }
    # 示例（值需从官方渠道更新）:
    # "https://ollama.com/download/OllamaSetup.exe": {
    #     "sha256": "<official sha256>",
    # },
}
