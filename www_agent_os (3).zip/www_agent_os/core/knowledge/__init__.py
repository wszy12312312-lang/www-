# core / knowledge package
