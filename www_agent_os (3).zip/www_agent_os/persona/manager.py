"""
PersonaManager — 人格管理器 v2.0（第三阶段升级）

功能：
- 注册 Persona（集成 PersonaRegistry）
- 五维评分匹配算法（基于能力标签 + 关键词双路匹配）
- 任务调度与路由
- 保留旧 host_dispatch 的核心路由能力

五维评分：
1. 意图匹配度（Intent Match）— 用户意图与 Persona 能力的语义匹配
2. 历史成功率（Historical Success）— 该 Persona 历史任务成功率
3. 负载均衡（Load Balance）— 当前任务队列长短
4. 响应时效（Response Freshness）— 最近一次响应距今时间
5. 用户偏好（User Preference）— 用户明确指定的偏好权重

v2.0 变更：
- 集成 PersonaRegistry 支持按能力标签匹配
- 双路匹配：关键词映射 + 能力标签语义匹配
- 兼容旧 Persona 数据类，提供 to_base_persona() 转换

依赖最小化：Python 3.10+ 标准库
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from persona.base import Persona as BasePersona
from persona.base import PersonaState
from persona.registry import PersonaRegistry

logger = logging.getLogger("PersonaManager")


# ------------------------------------------------------------------
# 旧 Persona 数据类（向后兼容第二阶段）
# ------------------------------------------------------------------

@dataclass
class Persona:
    """
    Persona 定义 — 从旧 PERSONA_MAP 迁移而来（v1.0 兼容）。

    包含：身份、能力、记忆、版本、生命周期。
    v2.0：可转换为 BasePersona 以使用新状态机和能力标签系统。
    """

    persona_id: str
    """唯一标识符，如 'host', 'S1'。"""

    name: str
    """显示名称，如 '指挥者', '软件专员'。"""

    icon: str = "?"
    """显示图标缩写。"""

    color: str = "#3b82f6"
    """主题色。"""

    role: str = ""
    """角色描述，一句话概括职责。"""

    scope_keywords: list[str] = field(default_factory=list)
    """能力范围关键词列表，用于意图匹配。"""

    model: str = ""
    """绑定的模型名称。"""

    version: str = "1.0.0"
    """Persona 版本号。"""

    status: str = "active"
    """生命周期状态：active / inactive / archived。"""

    # 运行时统计（从旧 PersonaState 迁移）
    task_count: int = 0
    task_score: float = 0.0
    incentive_stars: int = 3
    penalty_stars: int = 0
    last_task_time: float = 0.0
    success_count: int = 0
    failure_count: int = 0

    @property
    def net_incentive(self) -> int:
        """净激励值。"""
        return self.incentive_stars - self.penalty_stars

    @property
    def success_rate(self) -> float:
        """历史成功率 (0.0 ~ 1.0)。"""
        total = self.success_count + self.failure_count
        if total == 0:
            return 1.0
        return self.success_count / total

    @property
    def idle_seconds(self) -> float:
        """距上次任务的空闲秒数。"""
        if self.last_task_time == 0:
            return float("inf")
        return time.time() - self.last_task_time

    def to_dict(self) -> dict:
        """序列化为字典。"""
        return {
            "persona_id": self.persona_id,
            "name": self.name,
            "icon": self.icon,
            "color": self.color,
            "role": self.role,
            "scope_keywords": self.scope_keywords,
            "model": self.model,
            "version": self.version,
            "status": self.status,
            "task_count": self.task_count,
            "task_score": self.task_score,
            "incentive_stars": self.incentive_stars,
            "penalty_stars": self.penalty_stars,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Persona:
        """从字典反序列化。"""
        return cls(
            persona_id=data["persona_id"],
            name=data.get("name", ""),
            icon=data.get("icon", "?"),
            color=data.get("color", "#3b82f6"),
            role=data.get("role", ""),
            scope_keywords=data.get("scope_keywords", []),
            model=data.get("model", ""),
            version=data.get("version", "1.0.0"),
            status=data.get("status", "active"),
            task_count=data.get("task_count", 0),
            task_score=data.get("task_score", 0.0),
            incentive_stars=data.get("incentive_stars", 3),
            penalty_stars=data.get("penalty_stars", 0),
            success_count=data.get("success_count", 0),
            failure_count=data.get("failure_count", 0),
        )

    def to_base_persona(self) -> BasePersona:
        """转换为新版 BasePersona（第三阶段 v2.0 能力标签系统）。

        Returns:
            BasePersona 实例，保留所有统计数据。
        """
        base = BasePersona(
            persona_id=self.persona_id,
            name=self.name,
            description=self.role,
            capabilities=self.scope_keywords,
            version=self.version,
            state=PersonaState.UNINITIALIZED,
            icon=self.icon,
            color=self.color,
            model=self.model,
            scope_keywords=self.scope_keywords,
            task_count=self.task_count,
            task_score=self.task_score,
            incentive_stars=self.incentive_stars,
            penalty_stars=self.penalty_stars,
            last_task_time=self.last_task_time,
            success_count=self.success_count,
            failure_count=self.failure_count,
        )
        return base


# ------------------------------------------------------------------
# 五维评分算法
# ------------------------------------------------------------------

@dataclass
class MatchScore:
    """五维评分的单项得分。"""

    intent_match: float = 0.0        # 权重 0.40
    historical_success: float = 0.0  # 权重 0.25
    load_balance: float = 0.0        # 权重 0.15
    response_freshness: float = 0.0  # 权重 0.10
    user_preference: float = 0.0     # 权重 0.10

    @property
    def total(self) -> float:
        """加权总分。"""
        return (
            self.intent_match * 0.40
            + self.historical_success * 0.25
            + self.load_balance * 0.15
            + self.response_freshness * 0.10
            + self.user_preference * 0.10
        )

    def to_dict(self) -> dict:
        return {
            "intent_match": round(self.intent_match, 3),
            "historical_success": round(self.historical_success, 3),
            "load_balance": round(self.load_balance, 3),
            "response_freshness": round(self.response_freshness, 3),
            "user_preference": round(self.user_preference, 3),
            "total": round(self.total, 3),
        }


# ------------------------------------------------------------------
# PersonaManager
# ------------------------------------------------------------------

# 旧版调度映射表（从 host SKILL.md 提取，保留核心路由能力）
_LEGACY_DISPATCH_MAP: dict[str, str] = {
    # 场景关键词 → persona_id
    "软件": "S1",
    "安装": "S1",
    "卸载": "S1",
    "应用": "S1",
    "APK": "S1",
    "EXE": "S1",
    "打开": "S1",
    "系统": "S2",
    "配置": "S2",
    "运维": "S2",
    "代码": "S2",
    "编程": "S2",
    "环境": "S2",
    "注册表": "S2",
    "网络": "S3",
    "网页": "S3",
    "爬虫": "S3",
    "浏览器": "S3",
    "抓取": "S3",
    "文件": "S4",
    "文档": "S4",
    "整理": "S4",
    "转换": "S4",
    "Excel": "S4",
    "PPT": "S4",
    "Word": "S4",
    "PDF": "S4",
    "搜索": "S5",
    "检索": "S5",
    "查": "S5",
    "找": "S5",
    "资料": "S5",
    "信息": "S5",
    "聊天": "S6",
    "闲聊": "S6",
    "倾诉": "S6",
    "日常": "S6",
    "对话": "S6",
}


# 旧 ID → 新 Persona ID 映射
_LEGACY_TO_NEW_ID_MAP: dict[str, str] = {
    "host": "host",
    "S1": "s1_software",
    "S2": "s2_system",
    "S3": "s3_web",
    "S4": "s4_file",
    "S5": "s5_search",
    "S6": "s6_monitor",
    "S7": "s7_chat",
}


class PersonaManager:
    """
    Persona 管理器 v2.0。

    负责:
    - Persona 注册与生命周期管理
    - 五维评分匹配（关键词 + 能力标签双路匹配）
    - 任务调度路由
    - 集成 PersonaRegistry 实现按能力标签查询
    """

    # 维度权重
    WEIGHT_INTENT = 0.40
    WEIGHT_HISTORICAL = 0.25
    WEIGHT_LOAD = 0.15
    WEIGHT_FRESHNESS = 0.10
    WEIGHT_PREFERENCE = 0.10

    def __init__(self, project_root: Optional[str] = None):
        """
        Args:
            project_root: 项目根目录。
        """
        self._personas: dict[str, Persona] = {}
        self._pending_tasks: dict[str, int] = {}  # persona_id → 排队任务数
        self._project_root = project_root or self._infer_project_root()
        self._registry: Optional[PersonaRegistry] = None
        self._use_registry = False

    @staticmethod
    def _infer_project_root() -> str:
        return str(Path(__file__).resolve().parent.parent)

    # ------------------------------------------------------------------
    # 注册（v1.0 兼容 + v2.0 Registry 集成）
    # ------------------------------------------------------------------

    def register(self, persona: Persona) -> None:
        """注册一个 Persona（v1.0 数据类或 v2.0 BasePersona）。

        同时同步到 PersonaRegistry。
        """
        self._personas[persona.persona_id] = persona
        if persona.persona_id not in self._pending_tasks:
            self._pending_tasks[persona.persona_id] = 0

        # 同步到 Registry
        if self._use_registry and self._registry is not None:
            if isinstance(persona, BasePersona):
                self._registry.register(persona)
            else:
                self._registry.register(persona.to_base_persona())

        logger.info("注册 Persona: %s (%s)", persona.persona_id, persona.name)

    def register_many(self, personas: list[Persona]) -> None:
        """批量注册 Persona。"""
        for p in personas:
            self.register(p)

    def unregister(self, persona_id: str) -> Optional[Persona]:
        """注销 Persona。"""
        persona = self._personas.pop(persona_id, None)
        if self._use_registry and self._registry is not None:
            self._registry.unregister(persona_id)
        return persona

    def get(self, persona_id: str) -> Optional[Persona]:
        """按 ID 获取 Persona。"""
        return self._personas.get(persona_id)

    def list_active(self) -> list[Persona]:
        """列出所有活跃 Persona。"""
        return [p for p in self._personas.values() if p.status == "active"]

    def list_all(self) -> list[Persona]:
        """列出所有 Persona（含非活跃）。"""
        return list(self._personas.values())

    # ------------------------------------------------------------------
    # v2.0：PersonaRegistry 集成
    # ------------------------------------------------------------------

    def enable_registry(self, registry: Optional[PersonaRegistry] = None) -> PersonaRegistry:
        """启用 PersonaRegistry 支持。

        Args:
            registry: 外部创建的 PersonaRegistry。不传则自动创建并预加载默认 Persona。

        Returns:
            PersonaRegistry 实例。
        """
        if registry is not None:
            self._registry = registry
        else:
            self._registry = PersonaRegistry()
            self._registry.preload_defaults()
        self._use_registry = True

        # 双向同步：Registry → v1 Persona 映射
        for bp in self._registry:
            pid = bp.persona_id
            if pid not in self._personas:
                v1 = Persona(
                    persona_id=pid,
                    name=bp.name,
                    icon=bp.icon or "?",
                    color=bp.color or "#3b82f6",
                    role=bp.description,
                    scope_keywords=bp.scope_keywords or bp.capabilities,
                    model=bp.model or "",
                    version=bp.version,
                )
                self._personas[pid] = v1

        # 反向同步：v1 Persona → Registry
        for pid, p in self._personas.items():
            if pid not in self._registry:
                self._registry.register(p.to_base_persona())

        logger.info("PersonaRegistry 已启用，共 %d 个 Persona", len(self._registry))
        return self._registry

    @property
    def registry(self) -> Optional[PersonaRegistry]:
        """获取 PersonaRegistry 实例。"""
        return self._registry

    # ------------------------------------------------------------------
    # 加载旧定义
    # ------------------------------------------------------------------

    def load_from_dicts(self, personas_dict: dict[str, dict], models_dict: Optional[dict[str, str]] = None) -> None:
        """
        从旧版 PERSONAS / PERSONA_MODELS 格式加载 Persona。

        Args:
            personas_dict: 旧 PERSONAS 字典 {persona_id: {name, icon, color, role}}
            models_dict: 旧 PERSONA_MODELS 字典 {persona_id: model_name}
        """
        for pid, meta in personas_dict.items():
            model = (models_dict or {}).get(pid, "")
            persona = Persona(
                persona_id=pid,
                name=meta.get("name", pid),
                icon=meta.get("icon", "?"),
                color=meta.get("color", "#3b82f6"),
                role=meta.get("role", ""),
                scope_keywords=self._extract_keywords(pid, meta),
                model=model,
            )
            self.register(persona)

    def _extract_keywords(self, pid: str, meta: dict) -> list[str]:
        """从角色描述和调度映射表提取能力关键词。"""
        role = meta.get("role", "")
        keywords: set[str] = set()

        for kw, target in _LEGACY_DISPATCH_MAP.items():
            if target == pid:
                keywords.add(kw)

        for seg in ["软件", "系统", "网络", "文件", "搜索", "检索", "聊天", "安装",
                     "卸载", "配置", "运维", "编程", "代码", "爬虫", "浏览器", "网页",
                     "文档", "整理", "转换", "闲聊", "日常", "抓取", "应用"]:
            if seg in role:
                keywords.add(seg)

        return sorted(keywords)

    # ------------------------------------------------------------------
    # 五维评分匹配（v2.0 升级：双路匹配）
    # ------------------------------------------------------------------

    def match(
        self,
        user_message: str,
        user_preference: Optional[str] = None,
    ) -> list[tuple[Persona, MatchScore]]:
        """
        根据用户消息计算所有活跃 Persona 的匹配分数，返回排序结果。

        v2.0 升级：双路匹配策略
        - 路1（关键词匹配）：基于 scope_keywords 的精确/部分匹配，继承自 v1.0
        - 路2（能力标签匹配）：基于 PersonaRegistry 的能力标签语义匹配
        - 最终 intent_match = max(关键词分, 能力标签分)

        Args:
            user_message: 用户输入消息。
            user_preference: 用户明确指定的偏好 persona_id（可选）。

        Returns:
            按总分降序排列的 (Persona, MatchScore) 列表。
        """
        active_personas = self.list_active()
        if not active_personas:
            return []

        scores: list[tuple[Persona, MatchScore]] = []
        message_lower = user_message.lower()

        # 路2：能力标签匹配（仅在 Registry 启用时生效）
        capability_scores: dict[str, float] = {}
        if self._use_registry and self._registry is not None:
            capability_scores = self._compute_capability_match(message_lower)

        for persona in active_personas:
            score = MatchScore()

            # 维度1：意图匹配度 (0.0~1.0) — 双路取最大值
            keyword_score = self._compute_intent_match(message_lower, persona)
            cap_score = capability_scores.get(persona.persona_id, 0.0)
            score.intent_match = max(keyword_score, cap_score)

            # 维度2：历史成功率 (0.0~1.0)
            score.historical_success = persona.success_rate

            # 维度3：负载均衡 (0.0~1.0)
            score.load_balance = self._compute_load_balance(persona.persona_id)

            # 维度4：响应时效 (0.0~1.0)
            score.response_freshness = self._compute_response_freshness(persona)

            # 维度5：用户偏好 (0.0~1.0)
            score.user_preference = self._compute_user_preference(persona.persona_id, user_preference)

            scores.append((persona, score))

        scores.sort(key=lambda x: x[1].total, reverse=True)
        return scores

    def dispatch(
        self,
        user_message: str,
        user_preference: Optional[str] = None,
    ) -> tuple[Persona, MatchScore, list[tuple[Persona, MatchScore]]]:
        """
        执行调度决策：返回最佳 Persona + 完整排名。

        Args:
            user_message: 用户输入。
            user_preference: 用户偏好（可选）。

        Returns:
            (best_persona, best_score, all_rankings)
        """
        rankings = self.match(user_message, user_preference)
        if not rankings:
            default = self.get("host")
            if default is None:
                default = Persona(persona_id="host", name="指挥者")
            return default, MatchScore(intent_match=1.0), []

        best = rankings[0]
        return best[0], best[1], rankings

    # ------------------------------------------------------------------
    # 维度计算
    # ------------------------------------------------------------------

    def _compute_intent_match(self, message_lower: str, persona: Persona) -> float:
        """
        路1：关键词匹配（基于 scope_keywords）。

        策略：
        1. 关键词精确匹配：每个命中 +0.25，上限 0.85
        2. 部分匹配（字符重叠 ≥ 60%）：每个 +0.10
        3. 默认 host：兜底 0.15
        """
        score = 0.0

        if not persona.scope_keywords:
            return 0.15 if persona.persona_id == "host" else 0.05

        full_hits = 0
        partial_hits = 0

        for kw in persona.scope_keywords:
            kw_lower = kw.lower()
            if kw_lower in message_lower:
                full_hits += 1
            else:
                kw_chars = set(kw_lower)
                msg_chars = set(message_lower)
                overlap = len(kw_chars & msg_chars) / max(len(kw_chars), 1)
                if overlap >= 0.5:
                    partial_hits += 1

        score += min(full_hits * 0.25 + partial_hits * 0.10, 0.85)

        if persona.persona_id == "host" and score < 0.15:
            score = 0.15

        return min(score, 1.0)

    def _compute_capability_match(self, message_lower: str) -> dict[str, float]:
        """
        路2：能力标签匹配（基于 PersonaRegistry）。

        使用 Registry 的 capability 匹配能力，
        按匹配标签数归一化为 0.0~1.0 得分。
        """
        if self._registry is None:
            return {}

        # 从用户消息提取可能的能力标签
        # 使用所有注册 Persona 的能力标签作为候选词
        all_tags: set[str] = set()
        for bp in self._registry:
            all_tags.update(bp.capabilities)

        # 命中消息的能力标签
        matched_tags: list[str] = []
        for tag in all_tags:
            tag_lower = tag.lower()
            if tag_lower in message_lower or any(
                word in message_lower
                for word in tag_lower.split()
                if len(word) >= 2
            ):
                matched_tags.append(tag)

        if not matched_tags:
            return {}

        results: dict[str, float] = {}
        for bp in self._registry:
            bp_caps = [c.lower() for c in bp.capabilities]
            hits = sum(
                1 for t in matched_tags
                if any(t.lower() in c or c in t.lower() for c in bp_caps)
            )
            if hits > 0:
                # 归一化：命中数 / 最多命中数
                max_possible = len(matched_tags)
                results[bp.persona_id] = min(hits / max(max_possible, 1), 1.0)

        return results

    def _compute_load_balance(self, persona_id: str) -> float:
        """
        计算负载均衡得分。
        无排队任务 = 1.0，每增加 1 个任务扣 0.2，下限 0.0。
        """
        pending = self._pending_tasks.get(persona_id, 0)
        return max(1.0 - pending * 0.2, 0.0)

    def _compute_response_freshness(self, persona: Persona) -> float:
        """
        计算响应时效得分。
        最近 60 秒内 = 1.0，每过 300 秒扣 0.1，下限 0.1。
        """
        idle = persona.idle_seconds
        if idle == float("inf"):
            return 0.5
        if idle <= 60:
            return 1.0
        return max(1.0 - (idle - 60) / 300 * 0.1, 0.1)

    @staticmethod
    def _compute_user_preference(persona_id: str, user_preference: Optional[str]) -> float:
        """
        计算用户偏好得分。
        匹配 persona_id = 1.0，否则 0.0，无偏好时均分 0.5。
        """
        if user_preference is None:
            return 0.5
        return 1.0 if persona_id == user_preference else 0.0

    # ------------------------------------------------------------------
    # v2.0 新增：基于能力标签的匹配
    # ------------------------------------------------------------------

    def match_by_capability(
        self,
        tags: list[str],
        mode: str = "best_match",
    ) -> list[BasePersona]:
        """
        基于能力标签匹配 Persona（v2.0 新增）。

        仅在 Registry 启用时有效；否则退回关键词匹配。

        Args:
            tags: 能力标签列表，如 ['软件管理', '安装']。
            mode: 匹配模式（参见 PersonaRegistry.find_by_capability）。

        Returns:
            匹配的 BasePersona 列表。
        """
        if not self._use_registry or self._registry is None:
            # 退回关键词匹配
            return self._fallback_capability_match(tags)

        return self._registry.find_by_capability(tags, mode=mode)

    def _fallback_capability_match(self, tags: list[str]) -> list[BasePersona]:
        """Registry 未启用时的后备方案。"""
        results: list[BasePersona] = []
        tags_lower = [t.lower() for t in tags]

        for p in self.list_active():
            kw_lower = [k.lower() for k in p.scope_keywords]
            hits = sum(1 for t in tags_lower if any(t in k or k in t for k in kw_lower))
            if hits > 0:
                bp = p.to_base_persona()
                results.append(bp)

        results.sort(key=lambda bp: sum(
            1 for t in tags_lower
            if any(t in c.lower() or c.lower() in t for c in bp.capabilities)
        ), reverse=True)
        return results

    # ------------------------------------------------------------------
    # 任务状态管理
    # ------------------------------------------------------------------

    def task_started(self, persona_id: str) -> None:
        """标记 Persona 开始执行任务。"""
        if persona_id in self._pending_tasks:
            self._pending_tasks[persona_id] += 1
        else:
            self._pending_tasks[persona_id] = 1

    def task_completed(self, persona_id: str, success: bool = True) -> None:
        """标记 Persona 任务完成。"""
        persona = self._personas.get(persona_id)
        if persona is None:
            return

        persona.task_count += 1
        persona.last_task_time = time.time()

        if success:
            persona.success_count += 1
        else:
            persona.failure_count += 1

        if persona_id in self._pending_tasks:
            self._pending_tasks[persona_id] = max(0, self._pending_tasks[persona_id] - 1)

    def update_score(self, persona_id: str, overall: float) -> None:
        """更新 Persona 均分和激励状态 — 互斥逻辑。

        规则（以 overall 总分为互斥判断依据，不按各维度独立判断）：
        - overall >= 4  → 只加激励星（+1，上限 5）
        - overall < 3   → 只加惩戒星（+1，上限 5）
        - 3 <= overall < 4 → 两者都不加（中间地带）

        同一评分周期内，激励星和惩戒星只能触发一个。
        多维度评分（四维：accuracy/completeness/format/efficiency）以 overall 为准。
        """
        persona = self._personas.get(persona_id)
        if persona is None:
            return

        persona.task_score = (
            (persona.task_score * (persona.task_count - 1) + overall)
            / max(persona.task_count, 1)
        )

        # 互斥判断：激励星和惩戒星不能同时触发
        if overall >= 4:
            persona.incentive_stars = min(5, persona.incentive_stars + 1)
        elif overall < 3:
            persona.penalty_stars = min(5, persona.penalty_stars + 1)
        # 3 <= overall < 4：中间地带，不加不减

    # ------------------------------------------------------------------
    # 持久化
    # ------------------------------------------------------------------

    def save_state(self, filepath: str) -> None:
        """保存所有 Persona 状态到 JSON。"""
        data = {
            pid: p.to_dict() for pid, p in self._personas.items()
        }
        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def load_state(self, filepath: str) -> None:
        """从 JSON 加载 Persona 状态。"""
        if not os.path.isfile(filepath):
            return
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        for pid, pd in data.items():
            if pid in self._personas:
                p = self._personas[pid]
                p.task_count = pd.get("task_count", p.task_count)
                p.task_score = pd.get("task_score", p.task_score)
                p.incentive_stars = pd.get("incentive_stars", p.incentive_stars)
                p.penalty_stars = pd.get("penalty_stars", p.penalty_stars)
                p.success_count = pd.get("success_count", p.success_count)
                p.failure_count = pd.get("failure_count", p.failure_count)
            else:
                self._personas[pid] = Persona.from_dict(pd)

    # ------------------------------------------------------------------
    # 状态报告
    # ------------------------------------------------------------------

    def status_report(self) -> str:
        """生成 Markdown 格式的状态报告。"""
        lines = [
            "| 人格 | 名称 | 激励 | 惩戒 | 净激励 | 任务 | 均分 | 成功率 |",
            "|------|------|------|------|--------|------|------|--------|",
        ]
        for p in self.list_all():
            lines.append(
                f"| {p.persona_id} | {p.name} | {'★' * p.incentive_stars} | {'★' * p.penalty_stars} | "
                f"{p.net_incentive:+d} | {p.task_count} | {p.task_score:.1f} | {p.success_rate:.0%} |"
            )
        return "\n".join(lines)
