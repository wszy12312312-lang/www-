"""
Persona 注册表 — 第三阶段：Persona 体系建立

提供 Persona 的注册、注销、查找、按能力标签/名称/ID 查询，
以及 PersonaManager 的集成接口。

依赖最小化：Python 3.10+ 标准库
"""

from __future__ import annotations

import json
import os
from typing import Any, Optional

from persona.base import Persona, PersonaState


class PersonaRegistry:
    """Persona 注册表 — 管理所有 Persona 实例的生命周期。

    Supports:
    - 注册 (register)
    - 注销 (unregister)
    - 按 ID 精确查找
    - 按名称模糊查找
    - 按能力标签匹配（支持交集/并集模式）
    - 持久化到 JSON 文件
    - 从 JSON 文件恢复

    Usage:
        registry = PersonaRegistry()
        registry.register(host_persona)
        results = registry.find_by_capability(["软件管理", "安装"])
    """

    def __init__(self, storage_path: str = "") -> None:
        """初始化注册表。

        Args:
            storage_path: 持久化 JSON 文件路径（可选）。
        """
        self._personas: dict[str, Persona] = {}
        self.storage_path: str = storage_path

    # ==================================================================
    # CRUD 操作
    # ==================================================================

    def register(self, persona: Persona) -> bool:
        """注册一个 Persona。

        Args:
            persona: Persona 实例。

        Returns:
            True 表示新注册，False 表示已存在同名 Persona。
        """
        if persona.persona_id in self._personas:
            return False
        self._personas[persona.persona_id] = persona
        return True

    def unregister(self, persona_id: str) -> Optional[Persona]:
        """注销一个 Persona。

        Args:
            persona_id: Persona 唯一标识。

        Returns:
            被移除的 Persona 实例，不存在时返回 None。
        """
        return self._personas.pop(persona_id, None)

    def get(self, persona_id: str) -> Optional[Persona]:
        """按 ID 精确查找。

        Args:
            persona_id: Persona 唯一标识。

        Returns:
            Persona 实例或 None。
        """
        return self._personas.get(persona_id)

    def find_by_name(self, name: str) -> list[Persona]:
        """按名称模糊查找（子串匹配）。

        Args:
            name: 搜索名称（大小写不敏感）。

        Returns:
            匹配的 Persona 列表。
        """
        name_lower = name.lower()
        return [
            p for p in self._personas.values()
            if name_lower in p.name.lower()
        ]

    def find_by_capability(
        self,
        tags: list[str],
        mode: str = "intersection",
        match_strategy: str = "substring",
    ) -> list[Persona]:
        """按能力标签匹配 Persona。

        Args:
            tags: 要匹配的能力标签列表。
            mode: 匹配模式。
                - "intersection": 交集（所有标签都匹配才算命中）
                - "union": 并集（任意标签匹配即命中）
                - "best_match": 最佳匹配（返回匹配标签数最多的 Persona，按得分降序）
            match_strategy: 标签匹配策略。
                - "exact": 精确匹配（大小写不敏感）
                - "substring": 子串匹配（标签包含搜索词或搜索词包含标签）

        Returns:
            匹配的 Persona 列表。"best_match" 模式下按匹配标签数降序排列。
        """
        tags_lower = [t.lower() for t in tags]

        scored: list[tuple[Persona, int]] = []
        for persona in self._personas.values():
            caps_lower = [c.lower() for c in persona.capabilities]
            match_count = 0

            if match_strategy == "exact":
                match_count = sum(1 for t in tags_lower if t in caps_lower)
            elif match_strategy == "substring":
                for t in tags_lower:
                    if any(t in c or c in t for c in caps_lower):
                        match_count += 1

            if mode == "intersection":
                if match_count == len(tags_lower):
                    scored.append((persona, match_count))
            elif mode in ("union", "best_match"):
                if match_count > 0:
                    scored.append((persona, match_count))

        if mode == "best_match":
            scored.sort(key=lambda x: x[1], reverse=True)

        return [p for p, _ in scored]

    def get_by_state(self, state: PersonaState) -> list[Persona]:
        """按状态筛选 Persona。

        Args:
            state: PersonaState 枚举值。

        Returns:
            处于该状态的 Persona 列表。
        """
        return [p for p in self._personas.values() if p.state == state]

    def get_active_personas(self) -> list[Persona]:
        """获取所有活跃 Persona（IDLE 或 BUSY 状态）。"""
        return [
            p for p in self._personas.values()
            if p.state in (PersonaState.IDLE, PersonaState.BUSY)
        ]

    def list_all(self) -> list[Persona]:
        """列出所有已注册 Persona。"""
        return list(self._personas.values())

    def count(self) -> int:
        """已注册 Persona 总数。"""
        return len(self._personas)

    # ==================================================================
    # 批量注册
    # ==================================================================

    def register_all(self, personas: list[Persona]) -> dict[str, bool]:
        """批量注册 Persona。

        Args:
            personas: Persona 实例列表。

        Returns:
            {persona_id: registered_successfully}。
        """
        results: dict[str, bool] = {}
        for persona in personas:
            results[persona.persona_id] = self.register(persona)
        return results

    def preload_defaults(self) -> int:
        """预加载所有 8 个默认 Persona（无需外部传参）。

        Returns:
            成功注册的数量。
        """
        from persona.host_persona import HostPersona
        from persona.file_persona import FilePersona
        from persona.chat_persona import ChatPersona
        from persona.software_persona import SoftwarePersona
        from persona.system_persona import SystemPersona
        from persona.web_persona import WebPersona
        from persona.search_persona import SearchPersona
        from persona.monitor_persona import MonitorPersona

        defaults: list[Persona] = [
            HostPersona(),
            SoftwarePersona(),
            SystemPersona(),
            WebPersona(),
            FilePersona(),
            SearchPersona(),
            ChatPersona(),
            MonitorPersona(),
        ]
        count = 0
        for p in defaults:
            if self.register(p):
                count += 1
        return count

    # ==================================================================
    # 持久化
    # ==================================================================

    def save_to_file(self, path: str = "") -> str:
        """将注册表持久化为 JSON 文件。

        Args:
            path: 目标文件路径。不传则使用初始化时的 storage_path。

        Returns:
            实际写入的文件路径。

        Raises:
            ValueError: 未指定路径。
        """
        target = path or self.storage_path
        if not target:
            raise ValueError("storage_path 未设置，请提供 path 参数")

        os.makedirs(os.path.dirname(target) or ".", exist_ok=True)

        data: dict[str, Any] = {
            "version": "1.0.0",
            "updated_at": __import__("time").time(),
            "personas": [p.to_dict() for p in self._personas.values()],
        }

        with open(target, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return target

    def load_from_file(self, path: str = "") -> int:
        """从 JSON 文件恢复注册表。

        Args:
            path: JSON 文件路径。不传则使用 storage_path。

        Returns:
            恢复的 Persona 数量。

        Raises:
            FileNotFoundError: 文件不存在。
            ValueError: 文件格式无效。
        """
        target = path or self.storage_path
        if not target:
            raise ValueError("storage_path 未设置，请提供 path 参数")

        with open(target, "r", encoding="utf-8") as f:
            data = json.load(f)

        personas_data = data.get("personas", [])
        count = 0
        for item in personas_data:
            persona = Persona.from_dict(item)
            self._personas[persona.persona_id] = persona
            count += 1
        return count

    # ==================================================================
    # 统计信息
    # ==================================================================

    def stats(self) -> dict[str, Any]:
        """返回注册表统计摘要。"""
        states: dict[str, int] = {}
        for p in self._personas.values():
            s = p.state.name
            states[s] = states.get(s, 0) + 1

        return {
            "total": len(self._personas),
            "by_state": states,
            "active": len(self.get_active_personas()),
        }

    def __repr__(self) -> str:
        return f"PersonaRegistry(total={len(self._personas)})"

    def __contains__(self, persona_id: str) -> bool:
        return persona_id in self._personas

    def __iter__(self):
        return iter(self._personas.values())

    def __len__(self) -> int:
        return len(self._personas)
