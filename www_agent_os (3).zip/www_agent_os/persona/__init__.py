# persona package — Persona 15核心属性模型
#
# 技术文档 §1.2：Persona 15核心属性
#   - 身份：persona_id / name / description / role
#   - 能力：capabilities / core_prompt / model_binding
#   - 人格：personality (OCEAN)
#   - 安全：permission_level (L0-L4)
#   - 演化：lineage (parent_id / generation / children)
#   - 状态：13阶段 FSM（CREATE → INSTALL → ... → DESTROY）

from persona.base import (
    Persona,
    PersonaState,
    PersonaRole,
    PermissionLevel,
    ModelBinding,
    PersonalityProfile,
    Lineage,
)

__all__ = [
    "Persona",
    "PersonaState",
    "PersonaRole",
    "PermissionLevel",
    "ModelBinding",
    "PersonalityProfile",
    "Lineage",
]
