"""
SQLite 连接管理器 — 线程安全的连接池与 Schema 管理。

特性：
- 单例连接管理，WAL 模式
- 自动建表
- 线程安全（check_same_thread=False + WAL）
"""

from __future__ import annotations

import logging
import os
import sqlite3
import threading
from contextlib import contextmanager
from typing import Generator, Optional

logger = logging.getLogger(__name__)

DEFAULT_DB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "data", "sqlite")


class SQLiteManager:
    """SQLite 连接管理器（单例）。"""

    _instance: Optional["SQLiteManager"] = None
    _lock = threading.Lock()

    def __init__(self, db_path: str = "") -> None:
        if db_path:
            self.db_path = db_path
        else:
            os.makedirs(DEFAULT_DB_DIR, exist_ok=True)
            self.db_path = os.path.join(DEFAULT_DB_DIR, "memory.db")
        self._local = threading.local()
        self._ensure_tables()

    def __new__(cls, db_path: str = "") -> "SQLiteManager":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def _get_connection(self) -> sqlite3.Connection:
        """获取当前线程的连接，按需创建。"""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(self.db_path, check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA busy_timeout=5000")
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return self._local.conn

    @contextmanager
    def cursor(self) -> Generator[sqlite3.Cursor, None, None]:
        """获取游标的上下文管理器，自动提交/回滚。"""
        conn = self._get_connection()
        cur = conn.cursor()
        try:
            yield cur
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            cur.close()

    def _ensure_tables(self) -> None:
        """创建核心表。"""
        with self.cursor() as cur:
            # 短时记忆表
            cur.execute("""
                CREATE TABLE IF NOT EXISTS short_memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    persona_id TEXT DEFAULT 'host',
                    created_at REAL NOT NULL DEFAULT (julianday('now')),
                    ttl_seconds INTEGER DEFAULT 3600
                )
            """)
            cur.execute("CREATE INDEX IF NOT EXISTS idx_short_session ON short_memory(session_id)")

            # 长时记忆表（经验压缩）
            cur.execute("""
                CREATE TABLE IF NOT EXISTS long_memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    persona_id TEXT NOT NULL,
                    category TEXT NOT NULL DEFAULT 'general',
                    summary TEXT NOT NULL,
                    key_facts TEXT DEFAULT '[]',
                    embedding_id TEXT DEFAULT '',
                    importance REAL DEFAULT 0.5,
                    created_at REAL NOT NULL DEFAULT (julianday('now')),
                    last_accessed REAL,
                    access_count INTEGER DEFAULT 0
                )
            """)
            cur.execute("CREATE INDEX IF NOT EXISTS idx_long_persona ON long_memory(persona_id)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_long_category ON long_memory(category)")

            # 语义记忆向量（为向量检索预留）
            cur.execute("""
                CREATE TABLE IF NOT EXISTS semantic_memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    persona_id TEXT NOT NULL,
                    content_hash TEXT NOT NULL UNIQUE,
                    content TEXT NOT NULL,
                    embedding BLOB,
                    embedding_model TEXT DEFAULT '',
                    metadata_json TEXT DEFAULT '{}',
                    created_at REAL NOT NULL DEFAULT (julianday('now'))
                )
            """)
            cur.execute("CREATE INDEX IF NOT EXISTS idx_semantic_persona ON semantic_memory(persona_id)")

            # 对话轮次表
            cur.execute("""
                CREATE TABLE IF NOT EXISTS conversation_turns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    turn_index INTEGER NOT NULL,
                    user_message TEXT NOT NULL,
                    assistant_reply TEXT,
                    persona_id TEXT DEFAULT 'host',
                    latency_ms REAL DEFAULT 0,
                    token_count INTEGER DEFAULT 0,
                    score REAL,
                    created_at REAL NOT NULL DEFAULT (julianday('now'))
                )
            """)
            cur.execute("CREATE INDEX IF NOT EXISTS idx_conv_session ON conversation_turns(session_id)")

            # 评分记录表
            cur.execute("""
                CREATE TABLE IF NOT EXISTS scores (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    persona_id TEXT NOT NULL,
                    session_id TEXT,
                    turn_id INTEGER,
                    criterion TEXT NOT NULL,
                    score REAL NOT NULL,
                    reason TEXT DEFAULT '',
                    created_at REAL NOT NULL DEFAULT (julianday('now'))
                )
            """)

        logger.info("SQLite 数据库已就绪: %s", self.db_path)

    def close(self) -> None:
        """关闭当前线程的连接。"""
        if hasattr(self._local, "conn") and self._local.conn:
            self._local.conn.close()
            self._local.conn = None

    @classmethod
    def reset_instance(cls) -> None:
        """重置单例（测试用）。"""
        with cls._lock:
            cls._instance = None


def get_db(db_path: str = "") -> SQLiteManager:
    """获取 SQLite 数据库管理器实例。"""
    return SQLiteManager(db_path)


def init_db(db_path: str = "") -> SQLiteManager:
    """初始化数据库（建表+返回管理器）。"""
    db = get_db(db_path)
    return db
