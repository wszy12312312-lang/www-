"""
database/sqlite/memory_migration — JSON → SQLite 迁移工具

将 data/memory/ 下的旧 JSON 文件迁移到 SQLite 数据库中。

Usage:
    python -m database.sqlite.memory_migration --json-dir data/memory/
"""

from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import List, Tuple

from database.sqlite.connection import get_db, init_db

logger = logging.getLogger(__name__)


def scan_json_files(json_dir: str) -> List[str]:
    """扫描 JSON 目录下的所有 .json 文件。"""
    json_path = Path(json_dir)
    if not json_path.exists():
        logger.warning("JSON 目录不存在: %s", json_dir)
        return []
    return [str(f) for f in json_path.glob("*.json")]


def migrate_short_memory(filepath: str) -> int:
    """迁移单个短时记忆 JSON 文件。"""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        logger.warning("跳过 %s: %s", filepath, e)
        return 0

    if not isinstance(data, list):
        data = [data] if isinstance(data, dict) else []

    db = get_db()
    count = 0
    with db.cursor() as cur:
        for entry in data:
            session_id = entry.get("session_id", "unknown")
            role = entry.get("role", "user")
            content = entry.get("content", "")
            persona_id = entry.get("persona_id", "host")
            cur.execute(
                "INSERT OR IGNORE INTO short_memory (session_id, role, content, persona_id, created_at, ttl_seconds) "
                "VALUES (?, ?, ?, ?, julianday('now'), 3600)",
                (session_id, role, content, persona_id),
            )
            count += 1
    return count


def migrate_long_memory(filepath: str) -> int:
    """迁移单个长时记忆 JSON 文件。"""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        logger.warning("跳过 %s: %s", filepath, e)
        return 0

    if not isinstance(data, list):
        data = [data] if isinstance(data, dict) else []

    db = get_db()
    count = 0
    with db.cursor() as cur:
        for entry in data:
            persona_id = entry.get("persona_id", "host")
            category = entry.get("category", "general")
            summary = entry.get("summary", "")
            key_facts = json.dumps(entry.get("key_facts", []), ensure_ascii=False)
            embedding_id = entry.get("embedding_id", "")
            importance = float(entry.get("importance", 0.5))
            cur.execute(
                "INSERT OR IGNORE INTO long_memory (persona_id, category, summary, key_facts, "
                "embedding_id, importance, created_at, last_accessed) "
                "VALUES (?, ?, ?, ?, ?, ?, julianday('now'), julianday('now'))",
                (persona_id, category, summary, key_facts, embedding_id, max(0.0, min(1.0, importance))),
            )
            count += 1
    return count


def migrate_all(json_dir: str) -> Tuple[int, int]:
    """执行完整迁移。

    Args:
        json_dir: JSON 文件目录路径。

    Returns:
        (短时记忆迁移数, 长时记忆迁移数)
    """
    init_db()

    files = scan_json_files(json_dir)
    if not files:
        logger.info("没有找到 JSON 文件")
        return (0, 0)

    short_count = 0
    long_count = 0

    for fp in files:
        fname = os.path.basename(fp).lower()
        if "short" in fname or "session" in fname or "conversation" in fname:
            n = migrate_short_memory(fp)
            short_count += n
            logger.info("短时记忆: %s → %d 条", fname, n)
        elif "long" in fname or "fact" in fname or "knowledge" in fname:
            n = migrate_long_memory(fp)
            long_count += n
            logger.info("长时记忆: %s → %d 条", fname, n)
        else:
            # 尝试两者
            n1 = migrate_short_memory(fp)
            n2 = migrate_long_memory(fp)
            short_count += n1
            long_count += n2
            logger.info("通用: %s → 短时 %d / 长时 %d 条", fname, n1, n2)

    return (short_count, long_count)


def main() -> None:
    """CLI 入口。"""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")

    json_dir = sys.argv[1] if len(sys.argv) > 1 else "data/memory/"
    s, l = migrate_all(json_dir)
    print(f"\n迁移完成: 短时记忆 {s} 条, 长时记忆 {l} 条")


if __name__ == "__main__":
    main()
