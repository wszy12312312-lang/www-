"""
HOST 入口 — 替代旧 main.py 核心调度逻辑（Stage 2 + Stage 5 增强）

功能：
- 用户输入接收 → InputSanitizer → PersonaManager → 返回结果
- Feature Flag 控制：支持按模块粒度渐进开关（非全有或全无）
- 健康检查：新模块异常时自动回退到旧链路
- 切换日志：记录每次新旧链路切换事件
- 全模块集成：InputSanitizer / PersonaManager / EventBus / TaskManager /
  ToolRouter / ModelGateway / MemoryStore

使用方式:
    from runtime.host import HostEntry

    host = HostEntry(project_root="C:/Users/wszy1/Desktop/www_agent_os")
    reply, meta = host.process("帮我装个 VS Code")
"""

from __future__ import annotations

import json
import logging
import os
import sys

# 确保项目根目录在 sys.path 中，支持从任意目录执行 python runtime/host.py
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("HostEntry")

# ------------------------------------------------------------------
# Feature Flag 加载
# ------------------------------------------------------------------

def _load_feature_flags(project_root: str) -> dict:
    """加载 feature_flags.yaml。"""
    flags_path = os.path.join(project_root, "feature_flags.yaml")
    flags: dict = {}

    if os.path.isfile(flags_path):
        try:
            with open(flags_path, "r", encoding="utf-8") as f:
                for line in f:
                    stripped = line.strip()
                    if not stripped or stripped.startswith("#"):
                        continue
                    if ":" in stripped:
                        key, _, value = stripped.partition(":")
                        key = key.strip()
                        # 去除行内注释
                        comment_pos = value.find(" #")
                        if comment_pos >= 0:
                            value = value[:comment_pos]
                        value = value.strip().strip('"').strip("'")
                        if value.lower() == "true":
                            flags[key] = True
                        elif value.lower() == "false":
                            flags[key] = False
                        elif value.isdigit():
                            flags[key] = int(value)
                        else:
                            flags[key] = value
        except Exception as e:
            logger.warning("加载 feature_flags.yaml 失败: %s", e)

    return flags


# ------------------------------------------------------------------
# 调度结果
# ------------------------------------------------------------------

@dataclass
class ModuleHealth:
    """模块健康状态。"""

    module: str
    healthy: bool = True
    last_error: Optional[str] = None
    last_error_time: float = 0.0
    error_count: int = 0
    fallback_used: bool = False


@dataclass
class HostResult:
    """HOST 调度结果。"""

    reply: str = ""
    """回复内容。"""

    persona_id: str = "host"
    """处理的人格 ID。"""

    persona_name: str = ""
    """人格名称。"""

    reasoning: str = ""
    """思考过程。"""

    score: dict = field(default_factory=dict)
    """评分结果。"""

    sanitizer_findings: list[str] = field(default_factory=list)
    """InputSanitizer 发现（如有）。"""

    using_new_path: bool = False
    """是否走新链路。"""

    active_modules: list[str] = field(default_factory=list)
    """本次请求启用的新模块列表。"""

    fallback_modules: list[str] = field(default_factory=list)
    """本次请求触发回退的模块列表。"""

    error: Optional[str] = None
    """错误信息（如有）。"""

    elapsed_ms: float = 0.0
    """处理耗时（毫秒）。"""


# ------------------------------------------------------------------
# 切换日志
# ------------------------------------------------------------------

class SwitchLogger:
    """新旧链路切换日志记录器。"""

    def __init__(self, log_dir: str) -> None:
        self._log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)
        self._log_file = os.path.join(log_dir, "switch_log.jsonl")

    def log_switch(
        self,
        module: str,
        direction: str,  # "new->legacy" or "legacy->new"
        reason: str = "",
        detail: str = "",
    ) -> None:
        """记录链路切换事件。

        Args:
            module: 模块名称。
            direction: 切换方向。
            reason: 切换原因。
            detail: 详细信息。
        """
        entry = {
            "timestamp": time.time(),
            "module": module,
            "direction": direction,
            "reason": reason,
            "detail": detail,
        }
        try:
            with open(self._log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def read_recent(self, limit: int = 50) -> list[dict]:
        """读取最近的切换日志。"""
        entries: list[dict] = []
        if not os.path.isfile(self._log_file):
            return entries
        try:
            with open(self._log_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            entries.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
        except Exception:
            pass
        return entries[-limit:]


# ------------------------------------------------------------------
# 模块健康检查器
# ------------------------------------------------------------------

class HealthChecker:
    """模块健康检查器 — 新模块异常时自动禁用并回退到旧链路。

    策略：
    - 每个模块独立追踪健康状态
    - 连续失败 N 次后标记为不健康（UNHEALTHY）
    - 不健康后进入冷却期（COOLDOWN），冷却期结束后尝试恢复
    - 默认：连续 3 次失败 → 不健康；冷却 300 秒 → 尝试恢复
    """

    DEFAULT_MAX_FAILURES = 3
    DEFAULT_COOLDOWN_SECONDS = 300.0

    def __init__(
        self,
        max_failures: int = 0,
        cooldown_seconds: float = 0.0,
    ) -> None:
        self._max_failures = max_failures or self.DEFAULT_MAX_FAILURES
        self._cooldown_seconds = cooldown_seconds or self.DEFAULT_COOLDOWN_SECONDS
        self._modules: Dict[str, ModuleHealth] = {}
        self._switch_logger: Optional[SwitchLogger] = None

    def set_switch_logger(self, logger_instance: SwitchLogger) -> None:
        self._switch_logger = logger_instance

    def register(self, module_name: str) -> None:
        """注册模块的健康追踪。"""
        if module_name not in self._modules:
            self._modules[module_name] = ModuleHealth(module=module_name)

    def can_use(self, module_name: str) -> bool:
        """检查模块当前是否可用。

        Returns:
            True 表示可以使用新模块。
        """
        if module_name not in self._modules:
            return True  # 未注册的模块默认可用

        mh = self._modules[module_name]

        # 健康 → 可用
        if mh.healthy:
            return True

        # 不健康 → 检查冷却期是否结束
        if mh.last_error_time > 0:
            elapsed = time.time() - mh.last_error_time
            if elapsed >= self._cooldown_seconds:
                # 冷却期结束，尝试恢复
                mh.healthy = True
                mh.error_count = 0
                logger.info("模块 %s 冷却期结束，尝试恢复", module_name)
                return True

        return False

    def report_success(self, module_name: str) -> None:
        """报告模块运行成功。"""
        if module_name not in self._modules:
            self.register(module_name)
        mh = self._modules[module_name]
        mh.healthy = True
        mh.error_count = 0
        mh.last_error = None

    def report_failure(self, module_name: str, error: str) -> bool:
        """报告模块运行失败。

        Returns:
            True 表示模块已标记为不健康（触发回退）。
        """
        if module_name not in self._modules:
            self.register(module_name)

        mh = self._modules[module_name]
        mh.error_count += 1
        mh.last_error = error
        mh.last_error_time = time.time()
        mh.fallback_used = True

        if mh.error_count >= self._max_failures and mh.healthy:
            mh.healthy = False
            logger.warning(
                "模块 %s 连续失败 %d 次，标记为不健康，回退到旧链路",
                module_name, mh.error_count,
            )
            if self._switch_logger:
                self._switch_logger.log_switch(
                    module=module_name,
                    direction="new->legacy",
                    reason=f"连续失败 {mh.error_count} 次",
                    detail=error[:200],
                )
            return True

        return False

    def get_health_report(self) -> Dict[str, Any]:
        """获取所有模块健康报告。"""
        report: Dict[str, Any] = {}
        for name, mh in self._modules.items():
            report[name] = {
                "healthy": mh.healthy,
                "error_count": mh.error_count,
                "last_error": mh.last_error[:100] if mh.last_error else None,
                "fallback_used": mh.fallback_used,
            }
        return report


# ------------------------------------------------------------------
# HOST 入口
# ------------------------------------------------------------------

class HostEntry:
    """
    HOST 入口 — 用户请求的统一入口。

    架构:
        User Input
          │
          ▼
        InputSanitizer (feature flag: USE_INPUT_SANITIZER)
          │                                   ↓ 异常 → 回退（跳过过滤）
          ▼
        PersonaManager.dispatch() (feature flag: USE_NEW_HOST + USE_PERSONA_MANAGER)
          │                                   ↓ 异常 → 回退（旧 host_dispatch）
          ▼
        执行链（ModelGateway / TaskManager / MemoryStore 各模块独立开关+健康检查）
          │                                   ↓ 异常 → 回退（旧 chat 接口）
          ▼
        Response
    """

    # 默认旧链路导入路径（已迁移到 services/ollama_service.py）
    LEGACY_CORE_PATH = "services.ollama_service"

    # 需要追踪健康状态的新模块
    TRACKED_MODULES = [
        "InputSanitizer",
        "PersonaManager",
        "ModelGateway",
        "TaskManager",
        "ToolRouter",
        "MemoryStore",
        "EventBus",
    ]

    def __init__(
        self,
        project_root: Optional[str] = None,
        feature_flags: Optional[dict] = None,
        max_failures: int = 3,
        cooldown_seconds: float = 300.0,
    ):
        """
        Args:
            project_root: 项目根目录。
            feature_flags: 预加载的 feature_flags 字典。None 时自动从文件加载。
            max_failures: 健康检查：连续失败多少次后标记不健康。
            cooldown_seconds: 健康检查：不健康冷却时间。
        """
        self._project_root = project_root or self._infer_project_root()
        self._flags = feature_flags or _load_feature_flags(self._project_root)

        # 切换日志
        self._switch_logger = SwitchLogger(
            os.path.join(self._project_root, "logs", "switch")
        )

        # 健康检查
        self._health = HealthChecker(
            max_failures=max_failures,
            cooldown_seconds=cooldown_seconds,
        )
        self._health.set_switch_logger(self._switch_logger)
        for mod in self.TRACKED_MODULES:
            self._health.register(mod)

        # 延迟初始化组件
        self._sanitizer = None
        self._persona_manager = None
        self._legacy_system = None
        self._event_bus = None
        self._task_manager = None
        self._tool_router = None
        self._model_gateway = None
        self._memory_store = None

        # 确保 services 模块可导入
        services_dir = os.path.join(self._project_root, "services")
        if services_dir not in sys.path:
            sys.path.insert(0, services_dir)

    @staticmethod
    def _infer_project_root() -> str:
        return str(Path(__file__).resolve().parent.parent)

    # ------------------------------------------------------------------
    # Feature Flag Getters — 按模块粒度
    # ------------------------------------------------------------------

    @property
    def use_input_sanitizer(self) -> bool:
        """是否启用 InputSanitizer。"""
        return bool(
            self._flags.get("USE_INPUT_SANITIZER", False)
            or self._flags.get("USE_NEW_HOST", False)
            or self._flags.get("USE_NEW_ARCH", False)
        )

    @property
    def use_new_host(self) -> bool:
        """是否启用新 HOST 链路。"""
        return bool(
            self._flags.get("USE_NEW_HOST", False)
            or self._flags.get("USE_NEW_ARCH", False)
        )

    @property
    def use_persona_manager(self) -> bool:
        """是否启用 PersonaManager。"""
        return bool(
            self._flags.get("USE_PERSONA_MANAGER", False)
            or self._flags.get("USE_NEW_PERSONA", False)
            or self._flags.get("USE_NEW_ARCH", False)
        )

    @property
    def use_new_persona_system(self) -> bool:
        """是否启用新版 Persona 体系（基类+子类+注册表+状态机）。"""
        return bool(
            self._flags.get("USE_NEW_PERSONA_SYSTEM", False)
            or self._flags.get("USE_NEW_ARCH", False)
        )

    @property
    def use_event_bus(self) -> bool:
        """是否启用 EventBus。"""
        return bool(
            self._flags.get("USE_EVENT_BUS", False)
            or self._flags.get("USE_NEW_ARCH", False)
        )

    @property
    def use_task_manager(self) -> bool:
        """是否启用 TaskManager。"""
        return bool(
            self._flags.get("USE_TASK_MANAGER", False)
            or self._flags.get("USE_NEW_ARCH", False)
        )

    @property
    def use_tool_router(self) -> bool:
        """是否启用 ToolRouter。"""
        return bool(
            self._flags.get("USE_TOOL_ROUTER", False)
            or self._flags.get("USE_NEW_ARCH", False)
        )

    @property
    def use_model_gateway(self) -> bool:
        """是否启用 ModelGateway。"""
        return bool(
            self._flags.get("USE_MODEL_GATEWAY", False)
            or self._flags.get("USE_NEW_ARCH", False)
        )

    @property
    def use_memory_store(self) -> bool:
        """是否启用 MemoryStore。"""
        return bool(
            self._flags.get("USE_MEMORY_STORE", False)
            or self._flags.get("USE_NEW_ARCH", False)
        )

    # ------------------------------------------------------------------
    # 健康检查包装器
    # ------------------------------------------------------------------

    def _healthy_wrapper(
        self,
        module_name: str,
        flag_value: bool,
        new_func: Callable[[], Any],
        fallback_func: Callable[[], Any],
    ) -> Tuple[Any, bool, bool]:
        """带健康检查的模块调用包装器。

        Args:
            module_name: 模块名（用于健康追踪）。
            flag_value: Feature Flag 值。
            new_func: 新模块调用函数。
            fallback_func: 旧模块回退函数。

        Returns:
            (result, used_new, fell_back)
            - result: 调用结果
            - used_new: 是否使用了新模块
            - fell_back: 是否触发了回退
        """
        used_new = False
        fell_back = False

        if flag_value and self._health.can_use(module_name):
            try:
                result = new_func()
                self._health.report_success(module_name)
                used_new = True
                return result, used_new, fell_back
            except Exception as e:
                # H05修复：只存储异常类名+消息，完整 traceback 仅写入内部日志
                err_str = f"{type(e).__name__}: {e}"
                logger.warning("模块 %s 执行失败，完整 traceback:\n%s", module_name, traceback.format_exc())
                unhealthy = self._health.report_failure(module_name, err_str)
                logger.warning(
                    "模块 %s 执行失败（%s），回退到旧链路: %s",
                    module_name,
                    "已标记不健康" if unhealthy else f"失败 {self._health._modules[module_name].error_count}/{self._health._max_failures}",
                    str(e)[:100],
                )
                fell_back = True

        # 回退到旧模块
        result = fallback_func()
        return result, used_new, fell_back

    # ------------------------------------------------------------------
    # Lazy Init
    # ------------------------------------------------------------------

    def _get_sanitizer(self):
        """获取 InputSanitizer 单例。"""
        if self._sanitizer is None:
            from core.input_sanitizer import InputSanitizer
            self._sanitizer = InputSanitizer(project_root=self._project_root)
        return self._sanitizer

    def _get_persona_manager(self):
        """获取 PersonaManager 单例。"""
        if self._persona_manager is None:
            from persona.manager import PersonaManager
            self._persona_manager = PersonaManager(project_root=self._project_root)
            self._init_personas_from_legacy()
        return self._persona_manager

    def _init_personas_from_legacy(self) -> None:
        """从 config.app_config 加载 Persona 定义。"""
        try:
            from config.app_config import PERSONAS, PERSONA_MODELS
            self._persona_manager.load_from_dicts(PERSONAS, PERSONA_MODELS)
        except ImportError:
            logger.warning("无法导入 config.app_config，PersonaManager 将以空状态运行")

    def _get_legacy_system(self):
        """获取旧 WWWSystem 实例（services/ollama_service.py）。"""
        if self._legacy_system is None:
            try:
                from services.ollama_service import WWWSystem
                self._legacy_system = WWWSystem()
            except ImportError:
                logger.error("无法导入 services.ollama_service")
                raise RuntimeError("旧系统导入失败，无法使用回退链路")
        return self._legacy_system

    def _get_event_bus(self):
        """获取 EventBus 单例。"""
        if self._event_bus is None:
            from events.bus import get_default_bus
            self._event_bus = get_default_bus()
        return self._event_bus

    def _get_task_manager(self):
        """获取 TaskManager 单例。"""
        if self._task_manager is None:
            from task.manager import TaskManager
            self._task_manager = TaskManager(bus=self._get_event_bus())
        return self._task_manager

    def _get_tool_router(self):
        """获取 ToolRouter 单例。"""
        if self._tool_router is None:
            from tools.router import ToolRouter
            self._tool_router = ToolRouter(bus=self._get_event_bus())
        return self._tool_router

    def _get_model_gateway(self):
        """获取 ModelGateway 单例。"""
        if self._model_gateway is None:
            from models.gateway import ModelGateway
            self._model_gateway = ModelGateway(bus=self._get_event_bus())
        return self._model_gateway

    def _get_memory_store(self):
        """获取 MemoryStore 单例。"""
        if self._memory_store is None:
            from memory.store import MemoryStore
            storage_dir = os.path.join(self._project_root, "data", "memory")
            self._memory_store = MemoryStore(
                storage_dir=storage_dir,
                bus=self._get_event_bus(),
            )
        return self._memory_store

    # ------------------------------------------------------------------
    # 主处理流程
    # ------------------------------------------------------------------

    def process(self, user_message: str, user_preference: Optional[str] = None) -> HostResult:
        """
        处理用户消息 — 主入口。

        Args:
            user_message: 用户输入文本。
            user_preference: 用户指定的偏好 persona_id（可选）。

        Returns:
            HostResult 包含回复和元信息。
        """
        t0 = time.perf_counter()
        result = HostResult()
        active_modules: list[str] = []
        fallback_modules: list[str] = []

        # ---- Step 1: InputSanitizer（带健康检查）----
        def _run_sanitizer():
            sanitizer = self._get_sanitizer()
            return sanitizer.sanitize(user_message)

        def _skip_sanitizer():
            # 回退：不做任何过滤
            from core.input_sanitizer import SanitizerResult
            return SanitizerResult(sanitized=user_message)

        sr, used_sanitizer, fb_sanitizer = self._healthy_wrapper(
            "InputSanitizer", self.use_input_sanitizer,
            _run_sanitizer, _skip_sanitizer,
        )
        if used_sanitizer:
            active_modules.append("InputSanitizer")
        if fb_sanitizer:
            fallback_modules.append("InputSanitizer")

        result.sanitizer_findings = sr.findings
        if sr.is_blocked:
            result.reply = sr.blocked_message
            result.elapsed_ms = (time.perf_counter() - t0) * 1000
            return result
        sanitized = sr.sanitized

        # ---- Step 2: PersonaManager 调度（带健康检查）----
        def _run_persona_manager():
            pm = self._get_persona_manager()
            best, score, _ = pm.dispatch(sanitized, user_preference)
            pm.task_started(best.persona_id)
            return best.persona_id

        def _run_legacy_dispatch():
            sys_legacy = self._get_legacy_system()
            pid, _ = sys_legacy.host_dispatch(sanitized)
            return pid

        def _default_host():
            return "host"

        if self.use_new_host:
            persona_id, used_pm, fb_pm = self._healthy_wrapper(
                "PersonaManager", self.use_persona_manager,
                _run_persona_manager, _run_legacy_dispatch,
            )
        else:
            persona_id, used_pm, fb_pm = self._healthy_wrapper(
                "PersonaManager", False,
                lambda: "host", _run_legacy_dispatch,
            )

        if used_pm:
            active_modules.append("PersonaManager")
            result.using_new_path = True
        if fb_pm:
            fallback_modules.append("PersonaManager")

        # ---- Step 3: 获取 Persona 名称 ----
        result.persona_id = persona_id
        try:
            from config.app_config import PERSONAS
            result.persona_name = PERSONAS.get(persona_id, {}).get("name", persona_id)
        except ImportError:
            result.persona_name = persona_id

        # ---- Step 4: 执行（带模块健康检查）----
        # 如果启用了 TaskManager，创建任务
        task_id: Optional[str] = None
        if self.use_task_manager and self._health.can_use("TaskManager"):
            try:
                tm = self._get_task_manager()
                task = tm.create_task(persona_id=persona_id, user_input=user_message)
                task_id = task.id
                active_modules.append("TaskManager")
            except Exception as e:
                self._health.report_failure("TaskManager", str(e))
                fallback_modules.append("TaskManager")

        # 实际调用
        try:
            # 尝试使用 ModelGateway
            if self.use_model_gateway and self._health.can_use("ModelGateway"):
                try:
                    mg = self._get_model_gateway()
                    # 使用 ModelGateway 生成回复
                    reply, reasoning = self._call_via_gateway(persona_id, sanitized)
                    active_modules.append("ModelGateway")
                except Exception as e:
                    self._health.report_failure("ModelGateway", str(e))
                    fallback_modules.append("ModelGateway")
                    # 回退到旧接口
                    sys_legacy = self._get_legacy_system()
                    reply, reasoning = self._execute_via_legacy(sys_legacy, persona_id, sanitized)
            else:
                sys_legacy = self._get_legacy_system()
                reply, reasoning = self._execute_via_legacy(sys_legacy, persona_id, sanitized)

            result.reply = reply
            result.reasoning = reasoning

            # 评分（始终使用旧系统）
            sys_legacy = self._get_legacy_system()
            score = sys_legacy.s6_evaluate(persona_id, sanitized, reply)
            sys_legacy.apply_score(persona_id, score.get("overall", 3))
            sys_legacy.log_task(persona_id, sanitized, reply, score)
            result.score = score

            # 同步 PersonaManager 状态
            if self.use_persona_manager and self._persona_manager is not None:
                self._persona_manager.task_completed(persona_id, success=score.get("overall", 3) >= 3)
                self._persona_manager.update_score(persona_id, score.get("overall", 3))

            # 更新 TaskManager 状态
            if task_id and self._task_manager is not None:
                try:
                    tm = self._get_task_manager()
                    if score.get("overall", 3) >= 3:
                        tm.complete(task_id, result=reply)
                    else:
                        tm.fail(task_id, error=f"score={score.get('overall')}")
                except Exception:
                    pass

            # MemoryStore：记录对话
            if self.use_memory_store and self._health.can_use("MemoryStore"):
                try:
                    ms = self._get_memory_store()
                    ms.save_message(persona_id, sanitized, role="user", persist=True)
                    ms.save_message(persona_id, reply, role="assistant", persist=True)
                    active_modules.append("MemoryStore")
                except Exception as e:
                    self._health.report_failure("MemoryStore", str(e))
                    fallback_modules.append("MemoryStore")

        except Exception as e:
            # H05修复：只存储异常类名+消息，完整 traceback 仅写入内部日志
            result.error = f"{type(e).__name__}: {e}"
            result.reply = f"[系统错误] {e}"
            logger.error("执行失败:\n%s", traceback.format_exc())

        result.active_modules = active_modules
        result.fallback_modules = fallback_modules
        result.elapsed_ms = (time.perf_counter() - t0) * 1000
        return result

    def _call_via_gateway(self, persona_id: str, message: str) -> Tuple[str, str]:
        """通过 ModelGateway 调用模型生成回复。

        Returns:
            (reply, reasoning)

        Raises:
            RuntimeError: 网关返回错误时抛出，触发上层 healthy_wrapper 回退。
        """
        mg = self._get_model_gateway()
        # 获取该 persona 对应的模型名
        model_name = self._resolve_model(persona_id)
        # generate() 返回 str（纯文本），无 reasoning 字段
        reply = mg.generate(
            model=model_name,
            prompt=message,
        )
        # generate() 在错误时返回 "[<model>] generate 异常: ..." 字符串，需识别并抛出
        if reply.startswith("[") and "] generate 异常:" in reply:
            raise RuntimeError(reply)
        return reply, ""

    def _execute_via_legacy(self, sys_legacy, persona_id: str, message: str) -> Tuple[str, str]:
        """通过旧系统执行 persona 调用。

        HOST persona 走编排路径（host_orchestrate），其他 persona 走 chat 路径。
        将 HOST 调度和 H 指挥者合并为同一个 persona，不再分开维护两套逻辑。

        Returns:
            (reply, reasoning)
        """
        if persona_id == "host":
            # 检查是否有待处理的确认请求
            if sys_legacy.has_pending_confirmations():
                # 用户回复确认请求 → 走恢复回路
                final_reply, host_reasoning, _, _ = sys_legacy.host_resume_with_confirmation(
                    user_decision=message,
                    pending_confirmations=sys_legacy._pending_confirmations,
                    sub_results=sys_legacy._last_sub_results,
                    host_reasoning=sys_legacy._last_host_reasoning,
                    host_analysis=sys_legacy._last_host_analysis,
                )
            else:
                # 无待处理确认 → 正常编排路径：分解任务 → 调度副人格 → 综合回复
                final_reply, host_reasoning, _, _ = sys_legacy.host_orchestrate(message)
            return final_reply, host_reasoning
        else:
            return sys_legacy.chat(persona_id, message)

    def _resolve_model(self, persona_id: str) -> str:
        """解析 persona 对应的模型名。"""
        try:
            from config.app_config import PERSONA_MODELS
            return PERSONA_MODELS.get(persona_id, "qwen2.5:latest")
        except ImportError:
            return "qwen2.5:latest"

    # ------------------------------------------------------------------
    # 状态报告
    # ------------------------------------------------------------------

    def get_status_report(self) -> str:
        """获取当前系统状态报告。"""
        if self.use_persona_manager and self._persona_manager is not None:
            return self._persona_manager.status_report()
        try:
            return self._get_legacy_system().get_status_report()
        except Exception:
            return "状态不可用"

    def get_feature_flags_report(self) -> str:
        """获取当前 Feature Flag 状态。"""
        lines = ["| Flag | Value |", "|------|-------|"]
        relevant = [
            "USE_NEW_ARCH", "USE_NEW_HOST", "USE_INPUT_SANITIZER",
            "USE_PERSONA_MANAGER", "USE_NEW_PERSONA",
            "USE_EVENT_BUS", "USE_TASK_MANAGER", "USE_TOOL_ROUTER",
            "USE_MODEL_GATEWAY", "USE_MEMORY_STORE",
        ]
        for key in relevant:
            lines.append(f"| {key} | {self._flags.get(key, 'N/A')} |")
        return "\n".join(lines)

    def get_health_report(self) -> Dict[str, Any]:
        """获取模块健康报告。"""
        return self._health.get_health_report()

    def get_switch_log(self, limit: int = 50) -> list[dict]:
        """获取最近的切换日志。"""
        return self._switch_logger.read_recent(limit)

    def reset_all_health(self) -> None:
        """重置所有模块的健康状态（用于测试和手动恢复）。"""
        self._health = HealthChecker(
            max_failures=self._health._max_failures,
            cooldown_seconds=self._health._cooldown_seconds,
        )
        self._health.set_switch_logger(self._switch_logger)
        for mod in self.TRACKED_MODULES:
            self._health.register(mod)


# ------------------------------------------------------------------
# 交互式 CLI 入口
# ------------------------------------------------------------------

def _print_banner() -> None:
    """打印启动横幅。"""
    print()
    print("=" * 56)
    print("  WWW Agent OS  -  Multi-Persona Collaboration System")
    print("  Version 10.7.0")
    print("=" * 56)
    print()


def _print_help() -> None:
    """打印帮助信息。"""
    print()
    print("Commands:")
    print("  /help       - Show this help")
    print("  /status     - Show system status")
    print("  /flags      - Show feature flags")
    print("  /health     - Show module health")
    print("  /switchlog  - Show recent switch log")
    print("  /reset      - Reset all module health")
    print("  /exit, /quit - Exit")
    print("  <anything>  - Send message to HostEntry.process()")
    print()


def _interactive_loop(host: "HostEntry") -> None:
    """交互式命令行主循环。"""
    _print_banner()
    print("Type /help for available commands, or just type a message.\n")

    while True:
        try:
            user_input = input("You > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_input:
            continue

        # 处理斜杠命令
        cmd = user_input.lower()

        if cmd in ("/exit", "/quit", "/q"):
            print("Goodbye.")
            break

        if cmd == "/help":
            _print_help()
            continue

        if cmd == "/status":
            print(host.get_status_report())
            continue

        if cmd == "/flags":
            print(host.get_feature_flags_report())
            continue

        if cmd == "/health":
            import json
            print(json.dumps(host.get_health_report(), indent=2, ensure_ascii=False))
            continue

        if cmd == "/switchlog":
            entries = host.get_switch_log(20)
            if not entries:
                print("(no switch events recorded)")
            else:
                for entry in entries:
                    ts = entry.get("timestamp", 0)
                    from datetime import datetime
                    dt = datetime.fromtimestamp(ts)
                    print(f"[{dt.strftime('%Y-%m-%d %H:%M:%S')}] {entry.get('module')}: {entry.get('direction')} - {entry.get('reason')}")
            continue

        if cmd == "/reset":
            host.reset_all_health()
            print("All module health reset.")
            continue

        if cmd.startswith("/"):
            print(f"Unknown command: {user_input}. Type /help for available commands.")
            continue

        # 普通消息 → 调用 HostEntry.process()
        print()
        result = host.process(user_input)
        if result.error:
            print(f"[ERROR] {result.error}")
        else:
            print(f"[{result.persona_name}] {result.reply}")
        print(f"(elapsed: {result.elapsed_ms:.0f}ms | persona: {result.persona_id})")
        print()


def main() -> None:
    """main() — 从 start_www_agent.bat 调用的入口函数。

    启动交互式 CLI 循环，使用 HostEntry 处理用户输入。
    """
    import argparse

    parser = argparse.ArgumentParser(
        description="WWW Agent OS - Multi-Persona Collaboration System"
    )
    parser.add_argument(
        "--project-root",
        default=None,
        help="Project root directory (default: auto-detect from script location)",
    )
    parser.add_argument(
        "--version", "-V",
        action="store_true",
        help="Print version and exit",
    )
    args = parser.parse_args()

    if args.version:
        print("WWW Agent OS 10.7.0")
        return

    project_root = args.project_root or str(Path(__file__).resolve().parent.parent)
    print(f"[INFO] Project root: {project_root}")

    try:
        host = HostEntry(project_root=project_root)
    except Exception as e:
        print(f"[FATAL] Failed to initialize HostEntry: {e}")
        traceback.print_exc()
        sys.exit(1)

    _interactive_loop(host)


if __name__ == "__main__":
    main()
