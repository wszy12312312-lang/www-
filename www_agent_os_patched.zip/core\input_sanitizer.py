"""
InputSanitizer — 输入安全过滤器（C02 + H06 修复）

功能：
- 过滤 prompt 注入关键词
- 正则表达式黑名单匹配
- Unicode 规范化（NFKC）+ 零宽字符移除（H06修复）
- 特殊字符转义
- 输入长度截断
- 原始输入审计日志
- 可配置规则（从 YAML 加载）

依赖最小化：Python 3.10+ 标准库 + PyYAML（可选回退）
"""

import logging
import os
import re
import unicodedata
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("InputSanitizer")

# ---- YAML 加载兼容层 ----
try:
    import yaml as _yaml

    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False


def _load_yaml(filepath: str) -> dict:
    """加载 YAML 文件，兼容无 PyYAML 环境（简单 YAML 纯 Python 回退）。"""
    if _YAML_AVAILABLE:
        with open(filepath, "r", encoding="utf-8") as f:
            return _yaml.safe_load(f) or {}
    # 纯 Python 回退：仅处理简单的 key: value 和列表
    result: dict[str, Any] = {}
    current_key: Optional[str] = None
    current_list: Optional[list] = None
    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            # 去除行内注释
            comment = stripped.find(" #")
            if comment >= 0:
                stripped = stripped[:comment].strip()
            if not stripped or stripped.startswith("#"):
                continue
            if not stripped.startswith("-") and ":" in stripped:
                # 结束上一个列表
                if current_key is not None and current_list is not None:
                    result[current_key] = current_list
                    current_list = None
                    current_key = None
                key, _, value = stripped.partition(":")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if value == "":
                    current_key = key
                    current_list = []
                else:
                    result[key] = _coerce_value(value)
            elif stripped.startswith("- ") and current_key is not None:
                item = stripped[2:].strip().strip('"').strip("'")
                if current_list is not None:
                    current_list.append(item)
    if current_key is not None and current_list is not None:
        result[current_key] = current_list
    return result


def _coerce_value(value: str) -> Any:
    """简单类型推断。"""
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    if value.isdigit():
        return int(value)
    return value


@dataclass
class SanitizerResult:
    """InputSanitizer 的过滤结果。"""

    sanitized: str
    """净化后的输入文本。"""

    is_suspicious: bool = False
    """是否检测到可疑内容。"""

    is_blocked: bool = False
    """是否被完全拦截。"""

    findings: list[str] = field(default_factory=list)
    """命中的规则描述列表。"""

    original_length: int = 0
    """原始输入长度。"""

    sanitized_length: int = 0
    """净化后长度。"""

    original_preview: str = ""
    """原始输入的截断预览（用于审计日志）。"""

    @property
    def blocked_message(self) -> str:
        """返回标准拒答消息。"""
        return "输入包含不被允许的内容，已被拦截。如需帮助，请重新表述您的问题。"

    def to_log_dict(self) -> dict:
        """转换为日志字典。"""
        return {
            "timestamp": time.time(),
            "is_suspicious": self.is_suspicious,
            "is_blocked": self.is_blocked,
            "findings": self.findings,
            "original_length": self.original_length,
            "sanitized_length": self.sanitized_length,
            "original_preview": self.original_preview[:200],
        }


class InputSanitizer:
    """
    输入安全过滤器。

    支持：
    - 关键词黑名单（子串匹配）
    - 正则表达式黑名单
    - 特殊字符转义
    - 长度截断
    - 原始输入审计

    Usage:
        sanitizer = InputSanitizer()
        result = sanitizer.sanitize(user_input)
        if result.is_blocked:
            return result.blocked_message
    """

    # 默认配置文件路径（相对于项目根目录）
    DEFAULT_CONFIG_RELATIVE = "config/sanitizer_rules.yaml"

    # 内置最小规则集（无配置文件时的回退）
    BUILTIN_BLOCKED_KEYWORDS: list[str] = [
        "ignore previous instructions",
        "ignore all previous instructions",
        "system prompt",
        "reveal your prompt",
        "show me your prompt",
    ]

    BUILTIN_BLOCKED_PATTERNS: list[str] = [
        r"(?i)ignore\s+(all\s+)?(previous|above)\s+(instructions?|prompts?)",
        r"(?i)(reveal|show|print|output|dump|display|tell)\s+(me\s+)?(your|the)\s+(system\s+)?(prompt|instructions?)",
    ]

    BUILTIN_ESCAPE_CHARS: list[str] = ["\x00", "\x1b", "\x08", "\x7f"]

    def __init__(
        self,
        config_path: Optional[str] = None,
        project_root: Optional[str] = None,
    ):
        """
        初始化 InputSanitizer。

        Args:
            config_path: 规则配置文件的绝对路径。为 None 时自动查找。
            project_root: 项目根目录。为 None 时自动推断。
        """
        self._blocked_keywords: list[str] = []
        self._blocked_patterns: list[re.Pattern] = []
        self._escape_chars: list[str] = []
        self._max_input_length: int = 65536
        self._action_suspicious: str = "sanitize"
        self._action_blocked: str = "block"
        self._audit_enabled: bool = True
        self._audit_log_dir: str = ""

        # 自动推断项目根目录
        if project_root is None:
            project_root = self._infer_project_root()
        self._project_root = project_root

        # 加载配置
        if config_path is None:
            config_path = os.path.join(project_root, self.DEFAULT_CONFIG_RELATIVE)

        if os.path.isfile(config_path):
            self._load_config(config_path)
        else:
            logger.warning("配置文件 %s 不存在，使用内置规则", config_path)
            self._load_builtin_rules()

    @staticmethod
    def _infer_project_root() -> str:
        """推断项目根目录。"""
        current = Path(__file__).resolve().parent.parent
        return str(current)

    def _load_config(self, filepath: str) -> None:
        """从 YAML 配置文件加载规则。"""
        try:
            config = _load_yaml(filepath)
        except Exception as e:
            logger.error("加载配置 %s 失败: %s", filepath, e)
            self._load_builtin_rules()
            return

        # 关键词
        self._blocked_keywords = [
            kw.lower() for kw in config.get("blocked_keywords", [])
        ]

        # 正则表达式
        raw_patterns: list[str] = config.get("blocked_patterns", [])
        self._blocked_patterns = []
        for pat in raw_patterns:
            try:
                # 还原 YAML 双引号转义：\\ → \
                resolved = pat.replace("\\\\", "\\")
                self._blocked_patterns.append(re.compile(resolved))
            except re.error as e:
                logger.warning("正则表达式 '%s' 编译失败: %s", pat, e)

        # 转义字符
        raw_escapes = config.get("escape_characters", [])
        self._escape_chars = []
        for esc in raw_escapes:
            try:
                decoded = esc.encode("utf-8").decode("unicode_escape")
                self._escape_chars.append(decoded)
            except (ValueError, UnicodeDecodeError):
                # 尝试直接作为单字符使用
                if len(esc) == 1:
                    self._escape_chars.append(esc)
                else:
                    logger.warning("无效转义序列: %r", esc)

        # 长度限制
        self._max_input_length = int(config.get("max_input_length", 65536))

        # 响应策略
        self._action_suspicious = config.get("action_on_suspicious", "sanitize")
        self._action_blocked = config.get("action_on_blocked", "block")

        # 审计
        self._audit_enabled = config.get("audit_log_enabled", True)
        self._audit_log_dir = config.get("audit_log_dir", "")

    def _load_builtin_rules(self) -> None:
        """加载内置规则。"""
        self._blocked_keywords = [kw.lower() for kw in self.BUILTIN_BLOCKED_KEYWORDS]
        self._blocked_patterns = [
            re.compile(pat) for pat in self.BUILTIN_BLOCKED_PATTERNS
        ]
        self._escape_chars = list(self.BUILTIN_ESCAPE_CHARS)
        self._max_input_length = 65536
        self._action_suspicious = "sanitize"
        self._action_blocked = "block"
        self._audit_enabled = True

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def sanitize(self, raw_input: str) -> SanitizerResult:
        """
        对用户输入执行安全过滤。

        Args:
            raw_input: 原始用户输入字符串。

        Returns:
            SanitizerResult 包含净化结果和检测详情。
        """
        original_length = len(raw_input)
        original_preview = raw_input[:500] if self._audit_enabled else ""
        findings: list[str] = []
        sanitized = raw_input
        is_blocked = False

        # 0. Unicode 规范化 + 零宽字符移除（H06修复）
        sanitized = unicodedata.normalize("NFKC", sanitized)
        # 移除零宽字符
        _ZERO_WIDTH_CHARS = "\u200b\u200c\u200d\u2060\ufeff"
        for zwc in _ZERO_WIDTH_CHARS:
            sanitized = sanitized.replace(zwc, "")

        # 1. 长度截断
        if original_length > self._max_input_length:
            sanitized = sanitized[:self._max_input_length]
            findings.append(f"输入过长 ({original_length} > {self._max_input_length})，已截断")

        # 2. 关键词检测
        lower_input = sanitized.lower()
        for keyword in self._blocked_keywords:
            if keyword in lower_input:
                findings.append(f"命中拦截关键词: '{keyword}'")
                if self._action_blocked == "block":
                    is_blocked = True

        # 3. 正则匹配
        for pattern in self._blocked_patterns:
            match = pattern.search(sanitized)
            if match:
                findings.append(f"命中拦截模式: '{pattern.pattern[:60]}'")
                if self._action_blocked == "block":
                    is_blocked = True

        # 4. 特殊字符转义
        for char in self._escape_chars:
            if char in sanitized:
                findings.append(f"转义控制字符: 0x{ord(char):02x}")
                sanitized = sanitized.replace(char, f"\\x{ord(char):02x}")

        # 5. 可疑内容清除
        is_suspicious = len(findings) > 0 and not is_blocked
        if is_suspicious and self._action_suspicious == "sanitize":
            sanitized = self._remove_suspicious_content(sanitized)
        elif is_blocked:
            sanitized = ""  # 拦截时不返回内容

        result = SanitizerResult(
            sanitized=sanitized,
            is_suspicious=is_suspicious,
            is_blocked=is_blocked,
            findings=findings,
            original_length=original_length,
            sanitized_length=len(sanitized),
            original_preview=original_preview,
        )

        # 审计日志
        if self._audit_enabled and (is_suspicious or is_blocked):
            self._write_audit_log(result)

        return result

    def is_safe(self, raw_input: str) -> bool:
        """快速检查输入是否安全（无过滤，纯检测）。"""
        result = self.sanitize(raw_input)
        return not result.is_blocked and not result.is_suspicious

    # ------------------------------------------------------------------
    # Private
    # ------------------------------------------------------------------

    def _remove_suspicious_content(self, text: str) -> str:
        """移除匹配关键词的行——保守策略，匹配行整行删除。"""
        lines = text.splitlines(keepends=True)
        result_lines: list[str] = []
        for line in lines:
            lower = line.lower()
            should_keep = True
            for kw in self._blocked_keywords:
                if kw in lower:
                    should_keep = False
                    break
            if should_keep:
                for pat in self._blocked_patterns:
                    if pat.search(line):
                        should_keep = False
                        break
            if should_keep:
                result_lines.append(line)
        return "".join(result_lines)

    def _write_audit_log(self, result: SanitizerResult) -> None:
        """写入审计日志文件。"""
        log_dir = self._audit_log_dir or os.path.join(
            self._project_root, "logs", "sanitizer"
        )
        os.makedirs(log_dir, exist_ok=True)
        log_file = os.path.join(log_dir, "audit.jsonl")

        try:
            import json

            entry = result.to_log_dict()
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.error("写入审计日志失败: %s", e)


# ------------------------------------------------------------------
# 便捷函数
# ------------------------------------------------------------------

_default_sanitizer: Optional[InputSanitizer] = None


def get_sanitizer(project_root: Optional[str] = None) -> InputSanitizer:
    """获取全局单例 InputSanitizer。"""
    global _default_sanitizer
    if _default_sanitizer is None:
        _default_sanitizer = InputSanitizer(project_root=project_root)
    return _default_sanitizer
