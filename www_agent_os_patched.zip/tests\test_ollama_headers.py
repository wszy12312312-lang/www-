import os
import importlib


def _reload_config_and_service():
    """确保 config 读取当前环境变量，然后 reload services 模块。"""
    import config.app_config as app_config
    importlib.reload(app_config)
    import services.ollama_service as osrv
    importlib.reload(osrv)
    return osrv


def test_bearer_header(monkeypatch):
    """OLLAMA_AUTH_SCHEME=bearer 时发送 Bearer 令牌。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "secret123")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "bearer")
    osrv = _reload_config_and_service()
    sys = osrv.WWWSystem()
    headers = sys._get_ollama_headers()
    assert headers.get("Authorization") == "Bearer secret123"
    assert headers.get("Content-Type") == "application/json"


def test_basic_header(monkeypatch):
    """OLLAMA_AUTH_SCHEME=basic 时发送 Basic 令牌。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "basickey")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "basic")
    osrv = _reload_config_and_service()
    sys = osrv.WWWSystem()
    headers = sys._get_ollama_headers()
    assert headers.get("Authorization") == "Basic basickey"


def test_raw_header(monkeypatch):
    """OLLAMA_AUTH_SCHEME=raw 时发送原始令牌。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "rawkey")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "raw")
    osrv = _reload_config_and_service()
    sys = osrv.WWWSystem()
    headers = sys._get_ollama_headers()
    assert headers.get("Authorization") == "rawkey"


def test_no_key(monkeypatch):
    """未设置 OLLAMA_API_KEY 时不发送 Authorization 头。"""
    monkeypatch.delenv("OLLAMA_API_KEY", raising=False)
    monkeypatch.delenv("OLLAMA_AUTH_SCHEME", raising=False)
    osrv = _reload_config_and_service()
    sys = osrv.WWWSystem()
    headers = sys._get_ollama_headers()
    assert "Authorization" not in headers


def test_default_scheme_is_bearer(monkeypatch):
    """未设置 OLLAMA_AUTH_SCHEME 时默认使用 Bearer。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "default-token")
    monkeypatch.delenv("OLLAMA_AUTH_SCHEME", raising=False)
    osrv = _reload_config_and_service()
    sys = osrv.WWWSystem()
    headers = sys._get_ollama_headers()
    assert headers.get("Authorization") == "Bearer default-token"


def test_unknown_scheme_falls_back_to_bearer(monkeypatch):
    """未知 OLLAMA_AUTH_SCHEME 时回退为 Bearer。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "token-x")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "unknown")
    osrv = _reload_config_and_service()
    sys = osrv.WWWSystem()
    headers = sys._get_ollama_headers()
    assert headers.get("Authorization") == "Bearer token-x"


def test_scheme_case_insensitive(monkeypatch):
    """OLLAMA_AUTH_SCHEME 大小写不敏感。"""
    monkeypatch.setenv("OLLAMA_API_KEY", "case-token")
    monkeypatch.setenv("OLLAMA_AUTH_SCHEME", "BEARER")
    osrv = _reload_config_and_service()
    sys = osrv.WWWSystem()
    headers = sys._get_ollama_headers()
    assert headers.get("Authorization") == "Bearer case-token"
