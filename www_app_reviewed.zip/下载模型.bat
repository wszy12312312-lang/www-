@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo [%date% %time%] Starting model downloads...

echo [1/3] Pulling qwen2.5-coder:1.5b (S2)...
ollama pull qwen2.5-coder:1.5b
if %errorlevel% neq 0 echo [FAIL] qwen2.5-coder:1.5b & goto :next1
echo [OK] qwen2.5-coder:1.5b
:next1

echo [2/3] Pulling llama3.2:3b (S3)...
ollama pull llama3.2:3b
if %errorlevel% neq 0 echo [FAIL] llama3.2:3b & goto :next2
echo [OK] llama3.2:3b
:next2

echo [3/3] Pulling qwen2.5:3b (S4)...
ollama pull qwen2.5:3b
if %errorlevel% neq 0 echo [FAIL] qwen2.5:3b & goto :done
echo [OK] qwen2.5:3b
:done

echo [%date% %time%] All downloads finished.
echo. && echo Press any key to close... && pause >nul
