"""
www 多人格系统 v10.7.0 - 核心逻辑
每人格独立 Ollama 模型，独立对话历史
"""
import json
import os
import re
import time
from datetime import datetime
from dataclasses import dataclass, field
from typing import Optional

import requests

from config import OLLAMA_HOST, PERSONA_MODELS, PERSONAS, SKILL_DIR, MEMORY_DIR


@dataclass
class PersonaState:
    persona_id: str
    incentive_stars: int = 3
    penalty_stars: int = 0
    task_count: int = 0
    task_score: float = 0.0
    history: list = field(default_factory=list)
    model_online: Optional[bool] = None  # None=未检查, True=正常, False=异常
    memory_ok: Optional[bool] = None    # None=未检查, True=正常, False=异常
    score_history: list = field(default_factory=list)  # 评分历史
    recent_comments: list = field(default_factory=list)  # 监督员最近评语

    @property
    def net_incentive(self) -> int:
        return self.incentive_stars - self.penalty_stars

    @property
    def status_text(self) -> str:
        if self.net_incentive >= 3:
            return "激励状态"
        elif self.net_incentive <= -3:
            return "惩戒状态"
        return "正常"


class WWWSystem:
    def __init__(self):
        self.states: dict[str, PersonaState] = {}
        self.task_log: list = []
        self.current_persona: str = "host"
        self._running: bool = False
        self._checking: bool = False
        self.experiences: dict[str, list] = {}  # pid → 经验列表
        self._session = requests.Session()
        self._session.trust_env = False  # 绕过系统代理，直连 localhost
        self._init_states()
        self._load_skill_prompts()

    def _init_states(self):
        for pid in PERSONAS:
            self.states[pid] = PersonaState(persona_id=pid)
            self._load_persona_memory(pid)

    def check_all_models(self, progress_callback=None):
        """检查所有模型是否在线，更新 model_online 状态。
        progress_callback(pid, done_count, total) 每检查完一个模型时调用。"""
        self._checking = True
        total = len(PERSONA_MODELS)
        # 重置全部为 None（自检中）
        for s in self.states.values():
            s.model_online = None
            s.memory_ok = None

        try:
            resp = self._session.get(f"{OLLAMA_HOST}/api/tags", timeout=10)
            installed = {m["name"] for m in resp.json().get("models", [])}
        except Exception:
            installed = set()

        done = 0
        for pid, model in PERSONA_MODELS.items():
            state = self.states[pid]
            if model not in installed:
                state.model_online = False
                # 即使模型未安装，也要检查记忆文件
                self._check_persona_memory(pid)
                done += 1
                if progress_callback:
                    progress_callback(pid, done, total)
                continue
            try:
                test_resp = self._session.post(
                    f"{OLLAMA_HOST}/api/chat",
                    json={
                        "model": model,
                        "messages": [{"role": "user", "content": "ping"}],
                        "stream": False,
                        "options": {"num_predict": 1},
                    },
                    timeout=45,
                )
                state.model_online = test_resp.status_code == 200
            except Exception:
                state.model_online = False
            done += 1
            # 同步检查该人格的记忆状态
            self._check_persona_memory(pid)
            if progress_callback:
                progress_callback(pid, done, total)

        self._checking = False

    def mark_model_offline(self, persona_id: str):
        """标记指定人格的模型为离线"""
        if persona_id in self.states:
            self.states[persona_id].model_online = False

    def _check_persona_memory(self, pid: str):
        """检查单个人格的记忆文件是否正常可读写"""
        state = self.states[pid]
        try:
            mem_dir = self.get_persona_memory_dir(pid)
            # 检查 scores.json
            scores_path = os.path.join(mem_dir, "scores.json")
            if os.path.exists(scores_path):
                with open(scores_path, "r", encoding="utf-8") as f:
                    json.load(f)
            # 检查 history.json
            history_path = os.path.join(mem_dir, "history.json")
            if os.path.exists(history_path):
                with open(history_path, "r", encoding="utf-8") as f:
                    json.load(f)
            state.memory_ok = True
        except Exception:
            state.memory_ok = False

    def _load_skill_prompts(self):
        """从 SKILL.md 加载各人格系统提示词"""
        self.skill_prompts: dict[str, str] = {}
        skill_map = {
            "host": "host",
            "S1": "software-specialist",
            "S2": "system-specialist",
            "S3": "web-specialist",
            "S4": "file-specialist",
            "S5": "search-specialist",
            "S": "monitor-specialist",
            "S6": "chat-specialist",
        }
        for pid, dirname in skill_map.items():
            path = os.path.join(SKILL_DIR, dirname, "SKILL.md")
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                # 去掉 frontmatter
                content = re.sub(r'^---.*?---\s*', '', content, flags=re.DOTALL)
                self.skill_prompts[pid] = content[:8000]  # 截断以节省 token
            else:
                self.skill_prompts[pid] = f"你是 {PERSONAS[pid]['name']}，{PERSONAS[pid]['role']}。"

    def get_system_prompt(self, persona_id: str, user_query: str = "") -> str:
        """构建完整 system prompt"""
        meta = PERSONAS[persona_id]
        state = self.states[persona_id]
        skill = self.skill_prompts.get(persona_id, "")

        # 构建状态面板
        status_block = f"""
当前系统状态：
- 人格：{meta['name']}（{persona_id}）
- 激励星：{'★' * state.incentive_stars} | 惩戒星：{'★' * state.penalty_stars}
- 净激励：{state.net_incentive} | 状态：{state.status_text}
- 任务数：{state.task_count} | 均分：{state.task_score:.1f}
"""
        prompt = skill + "\n" + status_block

        # 注入监督员评语
        comments = self.inject_recent_comments(persona_id)
        if comments:
            prompt += "\n" + comments

        # 注入相关历史经验
        if user_query:
            experiences = self.search_similar_experiences(persona_id, user_query)
            if experiences:
                prompt += "\n" + experiences

        return prompt

    def chat(self, persona_id: str, user_message: str) -> tuple:
        """向指定人格发送消息，返回 (reply, reasoning) 元组"""
        model = PERSONA_MODELS.get(persona_id, "qwen2.5:7b")
        state = self.states[persona_id]
        system_prompt = self.get_system_prompt(persona_id, user_message)

        messages = [{"role": "system", "content": system_prompt}]
        # 保留最近 20 轮历史
        for h in state.history[-20:]:
            messages.append(h)
        messages.append({"role": "user", "content": user_message})

        try:
            resp = self._session.post(
                f"{OLLAMA_HOST}/api/chat",
                json={
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "include_reasoning": True,
                },
                timeout=120,
            )
            data = resp.json()
            msg = data.get("message", {})
            reply = msg.get("content", "")
            # qwen3 系列使用 thinking 字段，其他模型用 reasoning_content
            reasoning = msg.get("reasoning_content", "") or msg.get("thinking", "")

            # 修复：content 为空时降级重试
            if not reply and not reasoning:
                resp2 = self._session.post(
                    f"{OLLAMA_HOST}/api/chat",
                    json={
                        "model": model,
                        "messages": messages,
                        "stream": False,
                    },
                    timeout=120,
                )
                data2 = resp2.json()
                reply = data2.get("message", {}).get("content", "")
            # reply 为空但 reasoning 有内容 → 当前不触发降级，推理气泡正常但主气泡空白
            # 这是模型行为限制，已由 _add_bot_msg 空文本兜底处理

            state.model_online = True  # 调用成功，标记在线
        except Exception as e:
            state.model_online = False  # 调用失败，标记离线
            reply = f"[{model} 响应异常: {e}]"
            reasoning = ""

        # 保存历史
        state.history.append({"role": "user", "content": user_message})
        state.history.append({"role": "assistant", "content": reply})
        state.task_count += 1

        return reply, reasoning

    def host_dispatch(self, user_message: str) -> tuple[str, str]:
        """HOST 分析任务并调度到对应专员"""
        host_prompt = f"""你是 www 系统 HOST。分析以下用户消息，判断应该调度哪个专员。
回复格式：{{"persona": "S1"}} 或 {{"persona": "host"}}

专员映射：
S1-软件(安装/卸载/打开应用/APK/EXE)、S2-系统(配置/运维/代码/编程)、
S3-网络(网页/爬虫/浏览器)、S4-文件(文档/整理/转换/Excel/PPT)、
S5-检索(搜索/查资料/信息)、S6-聊天(闲聊/倾诉/日常)、S-监督(评分/质量/评估)、host-综合/调度

用户消息：{user_message}"""
        try:
            resp = self._session.post(
                f"{OLLAMA_HOST}/api/chat",
                json={
                    "model": PERSONA_MODELS["host"],
                    "messages": [{"role": "user", "content": host_prompt}],
                    "stream": False,
                },
                timeout=30,
            )
            data = resp.json()
            content = data.get("message", {}).get("content", "")
            match = re.search(r'"persona"\s*:\s*"(\w+)"', content)
            if match:
                return match.group(1), content
        except Exception:
            pass
        return "host", "调度默认"

    def s6_evaluate(self, persona_id: str, question: str, answer: str) -> dict:
        """S Supervise 评分"""
        s6_prompt = f"""你是 S Supervise。对以下回答评分（1-5星）。
四维标准：准确性40% + 完整性30% + 格式20% + 效率10%

用户问题：{question}
{persona_id} 的回答：{answer}

回复JSON格式：{{"accuracy": 4, "completeness": 3, "format": 4, "efficiency": 3, "overall": 3.5, "comment": "评语"}}"""
        try:
            resp = self._session.post(
                f"{OLLAMA_HOST}/api/chat",
                json={
                    "model": PERSONA_MODELS["S"],
                    "messages": [{"role": "user", "content": s6_prompt}],
                    "stream": False,
                },
                timeout=120,
            )
            data = resp.json()
            content = data.get("message", {}).get("content", "")
            result = self._extract_json(content)
            if result:
                # 追加评语到被评分人格的 recent_comments（最多 10 条）
                state = self.states[persona_id]
                state.recent_comments.append({
                    "score": result.get("overall", 3),
                    "comment": result.get("comment", ""),
                    "time": datetime.now().isoformat(),
                })
                if len(state.recent_comments) > 10:
                    state.recent_comments = state.recent_comments[-10:]
                return result
        except Exception:
            pass
        return {"overall": 3, "comment": "评分系统异常"}

    def _extract_json(self, text: str) -> Optional[dict]:
        """从模型回复中提取第一个有效 JSON 对象（支持嵌套和跨行，处理中文引号/单引号/尾逗号/注释）"""
        # 清洗：中文引号 → 英文、去注释行
        cleaned = text.replace('\u201c', '"').replace('\u201d', '"').replace('\u2018', "'").replace('\u2019', "'")
        cleaned = re.sub(r'//.*', '', cleaned)
        # 去尾逗号
        cleaned = re.sub(r',\s*}', '}', cleaned)
        cleaned = re.sub(r',\s*]', ']', cleaned)

        # 优先提取 markdown 代码块中的 JSON
        md_match = re.search(r'```(?:json)?\s*([\s\S]*?)```', cleaned)
        if md_match:
            try:
                return json.loads(md_match.group(1).strip())
            except json.JSONDecodeError:
                pass
        # 回退：逐字符匹配完整 JSON 对象（处理嵌套）
        start = cleaned.find('{')
        if start == -1:
            return None
        depth = 0
        for i in range(start, len(cleaned)):
            if cleaned[i] == '{':
                depth += 1
            elif cleaned[i] == '}':
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(cleaned[start:i+1])
                    except json.JSONDecodeError:
                        return None
        # 最后兜底：正则直接提取 overall 和 comment
        overall_match = re.search(r'"overall"\s*:\s*([\d.]+)', text)
        comment_match = re.search(r'"comment"\s*:\s*"([^"]*)"', text)
        if overall_match:
            return {
                "overall": float(overall_match.group(1)),
                "comment": comment_match.group(1) if comment_match else ""
            }
        return None

    def apply_score(self, persona_id: str, overall: float):
        """应用评分结果，仅对被评人格独立激励/惩戒"""
        state = self.states[persona_id]
        state.task_score = ((state.task_score * (state.task_count - 1)) + overall) / max(state.task_count, 1)

        if overall >= 4:
            state.incentive_stars = min(5, state.incentive_stars + 1)
        elif overall < 3:
            state.penalty_stars = min(5, state.penalty_stars + 1)

        # 记录评分历史
        state.score_history.append({
            "time": datetime.now().isoformat(),
            "overall": overall,
            "incentive_after": state.incentive_stars,
            "penalty_after": state.penalty_stars,
        })

        # 持久化保存
        self._save_persona_memory(persona_id)

    def get_status_report(self) -> str:
        lines = ["| 人格 | 名称 | 激励 | 惩戒 | 净激励 | 状态 | 任务 | 均分 |",
                 "|------|------|------|------|--------|------|------|------|"]
        for pid, meta in PERSONAS.items():
            s = self.states[pid]
            model = PERSONA_MODELS[pid]
            lines.append(
                f"| {pid} | {meta['name']} | {'★'*s.incentive_stars} | {'★'*s.penalty_stars} | "
                f"{s.net_incentive:+d} | {s.status_text} | {s.task_count} | {s.task_score:.1f} |"
            )
        return "\n".join(lines)

    def log_task(self, persona_id: str, question: str, answer: str, score: dict):
        entry = {
            "time": datetime.now().isoformat(),
            "persona": persona_id,
            "question": question[:200],
            "answer": answer[:500],
            "score": score,
        }
        self.task_log.append(entry)
        os.makedirs(MEMORY_DIR, exist_ok=True)
        log_path = os.path.join(MEMORY_DIR, "www_task_log.jsonl")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

        # 持久化记忆 + 压缩经验
        self.save_all_memories()
        self.compress_task_to_experience(persona_id, question, answer, score.get("overall", 3))

    # ========== 记忆持久化方法 ==========

    def get_persona_memory_dir(self, pid: str) -> str:
        """返回 memory/{pid}/ 路径，不存在则创建"""
        d = os.path.join(MEMORY_DIR, pid)
        os.makedirs(d, exist_ok=True)
        return d

    def _load_persona_memory(self, pid: str):
        """从 memory/{pid}/ 加载该人格的所有记忆文件。不存在则使用默认值。"""
        mem_dir = self.get_persona_memory_dir(pid)
        state = self.states[pid]

        # 加载 scores.json
        scores_path = os.path.join(mem_dir, "scores.json")
        if os.path.exists(scores_path):
            try:
                with open(scores_path, "r", encoding="utf-8") as f:
                    scores = json.load(f)
                state.incentive_stars = scores.get("incentive_stars", 3)
                state.penalty_stars = scores.get("penalty_stars", 0)
                state.task_count = scores.get("task_count", 0)
                state.task_score = scores.get("task_score", 0.0)
                state.score_history = scores.get("score_log", [])
            except Exception:
                pass

        # 加载 history.json（最多 100 条）
        history_path = os.path.join(mem_dir, "history.json")
        if os.path.exists(history_path):
            try:
                with open(history_path, "r", encoding="utf-8") as f:
                    state.history = json.load(f)[:100]
            except Exception:
                pass

        # 加载 experiences.json
        exp_path = os.path.join(mem_dir, "experiences.json")
        if os.path.exists(exp_path):
            try:
                with open(exp_path, "r", encoding="utf-8") as f:
                    self.experiences[pid] = json.load(f)
            except Exception:
                self.experiences[pid] = []
        else:
            self.experiences[pid] = []

    def _save_persona_memory(self, pid: str):
        """保存该人格的 scores.json 和 history.json。"""
        mem_dir = self.get_persona_memory_dir(pid)
        state = self.states[pid]

        # scores.json
        scores_path = os.path.join(mem_dir, "scores.json")
        scores = {
            "incentive_stars": state.incentive_stars,
            "penalty_stars": state.penalty_stars,
            "task_count": state.task_count,
            "task_score": state.task_score,
            "score_log": state.score_history,
        }
        with open(scores_path, "w", encoding="utf-8") as f:
            json.dump(scores, f, ensure_ascii=False, indent=2)

        # history.json
        history_path = os.path.join(mem_dir, "history.json")
        with open(history_path, "w", encoding="utf-8") as f:
            json.dump(state.history[-100:], f, ensure_ascii=False, indent=2)

    def _save_experiences(self, pid: str):
        """保存该人格的 experiences.json。"""
        mem_dir = self.get_persona_memory_dir(pid)
        exp_path = os.path.join(mem_dir, "experiences.json")
        with open(exp_path, "w", encoding="utf-8") as f:
            json.dump(self.experiences.get(pid, []), f, ensure_ascii=False, indent=2)

    def save_all_memories(self):
        """所有人格保存 scores + history。"""
        for pid in self.states:
            self._save_persona_memory(pid)

    def shutdown(self):
        """关闭系统时保存所有记忆。"""
        self.save_all_memories()

    def inject_recent_comments(self, persona_id: str) -> str:
        """从 state.recent_comments 取最近 3 条监督员评语，格式化为提示文本。"""
        state = self.states[persona_id]
        if not state.recent_comments:
            return ""
        lines = ["[监督员近期反馈]"]
        for c in state.recent_comments[-3:]:
            lines.append(f"- ★{c.get('score', '?')} | {c.get('comment', '')}")
        return "\n".join(lines)

    def search_similar_experiences(self, persona_id: str, query: str) -> str:
        """基于关键词匹配检索相关历史经验，返回 top 3。"""
        exps = self.experiences.get(persona_id, [])
        if not exps or not query:
            return ""

        # 简单 TF-like 匹配
        query_words = set(query.lower().split())
        scored = []
        for exp in exps:
            pattern = exp.get("task_pattern", "").lower()
            matches = sum(1 for w in query_words if w in pattern)
            if matches > 0:
                scored.append((matches, exp))
        scored.sort(key=lambda x: x[0], reverse=True)

        if not scored:
            return ""

        lines = ["[相关历史经验]"]
        for _, exp in scored[:3]:
            lines.append(
                f"- 任务: {exp.get('task_pattern', '')[:60]} | "
                f"方案: {exp.get('solution', '')[:60]} | "
                f"评分: ★{exp.get('score', '?')}"
            )
        return "\n".join(lines)

    def compress_task_to_experience(self, persona_id: str, question: str, answer: str, overall: float):
        """将本次任务压缩为一条经验并持久化。"""
        exp = {
            "task_pattern": question[:150],
            "solution": answer[:200],
            "outcome": f"评分 {overall}/5",
            "score": overall,
            "persona": persona_id,
            "time": datetime.now().isoformat(),
        }

        if persona_id not in self.experiences:
            self.experiences[persona_id] = []
        self.experiences[persona_id].append(exp)

        # 超过 50 条：保留最近 30 + top 20 高分
        exps = self.experiences[persona_id]
        if len(exps) > 50:
            exps.sort(key=lambda x: x.get("time", ""), reverse=True)
            recent = exps[:30]
            rest = exps[30:]
            rest.sort(key=lambda x: x.get("score", 0), reverse=True)
            self.experiences[persona_id] = recent + rest[:20]

        self._save_experiences(persona_id)
