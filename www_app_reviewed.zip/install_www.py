#!/usr/bin/env python3
"""
www 智能体 - 一键安装器 v2.0
中文 GUI 安装向导：硬件检测 → 方案推荐 → 选择路径 → 一键安装
"""
import os
import sys
import json
import time
import shutil
import subprocess
import threading
import urllib.request
import urllib.error
from datetime import datetime

# ---------- 第三方依赖自动安装 ----------
def _ensure_deps():
    deps = {"customtkinter": "customtkinter", "requests": "requests", "Pillow": "PIL"}
    missing = []
    for pip_name, import_name in deps.items():
        try:
            __import__(import_name)
        except ImportError:
            missing.append(pip_name)
    if missing:
        print(f"[安装器] 正在安装必要依赖: {', '.join(missing)}")
        for dep in missing:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", dep, "-q"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
        print("[安装器] 依赖安装完成，请重新运行本程序")
        sys.exit(0)

_ensure_deps()

import customtkinter as ctk
from tkinter import filedialog, messagebox
import requests

# ---------- 常量 ----------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 项目文件下载地址（独立运行时自动下载项目核心文件）
# 发布时替换为实际的 GitHub Releases 或其他直链地址
PROJECT_ZIP_URL = ""  # 发布时替换为实际下载地址；本地安装器同目录已有项目文件时自动使用本地复制

OLLAMA_DOWNLOAD_URL = "https://ollama.com/download/OllamaSetup.exe"
OLLAMA_API_BASE = "http://localhost:11434"

DEFAULT_INSTALL_DIR = os.path.join(os.path.expanduser("~"), "www")

# 人格-模型硬编码映射表
# 注意：HOST 指挥者是内置调度系统，始终使用 qwen3:14b，不在用户可选列表中
HOST_MODEL = "qwen3:14b"
PERSONA_MODEL_MAP = {
    "S1":    "qwen2.5-coder:7b",   # 软件专员
    "S2":    "qwen2.5-coder:1.5b", # 系统专员
    "S3":    "llama3.2:3b",        # 网络专员
    "S4":    "qwen2.5:3b",         # 文件专员
    "S5":    "deepseek-r1:7b",     # 检索专员
    "S":     "gemma3:12b",         # 监督员
    "S6":    "qwen2.5:7b",         # 聊天专员
}

PERSONA_NAMES = {
    "S1":   "S1（软件专员）",
    "S2":   "S2（系统专员）",
    "S3":   "S3（网络专员）",
    "S4":   "S4（文件专员）",
    "S5":   "S5（检索专员）",
    "S":    "S（监督员）",
    "S6":   "S6（聊天专员）",
}

# 三种安装方案定义
# HOST 指挥者模型（qwen3:14b）始终自动安装，不占用方案额度
PLANS = {
    "light": {
        "name": "轻量方案",
        "condition": "RAM < 16GB 或 无独立显卡",
        "desc": "适合轻办公/文档处理，包含文件 + 检索两个核心人格（+ 指挥者调度系统）",
        "approx_size": "约 5~8 GB（含指挥者模型）",
        "active_personas": ["S4", "S5"],
        "model_overrides": {},
    },
    "standard": {
        "name": "标准方案",
        "condition": "RAM 16~32GB，有独立显卡",
        "desc": "全部 7 个专员就位，覆盖软件/系统/网络/文件/检索全场景（+ 指挥者调度系统）",
        "approx_size": "约 20 GB（含全部模型）",
        "active_personas": ["S1", "S2", "S3", "S4", "S5", "S", "S6"],
        "model_overrides": {},
    },
    "premium": {
        "name": "旗舰方案",
        "condition": "RAM >= 32GB 且 GPU 显存 >= 8GB",
        "desc": "全部 7 个专员 + 更强模型变体，追求最高智能表现（+ 指挥者调度系统）",
        "approx_size": "约 36 GB（含更强模型推荐）",
        "active_personas": ["S1", "S2", "S3", "S4", "S5", "S", "S6"],
        "model_overrides": {
            "S1": "qwen3:32b",
            "S2": "qwen3:32b",
            "S3": "qwen3:32b",
        },
    },
}

PLAN_ORDER = ["light", "standard", "premium"]

# ---------- 硬件检测 ----------
def _run_powershell(script):
    """执行 PowerShell 脚本，返回 stdout"""
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            capture_output=True, text=True, timeout=15
        )
        return r.stdout.strip()
    except Exception:
        return ""

def detect_hardware():
    """全面检测硬件：CPU 型号+核心数、RAM、GPU 名称+显存（NVIDIA/AMD/Intel）"""
    info = {
        "cpu_model": "未知",
        "cpu_cores": os.cpu_count() or 1,
        "ram_gb": 0.0,
        "has_gpu": False,
        "gpu_name": "无独立显卡",
        "gpu_vram_gb": 0.0,
        "gpu_vendor": "",
        "disk_free_gb": 0.0,
    }

    # CPU 型号
    cpu = _run_powershell("(Get-CimInstance Win32_Processor).Name")
    if cpu:
        info["cpu_model"] = cpu

    # RAM
    try:
        import psutil
    except ImportError:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "psutil", "-q"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        import psutil
    info["ram_gb"] = round(psutil.virtual_memory().total / (1024 ** 3), 1)

    # 磁盘可用空间（安装目标盘符）
    info["disk_free_gb"] = round(psutil.disk_usage("C:\\").free / (1024 ** 3), 1)

    # GPU 检测：多源采集
    gpu_list = _detect_gpus()
    if gpu_list:
        dgpu = [g for g in gpu_list if g["vram_gb"] > 0]
        best = dgpu[0] if dgpu else gpu_list[0]
        info["gpu_name"] = best["name"]
        info["gpu_vram_gb"] = best["vram_gb"]
        info["gpu_vendor"] = best["vendor"]
        info["has_gpu"] = best["vram_gb"] > 0
    return info

def _detect_gpus():
    """多层 GPU 检测：PowerShell CIM + NVIDIA-SMI 补充精确显存"""
    gpus = []

    # 方法1：PowerShell Get-CimInstance（替代 WMIC，Win11 兼容）
    ps_cmd = (
        "Get-CimInstance Win32_VideoController "
        "| Select-Object Name, AdapterRAM, VideoMemoryType "
        "| ForEach-Object { '{0}|{1}|{2}' -f $_.Name, $_.AdapterRAM, $_.VideoMemoryType }"
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_cmd],
            capture_output=True, text=True, timeout=15,
            encoding="utf-8", errors="replace"
        )
        if result.returncode == 0:
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if not line:
                    continue
                parts = line.split("|")
                name = parts[0].strip()
                vram_bytes = int(parts[1]) if len(parts) > 1 and parts[1].strip().isdigit() else 0
                vram_gb = round(vram_bytes / (1024 ** 3), 1) if vram_bytes else 0.0

                vendor = ""
                name_lower = name.lower()
                if "nvidia" in name_lower or "geforce" in name_lower:
                    vendor = "NVIDIA"
                elif "amd" in name_lower or "radeon" in name_lower:
                    vendor = "AMD"
                elif "intel" in name_lower or "uhd" in name_lower or "iris" in name_lower or "arc" in name_lower:
                    vendor = "Intel"

                gpus.append({"name": name, "vram_gb": vram_gb, "vendor": vendor})
    except Exception:
        pass

    # 方法2：nvidia-smi 补充精确显存
    try:
        r = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=5
        )
        if r.returncode == 0:
            for nv_line in r.stdout.strip().split("\n"):
                nv_parts = [p.strip() for p in nv_line.split(",")]
                if len(nv_parts) >= 2:
                    try:
                        nv_name = nv_parts[0]
                        nv_vram_gb = round(float(nv_parts[1]) / 1024, 1)
                    except ValueError:
                        continue
                    matched = False
                    for g in gpus:
                        if "nvidia" in (g.get("vendor", "")).lower() or "geforce" in g["name"].lower():
                            g["vram_gb"] = nv_vram_gb
                            g["name"] = nv_name
                            g["vendor"] = "NVIDIA"
                            matched = True
                            break
                    if not matched:
                        gpus.append({"name": nv_name, "vram_gb": nv_vram_gb, "vendor": "NVIDIA"})
    except Exception:
        pass

    gpus.sort(key=lambda g: (0 if g["vram_gb"] > 0 else 1, -g["vram_gb"]))
    return gpus

def recommend_plan(hw):
    """根据硬件自动推荐方案"""
    ram = hw["ram_gb"]
    vram = hw["gpu_vram_gb"]
    has_dgpu = hw["has_gpu"]

    if ram >= 32 and vram >= 8:
        return "premium"
    elif ram >= 16 and has_dgpu:
        return "standard"
    else:
        return "light"

def check_ollama_installed():
    """检查 Ollama 服务是否在运行"""
    try:
        r = requests.get(f"{OLLAMA_API_BASE}/api/tags", timeout=4)
        return r.status_code == 200
    except Exception:
        return False

def get_ollama_version():
    """获取已安装 Ollama 版本"""
    try:
        r = subprocess.run(["ollama", "--version"], capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            return r.stdout.strip()
    except Exception:
        pass
    return "未知版本"


# ======================================================================
#  GUI 安装器
# ======================================================================
class InstallerGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("www 智能体 - 一键安装向导")
        self.geometry("750x800")
        self.minsize(680, 700)
        self.configure(fg_color="#0d1117")

        self.install_path = ctk.StringVar(value=DEFAULT_INSTALL_DIR)
        self.hw_info = None
        self.selected_plan_key = "light"
        self.installing = False
        self.cancel_requested = False
        self.model_check_vars = {}   # persona_key -> BooleanVar
        self.model_entry_vars = {}   # persona_key -> StringVar
        self.log_msgs = []

        self._build_ui()
        self._do_detect()

    # ========== UI 构建 ==========
    def _build_ui(self):
        # ---- 标题 ----
        title_frame = ctk.CTkFrame(self, fg_color="transparent")
        title_frame.pack(fill="x", padx=24, pady=(20, 8))
        ctk.CTkLabel(
            title_frame, text="www 智能体 安装向导",
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color="#FF6B35"
        ).pack(anchor="w")
        ctk.CTkLabel(
            title_frame,
            text="基于 Ollama 的多人格协作 AI 助手 — 自动检测硬件，智能推荐方案",
            font=ctk.CTkFont(size=12), text_color="#8b949e"
        ).pack(anchor="w", pady=(2, 0))

        # ---- 硬件信息 ----
        hw_label = ctk.CTkFrame(self, fg_color="#161b22", corner_radius=8)
        hw_label.pack(fill="x", padx=24, pady=(12, 4))
        ctk.CTkLabel(
            hw_label, text="  硬件检测结果",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#58a6ff"
        ).pack(padx=14, pady=(10, 6), anchor="w")

        self.hw_textbox = ctk.CTkTextbox(
            self, font=ctk.CTkFont(size=12, family="Consolas"),
            fg_color="#0d1117", text_color="#c9d1d9",
            corner_radius=8, height=110, wrap="word",
            border_width=1, border_color="#30363d"
        )
        self.hw_textbox.pack(fill="x", padx=24, pady=(0, 10))

        # ---- 安装路径 ----
        path_label = ctk.CTkFrame(self, fg_color="transparent")
        path_label.pack(fill="x", padx=24, pady=(6, 2))
        ctk.CTkLabel(
            path_label, text="安装路径",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#58a6ff"
        ).pack(side="left")
        ctk.CTkButton(
            path_label, text="浏览...", width=70, height=28,
            font=ctk.CTkFont(size=11), fg_color="#30363d",
            hover_color="#484f58", corner_radius=6,
            command=self._browse_path
        ).pack(side="right")

        self.path_entry = ctk.CTkEntry(
            self, textvariable=self.install_path,
            font=ctk.CTkFont(size=12), fg_color="#0d1117",
            text_color="#c9d1d9", corner_radius=6,
            border_width=1, border_color="#30363d"
        )
        self.path_entry.pack(fill="x", padx=24, pady=(0, 10))

        # ---- 方案选择 ----
        plan_label = ctk.CTkFrame(self, fg_color="#161b22", corner_radius=8)
        plan_label.pack(fill="x", padx=24, pady=(6, 4))
        ctk.CTkLabel(
            plan_label, text="  安装方案选择",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#58a6ff"
        ).pack(padx=14, pady=(10, 6), anchor="w")

        self.plan_var = ctk.IntVar(value=0)
        plan_radio_frame = ctk.CTkFrame(self, fg_color="transparent")
        plan_radio_frame.pack(fill="x", padx=24, pady=(0, 4))

        for idx, pkey in enumerate(PLAN_ORDER):
            plan = PLANS[pkey]
            label = f"{plan['name']}  —  {plan['desc']}（{plan['approx_size']}）"
            ctk.CTkRadioButton(
                plan_radio_frame, text=label, variable=self.plan_var, value=idx,
                font=ctk.CTkFont(size=12), text_color="#c9d1d9",
                fg_color="#FF6B35", hover_color="#e85d26",
                command=self._on_plan_changed
            ).pack(anchor="w", padx=16, pady=3)

        self.plan_hint_label = ctk.CTkLabel(
            self, text="", font=ctk.CTkFont(size=11), text_color="#8b949e"
        )
        self.plan_hint_label.pack(anchor="w", padx=40, pady=(0, 8))

        # ---- 模型勾选区 ----
        model_label = ctk.CTkFrame(self, fg_color="#161b22", corner_radius=8)
        model_label.pack(fill="x", padx=24, pady=(6, 4))
        ctk.CTkLabel(
            model_label, text="  模型详情（可手动勾选或修改模型名称）",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#58a6ff"
        ).pack(padx=14, pady=(10, 6), anchor="w")

        self.model_scroll = ctk.CTkScrollableFrame(
            self, fg_color="#0d1117", corner_radius=8,
            height=200, border_width=1, border_color="#30363d",
            scrollbar_button_color="#30363d",
            scrollbar_button_hover_color="#484f58"
        )
        self.model_scroll.pack(fill="x", padx=24, pady=(0, 8))
        self.model_inner = ctk.CTkFrame(self.model_scroll, fg_color="transparent")
        self.model_inner.pack(fill="both", expand=True)

        # ---- 进度条 ----
        self.progress = ctk.CTkProgressBar(
            self, fg_color="#21262d", progress_color="#FF6B35",
            corner_radius=6, height=14
        )
        self.progress.pack(fill="x", padx=24, pady=(6, 4))
        self.progress.set(0)

        self.status_label = ctk.CTkLabel(
            self, text="就绪 — 请选择方案后点击「开始安装」",
            font=ctk.CTkFont(size=12), text_color="#3fb950"
        )
        self.status_label.pack(anchor="w", padx=28, pady=(0, 4))

        # ---- 日志 ----
        log_label = ctk.CTkFrame(self, fg_color="#161b22", corner_radius=8)
        log_label.pack(fill="x", padx=24, pady=(6, 4))
        ctk.CTkLabel(
            log_label, text="  安装日志",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#58a6ff"
        ).pack(padx=14, pady=(10, 6), anchor="w")

        self.log_textbox = ctk.CTkTextbox(
            self, font=ctk.CTkFont(size=11, family="Consolas"),
            fg_color="#0d1117", text_color="#c9d1d9",
            corner_radius=8, height=150, wrap="word",
            border_width=1, border_color="#30363d"
        )
        self.log_textbox.pack(fill="both", expand=True, padx=24, pady=(0, 8))

        # ---- 底部按钮 ----
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=24, pady=(8, 16))

        self.cancel_btn = ctk.CTkButton(
            btn_frame, text="取消", width=100, height=38,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#30363d", hover_color="#484f58",
            corner_radius=8, command=self._on_cancel
        )
        self.cancel_btn.pack(side="left")

        self.install_btn = ctk.CTkButton(
            btn_frame, text="开始安装", width=160, height=38,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color="#FF6B35", hover_color="#e85d26",
            corner_radius=8, command=self._start_install
        )
        self.install_btn.pack(side="right")

    # ========== 检测与交互 ==========
    def _do_detect(self):
        self._log("正在检测硬件配置...")
        self.hw_info = detect_hardware()
        hw = self.hw_info

        lines = [
            f"CPU 型号: {hw['cpu_model']}",
            f"CPU 核心数: {hw['cpu_cores']}",
            f"内存 (RAM): {hw['ram_gb']} GB",
            f"显卡: {hw['gpu_name']}",
            f"显卡厂商: {hw['gpu_vendor'] if hw['gpu_vendor'] else '未知'}",
            f"显存 (VRAM): {hw['gpu_vram_gb']} GB",
            f"C 盘可用空间: {hw['disk_free_gb']} GB",
        ]
        self.hw_textbox.configure(state="normal")
        self.hw_textbox.delete("1.0", "end")
        self.hw_textbox.insert("end", "\n".join(lines))
        self.hw_textbox.configure(state="disabled")

        if check_ollama_installed():
            ver = get_ollama_version()
            self._log(f"Ollama 已安装（{ver}）")
        else:
            self._log("Ollama 未安装，将在安装过程中自动下载并静默安装")

        rec_key = recommend_plan(hw)
        self.selected_plan_key = rec_key
        idx = PLAN_ORDER.index(rec_key)
        self.plan_var.set(idx)
        self._on_plan_changed()

    def _browse_path(self):
        path = filedialog.askdirectory(
            title="选择安装目录",
            initialdir=self.install_path.get()
        )
        if path:
            self.install_path.set(path)

    def _on_plan_changed(self):
        idx = self.plan_var.get()
        self.selected_plan_key = PLAN_ORDER[idx]
        plan = PLANS[self.selected_plan_key]
        self.plan_hint_label.configure(
            text=f"适用条件：{plan['condition']}    |    预估磁盘占用：{plan['approx_size']}"
        )
        self._rebuild_model_list()

    def _rebuild_model_list(self):
        for w in self.model_inner.winfo_children():
            w.destroy()
        self.model_check_vars.clear()
        self.model_entry_vars.clear()

        plan = PLANS[self.selected_plan_key]

        # 表头
        header = ctk.CTkFrame(self.model_inner, fg_color="transparent")
        header.pack(fill="x", padx=8, pady=(4, 2))
        ctk.CTkLabel(
            header, text="人格", font=ctk.CTkFont(size=11, weight="bold"),
            text_color="#58a6ff", width=160
        ).pack(side="left", padx=4)
        ctk.CTkLabel(
            header, text="模型名称", font=ctk.CTkFont(size=11, weight="bold"),
            text_color="#58a6ff", width=220
        ).pack(side="left", padx=4)

        for persona_key in PERSONA_MODEL_MAP:
            base_model = PERSONA_MODEL_MAP[persona_key]
            if persona_key in plan["model_overrides"]:
                model_name = plan["model_overrides"][persona_key]
            else:
                model_name = base_model

            active = persona_key in plan["active_personas"]
            var = ctk.BooleanVar(value=active)

            row = ctk.CTkFrame(self.model_inner, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=1)

            cb = ctk.CTkCheckBox(
                row, text=PERSONA_NAMES.get(persona_key, persona_key),
                variable=var,
                font=ctk.CTkFont(size=12), text_color="#c9d1d9",
                fg_color="#FF6B35", hover_color="#e85d26",
                width=24, border_width=1
            )
            cb.pack(side="left", padx=4)

            entry_var = ctk.StringVar(value=model_name)
            entry = ctk.CTkEntry(
                row, textvariable=entry_var,
                font=ctk.CTkFont(size=11), fg_color="#161b22",
                text_color="#c9d1d9", corner_radius=4,
                border_width=1, border_color="#30363d", width=200
            )
            entry.pack(side="left", padx=4)

            self.model_check_vars[persona_key] = var
            self.model_entry_vars[persona_key] = entry_var

    def _log(self, msg: str):
        self.log_msgs.append(msg)
        self.after(0, self._flush_log)

    def _flush_log(self):
        self.log_textbox.configure(state="normal")
        self.log_textbox.delete("1.0", "end")
        self.log_textbox.insert("end", "\n".join(self.log_msgs[-60:]))
        self.log_textbox.see("end")
        self.log_textbox.configure(state="disabled")

    def _set_status(self, msg: str, color: str = "#d2991b"):
        self.status_label.configure(text=msg, text_color=color)

    # ========== 安装流程 ==========
    def _start_install(self):
        if self.installing:
            return

        selected = {}
        # 指挥者调度模型始终安装
        selected["host"] = HOST_MODEL
        for pk in PERSONA_MODEL_MAP:
            if self.model_check_vars.get(pk) and self.model_check_vars[pk].get():
                selected[pk] = self.model_entry_vars[pk].get().strip()

        if not selected:
            messagebox.showwarning("未选择模型", "请至少勾选一个人格模型后再安装。")
            return

        install_dir = self.install_path.get()

        # 磁盘空间预估
        try:
            import psutil
            free_gb = round(psutil.disk_usage(install_dir).free / (1024 ** 3), 1)
        except Exception:
            free_gb = 0
        unique_models = set(selected.values())
        est_gb = len(unique_models) * 6
        if free_gb > 0 and free_gb < est_gb:
            messagebox.showwarning(
                "磁盘空间不足",
                f"目标磁盘剩余空间 {free_gb} GB，预估需要约 {est_gb} GB。\n请更换安装路径或取消部分模型。"
            )
            return

        self.installing = True
        self.cancel_requested = False
        self.install_btn.configure(state="disabled", text="安装中...")
        self.cancel_btn.configure(text="中止安装", fg_color="#da3633", hover_color="#c42f2f")

        self._log("========== 开始安装 www 智能体 ==========")
        self._log(f"安装路径: {install_dir}")
        self._log(f"已选人格: {list(selected.keys())}")
        self._log(f"需拉取模型: {list(unique_models)}")

        threading.Thread(
            target=self._install_thread,
            args=(selected, install_dir),
            daemon=True
        ).start()

    def _on_cancel(self):
        if self.installing:
            self.cancel_requested = True
            self._log("用户请求中止安装，将在当前步骤完成后清理...")
            self.cancel_btn.configure(state="disabled", text="正在中止...")
        else:
            self.destroy()

    def _install_thread(self, selected_models: dict, install_dir: str):
        try:
            unique_models = list(dict.fromkeys(selected_models.values()))
            total_steps = 5 + len(unique_models)
            step = 0

            def _step(label):
                nonlocal step
                step += 1
                self._set_status(f"({step}/{total_steps}) {label}")
                self.after(0, lambda: self.progress.set(step / total_steps))
                if self.cancel_requested:
                    raise _CancelException()

            # Step 1: 创建安装目录
            _step("创建安装目录")
            os.makedirs(install_dir, exist_ok=True)

            # Step 2: 检查/安装 Ollama
            _step("检查/安装 Ollama")
            self._ensure_ollama()

            # Step 3: 拉取模型
            for model in unique_models:
                _step(f"拉取模型 {model}")
                self._pull_model(model)
                self._log(f"模型 {model} 拉取完成")

            # Step 4: 安装依赖
            _step("安装 Python 依赖")
            self._install_pip_deps()

            # Step 5: 复制项目文件
            _step("复制项目文件")
            self._copy_project_files(install_dir)

            # Step 6: 写入安装信息
            _step("写入安装配置")
            info = {
                "install_path": install_dir,
                "models": unique_models,
                "model_map": selected_models,
                "plan": self.selected_plan_key,
                "created": datetime.now().isoformat(),
            }
            info_path = os.path.join(install_dir, "install_info.json")
            with open(info_path, "w", encoding="utf-8") as f:
                json.dump(info, f, ensure_ascii=False, indent=2)

            # Step 7: 创建启动脚本与快捷方式
            _step("创建启动脚本与快捷方式")
            self._create_launcher_vbs(install_dir)
            self._create_desktop_shortcut(install_dir)

            # 完成
            self.after(0, lambda: self.progress.set(1.0))
            self._set_status("安装完成！", "#3fb950")
            self._log("========== www 智能体 安装完成 ==========")
            self._log(f"安装目录: {install_dir}")
            self._log(f"已安装模型: {unique_models}")
            self._log("双击桌面「www智能」快捷方式即可启动")
            self._on_install_finished(install_dir, aborted=False)

        except _CancelException:
            self._log("安装已中止，正在清理...")
            self._cleanup_install(install_dir)
            self._on_install_finished(install_dir, aborted=True)
        except Exception as e:
            self._log(f"安装失败: {e}")
            self._set_status("安装失败", "#f85149")
            self._cleanup_install(install_dir)
            self._on_install_finished(install_dir, aborted=True)

    def _on_install_finished(self, install_dir: str, aborted: bool):
        self.installing = False
        self.after(0, lambda: self.install_btn.configure(
            state="normal", text="安装完成" if not aborted else "开始安装"
        ))
        self.after(0, lambda: self.cancel_btn.configure(
            text="关闭", fg_color="#30363d", hover_color="#484f58",
            command=self.destroy
        ))
        if not aborted:
            self.after(100, lambda: messagebox.showinfo(
                "安装完成",
                f"www 智能体已成功安装到：\n{install_dir}\n\n双击桌面「www智能」快捷方式即可启动。"
            ))

    def _cleanup_install(self, install_dir: str):
        """中止时清理已下载内容"""
        if os.path.isdir(install_dir):
            for item in os.listdir(install_dir):
                item_path = os.path.join(install_dir, item)
                try:
                    if os.path.isdir(item_path):
                        shutil.rmtree(item_path, ignore_errors=True)
                    else:
                        os.remove(item_path)
                except Exception:
                    pass
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        lnk = os.path.join(desktop, "www智能.lnk")
        if os.path.exists(lnk):
            try:
                os.remove(lnk)
            except Exception:
                pass

    # ---------- 子步骤 ----------
    def _ensure_ollama(self):
        if check_ollama_installed():
            ver = get_ollama_version()
            self._log(f"Ollama 已就绪（{ver}）")
            return

        self._log("Ollama 未安装，正在下载安装包...")
        temp_dir = os.environ.get("TEMP", SCRIPT_DIR)
        installer_exe = os.path.join(temp_dir, "OllamaSetup.exe")

        try:
            urllib.request.urlretrieve(OLLAMA_DOWNLOAD_URL, installer_exe)
            self._log("Ollama 安装包下载完成")
        except Exception as e:
            raise RuntimeError(f"下载 Ollama 安装包失败: {e}")

        self._log("正在静默安装 Ollama（请稍候）...")
        try:
            subprocess.run([installer_exe, "/S"], check=True, timeout=300)
        except subprocess.TimeoutExpired:
            raise RuntimeError("Ollama 安装超时，请检查网络或手动安装")
        except Exception as e:
            raise RuntimeError(f"Ollama 安装失败: {e}")

        self._log("等待 Ollama 服务启动...")
        for retry in range(30):
            if self.cancel_requested:
                raise _CancelException()
            time.sleep(2)
            if check_ollama_installed():
                self._log("Ollama 服务已启动")
                return
        raise RuntimeError("Ollama 服务启动失败，请尝试手动启动")

    def _pull_model(self, model: str):
        self._log(f"正在拉取模型: {model} ...")
        try:
            proc = subprocess.Popen(
                ["ollama", "pull", model],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                if self.cancel_requested:
                    proc.terminate()
                    raise _CancelException()
                line = line.strip()
                if line:
                    self._log(f"  {line}")
            proc.wait()
            if proc.returncode != 0:
                raise RuntimeError(f"模型 {model} 拉取失败，返回码 {proc.returncode}")
        except FileNotFoundError:
            raise RuntimeError("未找到 ollama 命令，请确认 Ollama 安装成功")

    def _install_pip_deps(self):
        deps = ["customtkinter", "requests", "Pillow"]
        self._log(f"正在安装 Python 依赖: {', '.join(deps)}")
        for dep in deps:
            try:
                subprocess.check_call(
                    [sys.executable, "-m", "pip", "install", dep, "-q"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            except Exception:
                pass
        self._log("Python 依赖安装完成")

    def _copy_project_files(self, install_dir: str):
        """复制项目文件：优先用本地文件（安装器同目录），否则从网络下载"""
        essential = ["main.py", "www_core.py", "logo.ico"]
        local_ok = all(os.path.exists(os.path.join(SCRIPT_DIR, f)) for f in essential)

        if local_ok:
            exclude = {
                "install_www.py", "uninstall_www.py",
                "install_www.bat", "install_info.json",
                "www智能.lnk", "__pycache__",
            }
            copied = 0
            for item in os.listdir(SCRIPT_DIR):
                if item in exclude:
                    continue
                src = os.path.join(SCRIPT_DIR, item)
                dst = os.path.join(install_dir, item)
                try:
                    if os.path.isdir(src):
                        if os.path.exists(dst):
                            shutil.rmtree(dst, ignore_errors=True)
                        shutil.copytree(src, dst)
                    else:
                        shutil.copy2(src, dst)
                    copied += 1
                except Exception as e:
                    self._log(f"  复制失败: {item} — {e}")
            self._log(f"已从本地复制 {copied} 个项目文件到安装目录")
        else:
            self._log("安装器独立运行模式：正在从网络下载项目文件...")
            self._download_project_files(install_dir)

    def _download_project_files(self, install_dir: str):
        """从 PROJECT_ZIP_URL 下载项目文件并解压；URL 为空时提示用户手动复制"""
        if not PROJECT_ZIP_URL:
            raise RuntimeError(
                "未配置项目下载地址。请将 main.py、www_core.py、config.py 等核心文件"
                "复制到安装器同目录后重试，或手动将文件放入安装目录。"
            )
        import tempfile, zipfile
        zip_path = os.path.join(tempfile.gettempdir(), "www_project_tmp.zip")
        try:
            self._log(f"下载地址: {PROJECT_ZIP_URL}")
            urllib.request.urlretrieve(PROJECT_ZIP_URL, zip_path)
            self._log("下载完成，正在解压...")

            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(install_dir)
            self._log("项目文件解压完成")

            # 清理 zip
            try:
                os.remove(zip_path)
            except Exception:
                pass
        except Exception as e:
            self._log(f"网络下载失败: {e}")
            self._log("请确保安装器与项目文件放在同一目录，或检查网络连接后重试")
            raise

    def _create_launcher_vbs(self, install_dir: str):
        vbs_path = os.path.join(install_dir, "www智能.vbs")
        content = (
            'Set WshShell = CreateObject("WScript.Shell")\r\n'
            'Set fso = CreateObject("Scripting.FileSystemObject")\r\n'
            'WshShell.CurrentDirectory = fso.GetParentFolderName(WScript.ScriptFullName)\r\n'
            'WshShell.Run "pythonw.exe main.py", 0, False\r\n'
        )
        with open(vbs_path, "w", encoding="utf-8") as f:
            f.write(content)
        self._log("已生成启动脚本: www智能.vbs")

    def _create_desktop_shortcut(self, install_dir: str):
        try:
            import pythoncom
            from win32com.client import Dispatch
        except ImportError:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "pywin32", "-q"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            import pythoncom
            from win32com.client import Dispatch

        pythoncom.CoInitialize()
        try:
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            shortcut_path = os.path.join(desktop, "www智能.lnk")
            target = os.path.join(install_dir, "www智能.vbs")
            icon = os.path.join(install_dir, "logo.ico")
            if not os.path.exists(icon):
                icon = os.path.join(install_dir, "logo.png")

            shell = Dispatch("WScript.Shell")
            shortcut = shell.CreateShortcut(shortcut_path)
            shortcut.TargetPath = target
            shortcut.WorkingDirectory = install_dir
            shortcut.Description = "www 智能体 — 多人格协作 AI 助手"
            if os.path.exists(icon):
                shortcut.IconLocation = icon
            shortcut.Save()
            self._log("桌面快捷方式已创建: www智能.lnk")
        finally:
            pythoncom.CoUninitialize()


class _CancelException(Exception):
    """安装中止信号"""
    pass


# ======================================================================
if __name__ == "__main__":
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")
    app = InstallerGUI()
    app.mainloop()
