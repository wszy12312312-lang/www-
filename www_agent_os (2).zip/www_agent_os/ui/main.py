"""
www 智能体协作系统 v10.7.0 — Desktop GUI
界面风格高度还原 Web UI；自检对接 check_all_models
"""
from __future__ import annotations
import os, sys, threading, traceback
from datetime import datetime
from pathlib import Path

_UI_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _UI_DIR.parent
sys.path.insert(0, str(_PROJECT_ROOT))

import customtkinter as ctk

from services.ollama_service import WWWSystem
from config.app_config import PERSONAS, PERSONA_MODELS


# ═══════════════════════════════════════════════════
# 配色
# ═══════════════════════════════════════════════════
C = {
    "bg_main":          "#0d1117",
    "bg_panel":         "#161b22",
    "bg_card":          "#161b22",
    "bg_input":         "#0d1117",
    "bg_user_bubble":   "#1a2332",
    "bg_bot_bubble":    "#161b22",
    "text_primary":     "#c9d1d9",
    "text_secondary":   "#8b949e",
    "text_muted":       "#484f58",
    "border":           "#30363d",
    "border_light":     "#21262d",
    "accent_blue":      "#58a6ff",
    "accent_green":     "#3fb950",
    "accent_red":       "#da3633",
    "accent_orange":    "#d29922",
    "accent_cyan":      "#39d2c0",
    "btn_send":         "#1f6feb",
    "btn_send_hover":   "#388bfd",
}

FONT = {
    "title":    ("Microsoft YaHei UI", 15, "bold"),
    "heading":  ("Microsoft YaHei UI", 12, "bold"),
    "body":     ("Microsoft YaHei UI", 11),
    "small":    ("Microsoft YaHei UI", 10),
    "mono":     ("Consolas", 10),
    "mono_s":   ("Consolas", 9),
    "mono_xs":  ("Consolas", 8),
}


# ═══════════════════════════════════════════════════
# 后端桥接
# ═══════════════════════════════════════════════════
class BackendBridge:
    def __init__(self, system: WWWSystem):
        self.system = system

    def chat(self, persona_id: str, message: str, callback):
        def _run():
            try:
                reply, _ = self.system.chat(persona_id, message)
                callback(reply)
            except Exception as e:
                callback(f"[错误] {e}")
        threading.Thread(target=_run, daemon=True).start()

    def check_models(self, progress_callback):
        def _run():
            try:
                self.system.check_all_models(progress_callback=progress_callback)
            except Exception:
                traceback.print_exc()
        threading.Thread(target=_run, daemon=True).start()


# ═══════════════════════════════════════════════════
# 聊天气泡
# ═══════════════════════════════════════════════════
class ChatBubble(ctk.CTkFrame):
    def __init__(self, master, role: str, text: str, ts: str = "", **kw):
        is_user = (role == "user")
        bg = C["bg_user_bubble"] if is_user else C["bg_bot_bubble"]
        super().__init__(master, fg_color=C["bg_main"], corner_radius=0, **kw)

        inner = ctk.CTkFrame(self, fg_color=bg, corner_radius=10,
                             border_width=1, border_color=C["border_light"])
        inner.pack(fill="x", padx=8, pady=3)

        role_name = "你" if is_user else "www"
        role_color = C["accent_blue"] if is_user else C["accent_green"]
        header = ctk.CTkFrame(inner, fg_color="transparent")
        header.pack(fill="x", padx=10, pady=(8, 0))
        ctk.CTkLabel(header, text=role_name, font=FONT["small"],
                     text_color=role_color).pack(side="left")
        if ts:
            ctk.CTkLabel(header, text=ts, font=FONT["mono_xs"],
                         text_color=C["text_muted"]).pack(side="right")

        lbl = ctk.CTkLabel(
            inner, text=text, font=FONT["body"], text_color=C["text_primary"],
            wraplength=520, justify="left", anchor="w",
        )
        lbl.pack(fill="x", padx=12, pady=(4, 10))
        self._text_label = lbl


# ═══════════════════════════════════════════════════
# 角色状态卡片
# ═══════════════════════════════════════════════════
class PersonaCard(ctk.CTkFrame):
    def __init__(self, master, pid: str, info: dict, system: WWWSystem, **kw):
        super().__init__(master, fg_color=C["bg_card"], corner_radius=8,
                         border_width=1, border_color=C["border_light"], **kw)
        self.pid = pid
        self.info = info
        self.system = system
        color = info.get("color", C["accent_blue"])

        # 上方：图标 + 名称 + 状态
        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=10, pady=(10, 2))

        icon = ctk.CTkFrame(top, width=36, height=36, fg_color=color, corner_radius=6)
        icon.pack(side="left")
        icon.pack_propagate(False)
        ctk.CTkLabel(icon, text=info.get("icon", pid[0].upper()),
                     font=FONT["mono"], text_color="#fff").pack(expand=True)

        mid = ctk.CTkFrame(top, fg_color="transparent")
        mid.pack(side="left", fill="x", expand=True, padx=(10, 0))
        ctk.CTkLabel(mid, text=info.get("name", pid), font=FONT["heading"],
                     text_color=C["text_primary"]).pack(anchor="w")
        ctk.CTkLabel(mid, text=PERSONA_MODELS.get(pid, "?"), font=FONT["mono_s"],
                     text_color=C["text_muted"]).pack(anchor="w")

        self._badge = ctk.CTkLabel(top, text="自检中", font=FONT["mono_xs"],
                                   text_color=C["accent_orange"])
        self._badge.pack(side="right")

        # 健康度进度条
        bar_bg = ctk.CTkFrame(self, fg_color=C["border_light"], height=5, corner_radius=3)
        bar_bg.pack(fill="x", padx=10, pady=(6, 2))
        self._bar = ctk.CTkFrame(bar_bg, fg_color=color, height=5, corner_radius=3, width=10)
        self._bar.place(relx=0, rely=0, relheight=1, relwidth=0.1)

        # 底部：评分
        bot = ctk.CTkFrame(self, fg_color="transparent")
        bot.pack(fill="x", padx=10, pady=(2, 10))
        ctk.CTkLabel(bot, text="评分", font=FONT["small"],
                     text_color=C["text_secondary"]).pack(side="left")
        self._score_lbl = ctk.CTkLabel(bot, text="—", font=FONT["mono_s"],
                                       text_color=C["accent_green"])
        self._score_lbl.pack(side="right")

    def refresh(self):
        """刷新卡片状态，无 health_score 时从已有字段推算"""
        try:
            state = self.system.states[self.pid]
        except KeyError:
            return

        # 健康分：优先 health_score，否则基于 task_score * 20 或 incent_stars * 20
        score_raw = getattr(state, "health_score", None)
        if score_raw is not None:
            score = score_raw
        elif state.task_score > 0:
            score = round(state.task_score * 20)
        else:
            score = state.incentive_stars * 20
        score = min(max(score, 0), 100)

        if state.model_online is True:
            self._badge.configure(text="就绪", text_color=C["accent_green"])
            self._bar.configure(fg_color=C["accent_green"])
            self._bar.place(relwidth=score / 100.0)
            self._score_lbl.configure(text=f"+{score}")
        elif state.model_online is False:
            self._badge.configure(text="离线", text_color=C["accent_red"])
            self._bar.configure(fg_color=C["accent_red"])
            self._bar.place(relwidth=max(0.05, score / 100.0))
            self._score_lbl.configure(text=f"{score}")
        else:
            self._badge.configure(text="自检中", text_color=C["accent_orange"])
            self._bar.configure(fg_color=self.info.get("color", C["accent_orange"]))
            self._bar.place(relwidth=0.125)
            self._score_lbl.configure(text="...")


# ═══════════════════════════════════════════════════
# 主窗口
# ═══════════════════════════════════════════════════
class WWWApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("www 智能体协作系统 v10.7.0")
        self.geometry("1100x700")
        self.minsize(900, 540)
        self.configure(fg_color=C["bg_main"])
        ctk.set_appearance_mode("dark")
        try:
            ctk.set_default_color_theme("dark-blue")
        except Exception:
            pass
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.geometry(f"+{(sw - 1100) // 2}+{(sh - 700) // 2}")

        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.system = WWWSystem()
        self.bridge = BackendBridge(self.system)
        self._running = False
        self._persona_cards: dict[str, PersonaCard] = {}
        self._check_count = 0

        self._build_header()
        self._build_main_area()
        self._build_footer()

        self._add_system_msg("www v10.7.0 — 启动中，开始自检…")
        self.after(300, self._start_health_check)

    # ── 头部 ──────────────────────────────────────
    def _build_header(self):
        bar = ctk.CTkFrame(self, fg_color=C["bg_panel"], height=52, corner_radius=0)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        logo = ctk.CTkFrame(bar, width=30, height=30, corner_radius=15, fg_color="#f59e0b")
        logo.pack(side="left", padx=(14, 8), pady=11)
        logo.pack_propagate(False)
        ctk.CTkLabel(logo, text="W", font=FONT["mono"], text_color="#fff").pack(expand=True)

        ctk.CTkLabel(bar, text="www智能体", font=FONT["title"],
                     text_color=C["text_primary"]).pack(side="left")
        self._model_label = ctk.CTkLabel(bar, text=PERSONA_MODELS.get("host", ""),
                                         font=FONT["mono_s"], text_color=C["text_muted"])
        self._model_label.pack(side="left", padx=(6, 0))

        right = ctk.CTkFrame(bar, fg_color="transparent")
        right.pack(side="right", padx=12)

        skills_btn = ctk.CTkButton(
            right, text="技能库", width=72, height=28, font=ctk.CTkFont(size=11),
            fg_color=C["bg_card"], hover_color=C["border"], corner_radius=6,
            border_width=1, border_color=C["border_light"],
            text_color=C["text_secondary"], command=self._open_skills,
        )
        skills_btn.pack(side="right", padx=(6, 0))

        self._status_dot = ctk.CTkLabel(right, text="● 自检中", font=FONT["mono_xs"],
                                        text_color=C["accent_orange"])
        self._status_dot.pack(side="right")

    # ── 主区域 ────────────────────────────────────
    def _build_main_area(self):
        main = ctk.CTkFrame(self, fg_color="transparent")
        main.pack(fill="both", expand=True)
        main.grid_columnconfigure(0, weight=3)
        main.grid_columnconfigure(1, weight=1)
        main.grid_rowconfigure(0, weight=1)
        self._build_chat(main)
        self._build_sidebar(main)

    def _build_chat(self, parent):
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.grid(row=0, column=0, sticky="nsew", padx=(4, 2), pady=4)
        frame.grid_rowconfigure(0, weight=1)
        frame.grid_rowconfigure(1, weight=0)
        frame.grid_columnconfigure(0, weight=1)

        self._chat_scroll = ctk.CTkScrollableFrame(
            frame, fg_color="transparent",
            scrollbar_button_color=C["border"],
            scrollbar_button_hover_color=C["text_muted"],
        )
        self._chat_scroll.grid(row=0, column=0, sticky="nsew", pady=(4, 0))
        self._chat_scroll.grid_columnconfigure(0, weight=1)

        input_frame = ctk.CTkFrame(frame, fg_color=C["bg_panel"], corner_radius=10,
                                   border_width=1, border_color=C["border_light"])
        input_frame.grid(row=1, column=0, sticky="ew", padx=6, pady=(6, 8))

        inner = ctk.CTkFrame(input_frame, fg_color="transparent")
        inner.pack(fill="x", padx=8, pady=6)

        self._input = ctk.CTkTextbox(
            inner, font=FONT["body"], fg_color=C["bg_input"],
            text_color=C["text_primary"], height=48, corner_radius=8,
            activate_scrollbars=False, border_width=0,
        )
        self._input.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self._input.bind("<Return>", self._on_enter)
        self._input.bind("<Shift-Return>", lambda e: None)

        self._send_btn = ctk.CTkButton(
            inner, text="发送", width=68, height=36, font=FONT["body"],
            fg_color=C["btn_send"], hover_color=C["btn_send_hover"],
            command=self._send_message,
        )
        self._send_btn.pack(side="right")

    def _build_sidebar(self, parent):
        sidebar = ctk.CTkFrame(parent, fg_color=C["bg_panel"], corner_radius=8,
                               border_width=1, border_color=C["border_light"])
        sidebar.grid(row=0, column=1, sticky="nsew", padx=(2, 4), pady=4)

        hdr = ctk.CTkFrame(sidebar, fg_color="transparent")
        hdr.pack(fill="x", padx=12, pady=(12, 6))
        ctk.CTkLabel(hdr, text="状态检测表", font=FONT["heading"],
                     text_color=C["text_primary"]).pack(side="left")
        self._check_label = ctk.CTkLabel(hdr, text="自检中", font=FONT["mono_s"],
                                         text_color=C["accent_orange"])
        self._check_label.pack(side="right")

        self._sidebar_scroll = ctk.CTkScrollableFrame(
            sidebar, fg_color="transparent", scrollbar_button_color=C["border"],
        )
        self._sidebar_scroll.pack(fill="both", expand=True, padx=8)

        for pid, info in PERSONAS.items():
            card = PersonaCard(self._sidebar_scroll, pid, info, self.system)
            card.pack(fill="x", pady=2)
            self._persona_cards[pid] = card

        sep = ctk.CTkFrame(sidebar, fg_color=C["border_light"], height=1)
        sep.pack(fill="x", padx=12, pady=(8, 6))

        qhdr = ctk.CTkFrame(sidebar, fg_color="transparent")
        qhdr.pack(fill="x", padx=12, pady=(2, 2))
        ctk.CTkLabel(qhdr, text="任务队列", font=FONT["heading"],
                     text_color=C["text_primary"]).pack(side="left")
        ctk.CTkLabel(qhdr, text="0", font=FONT["mono_s"],
                     text_color=C["text_muted"]).pack(side="right")
        ctk.CTkLabel(sidebar, text="暂无待处理任务", font=FONT["small"],
                     text_color=C["text_muted"]).pack(pady=(0, 10))

        bot = ctk.CTkFrame(sidebar, fg_color="transparent")
        bot.pack(fill="x", padx=12, pady=(6, 10))
        ctk.CTkLabel(bot, text="Ollama 本地 · 8 模型独立运行",
                     font=FONT["mono_s"], text_color=C["text_muted"]).pack(side="left")

    # ── 底部 ──────────────────────────────────────
    def _build_footer(self):
        bar = ctk.CTkFrame(self, fg_color=C["bg_panel"], height=28, corner_radius=0)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        inner = ctk.CTkFrame(bar, fg_color="transparent")
        inner.pack(fill="x", padx=12, pady=4)
        ctk.CTkLabel(inner, text="● Ollama 本地", font=FONT["mono_xs"],
                     text_color=C["accent_green"]).pack(side="left")
        ctk.CTkLabel(inner, text="8 模型独立运行", font=FONT["mono_xs"],
                     text_color=C["text_muted"]).pack(side="left", padx=(4, 0))
        ctk.CTkLabel(inner, text="GPU 正常", font=FONT["mono_xs"],
                     text_color=C["text_muted"]).pack(side="right", padx=(8, 0))
        ctk.CTkLabel(inner, text="本地连接", font=FONT["mono_xs"],
                     text_color=C["text_muted"]).pack(side="right")

    # ── 发送消息 ──────────────────────────────────
    def _on_enter(self, event):
        if event.state & 0x4:
            return
        self._send_message()
        return "break"

    def _send_message(self):
        text = self._input.get("1.0", "end-1c").strip()
        if not text or self._running:
            return
        self._input.delete("1.0", "end")
        self._running = True
        self._send_btn.configure(state="disabled", text="…")

        ts = datetime.now().strftime("%H:%M")
        self._add_bubble("user", text, ts)

        self._thinking_bubble = ChatBubble(self._chat_scroll, "assistant", "思考中…", ts)
        self._thinking_bubble.pack(fill="x", pady=3)
        self._scroll_bottom()

        self.bridge.chat("host", text, self._on_reply)

    def _on_reply(self, reply: str):
        def _update():
            if hasattr(self, "_thinking_bubble") and self._thinking_bubble.winfo_exists():
                self._thinking_bubble._text_label.configure(text=reply)
            else:
                self._add_bubble("assistant", reply)
            self._running = False
            self._send_btn.configure(state="normal", text="发送")
            self._input.focus()
            self._scroll_bottom()
            self._safe_refresh()
        self.after(0, _update)

    # ── UI 辅助 ────────────────────────────────────
    def _add_bubble(self, role: str, text: str, ts: str = ""):
        ChatBubble(self._chat_scroll, role, text, ts).pack(fill="x", pady=3)

    def _add_system_msg(self, text: str, color: str = None):
        ctk.CTkLabel(self._chat_scroll, text=text, font=FONT["mono_s"],
                     text_color=color or C["text_muted"]).pack(pady=3)

    def _scroll_bottom(self):
        try:
            self._chat_scroll._parent_canvas.yview_moveto(1.0)
        except Exception:
            pass

    def _safe_refresh(self):
        """逐个 refresh 卡片，单张异常不影响其他"""
        for pid, card in self._persona_cards.items():
            try:
                card.refresh()
            except Exception:
                pass
        # 全局状态灯
        try:
            host_state = self.system.states.get("host")
            if host_state and host_state.model_online is True:
                self._status_dot.configure(text="● 就绪", text_color=C["accent_green"])
                self._check_label.configure(text="就绪", text_color=C["accent_green"])
            elif host_state and host_state.model_online is False:
                self._status_dot.configure(text="● 离线", text_color=C["accent_orange"])
                self._check_label.configure(text="离线", text_color=C["accent_orange"])
        except Exception:
            pass

    # ── 健康检查 ──────────────────────────────────
    def _start_health_check(self):
        self._check_count = 0
        total = len(PERSONA_MODELS)

        def _on_progress(pid, done, t):
            self._check_count = done
            def _update():
                self._add_system_msg(
                    f"自检: {pid} ({done}/{total})", C["accent_cyan"] if done < total else C["accent_green"]
                )
                self._safe_refresh()
                self._scroll_bottom()
                if done >= total:
                    self._add_system_msg("自检完成 — 所有智能体就绪", C["accent_green"])
            self.after(0, _update)

        self.bridge.check_models(_on_progress)
        # 自检仅执行一次；后续状态通过聊天回复后的 _safe_refresh 更新

    # ── 技能库 ────────────────────────────────────
    def _open_skills(self):
        from config.app_config import SKILL_DIR
        self._add_system_msg(f"技能库路径: {SKILL_DIR}", C["accent_cyan"])

    # ── 关闭 ──────────────────────────────────────
    def _on_close(self):
        try:
            self.system.shutdown()
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    app = WWWApp()
    app.mainloop()
