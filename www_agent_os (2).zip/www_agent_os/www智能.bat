﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo www v10.7.0 - Starting...
python -m pip install customtkinter requests Pillow -q 2>nul
cd ui
pythonw.exe legacy_gui.py
