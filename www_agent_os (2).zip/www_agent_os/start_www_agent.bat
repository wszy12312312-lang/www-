@echo off
chcp 65001 >nul 2>&1
title WWW Agent OS
setlocal enabledelayedexpansion

echo ========================================
echo   WWW Agent OS - Starting...
echo ========================================
echo.

:: ============================================================
:: Step 1: Smart Python Detection
:: ============================================================
set "PYTHON="

:: 1a. Known paths first (fastest, most reliable)
for %%P in (
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
) do (
    if exist %%P (
        set "PYTHON=%%~P"
        echo [INFO] Found Python at: %%~P
        goto :found
    )
)

:: 1b. Search %%LOCALAPPDATA%%\Programs\Python
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
    if exist "%%D\python.exe" (
        set "PYTHON=%%D\python.exe"
        echo [INFO] Found Python at: !PYTHON!
        goto :found
    )
)

:: 1c. Use PowerShell to find real Python (skip WindowsApps stubs)
echo [INFO] Searching for Python installations...
for /f "usebackq delims=" %%i in (
    `powershell -NoProfile -Command "Get-Command python -All 2>$null | ForEach-Object { $_.Source } | Where-Object { $_ -notmatch 'WindowsApps' -and (Test-Path $_) } | ForEach-Object { (Get-Item $_).Target 2>$null } | Where-Object { $_ } | Select-Object -First 1"`
) do (
    set "PYTHON=%%i"
)

if not "!PYTHON!"=="" (
    echo [INFO] Found Python at: !PYTHON!
    goto :found
)

:: 1d. Try python3 command
for /f "usebackq delims=" %%i in (`where python3 2^>nul`) do (
    echo %%i | findstr /i "WindowsApps" >nul
    if errorlevel 1 (
        set "PYTHON=%%i"
        echo [INFO] Found Python3 at: !PYTHON!
        goto :found
    )
)

:: 1e. Last resort: try python from PATH
for /f "usebackq delims=" %%i in (`where python 2^>nul`) do (
    set "PYTHON=%%i"
    echo !PYTHON! | findstr /i "WindowsApps" >nul
    if errorlevel 1 (
        echo [INFO] Using system PATH Python: !PYTHON!
        goto :found
    ) else (
        echo [WARNING] Only found WindowsApps stub: !PYTHON!
        echo [WARNING] This is not a real Python installation.
        echo.
        echo Please install Python 3.11+ from https://www.python.org/downloads/
        echo Or use: winget install Python.Python.3.12
        pause
        exit /b 1
    )
)

echo [ERROR] Python not found! Please install Python 3.11+ first.
echo Install from: https://www.python.org/downloads/
pause
exit /b 1

:found

:: ============================================================
:: Step 2: Verify Python version
:: ============================================================
for /f "tokens=2" %%v in ('"!PYTHON!" --version 2^>^&1') do (
    echo [INFO] Python version: %%v
)

:: ============================================================
:: Step 3: Change to project root
:: ============================================================
cd /d "%~dp0"
echo [INFO] Project root: %CD%
echo.

:: ============================================================
:: Step 4: Check host.py exists
:: ============================================================
if not exist "runtime\host.py" (
    echo [ERROR] runtime\host.py not found in %CD%
    echo Make sure you're running this script from the www_agent_os directory.
    pause
    exit /b 1
)

:: ============================================================
:: Step 5: Run host.py with stderr capture
:: ============================================================
echo [INFO] Starting WWW Agent OS...
echo.

"!PYTHON!" runtime\host.py 2>&1
set EXIT_CODE=%ERRORLEVEL%

if %EXIT_CODE% neq 0 (
    echo.
    echo ========================================
    echo   WWW Agent OS exited with code %EXIT_CODE%
    echo ========================================
    pause
    exit /b %EXIT_CODE%
)

echo.
echo ========================================
echo   WWW Agent OS has stopped.
echo ========================================
pause
exit /b 0
