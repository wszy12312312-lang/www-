"""
DIContainer — 依赖注入容器（H07 修复）

替代全局模块级单例，所有核心组件通过构造函数注入。

用法:
    from config.di_container import DIContainer

    container = DIContainer(project_root)
    container.sanitizer.sanitize(...)
    container.persona_manager.dispatch(...)

特性:
- 惰性初始化（首次访问时才创建实例）
- 线程安全（创建过程有锁保护）
- 可注入 mock 实例（测试友好）

版本: 1.0.0
"""

from __future__ import annotations

import threading
from typing import Any, Callable, Dict, Optional


class DIContainer:
    """集中式依赖注入容器。

    替代全局单例模式（_default_bus, _default_sanitizer 等），
    所有模块通过 `container.bus` / `container.sanitizer` 获取单例。
    """

    def __init__(self, project_root: str, mock_overrides: Optional[Dict[str, Any]] = None) -> None:
        self._project_root = project_root
        self._instances: Dict[str, Any] = {}
        self._factories: Dict[str, Callable[[], Any]] = {}
        self._lock = threading.RLock()

        # 注册默认工厂
        self._register_defaults()

        # 注入 mock 实例（测试用）
        if mock_overrides:
            self._instances.update(mock_overrides)

    def _register_defaults(self) -> None:
        """注册所有核心组件的惰性工厂函数。"""
        self._factories = {
            "bus": self._create_bus,
            "sanitizer": self._create_sanitizer,
            "persona_manager": self._create_persona_manager,
            "legacy_system": self._create_legacy_system,
            "event_bus": self._create_bus,
            "task_manager": self._create_task_manager,
            "tool_router": self._create_tool_router,
            "model_gateway": self._create_model_gateway,
            "memory_store": self._create_memory_store,
            "permission_layer": self._create_permission_layer,
            "flag_manager": self._create_flag_manager,
            "path_guard": self._create_path_guard,
            "download_verifier": self._create_download_verifier,
            "sandbox": self._create_sandbox,
        }

    # ------------------------------------------------------------------
    # 访问（惰性初始化）
    # ------------------------------------------------------------------

    def get(self, name: str) -> Any:
        """获取已注册的组件实例（惰性创建）。

        Args:
            name: 组件名（如 'bus', 'sanitizer'）。

        Returns:
            组件实例。

        Raises:
            KeyError: 未注册的组件名。
        """
        if name in self._instances:
            return self._instances[name]

        if name not in self._factories:
            raise KeyError(f"DI 组件未注册: {name}")

        with self._lock:
            # 双重检查
            if name in self._instances:
                return self._instances[name]

            instance = self._factories[name]()
            self._instances[name] = instance
            return instance

    def set(self, name: str, instance: Any) -> None:
        """直接注入组件实例（测试或自定义）。"""
        self._instances[name] = instance

    # ------------------------------------------------------------------
    # 便捷属性
    # ------------------------------------------------------------------

    def __getattr__(self, name: str) -> Any:
        """支持 container.bus, container.sanitizer 等属性访问。"""
        if name.startswith("_"):
            raise AttributeError(name)
        try:
            return self.get(name)
        except KeyError:
            raise AttributeError(f"DIContainer 中无组件 '{name}'")

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    def _create_bus(self):
        from events.bus import EventBus
        bus = EventBus(name="app")
        # M09: 启用持久化
        import os
        log_dir = os.path.join(self._project_root, "logs", "events")
        bus.enable_persistence(log_dir)
        return bus

    def _create_sanitizer(self):
        from core.input_sanitizer import InputSanitizer
        return InputSanitizer(project_root=self._project_root)

    def _create_persona_manager(self):
        from persona.manager import PersonaManager
        pm = PersonaManager(project_root=self._project_root)
        try:
            from config.app_config import PERSONAS, PERSONA_MODELS
            pm.load_from_dicts(PERSONAS, PERSONA_MODELS)
        except ImportError:
            pass
        return pm

    def _create_legacy_system(self):
        from services.ollama_service import WWWSystem
        return WWWSystem()

    def _create_task_manager(self):
        from task.manager import TaskManager
        return TaskManager(bus=self.get("bus"))

    def _create_tool_router(self):
        from tools.router import ToolRouter
        return ToolRouter(bus=self.get("bus"))

    def _create_model_gateway(self):
        from models.gateway import ModelGateway
        import os
        from config.app_config import OLLAMA_HOST, OLLAMA_API_KEY
        return ModelGateway(
            host=OLLAMA_HOST,
            api_key=OLLAMA_API_KEY,
            bus=self.get("bus"),
        )

    def _create_memory_store(self):
        from memory.store import MemoryStore
        import os
        storage_dir = os.path.join(self._project_root, "data", "memory")
        return MemoryStore(storage_dir=storage_dir, bus=self.get("bus"))

    def _create_permission_layer(self):
        from security.permission import PermissionLayer
        import os
        pl = PermissionLayer()
        policy_path = os.path.join(self._project_root, "security", "policy.yaml")
        if os.path.isfile(policy_path):
            pl.load_policy(policy_path)
        return pl

    def _create_flag_manager(self):
        from config.flag_manager import FlagManager
        return FlagManager(self._project_root)

    def _create_path_guard(self):
        from core.path_guard import PathGuard
        import os
        skills_root = os.path.join(self._project_root, "data", "skills")
        return PathGuard(allowed_root=skills_root)

    def _create_download_verifier(self):
        from core.download_verifier import DownloadVerifier
        return DownloadVerifier()

    def _create_sandbox(self):
        from security.sandbox import create_default_sandbox
        return create_default_sandbox()

    # ------------------------------------------------------------------
    # 健康检查
    # ------------------------------------------------------------------

    def health_report(self) -> dict:
        """所有已创建组件的健康报告。"""
        report = {}
        for name, instance in self._instances.items():
            if hasattr(instance, "check_health"):
                report[name] = instance.check_health()
            elif hasattr(instance, "is_online"):
                report[name] = instance.is_online
            else:
                report[name] = "created"
        return report

    def shutdown(self) -> None:
        """关闭所有组件。"""
        for instance in self._instances.values():
            if hasattr(instance, "close"):
                instance.close()
            elif hasattr(instance, "shutdown"):
                instance.shutdown()
        self._instances.clear()
