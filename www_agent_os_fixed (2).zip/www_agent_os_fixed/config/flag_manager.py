"""
FlagManager — 集中式 Feature Flag 管理（H05 修复）

替代 runtime/host.py 中 10 个分散的 @property getter，
所有 Flag 层级关系通过 YAML 配置定义，单点维护。

用法:
    from config.flag_manager import FlagManager
    flags = FlagManager(project_root)
    if flags.use_input_sanitizer:
        ...

层级关系（在 feature_flags.yaml 的 `flag_hierarchy` 段中定义）：
    USE_NEW_ARCH:
      children: [USE_NEW_HOST, USE_INPUT_SANITIZER, USE_PERSONA_MANAGER, ...]
      mode: override  # 父级=on → 所有子级=on

版本: 1.0.0
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional


class FlagManager:
    """集中式 Feature Flag 管理器。

    特性:
    - 从 YAML 加载 flags + 层级关系
    - 父级覆盖子级（override 模式）
    - 键值类型推断（bool / int / str）
    - 支持嵌套层级（最多 4 层：全量 → 链路 → 子系统 → 模块）
    """

    # 默认层级定义（无需额外配置即生效）
    DEFAULT_HIERARCHY: Dict[str, Any] = {
        "USE_NEW_ARCH": {
            "children": [
                "USE_NEW_HOST", "USE_INPUT_SANITIZER", "USE_NEW_PERSONA",
                "USE_PERSONA_MANAGER", "USE_NEW_PERSONA_SYSTEM",
                "USE_EVENT_BUS", "USE_TASK_MANAGER", "USE_TOOL_ROUTER",
                "USE_MODEL_GATEWAY", "USE_MEMORY_STORE",
            ],
            "mode": "override",
        },
        "USE_NEW_HOST": {
            "children": ["USE_INPUT_SANITIZER"],
            "mode": "override",
        },
        "USE_NEW_PERSONA": {
            "children": ["USE_PERSONA_MANAGER", "USE_NEW_PERSONA_SYSTEM"],
            "mode": "override",
        },
    }

    DEFAULT_FLAG_FILE = "feature_flags.yaml"

    def __init__(self, project_root: str) -> None:
        self._project_root = project_root
        self._flags: Dict[str, Any] = {}
        self._hierarchy: Dict[str, Any] = dict(self.DEFAULT_HIERARCHY)
        self._load()

    # ------------------------------------------------------------------
    # 加载
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """从 YAML 加载 flags 和层级定义。"""
        flags_path = os.path.join(self._project_root, self.DEFAULT_FLAG_FILE)
        if not os.path.isfile(flags_path):
            return

        parser = _SimpleYamlParser()
        raw = parser.parse_file(flags_path)

        # 分离 hierarchy 段和 flags 段
        for key, value in raw.items():
            if key == "flag_hierarchy":
                self._merge_hierarchy(value)
            elif key.startswith("USE_"):
                self._flags[key] = self._coerce(value)
            else:
                self._flags[key] = value

    def _merge_hierarchy(self, extra: Any) -> None:
        """合并额外的层级定义。"""
        if not isinstance(extra, dict):
            return
        for parent, config in extra.items():
            if parent not in self._hierarchy:
                self._hierarchy[parent] = {}
            existing = self._hierarchy[parent]
            if isinstance(config, dict):
                if "children" in config:
                    existing["children"] = config["children"]
                if "mode" in config:
                    existing["mode"] = config["mode"]

    @staticmethod
    def _coerce(value: Any) -> Any:
        """类型推断。"""
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            v = value.strip().lower()
            if v == "true":
                return True
            if v == "false":
                return False
            if v.isdigit():
                return int(v)
        return value

    # ------------------------------------------------------------------
    # Flag 查询（支持层级覆盖）
    # ------------------------------------------------------------------

    def get(self, flag_name: str, default: Any = False) -> Any:
        """获取 flag 值（考虑父级覆盖）。

        Args:
            flag_name: Flag 名称，如 'USE_NEW_HOST'。
            default: 默认值。

        Returns:
            Flag 值（bool / int / str）。
        """
        # 1. 直接值
        direct = self._flags.get(flag_name)
        if self._is_truthy(direct):
            return direct if direct is not None else default

        # 2. 检查父级覆盖
        resolved = self._resolve_parent(flag_name)
        if resolved is not None:
            return resolved

        # 3. 默认
        return direct if direct is not None else default

    def is_on(self, flag_name: str) -> bool:
        """检查 flag 是否开启。"""
        return bool(self.get(flag_name, False))

    def _resolve_parent(self, flag_name: str) -> Optional[Any]:
        """向上查找：如果任何父级为真，且模式为 override，返回 True。"""
        for parent, config in self._hierarchy.items():
            children = config.get("children", [])
            if flag_name in children:
                mode = config.get("mode", "override")
                if mode == "override":
                    parent_val = self._flags.get(parent)
                    if self._is_truthy(parent_val):
                        # 递归：父级也可能被更上层的 flag 覆盖
                        grandparent_val = self._resolve_parent(parent)
                        if grandparent_val is not None:
                            return grandparent_val
                        return parent_val
        return None

    @staticmethod
    def _is_truthy(val: Any) -> bool:
        """检查值是否「为真」。"""
        if val is None:
            return False
        if isinstance(val, bool):
            return val
        if isinstance(val, (int, float)):
            return val != 0
        if isinstance(val, str):
            return val.lower() not in ("", "false", "0", "no", "off")
        return bool(val)

    # ------------------------------------------------------------------
    # 修改
    # ------------------------------------------------------------------

    def set(self, flag_name: str, value: Any) -> None:
        """直接设置 flag 值（不持久化）。"""
        self._flags[flag_name] = value

    def reset_all(self) -> None:
        """重新加载 flags。"""
        self._flags.clear()
        self._load()

    # ------------------------------------------------------------------
    # 便捷属性（保持向后兼容）
    # ------------------------------------------------------------------

    def __getattr__(self, name: str) -> Any:
        """支持 flags.use_input_sanitizer 等点号访问。"""
        if name.startswith("use_") or name.startswith("USE_"):
            # 尝试 use_input_sanitizer → USE_INPUT_SANITIZER
            flag_name = name if name.startswith("USE_") else "USE_" + name[4:].upper()
            return self.get(flag_name)
        raise AttributeError(f"'FlagManager' 没有属性 '{name}'")

    # ------------------------------------------------------------------
    # 序列化
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """导出所有 flag 和层级关系。"""
        return {"flags": dict(self._flags), "hierarchy": dict(self._hierarchy)}

    def get_resolved_flags(self) -> Dict[str, Any]:
        """获取所有 flag 的解析后值。"""
        result: Dict[str, Any] = {}
        all_names = set(self._flags.keys())
        for h in self._hierarchy.values():
            all_names.update(h.get("children", []))
        for name in sorted(all_names):
            result[name] = self.get(name)
        return result

    def status_report(self) -> str:
        """生成 Markdown 格式的状态报告。"""
        lines = ["| Flag | Value |", "|------|-------|"]
        resolved = self.get_resolved_flags()
        for name in sorted(resolved):
            val = resolved[name]
            mark = "✓" if self._is_truthy(val) else "—"
            lines.append(f"| {name} | {mark} {val} |")
        return "\n".join(lines)


# ------------------------------------------------------------------
# 简单 YAML 解析器（零依赖）
# ------------------------------------------------------------------

class _SimpleYamlParser:
    """简单 YAML 解析器，仅处理 key: value 和嵌套 dict，不依赖 PyYAML。"""

    def parse_file(self, filepath: str) -> Dict[str, Any]:
        with open(filepath, "r", encoding="utf-8") as f:
            return self.parse(f.read())

    def parse(self, text: str) -> Dict[str, Any]:
        lines = text.split("\n")
        result: Dict[str, Any] = {}
        stack: List[Dict[str, Any]] = [result]
        indent_stack: List[int] = [-1]

        for raw_line in lines:
            line = raw_line.rstrip()
            if not line or line.lstrip().startswith("#"):
                continue

            stripped = line.lstrip()
            indent = len(line) - len(stripped)

            # 计算实际缩进（2 空格 = 1 级）
            level = indent // 2

            # 回退栈
            while level <= indent_stack[-1] and len(stack) > 1:
                stack.pop()
                indent_stack.pop()

            if ":" in stripped:
                comment = stripped.find(" #")
                if comment >= 0:
                    stripped = stripped[:comment].strip()
                key, _, value = stripped.partition(":")
                key = key.strip()
                value = value.strip().strip('"').strip("'")

                if value == "":
                    # 嵌套对象
                    new_dict: Dict[str, Any] = {}
                    stack[-1][key] = new_dict
                    stack.append(new_dict)
                    indent_stack.append(level)
                else:
                    # 叶子值
                    if value.lower() == "true":
                        stack[-1][key] = True
                    elif value.lower() == "false":
                        stack[-1][key] = False
                    elif value.isdigit():
                        stack[-1][key] = int(value)
                    else:
                        stack[-1][key] = value

        return result
