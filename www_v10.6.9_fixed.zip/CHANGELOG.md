﻿# www 变更记录


## v10.6.9 变更（2026-07-12）

### P0 紧急修复
- **P0-1** monitor/SKILL.md 添加 frontmatter（name/description/agent_created）
- **P0-2** host/SKILL.md §5.9 S7 激励分发 S1~S5 → S1~S5,S7
- **P0-3** registry.json 重置激励星（S1~S5,S7: 5→3/1→0; HOST: 2→3; S6: 2→3）
- **P0-4** 5 个文档末尾签名 v10.6.7→v10.6.9；README_SUPPLEMENT 标题同步

### P1 版本号统一
- **P1-5** MEMORY.md 全量更新（架构 7 副人格、S7 职责行、删除共享记忆模板）
- **P1-6** README.md 更新（打包目录、记忆文件列表 S1~S7、版本历史表补全）
- **P1-7** README_SUPPLEMENT.md 更新（目录添加 S7、记忆库 8 个、S7 行）
- **P1-8** SKILL_INSTALL_GUIDE.md 更新（路径变量化、chat-specialist 安装命令、S7 追加）

### P2 架构一致性修复
- **P2-9** host/SKILL.md 消息类型 "9种"→"11种"
- **P2-10** registry.json message_types 追加 "升级""分治"
- **P2-11** host/SKILL.md §5.8 阈值 ≤2星→<3星
- **P2-12** host/SKILL.md S7 调度覆盖（STATE-3 错误分支/空闲学习/记忆架构）
- **P2-13** monitor/SKILL.md §0.2 增加 S7 评分维度
- **P2-14** monitor/SKILL.md 题库新增 S7 题目（简单 3+复杂 3）
- **P2-15** host/SKILL.md §5.1 补充联动说明

### P3 文档清理
- **P3-16** README.md 内部矛盾修复（七人格→八人格）
- **P3-17** README_SUPPLEMENT.md 追加弃用共同记忆池提示
- **P3-18** registry.json _config.note 更新
- **P3-19** 6 个 SKILL.md frontmatter 追加 v10.6.9 标记

### 深度架构优化
- **DA-1** "观"层增加 3 条可检测规则（error→STATE-3、进度停滞、偏差量化）
- **DA-2** "合"层简化（去 DAG 拓扑排序+语义等价→格式标准化+冲突标记交用户）
- **DA-3** STATE-3 动态轮次上限（简单2/中等3/复杂5）+搜索角度切换表
- **DA-4** STATE-4 分治兜底简化
- **DA-5** 激励体系优化（非执行人格 floor×0.5、连续低分额外惩戒、深评加权）
- **DA-6** 即时评分会话批量模式
- **DA-7** CFM 超时优化（风险分级 120s/300s/120s、重试换通道）
- **DA-8** 记忆检查优化（取消每日/每周，保留月度+异常标记）
- **DA-9** 空闲学习优化（取消定时泛化爬网→按需学习）
- **DA-10** S6 独立定时器（每天+每周六 12:00 自行启动）
- **DA-11** S7 梯度逼近加固（偏好阈值35→45、对抗检查、α截断）
- **DA-12** 记忆退场机制（连续3次待恢复→归档、经验 TTL）
- **DA-13** S7 用户画像 base64 编码+隐私声明

### 影响范围
- ✅ skills/host/SKILL.md
- ✅ skills/monitor-specialist/SKILL.md
- ✅ skills/chat-specialist/SKILL.md
- ✅ skills/software-specialist/SKILL.md
- ✅ skills/system-specialist/SKILL.md
- ✅ skills/web-specialist/SKILL.md
- ✅ skills/file-specialist/SKILL.md
- ✅ skills/search-specialist/SKILL.md
- ✅ www_personas_registry.json
- ✅ VERSION.md
- ✅ README.md
- ✅ CHANGELOG.md
- ✅ README_SUPPLEMENT.md
- ✅ SKILL_INSTALL_GUIDE.md
- ✅ memory/MEMORY.md


## v10.6.8 变更（2026-07-12）

### 新增 S7 语音文字聊天专员

| 变更项 | 说明 |
|--------|------|
| 新增人格 | S7（chat-specialist），语音文字聊天专员 |
| 核心能力 | 实时对话记忆、用户交流偏好分析（语气/用词/话题/回复长度/情感倾向）、自适应人格调整（6维梯度逼近算法）、自动成长（初始期→探索期→适配期→稳定期）、智能上下文压缩（分层保留） |
| 双模态 | 支持语音和文字两种输入输出形态，模态自动匹配与切换 |
| 系统接入 | 纳入 HOST 调度状态机（STATE-1~5）、接受 S6 四层监察评分、遵循 v10.6.5+ 确认转发协议、拥有独立个人记忆库 |
| 空闲学习 | 对话系统/NLP/情感计算等方向自主爬网学习 |

### 文件变更

| 操作 | 文件 |
|------|------|
| 新增 | `skills/chat-specialist/SKILL.md`（完整技能定义：五层架构含自适应算法/压缩策略/成长机制等） |
| 新增 | `memory/www_memory_S7.md`（个人记忆库，含对话记忆/用户画像/人格演化/成长记录等 S7 专属章节） |
| 修改 | `www_personas_registry.json`（注册 S7，更新架构描述，版本→10.6.8） |
| 修改 | `VERSION.md`（v10.6.7 → v10.6.8） |
| 修改 | `README.md`（人格数 7→8，架构图更新，S7 描述补充） |
| 修改 | `CHANGELOG.md`（新增 v10.6.8 条目） |
| 修改 | `skills/host/SKILL.md`（人格花名册新增 S7、场景匹配表新增闲聊/倾诉场景、确认场景覆盖清单更新） |
| 修改 | `skills/monitor-specialist/SKILL.md`（动态人格列表维护增加 S7） |

### 影响范围

- ✅ skills/chat-specialist/SKILL.md（新增）
- ✅ memory/www_memory_S7.md（新增）
- ✅ www_personas_registry.json（注册 S7 + 架构描述更新）
- ✅ VERSION.md
- ✅ README.md
- ✅ CHANGELOG.md
- ✅ skills/host/SKILL.md
- ✅ skills/monitor-specialist/SKILL.md


## v10.6.7 变更（2026-07-12）

### 二次审查修复

| 变更项 | v10.6.6 | v10.6.7 | 说明 |
|--------|---------|---------|------|
| 版本号残留 | MEMORY.md 第12行仍显示 v10.6.4 | 修正为 v10.6.6 | 标题行版本号更新 |
| 真实数据清理 | memory/2026-05-25.md（241行）、2026-05-24.md（13行）含真实历史数据 | 清空为空白模板 | 部署安全 |
| 用户画像清理 | MEMORY.md 含真实用户偏好数据 | 替换为空白模板占位 | 隐私保护 |
| 残余引用 | MEMORY.md 更新包章节引用 v10.6.3 | 更新为 v10.6.7 | 引用一致性 |
| 模板章节补齐 | www_memory_host.md 缺失[用户回顾记录]/[确认请求历史记录]，含未定义[回答后评估记录]，底部重复[用户纠正记录] | 补充缺失章节，移除未定义章节，修复重复 | 模板一致性 |
| 模板章节补齐 | www_memory_S1~S6.md 各缺失2个章节 | 各补充[用户回顾记录]和[确认请求历史记录] | 模板一致性 |
| 全局版本统一 | 多处文件版本号残留 v10.6.6 | 统一更新为 v10.6.7 | VERSION/README/CHANGELOG/注册表/补充包/安装指南 |

### 影响范围

- ✅ memory/MEMORY.md（版本号修正、用户画像清理、更新包引用更新）
- ✅ memory/2026-05-25.md（真实数据清空）
- ✅ memory/2026-05-24.md（真实数据清空）
- ✅ memory/www_memory_host.md（章节补齐与清理）
- ✅ memory/www_memory_S1.md ~ S6.md（章节补齐，6个文件）
- ✅ VERSION.md（更新为 v10.6.7）
- ✅ README.md（版本号更新）
- ✅ README_SUPPLEMENT.md（版本号更新）
- ✅ SKILL_INSTALL_GUIDE.md（版本号更新）
- ✅ CHANGELOG.md（新增 v10.6.7 条目）
- ✅ www_personas_registry.json（版本号与架构描述更新）

---
## v10.6.6 变更（2026-07-12）

### 工程打磨 — 部署就绪化

| 变更项 | v10.6.5 | v10.6.6 | 说明 |
|--------|---------|---------|------|
| 版本号统一 | 多处版本号不一致（v10.6.4/v10.6.5混用） | 全系统统一为 v10.6.6 | VERSION.md、README、注册表等全部统一 |
| 硬编码路径 | {WORKSPACE_DIR}、{USERPROFILE} 等绝对路径 | 替换为 {WORKSPACE_DIR}、{USERPROFILE} 变量占位符 | 支持任意环境部署 |
| 模拟数据清理 | memory/ 目录含真实历史会话数据 | 替换为空白模板，标注待填充 | 部署时可根据需要填充 |
| 残余引用清理 | 多处引用已删除的 www_shared_memory.md、旧版打包目录名 | 全部更新为当前架构命名 | 代码和文档一致性 |

### 影响范围

- ✅ `VERSION.md`（更新为 v10.6.6）
- ✅ `README.md`（版本号与路径变量更新）
- ✅ `README_SUPPLEMENT.md`（版本号与路径变量更新）
- ✅ `SKILL_INSTALL_GUIDE.md`（打包目录名与路径变量更新）
- ✅ `CHANGELOG.md`（新增 v10.6.6 条目）
- ✅ `www_personas_registry.json`（版本号、路径变量、架构描述更新）
- ✅ `skills/*/SKILL.md`（7 个文件：变量说明与路径更新）
- ✅ `memory/*.md`（11 个文件：模拟数据清理为模板，路径变量化）

---

## v10.6.5 变更（2026-07-12）

### 确认流程重构 — 统一交由 HOST 处理

将所有确认操作的处理权从各副人格（S1~S5）统一收归至 HOST（主人格）。

| 变更项 | v10.6.4 | v10.6.5 |
|--------|---------|---------|
| 确认处理架构 | 各专员内部自行处理（各自实现确认弹窗/交互逻辑） | 统一经 HOST 集中确认处理 |
| HOST 新增能力 | 无形中确认逻辑 | §4.4 统一确认流程管理，支持确认请求/确认结果消息格式 |
| S1 软件专员 | 安装前自行报告确认 | 移除内部确认逻辑，发送确认请求至 HOST |
| S2 系统专员 | 高风险操作分步确认、自行确认 | 移除内部确认逻辑，发送确认请求至 HOST |
| S3 网络专员 | 权限弹窗自行处理 | 移除内部确认逻辑，发送确认请求至 HOST |
| S4 文件专员 | 删除/覆盖自行确认 | 移除内部确认逻辑，发送确认请求至 HOST |
| S5 检索专员 | — | 新增确认流程兼容性说明（通常不涉及确认操作） |

### 确认流程架构

- **请求格式**：`[Sx→HOST] 确认请求：CFM-{日期}-{时间}-{序列号}` 标准化消息
- **决策逻辑**：HOST 按风险等级（高/中/低）分级决策，支持同意/拒绝/修改参数三种处理
- **超时保护**：HOST 决策超时 60 秒，专员等待超时 300 秒
- **重试机制**：2 次降级重试（300s→120s→60s），超时后按风险等级降级处理
- **确认场景覆盖**：安装确认、卸载确认、覆盖确认、权限弹窗、配置变更确认、删除确认、批量操作确认等

### 通信协议扩展

`message_types` 从 7 种扩展为 9 种：
- 新增 `"确认请求"`（专员→HOST）
- 新增 `"确认结果"`（HOST→专员）

### 影响范围

- ✅ `skills/host/SKILL.md`（新增 §4.4 统一确认流程管理，含消息格式、决策表、超时重试、确认历史）
- ✅ `skills/software-specialist/SKILL.md`（移除内部确认逻辑，新增确认转发协议）
- ✅ `skills/system-specialist/SKILL.md`（移除内部确认逻辑，新增确认转发协议）
- ✅ `skills/web-specialist/SKILL.md`（移除内部确认逻辑，新增确认转发协议）
- ✅ `skills/file-specialist/SKILL.md`（移除内部确认逻辑，新增确认转发协议）
- ✅ `skills/search-specialist/SKILL.md`（新增确认流程兼容性说明）
- ✅ `www_personas_registry.json`（版本更新、通信协议扩展、新增 confirmation_protocol 配置块）

---

## v10.6.4 变更（2026-07-12）

### 三项核心变更

| 变更项 | v10.6.3 | v10.6.4 | 说明 |
|--------|---------|---------|------|
| 记忆库架构 | 个人记忆库 + 共同经验池 | 仅个人记忆库 | 去除共同经验池，所有经验仅存个人库 |
| 记忆审查 | 清理（评分<60删除） | 检查和恢复（不删除） | <60分标注「待恢复」，保留所有经验 |
| 惩戒规则 | 全员联动惩戒 | 仅个人惩戒 | <3星仅该回答人格惩戒+1，不连带其他人格 |

### 影响范围

- ✅ `skills/host/SKILL.md`（§3.2信息共享、§5.8-5.9评分惩戒、§6.1-6.8记忆库管理）
- ✅ `skills/monitor-specialist/SKILL.md`（§0.3联动规则、§0.4执行流程、§7.1-7.5记忆检查）
- ✅ `skills/software-specialist/SKILL.md` ~ `skills/search-specialist/SKILL.md`（上传规范）
- ✅ `www_personas_registry.json`（memory_mechanism、incentive_rules、architecture）
- ✅ `memory/www_memory_*.md`（7个个人记忆文件模板更新）
- ✅ `VERSION.md` / `MEMORY.md`（文档更新）
- ❌ `memory/www_shared_memory.md`（已删除）
- ❌ `www_shared_memory_template.md`（已删除）

---

## v10.6.3 变更记录（历史，仅供参考）

> **注意**：v10.6.4 已去除共同记忆池（`www_shared_memory.md`），以下 v10.6.3 升级步骤中涉及共享记忆的操作已不再需要。

## 📊 版本对比

| 项目 | v10.6.1 | v10.6.3 | 变更说明 |
|------|----------|----------|----------|
| 评分体系 | 单层（S6 评分） | 四层（即时+每日+每周+任务） | 新增三层评分 |
| 即时评分 | 无 | 有（S6评分→用户评分→综合评分） | 新增完整流程 |
| 用户参与 | 无 | 有（用户打分+回顾） | 新增用户回顾环节 |
| 全员联动 | 部分（仅每周深评） | 全部（四层均触发） | 扩展联动范围 |
| 个人记忆库 | 3 章节 | 4 章节（新增[用户回顾记录]） | 新增章节 |
| 共享记忆 | 无 [用户回顾记录] | 有（新增章节） | 新增章节 |
| host/SKILL.md | ~800 行 | 1416 行 | 新增四层评分流程 |
| monitor-specialist/SKILL.md | ~500 行 | ~800 行 | 新增第零层即时评分 |

---

## 🔄 升级影响范围

### 1. 必须更新

- ✅ `host/SKILL.md`（新增 §5.8 即时评分完整流程）
- ✅ `monitor-specialist/SKILL.md`（新增第零层即时评分）
- ✅ `www_personas_registry.json`（更新 architecture 字段）

### 2. 建议更新

- ⚠️ `www_memory_*.md`（个人记忆库模板，新增 [用户回顾记录] 章节）
- ⚠️ `README.md` / `VERSION.md`（更新文档）

### 3. 可选更新

- 📝 `skills/host/SKILL.md` §6.1（个人记忆库模板定义）

---

## 🔧 手动升级步骤

### 步骤 1：更新 host/SKILL.md

```bash
# 1. 打开 host/SKILL.md
edit {WORKSPACE_DIR}/skills/skills/host/SKILL.md

# 2. 新增 §5.8 即时评分完整流程（复制补充包中的 host/SKILL.md §5.8）
# 3. 更新 §5.9 即时激励/惩戒机制（复制补充包中的 host/SKILL.md §5.9）
# 4. 新增 §6.1 个人记忆库模板（复制补充包中的 host/SKILL.md §6.1）
```

### 步骤 2：更新 monitor-specialist/SKILL.md

```bash
# 1. 打开 monitor-specialist/SKILL.md
edit {WORKSPACE_DIR}/skills/skills/monitor-specialist/SKILL.md

# 2. 新增第零层：即时评分（§0.1 ~ §0.5）
# - 复制补充包中的 monitor-specialist/SKILL.md 第零层内容
# 3. 更新 §1.2 每日评估汇报格式（取最低分作为全员联动基准）
# 4. 更新 §2.4 每周深评联动映射（加入全员联动说明）
# 5. 更新 §3.2 任务评分全员联动触发表（6 行触发条件）
```

### 步骤 3：更新 www_shared_memory.md

```bash
# 1. 打开 www_shared_memory.md
edit {WORKSPACE_DIR}/skills/memory/www_shared_memory.md

# 2. 在 [共同经验池] 章节之前，新增 [用户回顾记录] 章节
# - 章节标题：## 用户回顾记录（v10.6.3 新增）
# - 格式说明：
#   - 回顾记录格式：REV-{YYYYMMDD}-{HHMMSS}
#   - 回顾记录链接到任务 ID
#   - 包含用户评分、用户回顾、改进方向
```

### 步骤 4：更新个人记忆库模板

```bash
# 1. 打开 host/SKILL.md §6.1
edit {WORKSPACE_DIR}/skills/skills/host/SKILL.md

# 2. 找到个人记忆库模板定义（§6.1）
# 3. 在 [任务执行记录] 章节之后，新增 [用户回顾记录] 章节
# - 章节标题：### 用户回顾记录（v10.6.3 新增）
# - 格式说明：同 www_shared_memory.md 的 [用户回顾记录] 章节
```

### 步骤 5：更新注册表

```bash
# 1. 打开 www_personas_registry.json
edit ~/www_personas_registry.json

# 2. 更新 version 字段为 "v10.6.3"
# 3. 更新 architecture 字段（追加 v10.6.3 描述）
```

### 步骤 6：验证升级结果

```bash
# 1. 重启 AI 会话
# 2. 输入：启动 www 系统
# 3. 检查 HOST 是否正常加载
# 4. 检查 S6 是否能进行即时评分
# 5. 检查 www_shared_memory.md 是否包含 [用户回顾记录] 章节
```

---

## 📦 补充包使用说明

### 方式一：完全导入（覆盖式）

适用于：对方没有记忆数据，或希望直接使用你的数据。

```bash
# 1. 解压补充包
unzip www_v10.6.3_supplement.zip -d {WORKSPACE_DIR}/www_supplement/

# 2. 备份现有记忆文件（可选）
mkdir -p {WORKSPACE_DIR}/skills/memory/backup/
cp {WORKSPACE_DIR}/skills/memory/www_* {WORKSPACE_DIR}/skills/memory/backup/
cp {WORKSPACE_DIR}/skills/memory/www_shared_memory.md {WORKSPACE_DIR}/skills/memory/backup/

# 3. 复制记忆文件到工作目录
cp {WORKSPACE_DIR}/www_supplement/memory/* {WORKSPACE_DIR}/skills/memory/

# 4. 参考注册表（不覆盖）
# 对比 www_personas_registry.json 与现有注册表，手动合并
```

### 方式二：经验合并（推荐）

适用于：对方已有记忆数据，只想合并经验池。

```bash
# 1. 解压补充包
unzip www_v10.6.3_supplement.zip -d {WORKSPACE_DIR}/www_supplement/

# 2. 打开双方 www_shared_memory.md
# - 你的文件：{WORKSPACE_DIR}/www_supplement/memory/www_shared_memory.md
# - 对方文件：{WORKSPACE_DIR}/skills/memory/www_shared_memory.md

# 3. 合并 [共同经验池] 章节
# - 将你的 EXP-20260525-001 ~ EXP-20260525-003 复制到对方文件
# - 避免重复 ID（如有冲突，重命名后复制）

# 4. 合并 [用户回顾记录] 章节（如有）
# - 将你的回顾记录复制到对方文件
```

---

## 📊 经验条目清单（v10.6.3）

### 学习经验（EXP-20260525-001 ~ EXP-20260525-014）

| ID | 来源 | 标签 | 说明 |
|----|------|------|------|
| EXP-20260525-001 | 自动学习 | #Python #运维 | Python 运维学习 |
| EXP-20260525-002 | 自动学习 | #Pandas #Excel | Pandas Excel 处理 |
| ... | ... | ... | ... |
| EXP-20260525-014 | 自动学习 | #AI #搜索优化 | AI 搜索优化 |

### 回答经验（EXP-ANS-20260525-001 ~ EXP-ANS-20260525-003）

| ID | 评分 | 标签 | 说明 |
|----|------|------|------|
| EXP-ANS-20260525-001 | 2 星 | #错误经验 #北疆 #旅游 | 北疆旅游回答不完整 |
| EXP-ANS-20260525-002 | 4 星 | #喀什 #自驾游 | 喀什路线规划详细 |
| EXP-ANS-20260525-003 | 3 星 | #机票查询 #和田 #济南 | 机票查询需浏览器自动化 |

---

## ❓ 常见问题

### Q1：对方使用 v10.6.1，能直接导入记忆文件吗？

**可以**，但需注意：
- v10.6.1 的 `www_shared_memory.md` 没有 [用户回顾记录] 章节，需手动添加
- v10.6.1 的 `host/SKILL.md` 没有即时评分流程，需手动更新
- 建议对方先升级到 v10.6.3 全量包，再导入记忆文件

### Q2：对方使用 v10.3，能直接导入记忆文件吗？

**不建议**，因为：
- v10.3 架构差异较大（无 S6 监察专员）
- 记忆文件格式可能不兼容
- 建议对方先升级到 v10.6.3 全量包

### Q3：如何避免经验 ID 冲突？

**方法**：
1. 检查双方经验 ID 是否有重复
2. 如有重复，重命名后复制（例如：EXP-20260525-001 改为 EXP-20260525-001-A）
3. 或者使用更复杂的 ID 格式（例如：EXP-{YYYYMMDD}-{HHMMSS}-{NNN}）

### Q4：如何验证记忆文件导入成功？

**方法**：
1. 重启 AI 会话
2. 输入：`启动 www 系统`
3. 检查 HOST 是否正常加载
4. 输入：`查看经验池`
5. 检查经验条目是否正确显示

---

## 📝 总结

| 项目 | 说明 |
|------|------|
| 补充包内容 | 记忆文件（含经验池）+ 注册表 + 文档 |
| 适用对象 | 已部署 www 智能体的大模型 |
| 导入方式 | 完全导入（覆盖式）或 经验合并（推荐） |
| 版本兼容性 | v10.6.2+ 部分兼容，v10.6.1- 需手动升级 |
| 注意事项 | 备份优先、避免 ID 冲突、验证导入结果 |

---

**版本**：v10.6.9  
**发布日期**：2026-07-12  
**开发者**：Claw  
**系统**：www 多人格协作智能系统
