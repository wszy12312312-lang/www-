﻿# www v10.6.9 记忆数据补充包

## 适用对象

**已部署 www 智能体的大模型**（无论版本），用于补全记忆、经验数据，无需覆盖现有 SKILL.md。

---

## 包含内容

```
www_v10.6.9_supplement/
├── README_SUPPLEMENT.md          # 本文件
├── CHANGELOG.md                 # 变更记录
├── www_personas_registry.json    # 人格注册表（参考）
└── memory/                      # 记忆/经验数据
    ├── www_memory_host.md        # HOST 个人记忆库
    ├── www_memory_S1.md         # S1 软件专员记忆库
    ├── www_memory_S2.md         # S2 系统专员记忆库
    ├── www_memory_S3.md         # S3 网络专员记忆库
    ├── www_memory_S4.md         # S4 文件专员记忆库
    ├── www_memory_S5.md         # S5 检索专员记忆库
    ├── www_memory_S6.md         # S6 监察专员记忆库
    ├── www_memory_S7.md         # S7 聊天专员记忆库
    └── www_task_log.md          # 任务日志
```

**注意**：v10.6.4 起弃用共同记忆池（`www_shared_memory.md`），所有经验仅存储在各人格个人记忆库中。v10.6.9 确认此架构不变。

---

## 使用方法

### 方式一：完全导入（覆盖式）

适用于：对方没有记忆数据，或希望直接使用你的数据。

```bash
# 1. 解压补充包
unzip www_v10.6.9_supplement.zip -d {WORKSPACE_DIR}/www_supplement/

# 2. 备份现有记忆文件（可选）
cp {WORKSPACE_DIR}/skills/memory/www_* {WORKSPACE_DIR}/skills/memory/backup/

# 3. 复制记忆文件到工作目录
cp {WORKSPACE_DIR}/www_supplement/memory/* {WORKSPACE_DIR}/skills/memory/

# 4. 参考注册表（可选，不覆盖）
# 对比 www_personas_registry.json 与现有注册表，手动合并
```

---

### 方式二：个人记忆库合并（推荐）

适用于：对方已有记忆数据，只想合并特定人格的经验。

```bash
# 1. 解压补充包
unzip www_v10.6.9_supplement.zip -d {WORKSPACE_DIR}/www_supplement/

# 2. 打开双方对应人格的个人记忆库
# - 你的文件：{WORKSPACE_DIR}/www_supplement/memory/www_memory_S5.md
# - 对方文件：{WORKSPACE_DIR}/skills/memory/www_memory_S5.md

# 3. 合并 [经验记忆] 章节
# - 将你的 EXP-20260525-001 ~ EXP-20260525-003 复制到对方文件
# - 避免重复 ID（如有冲突，重命名后复制）

# 4. 合并 [用户回顾记录] 章节（如有）
# - 将你的回顾记录复制到对方文件
```

---

### 方式三：仅导入经验 ID（最小化）

适用于：对方只想获取经验条目，不想导入完整记忆文件。

```bash
# 1. 解压补充包
unzip www_v10.6.9_supplement.zip -d {WORKSPACE_DIR}/www_supplement/

# 2. 查看各人格经验列表
grep "^- EXP-" {WORKSPACE_DIR}/www_supplement/memory/www_memory_S5.md
grep "^- EXP-" {WORKSPACE_DIR}/www_supplement/memory/www_memory_host.md

# 3. 手动复制需要的经验条目到对方对应人格的个人记忆库
```

---

## 数据说明

### 个人记忆库（8 个）

| 文件 | 人格 | 内容 |
|------|------|------|
| www_memory_host.md | HOST (Claw) | 用户偏好、项目背景、任务记录 |
| www_memory_S1.md | S1 软件专员 | 软件安装记录、用户偏好 |
| www_memory_S2.md | S2 系统专员 | 系统配置、运维记录 |
| www_memory_S3.md | S3 网络专员 | 网页抓取、浏览器自动化记录 |
| www_memory_S4.md | S4 文件专员 | 文件处理、格式转换记录 |
| www_memory_S5.md | S5 检索专员 | 搜索记录、信息聚合偏好 |
| www_memory_S6.md | S6 监察专员 | 评分记录、激励/惩戒星状态 |
| www_memory_S7.md | S7 聊天专员 | 对话记忆、用户画像、人格演化记录 |

每个个人记忆库包含以下章节：
- `[基本信息]`：人格 ID、名称、状态
- `[任务执行记录]`：历史任务记录
- `[经验记忆]`：经验条目（EXP-{YYYYMMDD}-{NNN}）
- `[用户回顾记录]`：用户评分与回顾意见
- `[评估记录]`：S6 评分结果

### 任务日志（www_task_log.md）

- 记录所有任务执行过程
- 含 S6 评分结果
- 含用户反馈记录

---

## 版本兼容性

| 对方版本 | 兼容性 | 说明 |
|---------|--------|------|
| v10.6.4 | 完全兼容 | 直接导入即可 |
| v10.6.3 | 部分兼容 | 个人记忆库格式相同，但对方有 www_shared_memory.md 可忽略或删除 |
| v10.6.2 | 部分兼容 | 经验格式相同，但缺少 [用户回顾记录] 章节，需手动添加 |
| v10.6.1 | 部分兼容 | 经验格式相同，但缺少四维评分标准，需手动更新 S6 |
| v10.3 | 不兼容 | 架构差异较大，建议对方先升级到 v10.6.4 全量包 |

---

## 手动合并步骤（详细）

### 步骤 1：备份对方现有数据

```bash
mkdir -p {WORKSPACE_DIR}/skills/memory/backup/
cp {WORKSPACE_DIR}/skills/memory/www_* {WORKSPACE_DIR}/skills/memory/backup/
```

### 步骤 2：合并个人记忆库

```bash
# 以 S5 检索专员为例：

# 1. 打开对方文件
edit {WORKSPACE_DIR}/skills/memory/www_memory_S5.md

# 2. 打开你的文件
edit {WORKSPACE_DIR}/www_supplement/memory/www_memory_S5.md

# 3. 复制 [经验记忆] 章节的经验条目
# - 从你的文件复制 EXP-20260525-001 ~ EXP-20260525-003
# - 粘贴到对方文件的 [经验记忆] 章节末尾
# - 注意避免 ID 冲突（如有冲突，重命名后复制）

# 4. 复制 [用户回顾记录] 章节（如果对方文件没有此章节）
# - 在你的文件中找到 [用户回顾记录] 章节
# - 复制到对方文件的 [经验记忆] 章节之后

# 5. 对其他人格（S1~S4, S6, HOST）重复上述步骤
```

### 步骤 3：验证合并结果

```bash
# 1. 检查个人记忆库格式
# - 确保章节标题格式正确（## 章节名）
# - 确保经验 ID 唯一

# 2. 重启 AI 会话，输入：
启动 www 系统
# - 检查是否正常加载所有记忆
# - 检查各人格经验是否正确显示
```

---

## 注意事项

1. **隐私保护**：记忆文件包含真实对话历史和用户信息，分享前请确认已清除敏感信息
2. **版本冲突**：如果对方使用旧版本（v10.6.3 或更早），导入记忆后建议升级到 v10.6.4 以获得完整功能
3. **ID 冲突**：如果双方经验 ID 冲突，需重命名后合并（例如：EXP-20260525-001 改为 EXP-20260525-001-A）
4. **备份优先**：合并前务必备份对方现有数据，以便回滚
5. **无共享记忆**：v10.6.4 不再使用 `www_shared_memory.md`，所有经验仅存个人记忆库

---

## 联系方式

如有问题或建议，请联系开发者。

---

**版本**：v10.6.9  
**发布日期**：2026-07-12  
**开发者**：Claw  
**系统**：www 多人格协作智能系统
