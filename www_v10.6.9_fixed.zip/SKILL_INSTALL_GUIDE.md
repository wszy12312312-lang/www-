﻿# www 多人格系统 - 技能安装指南

## 安装前准备

### 系统要求

- **AI 平台**：支持 Skill 工具的 AI 系统（如 WorkBuddy、OpenClaw 等）
- **文件系统**：可读写本地文件系统
- **技能系统**：支持调用自定义 Skill
- **Shell 环境**：Bash（Linux/macOS）或 PowerShell（Windows）

### 检查 Skill 工具可用性

在 AI 会话中输入：

```
/list-skills
```

或

```
/skills
```

如果看到技能列表，说明 Skill 工具可用。

## 安装方法

### 方法一：自动安装（推荐）

#### 步骤 1：确定技能目录

技能文件需要放到 AI 系统的技能目录。常见路径：

**WorkBuddy**：
```
{WORKSPACE_DIR}/skills/skills/
```

**OpenClaw**：
```
~/.openclaw/skills/
```

**其他系统**：
请参考对应系统的文档。

#### 步骤 2：复制技能文件

将 `www_v10.6.9_pack/skills/` 目录下的所有文件夹复制到技能目录：

**Linux/macOS**：
```bash
cd www_v10.6.9_pack/
cp -r skills/* {WORKSPACE_DIR}/skills/skills/
```

**Windows（PowerShell）**：
```powershell
cd www_v10.6.9_pack/
Copy-Item -Recurse -Force skills/* {WORKSPACE_DIR}/skills/skills/
```

#### 步骤 3：复制注册表

将 `www_personas_registry.json` 复制到工作目录：

**Linux/macOS**：
```bash
cp www_personas_registry.json {WORKSPACE_DIR}/
```

**Windows（PowerShell）**：
```powershell
Copy-Item www_personas_registry.json {WORKSPACE_DIR}\
```

#### 步骤 4：重启 AI 会话

重启后，系统会自动识别并加载所有人格。

#### 步骤 5：验证安装

在 AI 会话中输入：

```
启动 www 系统
```

如果看到 HOST 的欢迎信息和系统状态，说明安装成功。

### 方法二：手动安装（适合高级用户）

#### 步骤 1：创建技能目录

如果技能目录不存在，先创建：

**Linux/macOS**：
```bash
mkdir -p {WORKSPACE_DIR}/skills/skills/host
mkdir -p {WORKSPACE_DIR}/skills/skills/software-specialist
mkdir -p {WORKSPACE_DIR}/skills/skills/system-specialist
mkdir -p {WORKSPACE_DIR}/skills/skills/web-specialist
mkdir -p {WORKSPACE_DIR}/skills/skills/file-specialist
mkdir -p {WORKSPACE_DIR}/skills/skills/search-specialist
mkdir -p {WORKSPACE_DIR}/skills/skills/monitor-specialist
mkdir -p {WORKSPACE_DIR}/skills/skills/chat-specialist
```

**Windows（PowerShell）**：
```powershell
New-Item -ItemType Directory -Force -Path {WORKSPACE_DIR}/skills/skills/host
New-Item -ItemType Directory -Force -Path {WORKSPACE_DIR}/skills/skills/software-specialist
New-Item -ItemType Directory -Force -Path {WORKSPACE_DIR}/skills/skills/system-specialist
New-Item -ItemType Directory -Force -Path {WORKSPACE_DIR}/skills/skills/web-specialist
New-Item -ItemType Directory -Force -Path {WORKSPACE_DIR}/skills/skills/file-specialist
New-Item -ItemType Directory -Force -Path {WORKSPACE_DIR}/skills/skills/search-specialist
New-Item -ItemType Directory -Force -Path {WORKSPACE_DIR}/skills/skills/monitor-specialist
New-Item -ItemType Directory -Force -Path {WORKSPACE_DIR}/skills/skills/chat-specialist
```

#### 步骤 2：复制 SKILL.md

将每个人格的 `SKILL.md` 复制到对应目录：

**Linux/macOS**：
```bash
cp skills/host/SKILL.md {WORKSPACE_DIR}/skills/skills/host/
cp skills/software-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/software-specialist/
cp skills/system-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/system-specialist/
cp skills/web-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/web-specialist/
cp skills/file-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/file-specialist/
cp skills/search-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/search-specialist/
cp skills/monitor-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/monitor-specialist/
cp skills/chat-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/chat-specialist/
```

**Windows（PowerShell）**：
```powershell
Copy-Item skills/host/SKILL.md {WORKSPACE_DIR}/skills/skills/host/
Copy-Item skills/software-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/software-specialist/
Copy-Item skills/system-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/system-specialist/
Copy-Item skills/web-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/web-specialist/
Copy-Item skills/file-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/file-specialist/
Copy-Item skills/search-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/search-specialist/
Copy-Item skills/monitor-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/monitor-specialist/
Copy-Item skills/chat-specialist/SKILL.md {WORKSPACE_DIR}/skills/skills/chat-specialist/
```

#### 步骤 3：注册人格

将 `www_personas_registry.json` 复制到工作目录：

**Linux/macOS**：
```bash
cp www_personas_registry.json {WORKSPACE_DIR}/
```

**Windows（PowerShell）**：
```powershell
Copy-Item www_personas_registry.json {WORKSPACE_DIR}\
```

#### 步骤 4：重启 AI 会话

重启后，系统会自动识别并加载所有人格。

#### 步骤 5：验证安装

在 AI 会话中输入：

```
启动 www 系统
```

如果看到 HOST 的欢迎信息和系统状态，说明安装成功。

## 故障排除

### 问题 1：Skill 工具找不到人格

**现象**：
```
Skill tool error: skill "host" not found
```

**原因**：
- 技能文件放错了目录
- 技能文件名不是 `SKILL.md`
- 技能文件的 `name:` 字段不匹配

**解决方法**：
1. 检查技能文件是否在正确的目录
2. 检查技能文件名是否是 `SKILL.md`（大写）
3. 检查技能文件的 `name:` 字段是否与目录名一致

示例：
```markdown
---
name: host
description: HOST 主人格
---
```

### 问题 2：HOST 无法调度其他人格

**现象**：
HOST 回复："未找到 S1 软件专员的技能文件"

**原因**：
- S1~S6 的技能文件未正确安装
- `www_personas_registry.json` 中的路径不正确

**解决方法**：
1. 检查 S1~S6 的技能文件是否已安装
2. 检查 `www_personas_registry.json` 中的 `path` 字段是否正确

示例：
```json
{
  "id": "S1",
  "name": "software-specialist",
  "path": "{WORKSPACE_DIR}/skills/skills/software-specialist/SKILL.md"
}
```

### 问题 3：记忆库无法创建

**现象**：
HOST 回复："无法创建记忆库文件"

**原因**：
- 工作目录不可写
- 文件系统权限不足

**解决方法**：
1. 检查工作目录是否有写权限
2. 手动创建记忆库文件

示例（Linux/macOS）：
```bash
touch {WORKSPACE_DIR}/www_memory_HOST.md
chmod 644 {WORKSPACE_DIR}/www_memory_HOST.md
```

### 问题 4：评分系统不工作

**现象**：
任务完成后，S6 监察专员没有进行评分。

**原因**：
- S6 技能文件未正确安装
- HOST 的 §5.8 即时评分流程被禁用

**解决方法**：
1. 检查 S6 技能文件是否已安装
2. 检查 HOST 的 `SKILL.md` §5.8 是否启用

## 升级指南

### 从 v10.6.3 升级

1. **备份当前系统**
   ```bash
   cp -r {WORKSPACE_DIR}/skills/skills/ {WORKSPACE_DIR}/skills/skills.backup/
   cp {WORKSPACE_DIR}/www_personas_registry.json {WORKSPACE_DIR}/www_personas_registry.json.backup
   ```

2. **覆盖技能文件**
   ```bash
   cp -r www_v10.6.9_pack/skills/* {WORKSPACE_DIR}/skills/skills/
   ```

3. **更新注册表**
   ```bash
   cp www_v10.6.9_pack/www_personas_registry.json {WORKSPACE_DIR}/
   ```

4. **删除共享记忆文件**（v10.6.4 不再使用）
   ```bash
   rm {WORKSPACE_DIR}/www_shared_memory.md  # 如存在
   ```

5. **重启 AI 会话**

### 从 v10.6.1 升级

1. **备份当前系统**（同上）
2. **覆盖技能文件**（同上）
3. **更新注册表**（同上）
4. **创建个人记忆库**（从模板）
5. **重启 AI 会话**

### 从 v10.3 升级

建议全新安装，因为架构变化较大。

## 目录结构（安装后）

```
{WORKSPACE_DIR}/skills/skills/
├── host/
│   └── SKILL.md
├── software-specialist/
│   └── SKILL.md
├── system-specialist/
│   └── SKILL.md
├── web-specialist/
│   └── SKILL.md
├── file-specialist/
│   └── SKILL.md
├── search-specialist/
│   └── SKILL.md
├── monitor-specialist/
│   └── SKILL.md
├── chat-specialist/
│   └── SKILL.md
└── ...

{WORKSPACE_DIR}/
├── www_personas_registry.json
├── www_memory_HOST.md         # 自动创建
├── www_memory_S1.md          # 自动创建
├── www_memory_S2.md          # 自动创建
├── www_memory_S3.md          # 自动创建
├── www_memory_S4.md          # 自动创建
├── www_memory_S5.md          # 自动创建
├── www_memory_S6.md          # 自动创建
├── www_memory_S7.md          # 自动创建
└── www_task_log.md           # 自动创建
```

## 贡献指南

欢迎提交 Issue 和 Pull Request！

### 如何贡献

1. Fork 本仓库
2. 创建你的特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交你的更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开一个 Pull Request

### 开发规范

- **版本号**：遵循语义化版本规范（主版本.次版本.修订号）
- **技能文件**：每个 SKILL.md 必须包含 frontmatter（yaml 格式）
- **记忆库**：使用 Markdown 格式，章节标题用 `##`
- **经验条目**：格式 `EXP-{YYYYMMDD}-{NNN}`

## 许可证

MIT License

## 联系方式

如有问题或建议，请提交 Issue 或联系开发者。

---

**版本**：v10.6.9  
**发布日期**：2026-07-12  
**开发者**：Claw  
**系统**：www 多人格协作智能系统
